var fetch = global.nodemodule["node-fetch"];

var earth_get = function earth_get(type, data) {
	(async function () {
		var returntext = `Trái Đất hay Địa Cầu (地球), là hành tinh thứ ba tính từ Mặt Trời, đồng thời cũng là hành tinh lớn nhất trong các hành tinh đất đá của hệ Mặt Trời xét về bán kính, khối lượng và mật độ vật chất. Trái Đất còn được biết tên với các tên gọi "hành tinh xanh", là nhà của hàng triệu loài sinh vật, trong đó có con người và cho đến nay đây là nơi duy nhất trong vũ trụ được biết đến là có sự sống. Hành tinh này được hình thành cách đây 4,55 tỷ năm và sự sống xuất hiện trên bề mặt của nó khoảng 1 tỷ năm trước. Kể từ đó, sinh quyển, bầu khí quyển của Trái Đất và các điều kiện vô cơ khác đã thay đổi đáng kể, tạo điều kiện thuận lợi cho sự phổ biến của các vi sinh vật ưa khí cũng như sự hình thành của tầng ôzôn-lớp bảo vệ quan trọng, cùng với từ trường của Trái Đất, đã ngăn chặn các bức xạ có hại và chở che cho sự sống. Các đặc điểm vật lý của Trái Đất cũng như lịch sử địa lý hay quỹ đạo, cho phép sự sống tồn tại trong thời gian qua. Người ta ước tính rằng Trái Đất chỉ còn có thể hỗ trợ sự sống thêm 1,5 tỷ năm nữa , trước khi kích thước của Mặt Trời tăng lên và tiêu diệt hết sự sống Bề mặt Trái Đất được chia thành các mảng kiến tạo, chúng di chuyển từ từ trên bề mặt Trái Đất trong hàng triệu năm. Khoảng 71% bề mặt Trái Đất được bao phủ bởi các đại dương nước mặn, phần còn lại là các lục địa và các đảo. Nước là thành phần rất cần thiết cho sự sống và cho đến nay con người vẫn chưa phát hiện thấy sự tồn tại của nó trên bề mặt của bất kì hành tinh nào khác ngoại trừ sao Hỏa là có nước bị đóng băng ở hai cực.[note 3][note 4] Tuy nhiên, người ta có chứng cứ xác định nguồn nước có ở Sao Hỏa trong quá khứ, và có thể tồn tại cho tới ngày nay.[20] Lõi của Trái Đất vẫn hoạt động được bao bọc bởi lớp manti rắn dày, lớp lõi ngoài lỏng tạo ra từ trường và lõi sắt trong rắn. Trái Đất là hành tinh duy nhất có sự sống.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	earth_get: earth_get
}