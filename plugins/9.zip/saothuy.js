var fetch = global.nodemodule["node-fetch"];

var saothuy_get = function saothuy_get(type, data) {
	(async function () {
		var returntext = `Sao Thủy
Inferior Planet\nSao Thủy hay Thủy Tinh là hành tinh nhỏ nhất và gần Mặt Trời nhất trong tám hành tinh thuộc Hệ Mặt Trời, với chu kỳ quỹ đạo bằng 88 ngày Trái Đất. Nhìn từ Trái Đất, hành tinh hiện lên với chu kỳ giao hội trên quỹ đạo bằng xấp xỉ 116 ngày, và nhanh hơn hẳn những hành tinh khác. Tốc độ chuyển động nhanh này đã khiến người La Mã đặt tên hành tinh là Mercurius, vị thần liên lạc và đưa tin một cách nhanh chóng. Trong thần thoại Hy Lạp tên của vị thần này là Hermes (Ερμής). Tên tiếng Việt của hành tinh này dựa theo tên do Trung Quốc đặt, chọn theo hành thủy trong ngũ hành.\nBán kính:
2439.70 km\nĐịa điểm:
Inner Solar System\nBán trục lớn:
0.39 đơn vị thiên văn\nThiên thể mẹ:
Mặt Trời\nĐộ lệch tâm quỹ đạo:
0.21\nKhối lượng:
330 Yg`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	saothuy_get: saothuy_get
}