var wait = global.nodemodule["wait-for-stuff"];
var gmfunc = function(type, data){
var args = data.args;
	if(type != 'Facebook'){
		return {
			handler: 'internal',
			data: 'This command only work in Facebook platform'
		}
	}
	args.shift();
	if(!args[0]){
	return {
		handler: "internal",
		data: "Sử dụng: /gm kick <mention>|name <group name>"
	}
	}
		switch (args[0].toLowerCase()) {
		case 'kick':
	var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
	var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
	if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
	    for (var y in data.mentions) {
		    var id = y;
		    console.log(id);
	        if(id != "FB-"+data.facebookapi.getCurrentUserID()){
	            data.facebookapi.removeUserFromGroup(id.slice(3,id.length),data.msgdata.threadID);
				data.facebookapi.sendMessage({
                body: '@ Đã bị kick ra khỏi nhóm',
                mentions: [{
                     tag: '@',
                     id: (id.slice(3,id.length)),
                     fromIndex: 0, // Highlight the second occurrence of @Sender
                }],
            }, data.msgdata.threadID);
	    	                                                   }
		}
    }
	else {
		data.facebookapi.removeUserFromGroup(data.msgdata.senderID, data.msgdata.threadID);
		return {
			handler: "internal",
			data: "Bạn không có quyền để kick.",
			   }
		}
		break;
		case 'name':
		args.shift();
		var name = args.join(" ");
		data.facebookapi.setTitle(name, data.msgdata.threadID);
		var str = 'Đã thay đổi tên nhóm là '+name
				return {
			handler: "internal",
			data: str
			           }
	    break;
		case 'emoji':
		args.shift();
		var emoji = args.join(" ");
		data.facebookapi.changeThreadEmoji(emoji, data.msgdata.threadID);
		var str = 'Đã thay đổi emoji của nhóm là '+emoji
				return {
			handler: "internal",
			data: str
				}
				break;
	}
}

var nicknamefunc = function(type, datas) {

	var [err, threadInfo] = wait.for.function(datas.facebookapi.getThreadInfo, datas.msgdata.threadID);
	var fb = datas.facebookapi;
    var thread = datas.msgdata.threadID;
    var sender = datas.msgdata.senderID;
    var current = datas.facebookapi.getCurrentUserID();
	var args = datas.args;
	args.shift();
    string = args.join(' ');
    array = string.split('->');


if (array[0] === ''||array[0] === 'clear'||array[0] === 'reset'){
fb.changeNickname('',thread,sender);
	return {
		handler: 'internal',
		data: `Đã xóa biệu hiệu của bạn`
	}
}

if (array[0] === 'me'){
	if (array[1] === undefined) {
		fb.changeNickname(array[1],thread,current);
    return {
		handler: 'internal',
		data: `Đã xóa biệt hiệu của bạn`
	}
	}
	fb.changeNickname(array[1],thread,sender);
	return {
		handler: 'internal',
		data: `Đã đặt biệt hiệu cho bạn là ${array[1]}`
	}
}

if (array[0] === 'you'){
	if (array[1] === undefined) {
		fb.changeNickname(array[1],thread,current);
    return {
		handler: 'internal',
		data: `Đã xóa biệt hiệu của tui`
	}
	}
	fb.changeNickname(array[1],thread,current);
	return {
		handler: 'internal',
		data: `Đã đặt biệt hiệu cho tui là ${array[1]}`
	}
}

	    for (var y in datas.mentions) {
		    var id = y;
	        if(id != "FB-"+datas.facebookapi.getCurrentUserID()){
	            fb.changeNickname(array[1],datas.msgdata.threadID,id.slice(3,id.length));
				datas.log(id.slice(3,id.length));
			}
		    return {
			handler: 'internal',
	        data: `Đã đặt biệu hiệu cho (những) người dùng sau là là ${array[1]}`
}
  }
}
module.exports = {
	nicknamefunc,
	gmfunc
	
};