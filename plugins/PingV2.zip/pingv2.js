var deasync = global.nodemodule.deasync;

var pingtime = {};

var pingv2 = function (type, data) {
	switch (type) {
		case "Facebook":
			var SC = data.time - data.msgdata.timestamp;
			pingtime[data.msgdata.threadID] = {};
			pingtime[data.msgdata.threadID].sc = SC;
			var etime = Date.now();
			pingtime[data.msgdata.threadID].etime = etime;
			data.facebookapi.sendMessage("\u200F\u200F\u200F\u200FPINGING\u200F\u200F\u200F\u200F", data.msgdata.threadID, function (err) {
				if (err) {
					return data.return({
						handler: "internal",
						data: `Facebook => Bot: ${SC}ms\nBot => Facebook: ERR!\nRound trip: ERR!`
					});
				}
				var stime = Date.now();
				var CS = stime - etime;
				pingtime[data.msgdata.threadID].cs = CS;
			}, null, data.msgdata.isGroup);
	}
}

var chathook = function (type, data) {
	switch (type) {
		case "Facebook":
			switch (data.msgdata.type) {
				case "message":
					if (data.msgdata.body.startsWith("\u200F\u200F\u200F\u200FPINGING\u200F\u200F\u200F\u200F") && data.msgdata.senderID == data.facebookapi.getCurrentUserID()) {
						var rectime = Date.now();
						deasync.loopWhile(function () {
							return (typeof pingtime[data.msgdata.threadID].cs === "undefined");
						});
						data.return({
							handler: "internal",
							data: `Facebook => Bot: ${pingtime[data.msgdata.threadID].sc}ms\nBot => Facebook: ${pingtime[data.msgdata.threadID].cs}ms\nRound trip: ${rectime - pingtime[data.msgdata.threadID].etime}ms (expected: ${pingtime[data.msgdata.threadID].sc + pingtime[data.msgdata.threadID].cs}ms)`
						});
					}
			}
	}
}

module.exports = {
	pingv2: pingv2,
	chathook: chathook
}