var deasync = global.nodemodule.deasync;

var pingtime = {};
let xyz = "\u200F\u200B\u200F\u200BPinging...\u200F\u200B\u200F\u200B";

var ping = async function (type, data) {
	switch (type) {
		case "Facebook":
			pingtime["FB-" + data.msgdata.threadID] = {};
			var etime = Date.now();
			pingtime["FB-" + data.msgdata.threadID].etime = etime;
			data.facebookapi.sendMessage(xyz, data.msgdata.threadID, function (err) {
				if (err) {
					return data.return({
						handler: "internal",
						data: `Failed to ping.`
					});
				}
				var stime = Date.now();
				var CS = stime - etime;
				pingtime["FB-" + data.msgdata.threadID].cs = CS;
			}, null, data.msgdata.isGroup);
			break;
		case "Discord":
			pingtime["DC-" + data.msgdata.channel.id] = {};
			var etime = Date.now();
			pingtime["DC-" + data.msgdata.channel.id].etime = etime;
			try {
				await data.msgdata.channel.send(xyz);
				var stime = Date.now();
				var CS = stime - etime;
				pingtime["DC-" + data.msgdata.channel.id].cs = CS;
			} catch (_) {
				return data.return({
					handler: "internal",
					data: `Failed to ping.`
				});
			}
	}
}

var chathook = function (type, data) {
	switch (type) {
		case "Facebook":
			switch (data.msgdata.type) {
				case "message":
					if (
						data.msgdata.body === xyz && 
						data.msgdata.senderID === data.facebookapi.getCurrentUserID()
					) {
						var rectime = Date.now();
						deasync.loopWhile(function () {
							return (typeof pingtime["FB-" + data.msgdata.threadID].cs === "undefined");
						});
						data.return({
							handler: "internal",
							data: `OK! ${rectime - pingtime["FB-" + data.msgdata.threadID].etime}ms (API: ${pingtime["FB-" + data.msgdata.threadID].cs}ms)`
						});
					}
			}
			break;
		case "Discord":
			if (
				data.msgdata.content === xyz && 
				data.msgdata.author.id === data.discordapi.user.id
			) {
				var rectime = Date.now();
				deasync.loopWhile(function () {
					return (typeof pingtime["DC-" + data.msgdata.channel.id].cs === "undefined");
				});
				data.msgdata.edit(`OK! ${rectime - pingtime["DC-" + data.msgdata.channel.id].etime}ms (API: ${pingtime["DC-" + data.msgdata.channel.id].cs}ms)`);
			}
			break;
	}
}

module.exports = {
	ping: ping,
	chathook: chathook
}