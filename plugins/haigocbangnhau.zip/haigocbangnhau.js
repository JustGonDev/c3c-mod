var fetch = global.nodemodule["node-fetch"];

var haigocbangnhau = function haigocbangnhau(type, data) {
	(async function () {
		var returntext = `CHỨNG MINH 2 GÓC BẰNG NHAU:
C1: 2 góc đối đỉnh. 
C2: 2 góc đáy 1 tam giác cân
C3: 2 góc ở vị trí so le trong, đồng vị tạo bởi 2 đường thẳng //
C4: 2 góc cùng bằng hoặc cùng phụ với 1 góc thứ 3.
C5: Góc của 1 tứ giác đặc biệt ( 2 góc đối của hình bình hành,2 góc đáy hình thang cân)
C6: 2 góc nội tiếp cùng chắn 1 cung ; gnt và góc giữa ttuyến và dây cùng chắn 1 cung…
C7: 2 góc tương ứng của 2 △ đồng dạng, 2 △ bằng nhau.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"haigocbangnhau\"Diamond";

data.log(onLoadText);

}
module.exports = {
	haigocbangnhau: haigocbangnhau
}