var fetch = global.nodemodule["node-fetch"];

var doanthangbangnhau = function doanthangbangnhau(type, data) {
	(async function () {
		var returntext = `CHỨNG MINH ĐOẠN THẲNG BẰNG NHAU:
1/ Xét 2 tam giác bằng nhau.
2/ 2 cạnh bên tam giác cân.
3/ Cùng bằng 1 đoạn thứ 3...
4/ Tính 2 đoạn thẳng đó.
5/ Hai đường chéo hình thang cân, hình chữ nhật, 2 cạnh đối  hình bình hành…
6/ 2 ∆ có d.tích =nhau, 2 cạnh đáy =, thì 2 đường cao = nhau`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"doanthangbangnhau\"mod lại của by Wua'n";

data.log(onLoadText);

}
module.exports = {
	doanthangbangnhau: doanthangbangnhau
}