var fetch = global.nodemodule["node-fetch"];

var vanmau2 = function vanmau2(type, data) {
	(async function () {
		var returntext = `Ồ, Mày nhắc tới wibu ư ? Hay lắm đấy con chó, mày đã gáy đủ to để dành được sự chú ý của t rồi đấy. Mày nên mừng sau khi bỏ ra bao công sức, gáy khang cả giọng và mày đã làm được rồi! Mày đã thành công chứng minh mày chỉ là một con chó súc sinh hạ đẳng chuyên bú cu với cái mồm thối đầy bựa cặc. Kể cả vậy t vẫn cảm thấy tội ba má mày khi sinh ra mày đấy, một thằng điếm thèm cặc mê cu thích sủa, gây ô nhiễm không khí khi tiếp tục gáy và mồm phun đầy bựa cặc và tinh trùng. Địt con mẹ mày nếu mày đã đạt được điều mày muốn là thu hút sự chú ý của tao ? Thì làm ơn mày có thể bớt gáy được không ? Tao đéo ngại phải tiếp những con súc vật hạ đẳng như mày nhưng làm ơn đấy màn gáy của mày đã to đến mức làm phiền những người xung quanh đấy. Họ khác mày là những con người bình thường chứ đéo phải là một con sâu bọ như mày cứ mở mồm ra là gáy và gáy. Ôi chúa ơi, phật tổ ơi những con người đầy quyền năng và mạnh mẽ hãy giúp con trừng trị thứ loài vật khiếm khuyết này. Hãy khóa mõm con thú đáng ghê tởm mà cứ liên tục gáy trước mặt con, hãy trừ họa nó cho một thế giới tươi đẹp hơn, đẹp đẽ hơn. Địt con mẹ mày bớt gáy đi, thứ súc vật gớm ghiếc. Những gì mày gáy ra đéo đủ trình độ, đẳng cấp để tao hiểu đâu hết, thứ chó đẻ
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau2\"";

data.log(onLoadText);

}
module.exports = {
	vanmau2: vanmau2
}