var fetch = global.nodemodule["node-fetch"];

var vanmau6 = function vanmau6(type, data) {
	(async function () {
		var returntext = `Ừ Otaku tụi tao thế đấy rồi sao :))) trẻ trâu dell có quyền làm người đấy rồi sao :))) nói ra mấy cái câu chỉ trích người khác rằng họ họ là súc vật thì tụi mày cũng vậy thôi :))) không hiểu anime vì tụi mày chưa coi những bộ ý nghĩa nên tụi mày không biết lí do tụi tao thích :)) nói thiệt tuy cũng thích tự nhận là Otaku thế đấy nhưng tao dell nhận thằng này làm đồng loại nhé :)) dell phải cứ một thằng tự nhận là Otaku não bò thì cứ vơ cả những người khác cũng vậy :))) đâu phải đứa nào nghiện Anime cũng trẻ trâu họ xem đơn giản không phải để lấy cái danh đâu Anime cũng truyền tải nhiều thứ rất ý nghĩa :))) chúng mày nếu vẫn cứ ghét Otaku bọn tao thì tùy dell thích nói chuyện với lũ rảnh lz ngồi chê bai người khác :))))
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau6\"";

data.log(onLoadText);

}
module.exports = {
	vanmau6: vanmau6
}