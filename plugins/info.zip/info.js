var fetch = global.nodemodule["node-fetch"];
var streamBuffer = global.nodemodule['stream-buffers']

function sO(object) {
    return Object.keys(object).length;
}

var info = async function (type, data) {
    var args = data.args;
    var prefix = global.config.commandPrefix;
    var mentions = data.mentions;
    args.shift();
    var a = args[0]
    var adinfo = await data.facebookapi.getThreadInfo(data.msgdata.threadID);
    if (a === 'user') {
        if (sO(mentions) === 0) {
            var id = data.msgdata.senderID;
            var name = global.data.cacheName["FB-" + id];
            var money = global.data.economy["FB-" + id];
            if (money) {
                var money = money.toString().replace('n', 'Ƀ')
                var money = money.toString().slice(0, -7)
                var money = money.toString().slice(0, -1) + '.' + money.toString().slice(-1)
            } else if (money === undefined) {
                var money = 0
            }
            var link = 'facebook.com/' + id;
            var xp = global.data.eXPerience.xp[id];
            let level = 1
            while (xp >= parseInt(level * 50 + level * 5)) {
                level++;
            }
            for (let z in adinfo.userInfo) {
                if (adinfo.userInfo[z].id === id) {
                    var username = adinfo.userInfo[z].vanity
                    var tgen = adinfo.userInfo[z].gender
                    var tfr = adinfo.userInfo[z].isFriend
                    if (tfr === true) {
                        var fr = 'Đã kết bạn với facebook bot'
                    } else {
                        var fr = 'Chưa kết bạn với fb bot'
                    }
                    if (tgen === 'MALE') {
                        var gen = 'Nam'
                    } else {
                        var gen = 'Nữ'
                    }
                }
            }
            var api = 'https://api.berver.tech/avatar/id=' + id
            console.log(api)
            var apix = await fetch(api)
            var buffer = await apix.buffer()
            var imagesx = new streamBuffer.ReadableStreamBuffer({
                frequency: 10,
                chunksize: 1024,
            });
            imagesx.path = 'image.png'
            imagesx.put(buffer);
            imagesx.stop()
            return {
                handler: 'internal',
                data: {
                    body: `Tên của bạn là ${name}\nID của bạn là ${id}\nGiới tính:${gen}\nLink FB: ${link}\nTên người dùng: ${username}\n${fr}\nSố tiền: ${money}\nXP:${xp} xp (Level ${level})`,
                    attachment: ([imagesx])
                }
            }
        } else if (sO(mentions) === 1) {
            var id = Object.keys(mentions)[0].slice(3);
            var link = 'facebook.com/' + id;
            var money = global.data.economy["FB-" + id];
            if (money) {
                var money = money.toString().replace('n', 'Ƀ')
                var money = money.toString().slice(0, -7)
                var money = money.toString().slice(0, -1) + '.' + money.toString().slice(-1)
            } else if (money === undefined) {
                var money = 0
            }
            var xp = global.data.eXPerience.xp[id];
            let level = 1
            while (xp >= parseInt(level * 50 + level * 5)) {
                level++;
            }
            for (let z in adinfo.userInfo) {
                if (adinfo.userInfo[z].id === id) {
                    var name = adinfo.userInfo[z].name;
                    var username = adinfo.userInfo[z].vanity;
                    var tgen = adinfo.userInfo[z].gender
                    var tfr = adinfo.userInfo[z].isFriend
                    if (tfr === true) {
                        var fr = 'Đã kết bạn với facebook bot'
                    } else {
                        var fr = 'Chưa kết bạn với fb bot'
                    }
                    if (tgen === 'MALE') {
                        var gen = 'Nam'
                    } else {
                        var gen = 'Nữ'
                    }
                }
            }
            var link = 'facebook.com/' + id;
            var api = "https://api.berver.tech/avatar/id=" + id
            console.log(api)
            var apix = await fetch(api)
            var buffer = await apix.buffer()
            var imagesx = new streamBuffer.ReadableStreamBuffer({
                frequency: 10,
                chunksize: 1024,
            });
            imagesx.path = 'image.png'
            imagesx.put(buffer);
            imagesx.stop()
            return {
                handler: 'internal',
                data: {
                    body: `Tên: ${name}\nID: ${id}\nGiới tính: ${gen}\nLink FB: ${link}\nTên người dùng: ${username}\n${fr}\nSố tiền: ${money}\nXP: ${xp}xp (Level ${level})`,
                    attachment: ([imagesx]),
                }
            }
        } else return {
            handler: 'internal',
            data: 'Bạn chỉ có thể tag 1 người.'
        }
    } else if (a === 'thread') {
        var tid = adinfo.threadID;
        var tname = adinfo.threadName;
        var nam = [];
        var nu = [];
        for (let z in adinfo.userInfo) {
            var g = adinfo.userInfo[z].gender;
            if (g == "MALE") {
                nam.push(z);
            }
        }

        for (let z in adinfo.userInfo) {
            var gx = adinfo.userInfo[z].gender;
            if (gx == "FEMALE") {
                nu.push(z);
            }
        }
        var count = adinfo.messageCount
        var numm = nam.length
        var numf = nu.length
        var nump = adinfo.participantIDs.length
        var api = adinfo.imageSrc
        var apix = await fetch(api);
        var buffer = await apix.buffer();
        var imagesx = new streamBuffer.ReadableStreamBuffer({
            frequency: 10,
            chunksize: 1024
        });
        imagesx.path = 'image.png';
        imagesx.put(buffer);
        imagesx.stop()
        return {
            handler: 'internal',
            data: {
                body: `Tên nhóm: ${tname}\nID nhóm: ${tid}\nCó ${nump} thành viên, Số nam: ${numm}, Số nữ: ${numf}\n Tổng cộng có ${count} tin nhắn`,
                attachment: ([imagesx])
            }
        }
    } else return {
        handler: 'internal',
        data: `\`${prefix}info user [@mention]\` : xem user info của @mention, để trống nếu xem của mình\n\`${prefix}info thread\`: xem thông tin về thread`
    }
}

module.exports = {
    info: info
}