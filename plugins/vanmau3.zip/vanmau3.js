var fetch = global.nodemodule["node-fetch"];

var vanmau3 = function vanmau3(type, data) {
	(async function () {
		var returntext = `Mấy thằng ranh con trong đây đừng có nghĩ tao hay đùa trên cái mạng ảo này mà nghĩ ngoài đời tao là một thằng wibu hèn hạ đéo dám ra đường hay trầm cảm, tự kĩ nhé. Thật ra bố mày đéo phải một thằng wibu bệnh hoạn như chúng mày nghĩ đâu lũ óc cặc ạ. Tao đây là otaku đàng hoàng chân chính nhá. Kể từ khi lọt lòng tới nay tao đã cày hơn 10 triệu bộ anime và từ việc xem anime mỗi ngày tao đã thông thạo được 50 thứ tiếng trên toàn thế giới cùng với khả năng đọc vị bất kỳ ai. Chưa hết đâu. Kể từ năm 2017, khi mà xem One Punch Man tao đã giác ngộ được mọi triết lý trên đời và quyết tâm bảo vệ nền hòa bình thế giới. Vì lẽ đó nên tao đã tập tành như Saitama, mỗi ngày 1000 cái hít đất, 1000 cái gập bụng, 1000 cái bật nhảy và chạy 100km (gấp mười lần idol của tao). Và chưa đầy nửa năm tao đã luyện thành mình đồng da sắt, chỉ cần thằng nào đụng đến tao thì một cái búng tay cũng đủ để nó bay ra ngoài vũ trụ với vận tốc gấp 10 lần tốc độ ánh sáng. Nếu thằng nào trong này cả gan chửi tao thì nên biết tao là ai trước đi, đề phòng chết khi nào không hay đấy.
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau3\"";

data.log(onLoadText);

}
module.exports = {
	vanmau3: vanmau3
}