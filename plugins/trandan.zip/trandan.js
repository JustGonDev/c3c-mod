var fetch = global.nodemodule["node-fetch"];

var trandan = function trandan(type, data) {
	(async function () {
		var returntext = `Phúc cho những người không nghe thấy mà tin, vô phúc cho những người không nghe thấy mà tin
- Tiếc diên là năm 2003, tự nhiên tui cầu ở trên nhà ở Phao sần palay, tự nhiên thấy 1 hiện tượng lạ, lúc đó tui mới thấy ủa sao kì vậy, 1 cái hình tượng mà tui là đạo Phật, tui nói quý dị nghe tui là đạo Phật, tự nhiên tui thấy có trái tim màu hồng và có ánh hào quang ra sao, đó là mắt thấy tại nghe chứ không phải là tui nằm chiêm bao, tui dụi mắt thêm 1 lần nữa thì tui thấy ông Chúa Giê Su ổng nói tiếng Việt.

Cầu xin thượng đế 
Hồn thiên .. sông núi
Các bật siêu ... nhân 
AMEN

Ai mà chửi thề tôi sẽ lóc nha
Còn những người mà chửi thề
Nếu thích thì dô 
Còn không thích thì dô

Nhân danh đạo chúa Jêsu 
AMEN .. AMEN 
Tui là đạo phật mà ?`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"trandan\"mod lại của by Wua'n";

data.log(onLoadText);

}
module.exports = {
	trandan: trandan
}