var fetch = global.nodemodule["node-fetch"];

var BachDuong_get = function BachDuong_get(type, data) {
	(async function () {
		var returntext = `Bạch Dương hay Dương cưu - Aries (21/3 - 19/4), là cung đầu tiên của vòng Hoàng đạo. Biểu tượng cho cung này là con cừu đực có bộ lông vàng. Bạch Dương thuộc nguyên tố Lửa và là một trong bốn cung Thống lĩnh. Sao chiếu mệnh là Hỏa Tinh và Diêm Vương Tinh; chịu sự ảnh hưởng mạnh mẽ từ Mặt Trời.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	BachDuong_get: BachDuong_get
}