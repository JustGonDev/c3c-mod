var fetch = global.nodemodule["node-fetch"];

var hemattroi_get = function hemattroi_get(type, data) {
	(async function () {
		var returntext = `Hệ mặt trời\nHệ hành tinh\nHệ Mặt Trời là 1 hệ hành tinh có Mặt Trời ở trung tâm và các thiên thể nằm trong phạm vi lực hấp dẫn của Mặt Trời, tất cả chúng được hình thành từ sự suy sụp của 1 đám mây phân tử khổng lồ cách đây gần 4,6 tỷ năm. Đa phần các thiên thể quay quanh Mặt Trời, và khối lượng tập trung chủ yếu vào 8 hành tinh có quỹ đạo gần tròn và mặt phẳng quỹ đạo gần trùng khít với nhau gọi là mặt phẳng hoàng đạo. 4 hành tinh nhỏ vòng trong gồm: Sao Thủy, Sao Kim, Trái Đất và Sao Hỏa - người ta cũng còn gọi chúng là các hành tinh đá do chúng có thành phần chủ yếu từ đá và kim loại. 4 hành tinh khí khổng lồ vòng ngoài có khối lượng lớn hơn rất nhiều so với 4 hành tinh vòng trong. 2 hành tinh lớn nhất, Sao Mộc và Sao Thổ có thành phần chủ yếu từ heli và hiđrô; và 2 hành tinh nằm ngoài cùng, Sao Thiên Vương và Sao Hải Vương có thành phần chính từ băng, như nước, amoniac và mêtan, và đôi khi người ta lại phân loại chúng thành các hành tinh băng khổng lồ. Có 6 hành tinh và 3 hành tinh lùn có các vệ tinh tự nhiên quay quanh. Các vệ tinh này được gọi là "Mặt Trăng" theo tên gọi của Mặt Trăng của Trái Đất. Mỗi hành tinh vòng ngoài còn có các vành đai hành tinh chứa bụi, hạt và vật thể nhỏ quay xung quanh.\nĐường kính:
0 ly\nĐịa điểm:
inner and outer Solar System\nThiên thể mẹ:
Sagittarius A*\nKhối lượng:
1 Khối lượng Mặt Trời\nLà một phần của:
Đám mây liên sao địa phương`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	hemattroi_get: hemattroi_get
}