var color = {
	"DefaultBlue" : "196241301102133",
	"HotPink" : "169463077092846",
	"AquaBlue" : "2442142322678320",
	"BrightPurple" : "234137870477637",
	"CoralPink" : "980963458735625",
	"Orange" : "175615189761153",
	"Green" : "2136751179887052",
	"LavenderPurple" : "2058653964378557",
	"Red" : "2129984390566328",
	"Yellow" : "174636906462322",
	"TealBlue" : "1928399724138152",
	"Aqua" : "417639218648241",
	"Mango" : "930060997172551",
	"Berry" : "164535220883264",
	"Citrus" : "370940413392601",
	"Candy" : "205488546921017"
}
var alpha = 1000;
var random = function(min, max) { 
	return global.plugins.librandom.getRandomNumber(min, max, 0);
}

var rainbow = function(type, data){
	var name = Object.keys(color);
	var list = [];
	for(i = 0; i < name.length; i++){
		if(list.length == 0){
			list.push(random(0, name.length-1));
		}
		else {
			var temp1 = random(0, name.length-1);
			while (list.indexOf(temp1) != -1) {
				temp1 = random(0, name.length-1);
			}
			list.push(temp1);
		}
	}
	var count = 0;
	var interval = setInterval(function () {
		data.facebookapi.changeThreadColor(color[name[list[count]]], data.msgdata.threadID);
		count += 1;
		if(count == 15){
			clearInterval(interval);
		}
	}, alpha);
}

module.exports = {
	rainbow
}