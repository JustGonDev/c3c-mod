var fetch = global.nodemodule["node-fetch"];

function onLoad(data) {

var onLoadText = "Đang tải kit thiên văn học by DauPhuAB";
onLoadText += "\n\n";
onLoadText += "================================================================================\n";
onLoadText += "=                     ----------------------------------                       =\n";
onLoadText += "=                              Kit Thiên Văn Học                               =\n";
onLoadText += "=                     ==================================                       =\n";
onLoadText += "=                           *Facebook : Đậu Phụ Nè                             =\n";
onLoadText += "=                          *Plugin run by DauPhuAB*                            =\n";
onLoadText += "=                       Loader Kit Thiên Văn Học V2.0                          =\n";
onLoadText += "=                            Plugin For C3C Bot                                =\n";
onLoadText += "=                       Thank for the used and download                        =\n";
onLoadText += "=                     ==================================                       =\n";
onLoadText += "================================================================================\n";
onLoadText += "#############################################\n";
onLoadText += "Phiên bản hiện tại đang là mới nhất\n";
onLoadText += "#############################################\n";
onLoadText += "Đã tải xong plugins kit thiên văn học ^^\n";
onLoadText += "Đang sẵn sàng cho lần chạy này ..... \n"

data.log(onLoadText);
data.log(data);

}

var saotroi_get = function saotroi_get(type, data) {
	(async function () {
		var returntext = `Sao chổi là một thiên thể gần giống một tiểu hành tinh nhưng không cấu tạo nhiều từ đất đá, mà chủ yếu là băng. Nó được miêu tả bởi một số chuyên gia bằng cụm từ "quả bóng tuyết bẩn" vì nó chứa cácbonníc, mêtan và nước đóng băng lẫn với bụi và các khoáng chất. `;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	saotroi_get: saotroi_get,
	onLoad
}