var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var path = global.nodemodule["path"];

var meme = async function(type, data) {

    var fetchdata = await fetch(`http://meme-api.herokuapp.com/gimme`)
    var json = await fetchdata.json();
        var fetchimage = await fetch(json.url);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();

            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }

        module.exports = {
            meme: meme
        };