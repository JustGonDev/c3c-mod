var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var path = global.nodemodule["path"];
//https://graph.facebook.com/100024345931050/picture?height=720&width=720
// name = global.data.cacheName["FB-" + id]
var phcomment = async function(type, data) {
	var text = encodeURIComponent(data.args.slice(1).join(" "));
	var sender = data.msgdata.senderID;
	if(text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "phcmt <text> [pOrNhub Comment]"
		}
	} else {
		try {
			var img = "https://graph.facebook.com/" + sender + "/picture?height=360&width=360&access_token=170440784240186|bc82258eaaf93ee5b9f577a8d401bfc9&raw=1"
			var name = encodeURIComponent(global.data.cacheName["FB-" + sender]);
			data.log(name)
			data.log(sender)
			data.log(text)
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=phcomment&image=${img}&text=${text}&username=${name}&raw=1`);
			var buffer = await fetchdata.buffer();
				var phcmt = new streamBuffers.ReadableStreamBuffer({
					frequency: 1,
					chunkSize: 8192
				});
				phcmt.path = 'image.png';
				phcmt.put(buffer);
				phcmt.stop();

				 return {
			 		handler: "internal",
			 		data: {
			 			attachment: ([phcmt])
			 		},
			 		noDelay: true
			 	}
		} catch(ex) {data.log(ex)}
	}
}
var tweet = async function(type, data) {
	var text = encodeURIComponent(data.args.slice(1).join(" "));
	var sender = data.msgdata.senderID;
	if(text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "tweet <text> [Tweet Comment]"
		}
	} else {
		try {
			var name = encodeURIComponent(global.data.cacheName["FB-" + sender]);
			data.log(name)
			data.log(sender)
			data.log(text)
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=tweet&username=${name}&text=${text}&raw=1`);
			var buffer = await fetchdata.buffer();
				var phcmt = new streamBuffers.ReadableStreamBuffer({
					frequency: 1,
					chunkSize: 8192
				});
				phcmt.path = 'image.png';
				phcmt.put(buffer);
				phcmt.stop();

				 return {
			 		handler: "internal",
			 		data: {
			 			attachment: ([phcmt])
			 		},
			 		noDelay: true
			 	}
		} catch(ex) {data.log(ex)}
	}
}
var trumptweet = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	if (text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "trumptweet <text> [Đỗ Nam Trung tweet]"
		}	
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=trumptweet&text=${text}`)
			var json = await fetchdata.json();
			if (json.success == true) {
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 1,
						chunkSize: 8192
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

					return {
						handler: "internal",
						data: {
							attachment: ([imagesx])
						}
					}
			} else {
				return {
					handler: "internal",
					data: "Status code: "+ json.status
				}
			}
		} catch (ex) {data.log(ex)}
	}
}

var changemymind = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	if (text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "changemymind <text>"
		}	
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=changemymind&text=${text}`)
			var json = await fetchdata.json();
			if (json.success == true) {
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 1,
						chunkSize: 8192
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

					return {
						handler: "internal",
						data: {
							attachment: ([imagesx])
						}
					}
			} else {
				return {
					handler: "internal",
					data: "Status code: "+ json.status
				}
			}
		} catch (ex) {data.log(ex)}
	}
}

var punch2 = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	if (text === "@Nguyễn Minh Hiếu") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "punch2 <mentions> [đấm thằng khác đi :)]"
		}	
	} else {
		try {
            var sender = data.msgdata.senderID;
            var mentions = data.mentions;
			var fetchjson = await fetch(`https://neko-love.xyz/api/v1/punch`)
			var json = await fetchjson.json();
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 1,
						chunkSize: 8192
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

                    var name = global.data.cacheName["FB-" + Object.keys(mentions)[0].slice(3)]
					return {
						handler: "internal",
						data: {
                            body: `@${name}, Đã bị đấm 😈`,
                                mentions: [{
                                    tag: `@${name}`,
                                    id: Object.keys(mentions)[0].slice(3),
                                    fromIndex: 9
                                }],
							attachment: ([imagesx])
						}
					}
		} catch (ex) {data.log(ex)}
	}
}

var ball = async function(type, data) {
    var fetchjson = await fetch(`https://nekos.life/api/v2/8ball`)
    var json = await fetchjson.json();
        var fetchimage = await fetch(json.message);
        var buffer = await fetchimage.buffer();
            var imagesx = new streamBuffers.ReadableStreamBuffer({
                frequency: 1,
                chunkSize: 8192
            });
            imagesx.path = 'image.png';
            imagesx.put(buffer);
            imagesx.stop();

            var name = global.data.cacheName["FB-" + Object.keys(mentions)[0].slice(3)]
            return {
                handler: "internal",
                data: {
                    attachment: ([imagesx])
                }
            }
        }

var clyde = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	if (text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "clyde <text>"
		}	
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=clyde&text=${text}`)
			var json = await fetchdata.json();
			if (json.success == true) {
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 1,
						chunkSize: 8192
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

					return {
						handler: "internal",
						data: {
							attachment: ([imagesx])
						}
					}
			} else {
				return {
					handler: "internal",
					data: "Status code: "+ json.status
				}
			}
		} catch (ex) {data.log(ex)}
	}
}
var kannagen = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	if (text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "kannagen <text>"
		}	
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=kannagen&text=${text}`)
			var json = await fetchdata.json();
			if (json.success == true) {
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 1,
						chunkSize: 8192
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

					return {
						handler: "internal",
						data: {
							attachment: ([imagesx])
						}
					}
			} else {
				return {
					handler: "internal",
					data: "Status code: "+ json.status
				}
			}
		} catch (ex) {data.log(ex)}
	}
}
var natsuki = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	var background = ["bedroom","class","closet","club","corridor","house","kitchen","residential","sayori_bedroom"];
	var body = ["1b","1","2b","2"];
	var face = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1t","2bt","2bta","2btb","2btc","2btd","2bte","2btf","2btg","2bth","2bti","2t","2ta","2tb","2tc","2td","2te","2tf","2tg","2th","2ti"];
	if (text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "natsuki <text> [Note: Giới hạn 140 từ]"
		}	
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=ddlc&character=natsuki&background=${background[Math.floor(Math.random() * background.length)]}&body=${body[Math.floor(Math.random() * body.length)]}&face=${face[Math.floor(Math.random() * face.length)]}&text=${text}`)
			var json = await fetchdata.json();
			if (json.success == true) {
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 1,
						chunkSize: 8192
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

					return {
						handler: "internal",
						data: {
							attachment: ([imagesx])
						}
					}
			} else {
				return {
					handler: "internal",
					data: "Status code: "+ json.status
				}
			}
		} catch (ex) {data.log(ex)}
	}
}
var yuri = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	var background = ["bedroom","class","closet","club","corridor","house","kitchen","residential","sayori_bedroom"];
	var body = ["1b","1","2b","2"];
	var face = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y1","y2","y3","y4","y5","y6","y7"];
	if (text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "yuri <text> [Note: Giới hạn 140 từ]"
		}	
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=ddlc&character=yuri&background=${background[Math.floor(Math.random() * background.length)]}&body=${body[Math.floor(Math.random() * body.length)]}&face=${face[Math.floor(Math.random() * face.length)]}&text=${text}`)
			var json = await fetchdata.json();
			if (json.success == true) {
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 1,
						chunkSize: 8192
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

					return {
						handler: "internal",
						data: {
							attachment: ([imagesx])
						}
					}
			} else {
				return {
					handler: "internal",
					data: "Status code: "+ json.status
				}
			}
		} catch (ex) {data.log(ex)}
	}
}
var sayori = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	var background = ["bedroom","class","closet","club","corridor","house","kitchen","residential","sayori_bedroom"];
	var body = ["1b","1","2b","2"];
	var face = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y"];
	if (text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "sayori <text> [Note: Giới hạn 140 từ]"
		}	
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=ddlc&character=sayori&background=${background[Math.floor(Math.random() * background.length)]}&body=${body[Math.floor(Math.random() * body.length)]}&face=${face[Math.floor(Math.random() * face.length)]}&text=${text}`)
			var json = await fetchdata.json();
			if (json.success == true) {
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 1,
						chunkSize: 8192
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

					return {
						handler: "internal",
						data: {
							attachment: ([imagesx])
						}
					}
			} else {
				return {
					handler: "internal",
					data: "Status code: "+ json.status
				}
			}
		} catch (ex) {data.log(ex)}
	}
}
var monika = async function(type, data) {
	var text =  encodeURIComponent(data.args.slice(1).join(" "));
	var background = ["bedroom","class","closet","club","corridor","house","kitchen","residential","sayori_bedroom"];
	var body = ["1","2"];
	var face = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r"];
	if (text === "") {
		return {
			handler: "internal",
			data: global.config.commandPrefix + "monika <text> [Note: Giới hạn 140 từ]"
		}	
	} else {
		try {
			var fetchdata = await fetch(`https://nekobot.xyz/api/imagegen?type=ddlc&character=monika&background=${background[Math.floor(Math.random() * background.length)]}&body=${body[Math.floor(Math.random() * body.length)]}&face=${face[Math.floor(Math.random() * face.length)]}&text=${text}`)
			var json = await fetchdata.json();
			if (json.success == true) {
				var fetchimage = await fetch(json.message);
				var buffer = await fetchimage.buffer();
					var imagesx = new streamBuffers.ReadableStreamBuffer({
						frequency: 1,
						chunkSize: 8192
					});
					imagesx.path = 'image.png';
					imagesx.put(buffer);
					imagesx.stop();

					return {
						handler: "internal",
						data: {
							attachment: ([imagesx])
						}
					}
			} else {
				return {
					handler: "internal",
					data: "Status code: "+ json.status
				}
			}
		} catch (ex) {data.log(ex)}
	}
}
module.exports = {
	phcomment: phcomment,
	trumptweet: trumptweet,
	tweet: tweet,
	changemymind: changemymind,
	clyde: clyde,
	punch2: punch2,
	ball: ball,
	kannagen: kannagen,
	natsuki: natsuki,
	yuri: yuri,
	sayori: sayori,
	monika: monika
}