var fetch = global.nodemodule["node-fetch"];

var uid = function uid(type, data) {
	(async function () {
		var returntext = ` 
Tên của bạn là ${global.data.cacheName["FB-" + data.msgdata.senderID]}
UID của Bạn Là ${data.msgdata.senderID}
ID Thread là ${data.msgdata.threadID}`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"UID\" by Ber";

data.log(onLoadText);

}
module.exports = {
	uid: uid
}