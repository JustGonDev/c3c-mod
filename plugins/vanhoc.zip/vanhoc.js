var fetch = global.nodemodule["node-fetch"];

var van_get = function van_get(type, data) {
	(async function () {
		var returntext = `Cách làm một bài kiểm tra không bị tạch văn\n1. Thuộc cá phương thức biểu đặt < nó rất có ích vì mỗi đề bài cô cho sẽ có một câu xác định phương thức biểu đặt nếu bạn không biết bạn chỉ cần ghi hết vào kiểu gì cũng 0,25 điểm >\n2. Tim điểm dễ nghi ngờ\n< Việc này rất dễ bạn chỉ cần đọc kĩ văn bản và nhớ cho mình câu hỏi của nó bạn hãy iết ra một tờ nháp và bác bỏ những ý kiến trái ngược với câu hỏi >\n3. viết văn\nBạn hãy viết văn theo bố cục\nGiải Phân Bác Đánh\nCó nghĩa là giải thích - Phân tích - bác bỏ - đánh giá\nTrong trường hợp đề miêu tả bạn có thể thêm yếu tố Phản vào trong văn của mình\nPhản có nghĩa phản đề\nnhawmj nêu ra những ý chính sai lệnh của hiện thực và tưởng tượng\nCứ làm theo mình đi\nChắc chắn auto qua môn <3`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	van_get: van_get
}