var axios = global.nodemodule["axios"];

function onLoad(data){
	var onLoadText = `\n\n`;
	onLoadText += ` API Simsimi by Cunnobi( Phạm Đức Phi)\n`;
	onLoadText += ` Plugin cre by Citnut( Nguyễn Thanh Chính)\n`;
	data.log(onLoadText);
	data.log(data);
};

	/////////////////////////////////////////
	/////////////////SIMSIMI/////////////////
	/////////////////////////////////////////
var sim = function(type, data){
	var word = data.args.slice(1).join(" ");
	axios({
		url: `https://api.sfsu.xyz/?text=${encodeURI(word)}&format=json&key=82da5c6c56eff4d7d60a21e5d63dc933`,
		method: "GET",
		mode: "no-cors"
	}).then(res => {
		var msg = /"text":"(.*?)"}/.exec(res.data)[1];
		if (msg)
			data.return ({
			handler: "internal",
			data: msg
		})
	});
};
	/////////////////////////////////////////
	///////////////////END///////////////////
	/////////////////////////////////////////
module.exports = {
	sim,
	onLoad
}