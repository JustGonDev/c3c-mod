var fetch = global.nodemodule["node-fetch"];

var tangai = function tangai(type, data) {
	(async function () {
		var returntext = `Chị đẹp lắm
Em đã muốn pen houses trên đà lạt với chị , yêu ngay cái nhìn đầu tiên, sự ngây thơ, hồn nhiên với trái tim ấm nồng của em đã chinh phục anh. Cảm ơn cha mẹ đã sinh anh ra ở kiếp này để được gặp và yêu em như hôm nay. Tình yêu em dành cho chị ngày càng nhiều hơn. Lúc này đây em mới cảm nhận rõ về tình yêu ấy. Chị biết không? Chị chính là nàng thơ tuyệt đẹp của trần thế này với vẻ đẹp lung linh nghiêng nước nghiêng thành khiến bao người phải chìm đắm trong sắc đẹp của em. Chị như là một bông hoa đẹp nhất trong cả vườn hoa vậy, em chính là một hình mẫu lí tưởng của sắc đẹp. Em rất là may mắn khi có thể chiêm ngưỡng được vẻ đẹp như thế. Giống như là một phước lành mà Chúa đã trao tặng cho chị vậy. Ôi chị thật là đẹp quá, cảm vào giây phút này để em được ngắm chị nhiều
Có lẽ suốt đời này em chẳng thể nào quên được chị ôi bông hoa chẳng thuộc về emm❤`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"tangai\"Minh Mẫn mod lại của by Wua'n";

data.log(onLoadText);

}
module.exports = {
	tangai: tangai
}