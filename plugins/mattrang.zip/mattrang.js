var fetch = global.nodemodule["node-fetch"];

var moon_get = function moon_get(type, data) {
	(async function () {
		var returntext = `Mặt Trăng
Vệ Tinh Tự Nhiên
\nMặt Trăng là vệ tinh tự nhiên duy nhất của Trái Đất và là vệ tinh tự nhiên lớn thứ năm trong Hệ Mặt Trời.\nKhối lượng:
73.48 Yg\nBán kính:
1738.14 km\nLà một phần của:
Earth-Moon system\nĐược đặt tên theo:
ánh sáng\nBán trục lớn:
1738.14 km\nThiên thể mẹ:
Trái Đất`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	moon_get: moon_get
}