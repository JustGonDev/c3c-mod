var fetch = global.nodemodule["node-fetch"];

var saobang_get = function saobang_get(type, data) {
	(async function () {
		var returntext = `Sao băng, hay sao sa, là đường nhìn thấy của các thiên thạch và vẫn thạch khi chúng đi vào khí quyển Trái Đất. Trên Trái Đất, việc nhìn thấy đường chuyển động của các thiên thạch này là do nhiệt phát sinh ra bởi áp suất nén khi chúng đi vào khí quyển. `;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	saobang_get: saobang_get
}