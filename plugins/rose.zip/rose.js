var fetch = global.nodemodule["node-fetch"];

var rose = function rose(type, data) {
	(async function () {
		var returntext = `ở cái xã hội này 
làm liều thì ăn nhiều , không liều thì ăn ít : )
Sau lày chỉ có nàm , chịu khó 
Cần cù thì bù siêng năng 
Chỉ có làm , thì mới có ăn 
Những cái loại người ăn không làm 
Mà đòi có ăn thì ăn dbuoi , ăn cứt`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	rose: rose
}