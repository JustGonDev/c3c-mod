!global.data.deathtag ? global.data.deathtag = {} : "";
var wait = global.nodemodule["wait-for-stuff"];
var timer;
var counter;
var status = false;

var speak=["dậy nào @","mày đâu xuất hiện đi @","có ng cần mik gọi bạn dây, éo phải mik nên đừng chửi mik nhé @"]; //đây sẽ chứa các câu nói để deathtag, yêu cầu phải có @ để deathtag, nếu ko, câu nói sẽ ko đc áp dụng, hãy nói từ 3 câu trở lên để facebook ko coi bot là spam ví dụ ["địt mẹ mày dậy cho bố nha thg loz @","tao đợi mày lâu lắm rồi đấy @","dậy hoặc ăn kick @"];
var time=10; //đây là thời gian khoảng cách giữa các lần tag
var max = 5; //để tránh zucc bot hoặc spam quá nhiều, cái biến này sẽ cho số lần tag tối đa, mặc định là 30 tin, bạn có thể tùy chỉnh thoải mái con số này
var mentions = null;
var thread = null;
var starter;

var random = function(min, max) { 
	return global.plugins.librandom.getRandomNumber(min, max, 0);
}

var toggle = function(type, data){
	var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
	var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
	if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
	    var setupstatus = setup(data);
	    if(setupstatus.allow){
	        if(global.data.deathtag[data.msgdata.threadID].toggle == false){
			    global.data.deathtag[data.msgdata.threadID].toggle = true;
			    return{
				    handler: 'internal',
			    	data: 'turned on deathtag atibility'
			    }
		    }
		    else{
			    global.data.deathtag[data.msgdata.threadID].toggle = false;
		      	return{
		    		handler: 'internal',
		    		data: 'turned off deathtag atibility'
		    	}
	     	}
	    }
	    else{
	      	return{
		     	handler: 'internal',
		     	data: `error: ${setupstatus.reason}`
	     	}
		}
	}
	else{
		return{
			handler: 'internal',
			data: `admin only!`
		}
	}
	
}

var setup = function(data){
	!global.data.deathtag[data.msgdata.threadID] ? global.data.deathtag[data.msgdata.threadID] = {} : "";
	if(data.msgdata.isGroup){
		if(global.data.deathtag[data.msgdata.threadID].toggle == undefined){
    		!global.data.deathtag[data.msgdata.threadID].toggle ? global.data.deathtag[data.msgdata.threadID].toggle = false : "";
		}
		return{
		    allow: true,
			reason: ''
		}
	}
	else{
	    return{
			allow: false,
			reason: 'This command only works in group chat!'
		}
	}
}

var start = function(type, data){
	var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
	var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
	if (adminIDs.indexOf(data.msgdata.senderID) != -1) {
		if(mentions != null ){
			return{
				handler: 'internal',
				data: `nhóm khác đang dùng, chút bạn may mắn lần sau!`
			}
		}
	    !global.data.deathtag ? global.data.deathtag = {} : "";
	    !global.data.deathtag[data.msgdata.threadID] ? global.data.deathtag[data.msgdata.threadID] = {} : "";
	    var IDs = [];
    	var setupstatus = setup(data);
	    if(setupstatus.allow){
		    if(!global.data.deathtag[data.msgdata.threadID].toggle){
			    return{
				    handler: 'internal',
    				data: `chức năng này hiện đang tắt, để bật hãy dùng lệnh ${global.config.commandPrefix}toggledeathtag`
	    		}
			}
    	    if(mentions == null && thread == null){
	    		for (var y in data.mentions) {
		    		IDs.push(y);
			    }
   	     		if(IDs.length >1 || IDs.length <1){
    	 			return{
	    				handler: 'internal',
		    			data: `chỉ tag 1 người và phải tag 1 người!`
			    	}
    			}
				mentions = IDs[0];
				if(mentions == "FB-"+data.facebookapi.getCurrentUserID()){
					return{
	    				handler: 'internal',
		    			data: `đừng deathtag bot nhé :)`
			    	}
				}
				thread = data.msgdata.threadID;
				starter = data.msgdata.senderID;
	            return{
	    	        handler: 'internal',
	                data: `đã kích hoạt deathtag vs thời gian giữa lần tag là ${time}s và số lần tag tối đa là ${max}\r\nđể tắt deathtag, 1 là người dùng deathtag hoặc admin box dùng lệnh ${global.config.commandPrefix}stop, 2 là người bị deathtag phải lên tiếng!`
		        }
	        }
	        else if(thread == data.msgdata.threadID){
    	        return{
	     	        handler: 'internal',
		            data: `nhóm bạn đang dùng deathtag, vui lòng ko spam`
		        }
			}
	    }
	    else{
		    return{
			    handler: 'internal',
			    data: `error: ${setupstatus.reason}`
		    }
		}
	}
	else{
		return{
			handler: 'internal',
			data: `admin only!`
		}
	}
}

var chathook = function(type, data){
	if(mentions != null && thread != null && status == false){
		counter = max;
		timer = setInterval(() => {
			counter = counter-1;
			data.facebookapi.sendMessage({
				body: speak[random(0,speak.length-1)],
				mentions: [{
					tag: '@',
					id: mentions.slice(3,mentions.length)
				}],
			}, thread);
		}, (time*1000));
		status = true;
		return true;
	}
	if(mentions != null && thread != null && status == true){
		var [err, threadInfo] = wait.for.function(data.facebookapi.getThreadInfo, data.msgdata.threadID);
		var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
		var test = false;
		var test2 = false;
		if(data.msgdata.body == `${global.config.commandPrefix}stop` && data.msgdata.senderID == starter){
			test = true;
		}
		if(adminIDs.indexOf(data.msgdata.senderID) != -1 && data.msgdata.body == `${global.config.commandPrefix}stop`){
			test2 = true;
		}
		if(data.msgdata.senderID == mentions.slice(3,mentions.length) || test || counter == 0 || test2){
			clearInterval(timer);
			mentions = null;
			thread = null;
			status = false;
			data.return ({
				handler: "internal",
				data: "đã ngưng deathtag"
			});
			return true;
		}
	}
}
module.exports = {
	start,
	toggle,
	chathook
}