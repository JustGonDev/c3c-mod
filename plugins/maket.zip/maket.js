var fetch = global.nodemodule["node-fetch"];

var MaKet_get = function MaKet_get(type, data) {
	(async function () {
        var returntext = `Ma Kết là cung chiêm tinh thứ mười trong Hoàng Đạo, bắt nguồn từ chòm sao Ma Kết. Trong chiêm tinh học, Ma Kết được coi là cung đất, cung hướng nội, và là một trong 4 cung chính. Ma Kết được trị vì bởi Sao Thổ. Những người được sinh ra khi Mặt Trời ở cung này được gọi là Capricornian. Thông thường, Mặt Trời đi qua vùng hoàng đạo này giữa ngày 22 tháng 12 đến ngày 19 tháng 1 hàng năm.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	MaKet_get: MaKet_get
}