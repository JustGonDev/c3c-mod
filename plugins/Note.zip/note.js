(typeof global.data.Note != "object" || Array.isArray(global.data.Note)) ? global.data.Note = {} : "";

var noteFunc = function news(type, data) {
	(async function () {
	var args = data.args;
	args.shift();
	if(!args[0]) return;
		switch (args[0].toLowerCase()) {
			case 'add':
			case 'a':
				if (!data.admin) {
					return {
						handler: `internal`,
						data: `Only admin can run this command`
					}
				} else {
				args.shift();
				if (args.length > 2) {
					if (!isNaN(args[0])) {
				(typeof global.data.Note[args[0]] != "object" || Array.isArray(global.data.Note[args[0]])) ?
				global.data.Note[args[0]] = {} : {};
				global.data.Note[args[0]] = {
					 "noteTitle": args[1], 
					 "noteMessage": args[2]
				};
				return {
					handler: `internal`,
					data: `Done\r\nID: ${args[0]}, TITLE: ${args[1]}`
				}
					} else {
				return {
						handler: `internal`,
						data: `ID must be a number`
					}
				}
		} else {
			return {
				handler: `internal`,
				data: `Invaild args`
			}
		}
	}
				break;
			case 'del':
			case 'rem':
			case 'remove':
			case 'delete':
			case 'd':
			case 'r':
				if (!data.admin) {
					return {
						handler: `internal`,
						data: `Only admin can run this command`
					}
				} else {
			args.shift();
			if(!isNaN(args[0])) {
				if (data.args.length > 0) {
					var ask = args.join(" ");
					var d = delete global.data.Note[ask];
						return {
							handler: "internal",
							data: d ? `Deleted: ${ask}.` : `Error: No NOTE response data found.`
					}
			} else {
			return {
				handler: "internal",
				data: "Error: Missing arguments."
		}
	}	
} else {
	return {
		handler: `internal`,
		data: `ID must be a number`
	}
}
				}
				break;
			case 'list':
			case 'all':
			case 'a':
			case 'l':
	var res = `NOTE LIST (${Object.keys(global.data.Note).length} total): `;
	for (var n in global.data.Note) {
		res += `\r\nID: ${n} | TITLE: ${global.data.Note[n].noteTitle}`;
	}
	data.facebookapi.sendMessage(res, data.msgdata.threadID, data.msgdata.messageID);
			break;
			case 'view':
			case 'v':
			case 'get':
			case 'g':
		   args.shift();
		   var idNote = args.join(" ");
		   if (!isNaN(idNote)) {
		   var noteGet = global.data.Note[idNote];
		   if (noteGet == undefined) { return {handler: `internal`, data: `404 Not found`} } else {
		   var str = `[NOTE]\r\n ID: ${idNote} | TITLE: ${noteGet.noteTitle}:\r\n ${noteGet.noteMessage}`
		   data.facebookapi.sendMessage(str, data.msgdata.threadID, data.msgdata.messageID);
		   }
		   } else {
			   return {
				   handler: `internal`,
				   data: `ID must be a number` 
			   }
		   }
			break;
			
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
}

module.exports = {
	note: noteFunc
}