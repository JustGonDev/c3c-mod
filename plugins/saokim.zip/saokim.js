var fetch = global.nodemodule["node-fetch"];

var saokim_get = function saokim_get(type, data) {
	(async function () {
		var returntext = `Sao Kim
Inner Planet\nSao Kim hay Kim tinh, còn gọi là sao Thái Bạch (太白), Thái Bạch Kim tinh (太白金星), là hành tinh thứ hai trong hệ Mặt Trời, tự quay quanh nó với chu kỳ 224,7 ngày Trái Đất. Xếp sau Mặt Trăng, nó là thiên thể tự nhiên sáng nhất trong bầu trời tối, với cấp sao biểu kiến bằng −4.6, đủ sáng để tạo nên bóng trên mặt nước. Bởi vì Sao Kim là hành tinh phía trong tính từ Trái Đất, nó không bao giờ xuất hiện trên bầu trời mà quá xa Mặt Trời: góc ly giác đạt cực đại bằng 47,8°. Sao Kim đạt độ sáng lớn nhất ngay sát thời điểm hoàng hôn hoặc bình minh, do vậy mà dân gian còn gọi là sao Hôm, khi hành tinh này mọc lên lúc hoàng hôn, và sao Mai, khi hành tinh này mọc lên lúc bình minh.\nBán kính:
6051.80 km\nHình cầu dẹt:
0\nAcgumen của cận điểm:
131.60 độ\nLà một phần của:
Inner Solar System\nĐịa điểm:
Inner Solar System\nThiên thể mẹ:
Mặt Trời`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	saokim_get: saokim_get
}