var fetch = global.nodemodule["node-fetch"];

var SuTu_get = function SuTu_get(type, data) {
	(async function () {
        var returntext = `Sư Tử, hay còn gọi là Hải Sư, là cung thứ 5 trong 12 cung hoàng đạo của chiêm tinh Tây phương. Nó không giống với chòm sao thiên văn cũng như cung chiêm tinh theo chiêm tinh thiên văn của người Hindu. Khắc tinh với cung Bảo Bình.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	SuTu_get: SuTu_get
}