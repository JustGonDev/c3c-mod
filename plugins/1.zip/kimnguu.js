var fetch = global.nodemodule["node-fetch"];

var KimNguu_get = function KimNguu_get(type, data) {
	(async function () {
		var returntext = `Kim Ngưu là cung chiêm tinh thứ hai trong Hoàng Đạo, mà kéo dài Hoàng Đạo giữa độ thứ 30 và 59 của kinh độ thiên thể. Thông thường, Mặt Trời đi qua vùng hoàng đạo này giữa ngày 21 tháng 4 đến ngày 20 tháng 5 hàng năm. Nó là một trong 4 cung Cố định và là một trong 3 cung thuộc nguyên tố Đất. Những người sinh ra trong những ngày này, khi Mặt Trời đang ở trong cung này, được gọi là Taureans. Cung Kim Ngưu được Sao Kim chiếu mệnh.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	KimNguu_get: KimNguu_get
}