var fetch = global.nodemodule["node-fetch"];

var saohoa_get = function saohoa_get(type, data) {
	(async function () {
		var returntext = `Sao Hỏa
Inner Planet\nSao Hỏa hay Hỏa tinh là hành tinh thứ tư tính từ Mặt Trời trong Thái Dương Hệ. Nó thường được gọi với tên khác là "Hành tinh Đỏ", do sắt ôxít có mặt rất nhiều trên bề mặt hành tinh làm cho bề mặt nó hiện lên với màu đỏ đặc trưng. Sao Hỏa là một hành tinh đất đá với một khí quyển mỏng, có những đặc điểm trên bề mặt có nét giống với cả các hố va chạm trên Mặt Trăng và các núi lửa, thung lũng, sa mạc và chỏm băng ở cực trên của Trái Đất. Chu kỳ tự quay và sự tuần hoàn của các mùa trên Hỏa Tinh khá giống với của Trái Đất do độ nghiêng của trục quay tạo ra. Trên Sao Hỏa có ngọn núi Olympus Mons, ngọn núi cao nhất trong Hệ Mặt Trời, và hẻm núi Valles Marineris, hẻm núi dài và rộng nhất trong Thái Dương Hệ. Lòng chảo Borealis bằng phẳng trên bán cầu bắc bao phủ tới 40% diện tích bề mặt hành tinh đỏ và có thể là một hố va chạm khổng lồ trong quá khứ.\nNhiệt độ:
-63 độ Celsius\nBán kính:
3396.19 km\nKhối lượng:
641.71 Yg\nĐiểm cao nhất:
Olympus Mons\nKinh độ của điểm nút lên:
49.56 độ\nĐịa điểm:
Inner Solar System`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	saohoa_get: saohoa_get
}