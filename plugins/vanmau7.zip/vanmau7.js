var fetch = global.nodemodule["node-fetch"];

var vanmau7 = function vanmau7(type, data) {
	(async function () {
		var returntext = `Các ông chửi rank nova bọn tôi ngu , không biết ném smoke các thứ liệu các ông có nghĩ rằng chúng tôi đã khổ sở trong những tháng ngày qua Chúng tôi đã vượt qua biết bao chông gai của cái rank ngôi sao này. Các ông đâu có hiểu có những trận tôi đã cố gắng hết mình rằng " Ừ mình làm được " và rồi mọi thứ vẫn đổ sông đổ biển. Bản thân tôi là người đã ở cái rank ngôi sao này lâu năm , tôi khẳng định mình biết 365 smoke cơ bản , 50 góc kê tay to cộng 7749 tatic mà Astralis cũng chẳng ngờ tới. Nhớ cái ngày s1mple còn stack nova với tôi bắn vui vẻ đùa giỡn giờ đây 1 người đã vô địch giải này giải kia , top1 hltv , fanboi bu 1 đống còn tôi vẫn ngồi đây đếm 4 ngôi sao qua ngày. Tôi biết cá nhân mình chưa tốt , bản thân mình phải thay đổi cho quãng ngày tiếp theo thì mới thoát ra được khỏi cái máng lợn Nova này được. Xin đừng chửi những người rank nova như tôi nữa , bọn tôi cũng là con người , cũng có cảm xúc như bao người khác , buồn vui khók lók có hết. Chúng tôi thậm chí còn có tiếng nói hơn cả lũ Weaboo suốt ngày post mấy cái hình vú mông vậy tại sao các ông lại không tin tưởng bọn tôi. Hôm nay tôi sẽ quyết tâm thoát khỏi cái rank cứt bò này cho mấy ông xem.
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau7\"";

data.log(onLoadText);

}
module.exports = {
	vanmau7: vanmau7
}