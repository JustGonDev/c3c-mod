var fetch = global.nodemodule["node-fetch"];

var thienthach_get = function thienthach_get(type, data) {
	(async function () {
		var returntext = `Thiên thạch, theo nghĩa chữ Hán Việt là "đá trời", hiện nay trong tiếng Việt được dùng không thống nhất, để chỉ nhiều loại thiên thể với các bản chất hoàn toàn khác nhau. Thiên thạch là một vật thể tự nhiên từ ngoài không gian và tác động đến bề mặt Trái Đất. Khi còn ở trong vũ trụ thì nó được gọi là vân thạch.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	thienthach_get: thienthach_get
}