var facebookTools = global.nodemodule["facebook-tools"]; //KaySil
var cheerio = global.nodemodule["cheerio"];
var fetch = global.nodemodule["node-fetch"];
var fbget = async function(type, data) {
	if(data.args.length > 1) {
		var url = data.args[1];
		let videoObj;
		try {
			videoObj = await facebookTools.getVideoUrl(url);
			data.return({
				handler: "internal",
				data: 'Đang tìm dữ liệu, vui lòng chờ ^‌_‌^'
			});
			if(videoObj != undefined) {
				data.log(url)
				if(videoObj.hdLink != undefined) {
					data.log('Bingo Got Full Link Video...')
					try {
						var hdlink = await fetch(`https://tinyurl.com/create.php?source=indexpage&url=${encodeURIComponent(videoObj.hdLink)}`).then(x => x.text());
						var sdlink = await fetch(`https://tinyurl.com/create.php?source=indexpage&url=${encodeURIComponent(videoObj.sdLink)}`).then(x => x.text());
					} catch (ex) {data.log(ex)}
					var $ = cheerio.load(hdlink);
					var $$ = cheerio.load(sdlink);
					var hdurl = $("#copy_div").attr('href')
					var sdurl = $$("#copy_div").attr('href')
					return {
						handler: "internal",
						data: 'HD: '+hdurl+'\n'+'SD: '+sdurl
					}
				} else {
					data.log('Hmm Got Only SD Link...')
					try {
						var sdlink = await fetch(`https://tinyurl.com/create.php?source=indexpage&url=${encodeURIComponent(videoObj.sdLink)}`).then(x => x.text());
					} catch (ex) {data.log(ex)}
					var $ = cheerio.load(sdlink);
					var sdurl = $("#copy_div").attr('href')
					return {
						handler: "internal",
						data: 'SD: '+sdurl
					}
				}
			} else {
				return {
					handler: "internal",
					data: "Không tìm thấy link download hoặc link post không hợp lệ!"
				}
			}
		} catch (e) {
			data.log(e)
			data.return({
				handler: "internal",
				data: "Lỗi rùi..."
			});
		}
	} else {
		return {
			handler: "internal",
			data: `Missing link facebook...`
		}
	}
}
module.exports = {
	fbget
}