!global.data.piccommand ? global.data.piccommand = {} : "";
var get = function(type, data){
	var url = (data.msgdata.body).slice(4,(data.msgdata.body).length);
    var img = global.nodemodule['sync-request']("GET", url).body;
	var imagesx = new global.nodemodule["stream-buffers"].ReadableStreamBuffer({
        frequency: 10,
        chunkSize: 16
    });
	imagesx.path = "img.png";
    imagesx.put(img);
    imagesx.stop();
	console.log([imagesx]);
	global.data.piccommand.pic = imagesx;
	return {
		handler: "internal",
		data: "done"
	}
}
var nig = function(type, data){
	var img = global.data.piccommand.pic;
	return {
        handler: "internal-raw",
        data: {
            attachment: (img)
        }
    }
}
module.exports = {
	get,
	nig
}