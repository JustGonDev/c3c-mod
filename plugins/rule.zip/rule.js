var fetch = global.nodemodule["node-fetch"];

var rule = function rule(type, data) {
	(async function () {
		var returntext = `Luật khi dùng bot
	1. Không spam, lạm dụng bug
	2. Cấm dùng lệnh calladmin làm phiền chủ bot 
	3. Không dame bot, giết acc của bot
	4. Thỉnh thoảng acc bot die thì chưa đến nỗi phải kick, vì thằng này sẽ unlock sớm thôi
	5. Được phép add nhiều bot nhưng không được dùng 2 bot trùng prefix
	6. Không kick/add bot liên tục => bất cứ vi phạm sẽ bị cảnh bảo hoặc cao nhất là Global Ban.
	7. Thằng KDV này đôi lúc là bot, đôi lúc cũng là người nên đừng bất ngờ khi thấy tôi trả lời khác thường
	==== Hết ====.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"RULE\" by Team C3C";

data.log(onLoadText);

}
module.exports = {
	rule: rule
}