﻿var fetch = global.nodemodule["node-fetch"];

var HD_get = function HD_get(type, data) {
	(async function () {
		var returntext = `Hiện tại không có người phù hợp với bạn, vui lòng ế tiếp và đừng thử lại ^^`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	HD_get: HD_get
}