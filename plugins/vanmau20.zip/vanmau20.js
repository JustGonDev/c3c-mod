var fetch = global.nodemodule["node-fetch"];

var vanmau20 = function vanmau20(type, data) {
	(async function () {
		var returntext = `1 thằng 22 tuổi đầu vẫn còn phải ngửa tay ra xin tiền để đi net thì đéo hiểu mày định dạy khôn ai?, thật ra cái chuyện xin tiền cũng chả có gì đáng nói ở đây cả nhưng đấy là khi mày nên biết thân biết phận câm con mẹ mày mồm vào rồi tiếp tục cái công việc ăn bám mày đang và sẽ tiếp tục làm bây giờ. ăn bám thì ai cũng từng có 1 thời gian phải thế, nhưng ăn bám mà còn mặt dày như mày thì bố mày mới gặp lần đầu thôi. Thêm cách ăn mặc thì cũng đéo biết ví mày như nào vì nhà quê cũng đéo đúng vì mày vừa nhà quê lại còn trông bẩn bẩn nữa =)) cả vụ bị đánh oan bạn mày kể mà chỉ biết câm mồm chịu bị đánh đéo dám làm gì lại, cứ nghĩ đến việc 1 thằng vô dụng còn hèn như mày muốn dạy đời người khác là bố mày chỉ thấy khinh mày hơn thôi. Suốt ngày cà khịa người khác vụ học hành nhưng mà đéo ai chắc chắn là khi mày học xong có kiếm đc ra tiền ko hay vẫn ngửa tay xin vài đồng đi net như bây giờ hả thằng vô dụng?. Cũng định thôi đéo chấp mấy thằng hèn nhưng mà có vẻ cái tính đàn bà tiềm ẩn của mày ko làm mày câm đc thì để bố giúp thằng ngu như mày 1 lần vậy. Hì
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau20\"";

data.log(onLoadText);

}
module.exports = {
	vanmau20: vanmau20
}