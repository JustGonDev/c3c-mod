// *require stuff*
var PluginName = "googletrends";    // plugin_scope in plugins.js
var config = JSON.parse(global.privateFileMap[PluginName]["config"].toString())["config"];
var plugininfo = JSON.parse(global.privateFileMap[PluginName]["plugininfo"].toString());
var lang = JSON.parse(global.privateFileMap[PluginName]["lang"].toString())["lang"];
const googleTrends = global.nodemodule['google-trends-api'];

function getLang () {}
var onLoad = function (data) {
	check();
	if (global.getType(checkstatus) === "String") {
		console.log(checkstatus);
	}
	getLang = function (langVal, Lang) {
	    if (lang[Lang]) {
		    return String(lang[Lang][langVal]);
	    } else {
		    return String((lang[global.config.language] || {})[langVal]);
	    }
	}
}

// *ggdaily*
var Daily = async function(type, data){
    if (global.getType(checkstatus) === "Boolean") {
        var test;
    	var geocode;
    	if(data.args[1] == undefined){
    		geocode = config["DailyBasicGeocode"].toUpperCase();
     		test = true;
    	}
    	else {
    		geocode = data.args[1].toUpperCase();
    		test = false;
    	}
        var res;
        try {
	        res = await googleTrends.dailyTrends({
                geo: geocode,
	        });
    	} catch(err){
    	    return{
    		    handler: "internal",
    		    data : err
    	    }
        }
    	var code;
    	try{
    		code = JSON.parse(res);
    	}
    	catch (err){
	    	if(test){
		        return{
		            handler: "internal",
		            data : getLang("BasicGeoCodeError", data.resolvedLang).replace("{0}", config["DailyBasicGeocode"].toUpperCase())
    		    }
	    	}
		    else {
			    return{
		            handler: "internal",
    		        data : (getLang("GeoCodeError", data.resolvedLang).replace("{0}", geocode)).replace("{1}", config["DailyBasicGeocode"].toUpperCase())
	    	    }
		    }
	    }
    	var key = (code.default.trendingSearchesDays.map(x => x.trendingSearches).flat()).map(x => [x.title.query, x.formattedTraffic]).filter((e, i, a) => (a.map(x => x[0]).indexOf(e[0]) == i));
    	key = key.slice(0,config["DailyLimitSearches"]);
    	return {
            handler: "internal",
            data: key.reduce((a, e, i) => a + `\n- ${e[0]} [${e[1]} ${getLang("Searches" , data.resolvedLang)}]\n`, `${getLang("Daily", data.resolvedLang).replace("{0}", key.length)}\r\n`)
        }
	}
	else {
		return{
			handler: "internal",
			data: checkstatus
		}
	}
}

// *ggrelatedtopic*
var RelatedTopics = async function(type, data){
	if (global.getType(checkstatus) === "Boolean") {
		if(data.args[1] == undefined){
			return{
			    handler: "internal",
			    data : getLang("NoKeyWords", data.resolvedLang)
		    }
		}
 	    var res;
 	    try {
		    res = await googleTrends.relatedTopics({
				keyword: data.msgdata.body.slice(data.msgdata.body.indexOf(data.args[1]), data.msgdata.body.length),
  		        geo: config["RelatedTopicsBasicGeocode"],
			});
		} catch(err){
		    return{
			    handler: "internal",
			    data : err
		    }
 	    }
		var code;
		try{
			code = JSON.parse(res);
		}
			catch (err){
			return{
			    handler: "internal",
			    data : getLang("BasicGeoCodeError", data.resolvedLang).replace("{0}", config["RelatedTopicsBasicGeocode"].toUpperCase())
			}
	    }
		var key = (code.default.rankedList.map(x => x.rankedKeyword).flat()).map(x => x.topic.title).filter((value, index, arr) => arr.indexOf(value) == index);
		key = key.slice(0,config["RelatedTopicsLimitSearch"]);
		return {
	        handler: "internal",
	        data: key.reduce((a, e, i) => a + `\n- ${e}`, (getLang("RelatedTopics", data.resolvedLang).replace("{0}", key.length)).replace("{1}", data.msgdata.body.slice(data.msgdata.body.indexOf(data.args[1]), data.msgdata.body.length))+"\r\n")
 	    }
	}
	else {
		return{
			handler: "internal",
			data: checkstatus
		}
	}
}

// *ggrealtimetrend*
var Realtime = async function(type, data){	
    if (global.getType(checkstatus) === "Boolean") {
        var test;
    	var geocode;
    	if(data.args[1] == undefined){
    		geocode = config["RealtimeTrendsbasicGeocode"].toUpperCase();
    		test = true;
    	}
    	else {
    		geocode = data.args[1].toUpperCase();
    		test = false;
    	}
        var res;
        try {
    	    res = await googleTrends.realTimeTrends({
                geo: geocode,
    			category: 'all',
    	    });
    	} catch(err){
    	    return{
    		    handler: "internal",
    		    data : err
    	    }
        }
    	var code;
    	try{
    		code = JSON.parse(res);
    	}
    	catch (err){
    		if(test){
    		    return{
    		        handler: "internal",
    		        data : getLang("BasicGeoCodeError", data.resolvedLang).replace("{0}", config["RealtimeTrendsbasicGeocode"].toUpperCase())
    		    }
    		}
    		else {
    			return{
    		        handler: "internal",
    		        data : (getLang("GeoCodeError", data.resolvedLang).replace("{0}", geocode)).replace("{1}", config["RealtimeTrendsbasicGeocode"].toUpperCase())
    		    }
    		}
    	}
    	var key = (code.storySummaries.trendingStories.map(x => x.articles[0]).flat()).map(x => [x.articleTitle, x.source]);
    	key = key.slice(0,config["RealtimeTrendsLimitSearch"]);
    	return {
            handler: "internal",
            data: key.reduce((a, e, i) => a + `\n-[${e[1]}]: ${e[0].split("&#39;").join("'")} \n`, getLang("RealTimeTrends", data.resolvedLang).replace("{0}",key.length))
        }
	}
	else {
		return {
            handler: "internal",
			data: checkstatus
		}
	}
}

var checkstatus;
var check = function(data){
    function requireFromString(src, filename) {
        var Module = module.constructor;
        var m = new Module();
        m._compile(src, filename);
        return m.exports;
    }
	var path = global.nodemodule["path"];
	var func = requireFromString(global.privateFileMap[PluginName]["checker"].toString(),path.join(__dirname, "checker.js"));
	if(data == undefined || data.resolvedLang == undefined){
	    checkstatus = func.checkreturn(plugininfo, JSON.parse(global.privateFileMap[PluginName]["config"].toString()), JSON.parse(global.privateFileMap[PluginName]["lang"].toString()), global.config.language);
	}
	else {
		checkstatus = func.checkreturn(plugininfo, JSON.parse(global.privateFileMap[PluginName]["config"].toString()), JSON.parse(global.privateFileMap[PluginName]["lang"].toString()), data.resolvedLang);
	}
}

module.exports = {
	onLoad,
	Daily,
	RelatedTopics,
	Realtime
}