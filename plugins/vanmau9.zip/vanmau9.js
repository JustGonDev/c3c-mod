var fetch = global.nodemodule["node-fetch"];

var vanmau9 = function vanmau9(type, data) {
	(async function () {
		var returntext = `Không vui chút nào, tôi đã không cười. Trò đùa của bạn thật tệ, tôi sẽ thích trò đùa này nếu nó được xoá khỏi đầu tôi và bạn vui lòng từ bỏ nói lại cho tôi trò đùa đấy. Nói thật, đây là một nỗ lực kinh khủng khi cố gắng để mang một nụ cười ra khỏi tôi. Không phải cười, không phải hehe, thậm chí không phải là một sự bùng nổ tinh tế từ thực quản của tôi. Khoa học có nói trước khi bạn cười não của bạn chuẩn bị cơ mặt nhưng tôi thậm chí không cảm thấy một chuyển động nào dù là nhỏ nhất. 0/10 trò đùa này thật tệ, tôi không thể tin là có người lại đủ pháp lý để cho phép bạn được quyền sáng tạo. Lượng sức mạnh não bộ mà bạn đã đưa vào trò đùa đó có thể tạo năng lượng cho mọi ngôi nhà trên Trái Đất. Hãy có một nhân cách và học cách tạo ra trò đùa, đọc một cuốn sách đi. Tôi không nói điều này để trở nên buồn cười, tôi thực sự có ý đó về cách mà đây chỉ là sự bi hài trong hài kịch. Bạn đã giết chết sự hài hước và mọi hành động hài kịch trên hành tinh. Tôi rất thất vọng vì xã hội đã thất bại trong việc có thể dạy bạn cách hài hước. Thật lòng mà nói nếu tôi đặt tất cả sức mạnh và thời gian để cố gắng và làm cho trò đùa của bạn buồn cười, nó sẽ yêu cầu Einstein phải xây dựng một thiết bị để tôi có thể kết nối với năng lượng của một tỷ ngôi sao để làm điều đó, và thứ duy nhất mà trò đùa đó nhận được từ mọi người là một sự khinh bỉ tinh tế. Bạn thật may mắn vì tôi vẫn còn chút cảm thông cho bạn sau khi kể trò đùa đó nếu không tôi sẽ nhận hết mọi tội ác chiến tranh từng được ghi lại trong sử sách chỉ để ngăn cản bạn cố gắng mang đến bất kỳ sự hài hước nào nữa. Chúng ta nên đặt trò đùa đó vào sách giáo khoa để các thế hệ tương lai có thể cảnh giác khỏi việc trở thành một thất bại tuyệt đối trong hài kịch. Tôi thất vọng, tổn thương và bị xúc phạm hoàn toàn khi thời gian quý báu của tôi đã bị lãng phí chỉ để não tôi có thể hiểu trò đùa đó. Trong khoảng thời gian đó tôi đã lên kế hoạch giúp đỡ những đứa trẻ mồ côi, nhưng vì điều đó bạn đã làm tôi đã phải giải thích với một cách ít tục tĩu nhất về nỗ lực khủng khiếp của bạn trong hài kịch. Bây giờ những đứa trẻ đang đau khổ khi không có bữa ăn và không có ai để đổ lỗi ngoài bạn. Tôi hy vọng bạn hạnh phúc với những gì bạn đã làm và tôi thực sự hy vọng bạn có thể bước tiếp và học hỏi từ nỗ lực đáng thương này.
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau9\"";

data.log(onLoadText);

}
module.exports = {
	vanmau9: vanmau9
}