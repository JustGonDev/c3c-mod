var fetch = global.nodemodule["node-fetch"];

var nhomnguyentu = function nhomnguyentu(type, data) {
	(async function () {
		var returntext = `Bảng hóa trị một số nhóm nguyên tử
Tên/Hoá trị/Gốc axit/Axit tương ứng/Tính axit
Hiđroxit(*)(OH);Nitrat(NO3);Clorua(Cl) / I / NO3 / HNO3 / Mạnh
Sunfat(SO4);Cacbonat(CO3) /II / SO4 / H2SO4 / Mạnh
Photphat(PO4) / III / Cl / HCl / Mạnh 
(*):Tên này dùng trong các hợp chất với kim loại.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"nhomnguyentu\"mod lại của by Wua'n";

data.log(onLoadText);

}
module.exports = {
	nhomnguyentu: nhomnguyentu
}