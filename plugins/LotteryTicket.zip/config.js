{
	"config": {
		"LotteryTicketPrize": "50",
	    "WinnerPrize": "1000000000000000",
	    "MinimumNumber": "0",
	    "MaximumNumber": "50"
	},
	"configdes": {
		"LotteryTicketPrize": [false, false, false, 0],
	    "WinnerPrize": [false, false, false, 0],
	    "MinimumNumber": [false, false, false, 0],
	    "MaximumNumber": [false, false, false, 0]
	}
}