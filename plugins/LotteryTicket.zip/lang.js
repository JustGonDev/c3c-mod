{
	"lang": {
		"en_US": {
    		"NoLotteryNumber": "You have not selected a lottery number!",
    		"LotteryNumberCaution": "Choose a number from {0} to {1}!",
    		"TakenlotteryNumber": "The number ({0}) you have chosen already has buyers. Please choose another number!",
    		"BuyLotteryTicket": "You have purchased a lottery ticket with number {0}!",
    		"NotEnoughMoney": "You don't have enough money to buy lottery tickets!",
    		"GroupOnly": "The command is only used in groups!",
    		"WinLotterySeason": "This season's lottery has a winner is {0} with lottery number {1}. You will get {2}B into your account!",
    		"NoneWinLotterySeason": "No one has won this season's lottery! Winning number is {0}",
    		"AdminOnly": "Only admin groups can use this command",
     		"NoLotteryTicket": "You haven't bought any lottery tickets!",
     		"LotteryTicket": "You have {0} lottery tickets. Including number(s) {1}."
    	},
    	"vi_VN": {
    		"NoLotteryNumber": "Bạn chưa chọn số vé!",
    		"LotteryNumberCaution": "Hãy chọn số từ {0} đến {1}!",
    		"TakenlotteryNumber": "Số bạn chọn ({0}) đã có người mua. vui lòng chọn số khác!",
    		"BuyLotteryTicket": "Bạn đã mua vé số với mã {0}!",
	    	"NotEnoughMoney": "Bạn không đủ tiền để mua vé số!",
    		"GroupOnly": "Lệnh chỉ được dùng trong group!",
     		"WinLotterySeason": "Vé số mùa này có người trúng là bạn {0} với vé số số {1}.bạn sẽ nhận được {2}B vào tài khoản của mình!",
     		"NoneWinLotterySeason": "Vé số mùa này không ai trúng cả!,số trúng là {0}",
	    	"AdminOnly": "Chỉ admin group mới được dùng lệnh này",
    		"NoLotteryTicket": "Bạn chưa mua vé số nào cả!",
    		"LotteryTicket": "Bạn có {0} vé. Gồm số {1}."
        }
    },
	"langdes": {
		"NoLotteryNumber": [],
    	"LotteryNumberCaution": ["{0}","{1}"],
    	"TakenlotteryNumber": ["{0}"],
    	"BuyLotteryTicket": ["{0}"],
    	"NotEnoughMoney": [],
    	"GroupOnly": [],
    	"WinLotterySeason": ["{0}","{1}","{2}"],
    	"NoneWinLotterySeason": ["{0}"],
    	"AdminOnly": [],
     	"NoLotteryTicket": [],
     	"LotteryTicket": ["{0}","{1}"]
	}
}
