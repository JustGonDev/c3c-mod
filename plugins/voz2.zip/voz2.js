var fetch = global.nodemodule["node-fetch"];

var voz2 = function voz2(type, data) {
	(async function () {
		var returntext = `Review từ những người đã học hỏi và đổi đời từ 300 bài code thiếu nhi:
		1. Bà hàng xóm nhà mình đây, trước đi buôn đồng nát, tình cờ có thằng sinh viên khoa cntt nó bán đống sách
		cũ. Thế nào mà bà ấy mua "300 bài code thiếu nhi" cầm về đọc.
		Rồi sáng đi mua đồng nát, tối về đọc sách, cuối tuần ra quán net thực hành.
		Sáu tháng sau bà ấy khăn gói lên HN đi phỏng vấn, cũng nhờ code trên giấy nhiều mà mấy bài "white board"
		bà ấy làm ngon ơ. Cũng 5 năm rồi, giờ đang làm lead ở một công ty khá lớn.
		Đúng là cái nghề này mang lại cơ hội đổi đời cho nhiều người.
		2. Quê tôi miền biển, có gia đình cạnh nhà làm nghề chài lưới. Bữa đi kéo lưới, thấy gì nặng nặng tưởng
		được mẻ cá to, ai ngờ toàn sách là sách. Nào là "300 bài code thiếu nhi", "Lập trình căn bản", " Machine
		Learning", "Deep learning", "AI"...
		A định vất đi nhưng nhà mấy đời k biết mặt chữ là gì nên quyết tâm cầm về gối đầu giường. Đi học bổ túc
		văn hóa ban đêm phổ cập con chữ.
		Ấy thế mà bẵng đi 6 tháng tôi từ thủ đô về thăm A khoe giờ ở nhà làm freelancer cho cty gì ở Mỹ ấy, to lắm,
		lương xấp xỉ 1 củ Trump/năm.
		3. Gần nhà mình có ông tầm gần 30. bảo làm cà phê, tiêu mệt quá.
		Thế là khăn gói xuống tp học 1 khóa lập trình pithon dip leaning gì đó, xong rồi làm 300 bài code thiếu nhi
		luyện tập. Bữa mới nói chuyện khoe đang làm lương cũng 1 2k gì đó!
		4. Bác họ tui 46 rồi, chạy ba gác hoài mệt quá đi học lớp code cấp tốc. Học hết 2 tháng với làm hết bài trong
		cuốn 300 bài code thiếu nhi, xong apply vào công ty kia làm mảng data science mỗi tháng lương net hơn
		400tr.
		5. Ông xe ôm xóm mình sinh năm 82, hôm trước chạy xe lớ ngớ thế nào rớt xuống cống, rồi nhặt được cuốn
		lập trình "code thiếu nhi" gì gì đó, về đọc đâu hơn 1 tháng rồi ra HN làm cho công ty trí tuệ nhân tạo to lắm,
		mới làm 1 năm mua được nhà HN, mua được thêm con mazda 6 rồi.
		6. Giống tôi, trước đẩy xe hủ tiếu ngoài đường vô tình bắt gặp nhà nọ mở thời sự về blocktrain, thế là cứ
		ngày đi bán tối về coi NTN với tranh thủ coi clocktrain 1 xíu.
		Về nhà tối nào tôi cũng làm 3 bài trong "300 bài code thiếu nhi", mà sau 3 tháng cũng apply được công ty về
		tiền ảo. Giờ tôi đánh sang cả mảng AI nữa, mới viết app di dộng auto deepfake có người trả 300k$ chưa bán.
		7. Năm ngoái đi fuho sml ngoài công trình vô tình nhặt dc cuốn sách 300 bài lập trình dành cho thiếu nhi về
		nhà luyện tập theo sau 3 tháng tự tin apply 1 cty chuyên về ai, ml ở quận 1 lương 3k chưa thưởng hay phụ
		cấp đây.
		8. 6 tháng trước làm nhà hàng vất vả quá, trong lúc thái thịt đọc lướt được cuốn java căn bản với 300 bài
		code thiếu nhi. Bây giờ dev full stack lương 2,2k
		9. Mẹ thằng chú tôi làm sales sim số đẹp cho viettel đợt rồi đói ăn quá nên vất cho cuốn lập trình code thiếu
		nhi gì đấy, 6 tháng sau vào làm dev cứng FPT rồi , nghe bảo lương 2k vì ngành này đang hot
		10. Ông già tôi làm công nhân than đuối quá, muốn kiếm việc gì nhẹ hơn. Tôi giới thiệu ng khoá học HTML
		CSS PHP trên ucademy với làm bài tập trong cuốn 300 bài code thiếu nhi.
		Sau 6 tháng, giờ ỗng ở nhà làm freelancer rung đùi hàng tháng tài khoản cứ bắn vào mấy ngàn $. Đang tính
		bảo bà già khỏi đi làm nữa ở nhà mà xài tiền.
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"voz2\"";

data.log(onLoadText);

}
module.exports = {
	voz2: voz2
}