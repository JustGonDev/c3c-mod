!global.data.cacheName ? global.data.cacheName = {} : "";
var srequest = global.nodemodule["sync-request"];

var simsimi = function(type, data){
	var msg = "";
	var word = data.msgdata.body.slice(data.msgdata.body.indexOf(data.args[1]), data.msgdata.body.length);
	var raw = srequest('GET', `https://simsimi.copcute.pw/api/`, { qs: { text: word }});
	var raw2 = JSON.parse(raw.body);
	console.log(raw, raw2);
	console.log(raw.statusCode == 200, JSON.parse(raw2.database));
	if(raw.statusCode == 200 && JSON.parse(raw2.database)){
		msg = raw2.success;
	}
	else {
		var raw = srequest('GET', `https://simsumi.herokuapp.com/api`, { qs: { text: word }});
		var raw2 = JSON.parse(raw.body);
		console.log("bruhhhhhhhhhhhhhhhhhhhhh");
		console.log(raw, raw2);
		console.log(raw2.success);
		if(raw.statusCode == 200 && raw2.success != ""){
			msg = raw2.success;
			teach(word, msg, "c3c (data from J2Team)");
		}
		else {
			msg = "Dạ em hông hỉu gì hết trơn á! Dạy em qua https://www.facebook.com/simsim.copcute/ nhé anh/chị yêu dấu UwU";
		}
	}
	return{
		handler: "internal",
		data: msg
	}
}

var simteach = async function(type, data){
	var by = `c3c (bot ${global.data.cacheName["FB-"+data.facebookapi.getCurrentUserID()]})`;
	var args = data.msgdata.body.slice(data.msgdata.body.indexOf(data.args[1]), data.msgdata.body.length).split('"');
	console.log(args,args.length);
	if(args.length != 4){
		var msg = `Sai cú pháp simteach: ${global.config.commandPrefix}csimteach "từ/câu bạn muốn sim trả lời khi bạn chat" "từ/câu bạn muốn Simsimi trả lời"`;
	}
	else {
		var key = args[0];
		var value = args[2];
		if((key == "" || value == "") || (key == " " || value == " ")){
			var msg = `Sai cú pháp simteach: từ/câu bạn muốn sim trả lời khi bạn chat và từ/câu bạn muốn Simsimi trả lời không được để trống!`;
		}
		else {
			var value3 = teach(key, value, by);
			var msg = `Cảm ơn bạn đã dạy cho Simsimi 1 kiến thức mới ^^\r\nKey: ${value3.ask}\r\nValue: ${value3.ans}`;
		}
	}
	return{
		handler: "internal",
		data: msg
	}
}

function teach(x, y, by) {
	var value1 = x;
	var value2 = y;
	var value3 = JSON.parse(srequest('GET', `https://simsimi.copcute.pw/api/save.php`, { qs: { hoi: value1, dap: value2, by: by }}).body);
	return {
		ask: value3.ask,
		ans: value3.ans
	};
}

module.exports = {
	simsimi,
	simteach
}