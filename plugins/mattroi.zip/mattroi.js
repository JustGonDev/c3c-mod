var fetch = global.nodemodule["node-fetch"];

var sun_get = function sun_get(type, data) {
	(async function () {
		var returntext = `Mặt Trời
Sao Dãy Chính Loại G\nMặt Trời, cũng gọi là Thái Dương (太陽) hoặc Nhật (日), là ngôi sao ở trung tâm Hệ Mặt Trời, chiếm khoảng 99,86% khối lượng của Hệ Mặt Trời. Trái Đất và các thiên thể khác như các hành tinh, tiểu hành tinh, thiên thạch, sao chổi, và bụi quay quanh Mặt Trời. Khoảng cách trung bình giữa Mặt Trời và Trái Đất xấp xỉ 149,6 triệu kilômét nên ánh sáng Mặt Trời cần 8 phút 19 giây mới đến được Trái Đất. Trong một năm, khoảng cách này thay đổi từ 147,1 triệu kilômét ở điểm cận nhật, tới xa nhất là 152,1 triệu kilômét ở điểm viễn nhật. Năng lượng Mặt Trời ở dạng ánh sáng hỗ trợ cho hầu hết sự sống trên Trái Đất thông qua quá trình quang hợp, và điều khiển khí hậu cũng như thời tiết trên Trái Đất. Thành phần của Mặt Trời gồm hydro, heli, và một lượng nhỏ các nguyên tố khác, gồm sắt, nickel, oxy, silic, lưu huỳnh, magiê, carbon, neon, canxi, và crom. Mặt Trời có hạng quang phổ G2V. G2 có nghĩa nó có nhiệt độ bề mặt xấp xỉ 5.778 K (5.505 °C) khiến nó có màu trắng, và thường có màu vàng khi nhìn từ bề mặt Trái Đất bởi sự tán xạ khí quyển. Chính sự tán xạ này của ánh sáng ở giới hạn cuối màu xanh của quang phổ khiến bầu trời có màu xanh. Quang phổ Mặt Trời có chứa các vạch ion hoá và kim loại trung tính cũng như các đường hydro rất yếu. V trong lớp quang phổ thể hiện rằng Mặt Trời, như hầu hết các ngôi sao khác, là một ngôi sao thuộc dãy chính. Điều này có nghĩa nó tạo ra năng lượng bằng tổng hợp hạt nhân của hạt nhân hydro thành heli. Có hơn 100 triệu ngôi sao lớp G2 trong Ngân Hà của chúng ta. Từng bị coi là một ngôi sao nhỏ và khá tầm thường nhưng thực tế theo hiểu biết hiện tại, Mặt Trời sáng hơn 85% các ngôi sao trong Ngân Hà với đa số là các sao lùn đỏ.\nNhiệt độ:
5 triệu K\nKhối lượng:
1 Khối lượng Mặt Trời\nDiện tích:
6090 tỷ kilômét vuông\nBán kính:
1 bán kính Mặt Trời\nMật độ:
1.41 g/cm³\nThể tích:
1410000000 tỷ km³`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	sun_get: sun_get
}