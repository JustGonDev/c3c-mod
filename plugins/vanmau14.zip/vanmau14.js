var fetch = global.nodemodule["node-fetch"];

var vanmau14 = function vanmau14(type, data) {
	(async function () {
		var returntext = `Chào em, chị là luật sư của army và đã thu thập đủ bằng chứng em xúc phạm army của công ty bên chị. Em vui lòng xóa bài này sau 30 phút. Nếu sau 30 phút mà em vẫn chưa xóa bài thì bên chị sẽ dùng tới pháp luật và em sẽ bị lôi đầu ra Côn Đảo !
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau14\"";

data.log(onLoadText);

}
module.exports = {
	vanmau14: vanmau14
}