var fetch = global.nodemodule["node-fetch"];

var saohaivuong_get = function saohaivuong_get(type, data) {
	(async function () {
		var returntext = `Sao Thiên Vương
Hành Tinh Băng Khổng Lồ\nSao Thiên Vương hay Thiên Vương tinh là hành tinh thứ bảy tính từ Mặt Trời; là hành tinh có bán kính lớn thứ ba và có khối lượng lớn thứ tư trong hệ. Sao Thiên Vương có thành phần tương tự như Sao Hải Vương, và cả hai có thành phần hóa học khác so với hai hành tinh khí khổng lồ lớn hơn là Sao Mộc và Sao Thổ. Vì lý do này, các nhà thiên văn thỉnh thoảng phân chúng vào loại hành tinh khác gọi là "hành tinh băng khổng lồ". Khí quyển của Sao Thiên Vương, mặc dù tương tự như của Sao Mộc và Sao Thổ về những thành phần cơ bản như hiđrô và heli, nhưng chúng chứa nhiều "hợp chất dễ bay hơi" như nước, amoniac, và mêtan, cùng với lượng nhỏ các hiđrôcacbon. Hành tinh này có bầu khí quyển lạnh nhất trong số các hành tinh trong Hệ Mặt Trời, với nhiệt độ cực tiểu bằng 49 K. Nó có cấu trúc tầng mây phức tạp, với khả năng những đám mây thấp nhất chứa chủ yếu nước, trong khi mêtan lại chiếm chủ yếu trong những tầng mây phía trên. Ngược lại, cấu trúc bên trong Thiên Vương Tinh chỉ chứa chủ yếu một lõi băng và đá.\nĐịa điểm:
outer solar system\nThiên thể mẹ:
Mặt Trời\nHình cầu dẹt:
0.02\nThiên thể con:
Desdemona, Cressida (vệ tinh) ...\nĐộ lệch tâm quỹ đạo:
0.05\nBán kính:
24973 km`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	saohaivuong_get: saohaivuong_get
}