var configreturnlang = {
	"en_US": {
		"Basic": "CONFIG ERROR! Var {0} in config.js of plugin {1} unsatisfactory of config.js ({2})",
		"</>": "{0} {1} {2}",
		"!= true/false": "{0} is not a boolean",
		"!= number": "{0} is not a number",
		"!= string": "{0} is not a string",
		"!= interger": "{0} is not a interger"
	},
	"vi_VN": {
		"Basic": "CONFIG ERROR! Biến {0} trong config.js của plugin {1} không đạt yêu cầu của config.js ({2})",
		"</>": "{0} {1} {2}",
		"!= true/false": "{0} không thuộc true/false",
		"!= number": "{0} không phải số",
		"!= string": "{0} không phải chuỗi",
		"!= interger": "{0} không thuộc số nguyên"
	}
}

var langreturnlang = {
	"en_US": {
		"Basic": "LANG ERROR! Lang {0} of {1} in lang.js of plugin {2} unsatisfactory of lang.js ({3} is mising)"
	},
	"vi_VN": {
		"Basic": "LANG ERROR! Lang {0} của {1} trong lang.js của plugin {2} không đạt yêu cầu của lang.js (thiếu {3})"
	}
}

var getLang = function (src,langVal,lang) {
	if (src[lang]) {
		return String(src[lang][langVal]);
	} else {
		return String((src[global.config.language] || {})[langVal]);
	}
}

var langreturn = function(plugininfo,lang,language){
	function langcheck(lang){
		for(i = 0;i<Object.keys(lang["lang"]).length;i++){
			for(o=0;o<Object.keys(lang["lang"][Object.keys(lang["lang"])[i]]).length;o++){
				if(lang["langdes"][Object.keys(lang["lang"][Object.keys(lang["lang"])[i]])[o]].length != 0){
					for(p=0;p<lang["langdes"][Object.keys(lang["lang"][Object.keys(lang["lang"])[i]])[o]].length;p++){
						if(lang["lang"][Object.keys(lang["lang"])[i]][Object.keys(lang["lang"][Object.keys(lang["lang"])[i]])[o]].indexOf(lang["langdes"][Object.keys(lang["lang"][Object.keys(lang["lang"])[i]])[o]][p]) == -1){
							return [Object.keys(lang["lang"])[i],Object.keys(lang["lang"][Object.keys(lang["lang"])[i]])[o], `missing ${lang["langdes"][Object.keys(lang["lang"][Object.keys(lang["lang"])[i]])[o]][p]}`];
						}
					}
				}
			}
		}
		return true;
	}
	var result = langcheck(lang);
    if(Array.isArray(result)){
		    var reason = [false, getLang(langreturnlang,"Basic", language).replace("{0}", result[1]).replace("{1}", result[0]).replace("{2}", plugininfo["plugin_name"]).replace("{3}", result[2].slice(8, result[2].length))];
	}
	else {
		var reason = true;
	}
	return reason;
}

var configreturn = function(plugininfo,config,language){
	function configcheck(config){
    	for(i = 0; i < Object.keys(config["config"]).length; i++){
            for(o = 0; o < config["configdes"][Object.keys(config["config"])[i]].length; o++){
		    	switch (o){
			        case 0:
				        if(config["configdes"][Object.keys(config["config"])[i]][o] == false){		
							if(isNaN(config["config"][Object.keys(config["config"])[i]].toString()) === true || (config["config"][Object.keys(config["config"])[i]].toString()).indexOf(".") != -1){
								return [Object.keys(config["config"])[i], `!= interger`]
							}
			                else if(!(isNaN(config["config"][Object.keys(config["config"])[i]]) ==  false)){
					            return [Object.keys(config["config"])[i], `!= number`]
    					    }
	    				}
						else {
							if(!(isNaN(config["config"][Object.keys(config["config"])[i]]) ==  true)){
								return [Object.keys(config["config"])[i], `!= string`]
							}
						}
		    			break;
                    case 1:
                        if(config["configdes"][Object.keys(config["config"])[i]][o] == true){
                            if(!(config["config"][Object.keys(config["config"])[i]].toLowerCase() == 'true' || config["config"][Object.keys(config["config"])[i]] == 'false')){
                                return [Object.keys(config["config"])[i], `!= true/false`]
                            }
	    				}
                        break;
                    case 2: 
                        if(typeof config["configdes"][Object.keys(config["config"])[i]][o] == "number"){
                            if(!(parseFloat(config["config"][Object.keys(config["config"])[i]]) <= config["configdes"][Object.keys(config["config"])[i]][o])){
                                return [Object.keys(config["config"])[i], `> ${config["configdes"][Object.keys(config["config"])[i]][o]}`]
    						}
    					}
    					break;
    				case 3:
    				    if(typeof config["configdes"][Object.keys(config["config"])[i]][o] == "number"){
                            if(!(parseFloat(config["config"][Object.keys(config["config"])[i]]) >= config["configdes"][Object.keys(config["config"])[i]][o])){
                                return [Object.keys(config["config"])[i], `< ${config["configdes"][Object.keys(config["config"])[i]][o]}`]
    						}
	    				}
	    				break;
	    	    }
    	    }
	    }
	    return true;
    }   	
	var result = configcheck(config);
    if(Array.isArray(result)){
		var eng = result[1].slice(0,1);
		if(eng == "<" || eng == ">"){
		    var reason = [false, getLang(configreturnlang,"Basic", language).replace("{0}", result[0]).replace("{1}", plugininfo["plugin_name"]).replace("{2}", getLang(configreturnlang,"</>", language).replace("{0}", config["config"][result[0]]).replace("{1}", eng).replace("{2}", result[1].slice(2,result[1].length)))];
		}
		else {
			var reason = [false, getLang(configreturnlang,"Basic", language).replace("{0}", result[0]).replace("{1}", plugininfo["plugin_name"]).replace("{2}", getLang(configreturnlang,result[1], language).replace("{0}", config["config"][result[0]]))];
	    }
	}
	else {
		var reason = true;
	}
	return reason;
}

var checkreturn = function(plugininfo, config, lang, language){
	var configcheck = configreturn(plugininfo, config, language);
	var langcheck = langreturn(plugininfo, lang, language);
	var rep = true;
	if(global.getType(configcheck) === "Array"){
		rep = configcheck[1];
	}
	if(global.getType(langcheck) === "Array"){
		rep = langcheck[1];
	}
    return rep;
}

/* 
*put in main.js of plugin*
************************
var PluginName = "";    // plugin_scope in plugins.js
var config = JSON.parse(global.privateFileMap[PluginName]["config"].toString())["config"];
var plugininfo = JSON.parse(global.privateFileMap[PluginName]["plugininfo"].toString());
var lang = JSON.parse(global.privateFileMap[PluginName]["lang"].toString())["lang"];

function onLoad() {
	check();
	if (global.getType(checkstatus) === "object") {
		console.log(checkstatus);
	}
}

var checkstatus;
var check = function(data){
    function requireFromString(src, filename) {
        var Module = module.constructor;
        var m = new Module();
        m._compile(src, filename);
        return m.exports;
    }
	var path = global.nodemodule["path"];
	var func = requireFromString(global.privateFileMap[PluginName]["checker"].toString(),path.join(__dirname, "checker.js"));
	if(data == undefined || data.resolvedLang == undefined){
	    checkstatus = func.checkreturn(plugininfo, JSON.parse(global.privateFileMap[PluginName]["config"].toString()), JSON.parse(global.privateFileMap[PluginName]["lang"].toString()), global.config.language);
	}
	else {
		checkstatus = func.checkreturn(plugininfo, JSON.parse(global.privateFileMap[PluginName]["config"].toString()), JSON.parse(global.privateFileMap[PluginName]["lang"].toString()), data.resolvedLang);
	}
}
************************
*put this on the top of every command func*
************************
if (global.getType(checkstatus) === "Boolean") {
	// func
}
else if(global.getType(checkstatus) === "String"){
	// send error (checkstatus)
}


************************
*put in config.js of plugin*
************************
{
	"config": {
		"x": "60",
		"y": "false"
	},
	"configdes": {
    	"time": [false, false, false, 0],
    	"toggle": [true, true, false, false]
	}
}
**************************
        // check basic: [isNaN, is true/false, <= x , >= y]
    	// isNaN : false to check number, true to check character
    	// is true/fase : true to check true/false, false to none
    	// int < x : number to check the int is < number or not, false to none
    	// int > y : number to check the int is > number or not, false to none
    	// all true to pass the check!
************************
*put in lang.js of plugin*
**************************
{
	"lang": {
		"en_US": {
		    "x": ":( {1}",
    		"y": ":) {1} {0}",
    	},
	    "vi_VN": {
		    "x": ":< {1}",
    		"y": ":> {1} {0}",
	    }
    },
	"langdes": {
		"x": ["{1}"],
	    "y": ["{0}","{1}"],
	}
}
************************
*put in plugins.json (after command_map) of plugin*
************************
"private_file_map": {
        "plugins.json": "plugininfo",
		"checker.js": "checker",
		"config.js": "config",
		"lang.js": "lang"
    },
************************
*/
module.exports = {
	checkreturn
}