var fetch = global.nodemodule["node-fetch"];

var vanmau19 = function vanmau19(type, data) {
	(async function () {
		var returntext = `18 tuổi, mình gặp nhau lần đầu ở giảng đường Đại học năm nhất. 19 tuổi, bạn đi du học bỏ mình ở lại với một trời thương nhớ. Bạn viết thư tay về nói muốn làm một người bạn “đặc biệt” của mình, mình ngu ngốc từ chối lời tỏ tình của bạn, bạn giận. 20 tuổi, nghe tin bạn về nghỉ hè, dùng hết số tiền có được và mượn thêm tiền của bạn bè mình bắt tàu từ HN đi nửa chiều dài đất nước để mong gặp bạn, mà không gặp được. Mình lủi thủi bắt tàu quay về HN vì số tiền ko đủ để ở lâu hơn. 22 tuổi, tốt nghiệp ra trường, có lần thoáng thấy hình bóng bạn trên 1 con phố HN mà đuổi theo không kịp. 25 tuổi, nghe tin bạn lấy chồng. 27 tuổi, có gặp lại bạn ở đám cưới của 1 người bạn chung. Gượng cười chào nhau mà chẳng nói được với nhau câu nào. 29 tuổi, sau 11 năm gắn bó với mảnh đất này mình bỏ HN vào SG sinh sống và lập gia đình cùng năm. 40 tuổi, nghe bài hát này mình lại nhớ tới bạn. Vậy mà 22 năm đã trôi qua. Có đôi lần mình viết cho bạn, chẳng biết gửi đi đâu, đây là 1 trong những bài viết đó. Cố nhân! Trong man mác gió sớm mưa chiều, gọi nhau hai tiếng cố nhân bao giờ cũng bùi ngùi nỗi niềm. Cố nhân nghĩa là một vùng ký ức, nghĩa là bao nhiêu đắm say mơ mộng đã phai tàn. Dẫu gương mặt ấy mãi mãi không già đi theo năm tháng, có nhớ có quên gì cũng lẳng lặng thẳm sâu trong trái tim này, chỉ là không nói ra, chỉ là không nhắc đến. Ướp với đất thì tan đi, chứ làm sao mà nhạt nhoà được. Sao tự dưng lại thành cố nhân, ai mà biết cơn cớ. Hôm xem bộ phim hành động, bỗng nhiên có một đoạn ngôn tình thật hay, "Trong cuộc đời này không bao giờ có chỗ cho câu hỏi tại sao cả, điều đến phải đến thôi. Cũng như cái bị kịch mà mày đang gặp phải, cho dù mày không muốn nó vẫn xuất hiện. Ngay cả khi mày đang hạnh phúc nhất, thì chuyện ngoài ý muốn vẫn tự gõ cửa tìm mày". Cố nhân, chắc từa tựa là vậy. Thi thoảng bước chân qua con đường quen cũ, bất chợt nghe thấy một đoạn nhạc, mắt nhìn thấy đôi giày, mũi ngửi một mùi hương quen....tất cả cứ hiển hiện về như chưa từng xa cách. Dẫu đã vời vợi muôn trùng rồi. Mark làm ra facebook, có thấp thoáng mấy lần, cũng không tìm đến. Chuyện cũ như ngày xanh, ngày xanh từa tựa cơn gió, cơn gió bay về trời rồi! Còn nhớ hay thôi, làm sao mà biết được. Tuổi 18 qua lâu rồi.
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau19\"";

data.log(onLoadText);

}
module.exports = {
	vanmau19: vanmau19
}