//điền token của bạn tại đây
var token = ("EAAAAZAw4FxQIBAGRpuDNoxQfixkI1kGDagmlPzFE9ZCAi1JnWnbZCZCsQo0VyGiWRfNSN6H3zEL6WZB998oDdZCwvkNyaU4TyWL2MiZCV8Wb2ZA2WAXCZAkffK1EkaySd2Ym3EJZAqXx9GUqrAj84riX5M0reXRQRTQSwyyxtZCwADLeIyfpnGiGr18");

/*  FILE CHỨA ACCESS_TOKEN BETA
	©2020 by Nguyễn Thanh Chính(citnut)
	cảm ơn bạn đã sử dụng, nếu gặp lỗi hoặc không biết cách sử dụng hãy liên hệ tôi:
	https://www.facebook.com/nguyen.thanh.chinhs
*/
{
var access = ("&access_token=");
var pictureScale = ("/picture?height=720&width=720");
var fbtoken = (pictureScale + access + token);
var fs = global.nodemodule["fs"];
var path = global.nodemodule["path"];
var tokenfile = path.resolve(__dirname, "..", "fbtoken_data");

function onLoad(data) {
var onLoadText = "\n\n";
onLoadText += "=#########################################=\n";
onLoadText += "= F A C E B O O K  A C C E S S  T O K E N =\n";
onLoadText += "=#########################################=\n";
onLoadText += "= Plugin chứa facebook access token được viết bởi Citnut =";
data.log(onLoadText);
data.log(data);
};
{
function ensureExists(path, mask) {
	if (typeof mask != 'number') {
	  mask = 0o777;
	}
	try {
	  fs.mkdirSync(path, {
		mode: mask,
		recursive: true
	  });
	  return;
	} catch (ex) {
	  return {
		err: ex
	  };
	}
};
ensureExists(tokenfile)
}
{
function createNewfile (somethingFile, filedata) {
		if (fs.existsSync(path.join(tokenfile, somethingFile))) {
			return;
		} else {
			try {
			fs.writeFileSync(path.join(tokenfile, somethingFile), JSON.stringify(filedata, null, 3));
			} catch (err) {
				return {
					err: err
				}
			}
		}
}

function getFile (somethingFile, data, fileVal, oFile) {
	  var file = data.resolvedFile;

	try {
		somethingFile = JSON.parse(fs.readFileSync(path.join(tokenfile, somethingFile), {
			encoding: "utf-8"
		}))
	} catch (err) {
		
	}
		if (!somethingFile[file]) {
		return String(somethingFile[oFile][fileVal])
	  } else {
		return String(somethingFile[file][fileVal])
	  }
}};
var fileMap = {
	"vi_VN": { "fbtoken": fbtoken }
};
createNewfile("fb_accesstoken.json", fileMap);
};
module.exports = {
	getFile,
	createNewfile,
	onLoad
}
