!global.data.picarrow ? global.data.picarrow = {} : "";
var fs = require("fs");
var fetch = global.nodemodule["node-fetch"];
var path = require("path");
var basedir = path.join(__dirname, "..", "PicArrow_storage");
ensureExists(basedir);

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}
var picarrow = function(type, data){

}
var delpicarrow = async function(type, data){
	var word = data.msgdata.body.slice(13, data.msgdata.body.length);
    if(Object.keys(global.data.picarrow[data.msgdata.threadID]).indexOf(word) != -1){
		var dir = path.join(basedir,data.msgdata.threadID,word);
		var result = await fs.promises.rmdir(dir, { recursive: true });
		delete global.data.picarrow[data.msgdata.threadID][word];
		return{
            handler: "internal",
            data: `done`
		}			
	}
	else {
        return{
            handler: "internal",
            data: `undone :)`
		}	
	}		
}

var checkpicarrow = function(type, data){
	!global.data.picarrow[data.msgdata.threadID] ? global.data.picarrow[data.msgdata.threadID] = {} : "";
	var rep = `Những picarrow có trong nhóm:\r\n`;
	if(Object.keys(global.data.picarrow[data.msgdata.threadID]).length == 0){
		rep = `froup bạn chưa có picarrow nào!`;
	}
	for(i=0;i<Object.keys(global.data.picarrow[data.msgdata.threadID]).length;i++){
		var word = Object.keys(global.data.picarrow[data.msgdata.threadID])[i];
		var number = global.data.picarrow[data.msgdata.threadID][word].length;
		rep += `${word}: ${number} ảnh/gif\r\n`;
	}
	return{
		handler: "internal",
		data: rep
	}
}

var chathook = async function(type, data){
	!global.data.picarrow ? global.data.picarrow = {} : "";
	!global.data.picarrow[data.msgdata.threadID] ? global.data.picarrow[data.msgdata.threadID] = {} : "";
	if(data.msgdata.type == "message" || data.msgdata.type == "message_reply"){
	    if(Object.keys(global.data.picarrow[data.msgdata.threadID]).indexOf(data.msgdata.body) != -1){
		    !global.data.picarrow[data.msgdata.threadID][data.msgdata.body] ? global.data.picarrow[data.msgdata.threadID][data.msgdata.body] = [] : "";
		    if(global.data.picarrow[data.msgdata.threadID][data.msgdata.body].length-1 > 0){
			    data.return({
                    handler: "internal",
			        data: {
                        attachment: fs.createReadStream(global.data.picarrow[data.msgdata.threadID][data.msgdata.body][random(0, global.data.picarrow[data.msgdata.threadID][data.msgdata.body].length-1)])
                    }
		        });
		    }
		    else {
		        data.return({
                    handler: "internal",
		    	    data: {
                        attachment: fs.createReadStream(global.data.picarrow[data.msgdata.threadID][data.msgdata.body][0])
                    }
		         });
		    }
		}
	}
	AlowRun = false;
	if(data.msgdata.type == "message" || data.msgdata.type == "message_reply"){
    	if(data.msgdata.body.indexOf(global.config.commandPrefix+"picarrow") == 0){
    	    if(data.msgdata.type == "message_reply"){
    		    if(data.msgdata.messageReply.attachments != undefined && data.msgdata.messageReply.attachments.length >=1){
    			    var word = data.msgdata.body.slice(10, data.msgdata.body.length);
    			    if( word != "" && word != " " ){
    			        var NotAlowedCharacter = `”*:<>?/\|~”#%&*:<>?/\{|}.`;
    				    var NotAlowedName = ["AUX", "PRN", "NUL", "CON", "COM0", "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9", "LPT0", "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"];
    				   for(i=0;i<NotAlowedCharacter.length;i++){
    					   if(word.indexOf(NotAlowedCharacter[i]) != -1){
    					    	data.return({
                                    handler: "internal",
                                    data: `key không được có ký tự ${NotAlowedCharacter[i]}`
		                        });
				    	    	return false;
					        }
    				    }    
	    			    for(i=0;i<NotAlowedName.length;i++){
		    			    if(word == NotAlowedName[i]){
			    		    	data.return({
                                    handler: "internal",
                                    data: `key không được giống ${NotAlowedName[i]}`
		                        });
					    	    return false;
    					    }    
		    		    }
			    	    if(word.length > 50){
				    	    data.return({
                                handler: "internal",
                                data: `key không được dài hơn 50 ký tự`
    		                });
	    		    		return false;
		    	    	}
			        	!global.data.picarrow[data.msgdata.threadID][word] ? global.data.picarrow[data.msgdata.threadID][word] = [] : "";
			        	for(i=0;i<data.msgdata.messageReply.attachments.length;i++){
			    	    	var dir = path.join(basedir,data.msgdata.threadID,word);
			    		    var url = data.msgdata.messageReply.attachments[i].url;
			    		    ensureExists(dir);
    			    		var fetchResult = await fetch(url);
	    					var filetail;
		    				switch (data.msgdata.messageReply.attachments[i].type){
			    			    case "video":
				    			    filetail = ".mp4";
					    		    break;
						    	case "animated_image":
							        filetail = ".gif";
							        break;
        							case "photo":
		    					    filetail = ".png";
			    					break;
				    			default:
					    		    data.return({
						    			handler: "internal",
							    		data: "picarrow chỉ nhận ảnh, video hoặc gif"
								    });
    								return true;
	    					}
		    	    		fs.writeFileSync(path.join(dir,`${global.data.picarrow[data.msgdata.threadID][word].length}${filetail}`), await fetchResult.buffer());
		                    global.data.picarrow[data.msgdata.threadID][word].push(path.join(dir,`${global.data.picarrow[data.msgdata.threadID][word].length}${filetail}`));
			        	}
			    	    data.return({
                            handler: "internal",
                            data: "Done!"
		                });
			        	return true;
			        }
    			    else{
	    		    	data.return({
                            handler: "internal",
                            data: "Too few args!"
		                });
			        }
    		    }
	    		else {
		    		data.return({
			            handler: "internal",
                        data: "reply with a picture or gif for picarrow to work!"
		            });
    			}
	        }
		    else{ 
		        data.return({
			        handler: "internal",
                    data: "reply with a picture or gif for picarrow to work!"
		        });
    		}
	    }
	}
	return false;
}

var random = function(min, max) { 
	return global.plugins.librandom.getRandomNumber(min, max, 0);
};

module.exports = {
	picarrow,
	delpicarrow,
	checkpicarrow,
	chathook
}