!global.data.cacheName ? global.data.cacheName = {} : "";
!global.data.ban ? global.data.ban = [] : "";
var ban = function(type, data){}
var unban = function(type, data){}
var banlist = function(type, data){
	var user = global.data.ban.filter(x => x.length <= 15);
	var group = global.data.ban.filter(x => x.length == 16);
	var rep = "";
	for(i=0;i<user.length;i++){
		rep += ((i==0) ? "USER: " : "") + `\n    ${global.data.cacheName["FB-"+user[i]]} (${user[i]})` + ((i == user.length-1) ? "\n" : ", " );
	}
	for(i=0;i<group.length;i++){
		console.log(group, group[i], "FB-"+group[i], global.data.cacheName["FB-5450984831641837"]);
		rep += ((i==0) ? "GROUP: " : "") + `\n    ${global.data.cacheName["FB-"+group[i]]} (${group[i]})` + ((i == group.length-1) ? "\n" : ", " );
	}
	return{
		handler: "internal",
		data: ((user.length == 0 && group.length == 0) ? "none" : rep)
	}
}
var chathook = function(type, data){
	if(data.msgdata.type == "message"){
		if(global.config.admins.indexOf("FB-"+data.msgdata.senderID) != -1){
			if(data.msgdata.body.indexOf(`${global.config.commandPrefix}ban `) != -1 || data.msgdata.body == `${global.config.commandPrefix}ban`){
				if(data.msgdata.senderID != data.facebookapi.getCurrentUserID()){
					if(data.msgdata.type == "message_reply"){
						var uid = `${data.msgdata.messageReply.senderID}`;
					}
					else {
						var IDs = Object.keys(data.msgdata.mentions);
						if(IDs.length >= 1){
							var uid = IDs;
						}
						else {
							var msg = data.msgdata.body.split(" ");
							if(msg.length == 1){
								var uid = `${data.msgdata.threadID}`;
							}
							else if(msg.length == 2){
								var xuid = msg[1];
								if(Number(xuid) != NaN){
									var uid = xuid;
								}
								else {
									data.return({
										handler: "internal",
										data: "UID không tồn tại!"
									});
								}
							}
							else {
								data.return({
									handler: "internal",
									data: "Chỉ được điền 1 UID"
								});
							}
						}
					}
					if(typeof uid == 'string'){
						var group = "Group " + global.data.cacheName["FB-"+uid] + " (" + uid + ") đã bị ban!";
						var user = "User " + global.data.cacheName["FB-"+uid] + " (" + uid + ") đã bị ban!";
						if(global.data.ban.indexOf(uid) == -1 && global.config.admins.indexOf("FB-"+uid) == -1 && uid != data.facebookapi.getCurrentUserID()){
							global.data.ban.push(uid);
						}
						data.return({
							handler: "internal",
							data: ((uid.length == 16) ? group : user)
						});
					}
					if(typeof uid == "object"){
						var rep = "";
						for(i=0;i<uid.length;i++){
							rep += ((i == 0) ? "User": "") + ` ${global.data.cacheName["FB-"+uid[i]]} (${uid[i]})` + ((uid.length > 1 && i != uid.length-1) ? ", " : " ") + ((i == uid.length-1) ? "đã bị ban" : "");
							if(global.data.ban.indexOf(uid[i]) == -1 && global.config.admins.indexOf("FB-"+uid[i]) == -1 && uid[i] != data.facebookapi.getCurrentUserID()){
								global.data.ban.push(uid[i]);
							}
						}
						data.return({
							handler: "internal",
							data: rep
						});
								
					}
				}
			}
			
			if(data.msgdata.body.indexOf(`${global.config.commandPrefix}unban `) != -1 || data.msgdata.body == `${global.config.commandPrefix}unban`){
				if(data.msgdata.senderID != data.facebookapi.getCurrentUserID()){
					if(data.msgdata.type == "message_reply"){
						if(data.msgdata.messageReply.senderID != data.facebookapi.getCurrentUserID()){
							var uid = `${data.msgdata.messageReply.senderID}`;
						}
					}
					else {
						var IDs = Object.keys(data.msgdata.mentions);
						if(IDs.length >= 1){
							var uid = IDs;
						}
						else if(data.msgdata.body == `${global.config.commandPrefix}unban all`){
							global.data.ban.splice(0, global.data.ban.length);
							data.return({
								handler: "internal",
								data: "Đã unban tất cả!"
							});
						}
						else {
							var msg = data.msgdata.body.split(" ");
							if(msg.length == 1){
								var uid = `${data.msgdata.threadID}`;
							}
							else if(msg.length == 2){
								var xuid = msg[1];
								if(Number(xuid) != NaN){
									var uid = xuid;
								}
								else {
									data.return({
										handler: "internal",
										data: "UID không tồn tại!"
									});
								}
							}
							else {
								data.return({
									handler: "internal",
									data: "Chỉ được điền 1 UID"
								});
							}
						}
					}
					if(typeof uid == 'string'){
						var group = "Group " + global.data.cacheName["FB-"+uid] + " (" + uid + ") đã được unban!";
						var user = "User " + global.data.cacheName["FB-"+uid] + " (" + uid + ") đã được unban!";
						if(global.data.ban.indexOf(uid) != -1){
							global.data.ban.splice(global.data.ban.indexOf(uid), 1);
						}
						data.return({
							handler: "internal",
							data: ((uid.length == 16) ? group : user)
						});
					}
					if(typeof uid == "object"){
						var rep = "";
						for(i=0;i<uid.length;i++){
							rep += ((i == 0) ? "User": "") + ` ${global.data.cacheName["FB-"+uid[i]]} (${uid[i]})` + ((uid.length > 1 && i != uid.length-1) ? ", " : " ") + ((i == uid.length-1) ? "đã được unban" : "");
							if(global.data.ban.indexOf(uid[i]) != -1){
								global.data.ban.splice(global.data.ban.indexOf(uid[i]), 1);
							}
						}
						data.return({
							handler: "internal",
							data: rep
						});
								
					}
				}
			}
		}
	}
	if(global.data.ban.indexOf(data.msgdata.threadID) != -1 && global.config.admins.indexOf("FB-"+data.msgdata.senderID) == -1){
			return true;
	}
}

module.exports = {
	ban,
	unban,
	banlist,
	chathook
}