var fs = require('fs');
var path = require('path');
var dir = path.join(path.dirname(__dirname),'SSIT','inputdata.txt');
var search = function(type, data){
	var allowRun = true;
	if(!fs.existsSync(dir)){
		fs.mkdirSync(path.dirname(dir));
		fs.writeFileSync(dir,'');
		allowRun = false;
		return {
				handler: "internal",
		   	    data: "the sys detect that the forder do not have any file named (inputdata.txt), please create ones then write the text in it!"
			}
	}
	if(allowRun = true){	
		if(fs.readFileSync(dir,'utf8') == ""){
			return {
				handler: "internal",
		   	    data: "inputdata.txt is emty, please write the text in it!"
			}
		}
		var pagram = fs.readFileSync(dir,'utf8');
		if((data.msgdata.body).slice(7, (data.msgdata.body).length) == ""){
			return {
				handler: "internal",
		   	    data: "too few args!"
			}
		}
		var word = ((data.msgdata.body).slice(7, (data.msgdata.body).length)).toLowerCase();
		var rawsentense = pagram.split("\r\n");
		var sentense = [];
		for (i = 0; i < (rawsentense.length-1); i++){
			if(isEven(i)){
				sentense.push(rawsentense[i]);
			}
		}	
		var dataout;
		for(i = 0; i < sentense.length; i++){
			if((sentense[i].toString()).indexOf(word) !=-1){
				if(dataout != undefined){
				    dataout += sentense[i]+"\r\n";
				} 
				else { 
				    dataout = sentense[i]+"\r\n";
				}
			}
		}
		if(dataout == undefined){
			dataout = "null!";
		}
		return {
				handler: "internal",
		   	    data: "công thức gồm:\r\n"+dataout
		}
	}
}
function isEven(value){
	if(value%2 == 0)
		return true;
	else
		return false;
}
module.exports = {
    search
}