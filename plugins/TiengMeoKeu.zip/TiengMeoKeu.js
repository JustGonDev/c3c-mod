var deasync = global.nodemodule.deasync;

var pingtime = {};
let xyz = "\u200F\u200B\u200F\u200BHnay Po Sẽ Dạy Các Bạn Học Tiếng Mèo Kêu Nhé\u200F\u200B\u200F\u200B";

var tiengmeokeu = async function (type, data) {
	switch (type) {
		case "Facebook":
			pingtime["FB-" + data.msgdata.threadID] = {};
			var etime = Date.now();
			pingtime["FB-" + data.msgdata.threadID].etime = etime;
			data.facebookapi.sendMessage(xyz, data.msgdata.threadID, function (err) {
				if (err) {
					return data.return({
						handler: "internal",
						data: `Không Dạy Nữa.`
					});
				}
				var stime = Date.now();
				var CS = stime - etime;
				pingtime["FB-" + data.msgdata.threadID].cs = CS;
			}, null, data.msgdata.isGroup);
			break;
		case "Discord":
			pingtime["DC-" + data.msgdata.channel.id] = {};
			var etime = Date.now();
			pingtime["DC-" + data.msgdata.channel.id].etime = etime;
			try {
				await data.msgdata.channel.send(xyz);
				var stime = Date.now();
				var CS = stime - etime;
				pingtime["DC-" + data.msgdata.channel.id].cs = CS;
			} catch (_) {
				return data.return({
					handler: "internal",
					data: `Không Dạy Nữa.`
				});
			}
	}
}

var chathook = function (type, data) {
	switch (type) {
		case "Facebook":
			switch (data.msgdata.type) {
				case "message":
					if (
						data.msgdata.body === xyz && 
						data.msgdata.senderID === data.facebookapi.getCurrentUserID()
					) {
						var rectime = Date.now();
						deasync.loopWhile(function () {
							return (typeof pingtime["FB-" + data.msgdata.threadID].cs === "undefined");
						});
						data.return({
							handler: "internal",
							data: `Mèo Méo Meo Mèo Meo Nghe Để Học Tập Và Làm Theo Lời Bo Dạy Nha Moa (MP4:https://bitly.com.vn/ZPbZe MP3:https://bitly.com.vn/kxSmR)`
						});
					}
			}
			break;
		case "Discord":
			if (
				data.msgdata.content === xyz && 
				data.msgdata.author.id === data.discordapi.user.id
			) {
				var rectime = Date.now();
				deasync.loopWhile(function () {
					return (typeof pingtime["DC-" + data.msgdata.channel.id].cs === "undefined");
				});
				data.msgdata.edit(`OK! ${rectime - pingtime["DC-" + data.msgdata.channel.id].etime}ms (API: ${pingtime["DC-" + data.msgdata.channel.id].cs}ms)`);
			}
			break;
	}
}

module.exports = {
	tiengmeokeu: tiengmeokeu,
	chathook: chathook
}