var fetch = global.nodemodule["node-fetch"];

var vutru_get = function vutru_get(type, data) {
	(async function () {
		var returntext = `Vũ trụ\nVũ trụ bao gồm tất cả các vật chất, năng lượng và không gian hiện có, được coi là một tổng thể. Vũ trụ hiện tại chưa xác định được kích thước, nó đã được mở rộng kể từ khi thành lập ở Big Bang khoảng 13 tỷ năm trước.\nHình học: Hầu như phẳng với sai số biên chỉ 0,4%\nKhối lượng (vật chất thường): Ít nhất 1053 kg\nMật độ trung bình: 4,5 x 10−31 g/cm3\nNhiệt độ trung bình: 2,72548 K\nCác thành phần chính: Vật chất (baryon) thường (4,9%), vật chất tối (26,8%), năng lượng tối (68,3%)\nTuổi: 13,799 ± 0,021 tỷ năm`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	vutru_get: vutru_get
}