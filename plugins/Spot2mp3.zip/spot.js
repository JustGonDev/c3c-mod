module.exports = {
	spot2mp3 : async function (event, data) {
    var fs = require("fs")
    var path = require("path")

    const ffmpegPath = require('@ffmpeg-installer/ffmpeg').path;
    const ffmpeg = require('fluent-ffmpeg');
    ffmpeg.setFfmpegPath(ffmpegPath);

    var arg = data.args;

    const Spotify = global.nodemodule['spotifydl-core'].default

    const credentials = {
        clientId: '97c3e7bd62554a2089e037cb7c1f8836',
        clientSecret: 'b6609e7258154766822ca43565fa8932'
    }
    const spotify = new Spotify(credentials)
if(!arg[1]) {
    return data.sendMessage("Vui lòng nhập link nhạc Spotify!")
}
    await spotify.downloadTrack(arg.join(" "), file_name = path.join(__dirname, 'spotify.mp3'))
    
try {
    var msgs = "";
    var song = event.attachments
    for (let i of song) if (i.description == null) {
        msgs+= `${i.title}`;
    } else {msgs+= `${i.title + ' - ' + i.description}`;
}
    data.sendMessage({body : `${msgs}`, attachment: fs.createReadStream(path.join(__dirname, 'spotify.mp3'))}, event.threadID, () => fs.unlinkSync(path.join(__dirname, 'spotify.mp3')), event.messageID)
} catch(error) {
    data.sendMessage(error, event.threadID, event.messageID)
}

}
}