!global.data.GoogleTranslate ? global.data.GoogleTranslate = {}: "";

const googleTranslate = global.nodemodule["@kaysilvn/google-translate-api"];
const gTranslate = new googleTranslate().translate;

var changeLangFunc = function(type, data) {
    !global.data.GoogleTranslate[data.msgdata.senderID] ? global.data.GoogleTranslate[data.msgdata.senderID] = {}: ""; 
    !global.data.GoogleTranslate[data.msgdata.senderID]["src_lang"] ? global.data.GoogleTranslate[data.msgdata.senderID]["src_lang"] = data.resolvedLang.slice(0, 2): ""; 
    !global.data.GoogleTranslate[data.msgdata.senderID]["tar_lang"] ? global.data.GoogleTranslate[data.msgdata.senderID]["tar_lang"] = "en": ""; 
    
    let args = data.args;
        args.shift();
    if (args[0]) args[0] = args[0].toLowerCase();

    switch (args[0]) {
        case "source":
        case "src":
            if (!args[1]) return data.return({
                handler: "internal",
                data: "Missing arguments"
            });
            global.data.GoogleTranslate[data.msgdata.senderID]["src_lang"] = args[1].toLowerCase();

            return data.return({
                handler: "internal",
                data: "✔ Changed your source language to " + args[1]
            })
            break;
        case "target":
        case "tar":
            if (!args[1]) return data.return({
                handler: "internal",
                data: "Missing arguments"
            });
            global.data.GoogleTranslate[data.msgdata.senderID]["tar_lang"] = args[1].toLowerCase();
            
            return data.return({
                handler: "internal",
                data: "✔ Changed your target language to " + args[1]
            })
            break;
    }
}

var translateFunc = async function(type, data) {
    !global.data.GoogleTranslate[data.msgdata.senderID] ? global.data.GoogleTranslate[data.msgdata.senderID] = {}: ""; 
    !global.data.GoogleTranslate[data.msgdata.senderID]["src_lang"] ? global.data.GoogleTranslate[data.msgdata.senderID]["src_lang"] = data.resolvedLang.slice(0, 2): ""; 
    !global.data.GoogleTranslate[data.msgdata.senderID]["tar_lang"] ? global.data.GoogleTranslate[data.msgdata.senderID]["tar_lang"] = "en": ""; 

    let args = data.args;
        args.shift();

    if (args.join(" ") === "") return data.return({
        handler: "internal",
        data: "Nothing to translate!"
    });

    let text; 

    try {
        data.return({
            handler: "internal",
            data: "Translating..."
        });
        text = await gTranslate(args.join(" "), { src_lang: global.data.GoogleTranslate[data.msgdata.senderID]["src_lang"], tar_lang: global.data.GoogleTranslate[data.msgdata.senderID]["tar_lang"] });
    } catch (err) {
        data.return({
            handler: "internal",
            data: "Error when translating..."
        });

        data.log(err);
    }

    data.return({
        handler: "internal",
        data: "✔ " + text
    });
}

module.exports = {
    ggt: translateFunc,
    ggtConfig: changeLangFunc
}