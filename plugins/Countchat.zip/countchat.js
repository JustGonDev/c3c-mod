// *lang*
var langMap = {
	"en_US": {                                                                                   //       *defautl lang for en_US*
		"AdminOnly": "Admin only!",                                                              //    "AdminOnly": "Admin only!"
		"SuccessfulStart": "Countchat started successfully!",                                    //    "SuccessfulStart": "Countchat started successfully!"
		"SuccessfulStop": "Countchat stopped successfully!",                                     //    "SuccessfulStop": "Countchat stopped successfully!"
		"SuccessfulReset": "Reset countchat successfully!",                                      //    "SuccessfulReset": "Reset countchat successfully!"
		"CountchatNotStart": "Countchat has not been started!",                                  //    "CountchatNotStart": "Countchat has not been started!"
		"Messages": "message(s)",                                                                //    "Messages": "message(s)"
		"At": "At",                                                                              //    "At": "At"
		"day": '["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]', //    "day": '["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]'
		"SuccessfulSave": "Countchat saved successfully!",                                       //    "SuccessfulSave": "Countchat saved successfully!"
		"NoSave": "Countchat has not been saved yet!",                                           //    "NoSave": "Countchat has not been saved yet!"
		"SaveCount": "This is a countchat version saved on"                                      //    "SaveCount": "This is a countchat version saved on"
	},
	"vi_VN": {                                                                                   //        *defautl lang for vi_VN*
		"AdminOnly": "Chỉ admin mới được dùng!",                                                 //    "AdminOnly": "Chỉ admin mới được dùng!"
		"SuccessfulStart": "Countchat đã khởi động thành công!",                                 //    "SuccessfulStart": "Countchat đã khởi động thành công!"
		"SuccessfulStop": "Countchat đã ngưng hoạt động!",                                       //    "SuccessfulStop": "Countchat đã ngưng hoạt động!"
		"SuccessfulReset": "Countchat đã thiết lập lại thành công!",                             //    "SuccessfulReset": "Countchat đã thiết lập lại thành công!"
		"CountchatNotStart": "Countchat chưa hoạt động!",                                        //    "CountchatNotStart": "Countchat chưa hoạt động!"
		"Messages": "tin nhắn",                                                                  //    "Messages": "tin nhắn"
		"At": "lúc",                                                                             //    "At": "lúc"
		"day": '["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"]',   //    "day": '["Chủ nhật", "Thứ hai", "Thứ ba", "Thứ tư", "Thứ năm", "Thứ sáu", "Thứ bảy"]'
		"SuccessfulSave": "Countchat đã lưu thành công!",                                        //    "SuccessfulSave": "Countchat đã lưu thành công!"
		"NoSave": "Countchat chưa được lưu!",                                                    //    "NoSave": "Countchat chưa được lưu!"
		"SaveCount": "Đây là bản countchat được lưu vào"                                         //    "SaveCount": "Đây là bản countchat được lưu vào"
	}
}

// *require stuff*
!global.data.countchat ? global.data.countchat = {} : "";
!global.data.countchat.realtimedata ? global.data.countchat.realtimedata = {} : "";
!global.data.countchat.save ? global.data.countchat.save = {} : "";
!global.data.countchat.save.times ? global.data.countchat.save.times = {} : "";
!global.data.countchat.active ? global.data.countchat.active = [] : "";

// *lang stuff*
var getLang = function () {}
var onLoad = function (data) {
	getLang = function (langVal, lang) {
	    if (langMap[lang]) {
		    return String(langMap[lang][langVal]);
	    } else {
		    return String((langMap["en_US"] || {})[langVal]);
	    }
	}
}

// *togglecount*
var toggle = async function(type, data){
    var threadInfo = await data.facebookapi.getThreadInfo(data.msgdata.threadID);
    var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
    var isAdminGroup = adminIDs.indexOf(data.msgdata.senderID) != -1;
	if (isAdminGroup) {
	    if(global.data.countchat.active.indexOf(data.msgdata.threadID) == -1) {
	        var participantIDs = threadInfo.participantIDs;
            if (typeof global.data.countchat.realtimedata[data.msgdata.threadID] != "object" || Array.isArray(global.data.countchat.realtimedata[data.msgdata.threadID])) {
                global.data.countchat.realtimedata[data.msgdata.threadID] = participantIDs.reduce((a, id) => ({
                    [id]: 0,
                    ...a
                }), {});
            } else {
                participantIDs.forEach(v => {
                    if (
                        typeof global.data.countchat.realtimedata[data.msgdata.threadID][v] != "number" ||
                        isNaN(global.data.countchat.realtimedata[data.msgdata.threadID][v])
                    ) {
                        global.data.countchat.realtimedata[data.msgdata.threadID][v] = 0;
                    }
                });
            }
		    global.data.countchat.active.push(data.msgdata.threadID);
			return {
	    		handler: "internal",
	    		data: getLang("SuccessfulStart", data.resolvedLang)
	    	}
		} else {
			removeA(global.data.countchat.active, data.msgdata.threadID);
            return {
    			handler: "internal",
    			data: getLang("SuccessfulStop", data.resolvedLang)
    		}
		}
	} else {
    	return {
    		handler: "internal",
  			data: getLang("AdminOnly", data.resolvedLang)
    	}
	}
}

// *resetcount*
var reset = async function (type, data){
	var threadInfo = await data.facebookapi.getThreadInfo(data.msgdata.threadID);
    var adminIDs = threadInfo.adminIDs.map(x => x.id.toString());
    var isAdminGroup = adminIDs.indexOf(data.msgdata.senderID) != -1;
    if (isAdminGroup) {
	    if (global.data.countchat.realtimedata[data.msgdata.threadID] != undefined) {
			data.return({
				handler: 'internal',
				data: getLang("SuccessfulReset", data.resolvedLang)
			});
			var participantIDs = threadInfo.participantIDs;
    	    global.data.countchat.realtimedata[data.msgdata.threadID] = participantIDs.reduce((a, id) => ({
                [id]: 0,
                ...a
            }), {});
	    } else {
            return {
			    handler: "internal",
			    data: getLang("CountchatNotStart", data.resolvedLang)
		    }			
	    }
	} else {
    	return {
    		handler: "internal",
  			data: getLang("AdminOnly", data.resolvedLang)
    	}
	}
}

// *count* 
var show = async function (type, data){
	var IDs = [];
    for (var y in data.mentions) {
        IDs.push(y.substr(3));    
	}
	if (!global.data.countchat.realtimedata[data.msgdata.threadID]){
	    return {
			handler: "internal",
			data: getLang("CountchatNotStart", data.resolvedLang)
		}
	}
    if (IDs.length != 0){
		var thread = global.data.countchat.realtimedata[data.msgdata.threadID];
		var speech = "\n";
		for (let i in IDs){
			var cname = global.data.cacheName["FB-" + IDs[i]];
			var turn = thread[IDs[i]];
			var data = `${cname}: ${turn} ${getLang("Messages", data.resolvedLang)}\n`;
	    	speech = speech + data;
		}
		return {
			handler: "internal",
			data: speech
		}
	} else {
	    if (data.args[1] == "all") {
		    IDs = Object.keys(global.data.countchat.realtimedata[data.msgdata.threadID]);
    		var thread = global.data.countchat.realtimedata[data.msgdata.threadID];
			var speech = "\n";
			var message = getLang("Messages", data.resolvedLang);
	    	for (let i in IDs){
		    	var cname = global.data.cacheName["FB-" + IDs[i]];
			   	var turn = thread[IDs[i]];
			    var data = `${cname}: ${turn} ${message}\n`;
				speech = speech + data;
    		}
			return {
			    handler: "internal",
			    data: speech
		    }
	    } else {
		    var thread = global.data.countchat.realtimedata[data.msgdata.threadID];
    		var cname = global.data.cacheName["FB-" + data.msgdata.senderID];
	    	var turn = thread[data.msgdata.senderID];
		    var speech = `\r\n${cname}: ${turn} ${getLang("Messages", data.resolvedLang)}`;
			return {
			    handler: "internal",
			    data: speech
		    }
	    }
    }
}	
	
// *savecount*
var save = async function (type, data){
	var d = new Date();
    var hours = d.getHours();	
	var day = d.getDay();
	var date = d.getDate();
	var month = d.getMonth();
	var monthyear = month+1;
	var minutes = d.getMinutes();
	var maindate = [day, date, monthyear, hours, minutes];	
	if (!global.data.countchat.realtimedata[data.msgdata.threadID])
		return {
			handler: "internal",
			data: getLang("CountchatNotStart", data.resolvedLang)
		}

	var backup = global.data.countchat.realtimedata[data.msgdata.threadID];
	global.data.countchat.save[data.msgdata.threadID] = JSON.parse(JSON.stringify(backup));
	global.data.countchat.save.times[data.msgdata.threadID] = maindate;
	return {
	    handler: 'internal',
	    data: getLang("SuccessfulSave", data.resolvedLang)
	}
}	

// *opensavecount*
var opensave = async function (type, data){
	if (!global.data.countchat.save[data.msgdata.threadID]) {
		return{
		    handler: 'internal',
		    data: getLang("NoSave", data.resolvedLang)
	    }
	}
	var IDs = Object.keys(global.data.countchat.save[data.msgdata.threadID]);
    var thread = global.data.countchat.save[data.msgdata.threadID];
	var date = global.data.countchat.save.times[data.msgdata.threadID];
	var message = getLang("Messages", data.resolvedLang);
	var speech = `${getLang("SaveCount", data.resolvedLang)} ${JSON.parse(getLang("day", data.resolvedLang))[date[0]]}, ${date[1]}/${date[2]} ${getLang("At", data.resolvedLang)} ${date[3]}:${date[4]} :\n`;
	for (let i in IDs){
	    var cname = global.data.cacheName["FB-" + IDs[i]];
	    var turn = thread[IDs[i]];
		var data = `\n${cname}: ${turn} ${message}`;
		speech = speech + data;
    }
	return {
		handler: "internal",
		data: speech
	}
}
	
var chathook = function (type, data){
	if (data.msgdata.type == "message" || data.msgdata.type == "message_reply") {
		if (global.data.countchat.active.indexOf(data.msgdata.threadID) + 1){
			!global.data.countchat.realtimedata[data.msgdata.threadID] ? global.data.countchat.realtimedata[data.msgdata.threadID] = {} : "";
			if (typeof global.data.countchat.realtimedata[data.msgdata.threadID][data.msgdata.senderID] != "number") {
				global.data.countchat.realtimedata[data.msgdata.threadID][data.msgdata.senderID] = 0;
			}
			global.data.countchat.realtimedata[data.msgdata.threadID][data.msgdata.senderID] += 1;
		}
	}
}

function removeA(arr) {
    var what, a = arguments, L = a.length, ax;
    while (L > 1 && arr.length) {
        what = a[--L];
        while ((ax= arr.indexOf(what)) !== -1) {
            arr.splice(ax, 1);
        }
    }
    return arr;
}

module.exports = {
	onLoad,
	toggle,
	chathook,
	reset,
	show,
	save,
	opensave
}