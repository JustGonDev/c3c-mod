var fetch = global.nodemodule["node-fetch"];

var vanmau23 = function vanmau23(type, data) {
	(async function () {
		var returntext = `chỉ với một tiếng ''Gà'' mà nó đã khiến trái tim toi thổn thức, muốn vỡ ra làm từng mảnh, khóe mắt muốn ứa lệ... Sao ông lại có thể nặng lời với tôi như thế, ông thật phũ phàng, ông có biết lời nói của ông như con dao đâm vào trái tym mỏng manh íu đíu này hiccc
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau23\"";

data.log(onLoadText);

}
module.exports = {
	vanmau23: vanmau23
}