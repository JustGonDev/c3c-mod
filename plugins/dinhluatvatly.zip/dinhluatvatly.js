var fetch = global.nodemodule["node-fetch"];

var dinhluatvatly = function dinhluatvatly(type, data) {
	(async function () {
		var returntext = `Định Luật Ôm và Điện Trở Của Dây Dẫn
Cường độ dòng điện chạy qua dây dẫn tỉ lệ thuận với hiệu điện thế đặt vào hai đầu dây tỷ lệ nghịch với điện trở của dây : I = U/R
*trong đó: I đo bằng ampe 
           U đo bằng vôn
           R đo bằng ôm
Điện trở của một dây dẫn được xác định bằng công thức : R = U/I`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"dinhluatvatly\"Minh Mẫn";

data.log(onLoadText);

}
module.exports = {
	dinhluatvatly: dinhluatvatly
}