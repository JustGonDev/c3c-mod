var fetch = global.nodemodule["node-fetch"];

var TinhYeu_get = function TinhYeu_get(type, data) {
	(async function () {
        var returntext = `Tình yêu, hay ái tình, là một loạt các cảm xúc, trạng thái tâm lý, và thái độ khác nhau dao động từ tình cảm cá nhân đến niềm vui sướng. Tình yêu thường là một cảm xúc thu hút mạnh mẽ và nhu cầu muốn được ràng buộc gắn bó 
        Nhớ HỌC Đê chứ Đừng yêu Mi Chả Đương Khỏi Mất Lòng Bố Mẹ vì Bố mẹ cố gắng làm việc để nuôi Bọn mình đấy Nên tôn trọng bố mẹ Bỏ yêu Đương ADMIN.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	TinhYeu_get: TinhYeu_get
}