var fetch = global.nodemodule["node-fetch"];

var sao_get = function sao_get(type, data) {
	(async function () {
		var returntext = `Sao, định tinh, hay hằng tinh là một quả cầu plasma sáng, khối lượng lớn được giữ bởi lực hấp dẫn. Ngôi sao gần Trái Đất nhất là Mặt Trời, nó là nguồn của hầu hết năng lượng trên Trái Đất. Nhiều ngôi sao khác có thể nhìn thấy được trên bầu trời đêm, khi chúng không bị lu mờ đi dưới ánh sáng của Mặt Trời. Về mặt lịch sử, hầu hết các ngôi sao sáng và nhìn thấy bằng mắt thường nằm trên thiên cầu được nhóm lại cùng nhau thành các chòm sao và các mảng sao, và những ngôi sao sáng nhất đều được đặt những tên gọi riêng. Các danh mục sao mở rộng đã được các nhà thiên văn lập nên, cung cấp các cách định danh sao theo tiêu chuẩn hóa.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	sao_get: sao_get
}