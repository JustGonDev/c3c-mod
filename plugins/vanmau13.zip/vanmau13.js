var fetch = global.nodemodule["node-fetch"];

var vanmau13 = function vanmau13(type, data) {
	(async function () {
		var returntext = `chị ơi chị làm trò khùng điên bú fame BTS hoài vậy?chị không biết cách dùng instagram một cách văn minh à? chị đừng trách sao nước biển lại mặn, con cu lại nghe mùi nước đái nha. em đã chụp hình instagram của chị rồi. Ngày mai ảnh này sẽ có mặt ở trên mail em gửi tới Big Hit Entertainment vì tội làm trò bú fame BTS trên mạng xã hội. Em cho chị cơ hội, chị hãy xoá status này đi và hãy đăng những câu chuyện về BTS và trở thành army thì chị sẽ được bình yên. Còn không thì ngày mai em với chị hẹn nhau ở đồn cảnh sát
		`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"vanmau13\"";

data.log(onLoadText);

}
module.exports = {
	vanmau13: vanmau13
}