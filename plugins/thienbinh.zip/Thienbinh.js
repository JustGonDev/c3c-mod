var fetch = global.nodemodule["node-fetch"];

var ThienBinh_get = function ThienBinh_get(type, data) {
	(async function () {
		var returntext = `Thiên Bình, hay còn gọi là Thiên Xứng, là một cung trong 12 cung hoàng đạo tương ứng với chòm sao Thiên Bình, bao gồm những người sinh trong khoảng, thường biểu hình bằng hình cái cân.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	ThienBinh_get: ThienBinh_get
}