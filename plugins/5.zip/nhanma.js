var fetch = global.nodemodule["node-fetch"];

var NhanMa_get = function NhanMa_get(type, data) {
	(async function () {
        var returntext = `Nhân Mã là dấu hiệu chiêm tinh thứ chín, được liên kết với chòm sao Nhân Mã và trải dài 240–270 độ của hoàng đạo. Dưới cung hoàng đạo nhiệt đới, mặt trời đi qua dấu hiệu này trong khoảng từ ngày 23 tháng 11 đến ngày 21 tháng 12. Thần thoại Hy Lạp liên kết Nhân mã với nhân mã Chiron, người đã dìu dắt Achilles, một anh hùng Hy Lạp trong Chiến tranh thành Troy, trong môn bắn cung.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	NhanMa_get: NhanMa_get
}