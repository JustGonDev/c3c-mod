var fetch = global.nodemodule["node-fetch"];

var phepnhan2 = function phepnhan2(type, data) {
	(async function () {
		var returntext = `Bảng cửu chương 2
2 x 1 = 2
2 x 2 = 4 
2 x 3 = 6 
2 x 4 = 8
2 x 5 = 10
2 x 6 = 12
2 x 7 = 14
2 x 8 = 16
2 x 9 = 18
2 x 10 = 20`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"phepnhan2\"mod lại của by Wua'n";

data.log(onLoadText);

}
module.exports = {
	phepnhan2: phepnhan2
}