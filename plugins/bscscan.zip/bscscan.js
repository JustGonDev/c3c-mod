var request = global.nodemodule["sync-request"]
var apikey = ["11ZMWNGPT2D66XIIBIKIVN1RDBRT63P6XC","PQ5SHKDKI47CUW7SGF2DJIFM6F1P4TTKCR","9WX99E9A3DK3P8Y26NAX1C6U3PYRHVQJ3D"];
var bscscan = function(type,data) {
    var bsc = encodeURIComponent(data.args.slice(1).join(" "))
    var reply
    switch(bsc){
        case "":
            reply = global.config.commandPrefix+"bscscan <address>"
            break;
        default:
            switch(apikey){
                case "":
                    reply = "No API Key, lol"
                    break;
                default:
                    var api = `https://api.bscscan.com/api?module=account&action=balance&address=${bsc}&tag=latest&apikey=${apikey[Math.floor(Math.random() * apikey.length)]}`
                    var bufferdata = request("GET",api);
                    var stringdata = bufferdata.body.toString();
                        switch(stringdata){
                            case "[]":
                                reply = "Wrong Address"
                                break;
                            default:
                                var objdata = JSON.parse(stringdata);
                                var result = objdata[0]["result"];
                                var string_result = JSON.stringify(result);
                                var quotesreply = `BSC Balance: ${string_result / 100000000000000}`
                                reply = quotesreply.replace(/['"]+/g, '')
                                break;
                                    }
                    break;
            }
    }
    return{
        handler:"internal",
        data: reply
    }
}
module.exports = {
    bscscan
}