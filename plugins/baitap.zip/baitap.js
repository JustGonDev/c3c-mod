var fetch = global.nodemodule["node-fetch"];

var baitap = function baitap(type, data) {
	(async function () {
		var returntext = `1 Hãy cho biết số nguyên tử hoặc phân tử trong mỗi lượng chất sau
A ) 0,3 mol nguyên tử AL 
B ) 0,2 mol phân tử CO2
C ) 0,15 mol phân tử của NaCl 
D ) 0,5 mol phân tử của H2SO4

Khi hoàn thành bài hay dùng lệnh /calladmin sau đó nhập kết quả vào nhé . Bài tập sẽ chấm và thông báo trong ngày`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"baitap\"Diamond";

data.log(onLoadText);

}
module.exports = {
	baitap: baitap
}