# mark-plugin-for-c3cbot-0.x
- cách dùng: prefix + mark [cỡ chữ](mặc định 40) <tin nhắn> (nếu nhiều dòng thì để mỗi dòng trong '')!
- vd: 
- /mark địt mẹ nẻo wibu 2k7
- sẽ cho ra kết quả:

<img src = 'https://scontent.fhan3-1.fna.fbcdn.net/v/t1.0-9/165065901_443164200293485_6944138249340251672_n.jpg?_nc_cat=109&ccb=1-3&_nc_sid=dbeb18&_nc_ohc=w27LD0C_M-oAX8IvJ_D&_nc_ht=scontent.fhan3-1.fna&oh=1f2e44c4cfbfad97274edc5af4461eb9&oe=608600C9'>
- /mark 27 'tao là wibu' 'chúng mày sẽ phục tùng tao'
- kết quả: 

<img src= 'https://scontent.xx.fbcdn.net/v/t1.15752-0/p403x403/166224309_431861134583270_1236210173340495900_n.png?_nc_cat=107&ccb=1-3&_nc_sid=f79d6e&_nc_ohc=YKESYJfngwUAX8klxjM&_nc_ad=z-m&_nc_cid=0&_nc_ht=scontent.xx&_nc_tp=30&oh=90ef4fde377a07e8c0775aed16c75664&oe=608767AC'>
- lưu ý: font chữ có thể sẽ hơi khác so với ảnh ở trên.
