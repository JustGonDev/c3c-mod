// *lang*
var langMap = {
	"en_US": {                                                                                                                                                                //        *defautl lang for en_US*
		"NoKeyWords": "No Name or Chemical formula!",                                                                                                                         //    "NoKeyWords": "No Name or Chemical formula!"
		"VietnamRep": "Are you looking for chemical:\r\n-VN_name: {0} \r\n-formula: {1} \r\n-shorted formula: {2} \r\n-molecular mass: {3} \r\n-rounded molecular mass: {4}", //    "VietnamRep": "Are you looking for chemical:\r\n \r\n-VN_name: {0} \r\n-formula: {1} \r\n-shorted formula: {2} \r\n-molecular mass: {3} \r\n-rounded molecular mass: {4}"
		"Rep": "Are you looking for chemical:\r\n-formula: {0} \r\n-shorted formula: {1} \r\n-molecular mass: {2} \r\n-rounded molecular mass: {3}",                          //    "Rep": "Are you looking for chemical:\r\n \r\n-formula: {0} \r\n-shorted formula: {1} \r\n-molecular mass: {2} \r\n-rounded molecular mass: {3}"
		"NoneRepFormula": "No chemical found with such a formula ({0}) was found!",                                                                                           //    "NoneRepFormula": "No chemical found with such a formula ({0}) was found!"
	    "NoneRepName": "No chemical found with such a name ({0}) was found!"                                                                                                  //    "NoneRepName": "No chemical found with such a name ({0}) was found!"
	},
	"vi_VN": {                                                                                                                                                                //        *defautl lang for vi_VN*
		"NoKeyWords": "Không có tên hoặc CTHH!",                                                                                                                              //    "NoKeyWords": "Không có tên hoặc CTHH!"
		"VietnamRep": "Có phải bạn muốn tìm chất:\r\n-VN_name: {0} \r\n-CTHH: {1} \r\n-CT rút gọn: {2} \r\n-nguyên/phân tử khối: {3} \r\n-nguyên/phân tử khối làm tròn: {4}",    //    "VietnamRep": "Có phải bạn muốn tìm chất:\r\n \r\n-VN_name: {0} \r\n-CTHH: {1} \r\nCT rút gọn: {2} \r\n-nguyên/phân tử khối: {3} \r\nguyên/phân tử khối làm tròn: {4}"
		"Rep": "Có phải bạn muốn tìm chất:\r\n-CTHH: {0} \r\n-CT rút gọn: {1} \r\n-nguyên/phân tử khối: {2} \r\n-nguyên/phân tử khối làm tròn: {3}",                          //    "Rep": "Có phải bạn muốn tìm chất:\r\n \r\n-CTHH: {0} \r\nCT rút gọn: {1} \r\n-nguyên/phân tử khối: {2} \r\nguyên/phân tử khối làm tròn: {3}"
	    "NoneRepFormula": "Không tìm thấy chất hóa học có CTHH ({0}) như vậy!",                                                                                               //    "NoneRepFormula": "Không tìm thấy chất hóa học có CTHH ({0}) như vậy!"
	    "NoneRepName": "Không tìm thấy chất hóa học có tên ({0}) như vậy!"                                                                                                    //    "NoneRepName": "Không tìm thấy chất hóa học có tên ({0}) như vậy!"
	}
}

// *require stuff*
var molFormula = global.nodemodule['molecular-formula'];

// *lang stuff*
var getLang = function () {}
var onLoad = function (data) {
	getLang = function (langVal, id) {
	    var lang = global.config.language;
	    if (id && global.data.userLanguage[id]) {
		    lang = global.data.userLanguage[id];
		    if (!langMap[lang]) {
		        lang = global.config.language;
		    }
	    }
	    if (langMap[lang]) {
		    return String(langMap[lang][langVal]);
	    } else {
		    return String((langMap["en_US"] || {})[langVal]);
	    }
	}
}

// *chefind*
var find = function(type, data){
	if(data.args[1] == undefined){
		return{
			handler: 'internal',
			data: getLang("NoKeyWords", `FB-${data.msgdata.senderID}`)
		}
	}
	var word = data.msgdata.body.slice(data.msgdata.body.indexOf(data.args[1]),data.msgdata.body.length);
	var name = [];
	for(i=0;i<chedb.length;i++){
		name.push((chedb[i].vietnamese_name).toLowerCase());
	}
    var rep = getLang("NoneRepName", `FB-${data.msgdata.senderID}`).replace("{0}", word);
	var help = findBestMatch(word.toLowerCase(),name);
	if(help.bestMatch.rating >= 0.5){
	    if(chedb[help.bestMatchIndex].vietnamese_name == ""){
			rep = getLang("Rep", `FB-${data.msgdata.senderID}`).replace("{0}", chedb[help.bestMatchIndex].formula).replace("{1}", molecular(chedb[help.bestMatchIndex].formula).simFormula).replace("{2}", molecular(chedb[help.bestMatchIndex].formula).mass).replace("{3}", roundNumber(molecular(chedb[help.bestMatchIndex].formula).mass, 0));
	    }
		else{
			rep = getLang("VietnamRep", `FB-${data.msgdata.senderID}`).replace("{0}", chedb[help.bestMatchIndex].vietnamese_name).replace("{1}", chedb[help.bestMatchIndex].formula).replace("{2}", molecular(chedb[help.bestMatchIndex].formula).simFormula).replace("{3}", molecular(chedb[help.bestMatchIndex].formula).mass).replace("{4}", roundNumber(molecular(chedb[help.bestMatchIndex].formula).mass, 0));
		}
		return{
	    	handler:'internal',
		    data: rep 
		}
    }
	else{
		var formula1 = [];
	    for(i=0;i<chedb.length;i++){
		    formula1.push((chedb[i].formula).toLowerCase());
    	}
	    var rep = getLang("NoneRepFormula", `FB-${data.msgdata.senderID}`).replace("{0}", word);
		var help = findBestMatch(data.args[1].toLowerCase(),formula1);
    	if(help.bestMatch.rating >= 0.4){
	    	if(chedb[help.bestMatchIndex].vietnamese_name == ""){
			    rep = getLang("Rep", `FB-${data.msgdata.senderID}`).replace("{0}", chedb[help.bestMatchIndex].formula).replace("{1}", molecular(chedb[help.bestMatchIndex].formula).simFormula).replace("{2}", molecular(chedb[help.bestMatchIndex].formula).mass).replace("{3}", roundNumber(molecular(chedb[help.bestMatchIndex].formula).mass, 0));
	        }
		    else{
			    rep = getLang("VietnamRep", `FB-${data.msgdata.senderID}`).replace("{0}", chedb[help.bestMatchIndex].vietnamese_name).replace("{1}", chedb[help.bestMatchIndex].formula).replace("{2}", molecular(chedb[help.bestMatchIndex].formula).simFormula).replace("{3}", molecular(chedb[help.bestMatchIndex].formula).mass).replace("{4}", roundNumber(molecular(chedb[help.bestMatchIndex].formula).mass, 0));
		    }		
		}
    	return{
	    	handler:'internal',
		    data: rep 
		}
	}
}

var molecular = function(CTHH){
	var a = new molFormula(CTHH);
	var b = a.getSimplifiedFormula();
	var c = a.getMass();
    return{
		simFormula: b,
		mass: c
	}
}
// *near api*	
function roundNumber(num, scale) {
  if(!("" + num).includes("e")) {
    return +(Math.round(num + "e+" + scale)  + "e-" + scale);
  } else {
    var arr = ("" + num).split("e");
    var sig = ""
    if(+arr[1] + scale > 0) {
      sig = "+";
    }
    return +(Math.round(+arr[0] + "e" + sig + (+arr[1] + scale)) + "e-" + scale);
  }
}

// *near api*
function compareTwoStrings(first, second) {
  first = first.replace(/\s+/g, '')
  second = second.replace(/\s+/g, '')
  if (!first.length && !second.length) return 1;               
  if (!first.length || !second.length) return 0;                   
  if (first === second) return 1;                
  if (first.length === 1 && second.length === 1) return 0;        
  if (first.length < 2 || second.length < 2) return 0;      
  let firstBigrams = new Map();
  for (let i = 0; i < first.length - 1; i++) {
    const bigram = first.substring(i, i + 2);
    const count = firstBigrams.has(bigram) ? firstBigrams.get(bigram) + 1 : 1;
    firstBigrams.set(bigram, count);
  }
  let intersectionSize = 0;
  for (let i = 0; i < second.length - 1; i++) {
    const bigram = second.substring(i, i + 2);
    const count = firstBigrams.has(bigram) ? firstBigrams.get(bigram) : 0;
    if (count > 0) {
      firstBigrams.set(bigram, count - 1);
      intersectionSize++;
    }
  }
  return (2.0 * intersectionSize) / (first.length + second.length - 2);
}

// *near api*
function areArgsValid(mainString, targetStrings) {
  if (typeof mainString !== 'string') return false;
  if (!Array.isArray(targetStrings)) return false;
  if (!targetStrings.length) return false;
  if (targetStrings.find(s => typeof s !== 'string')) return false;
  return true;
}

// *near api*
function findBestMatch(mainString, targetStrings) {
  if (!areArgsValid(mainString, targetStrings)) throw new Error('Bad arguments: First argument should be a string, second should be an array of strings');
  const ratings = [];
  let bestMatchIndex = 0;
  for (let i = 0; i < targetStrings.length; i++) {
    const currentTargetString = targetStrings[i];
    const currentRating = compareTwoStrings(mainString, currentTargetString)
    ratings.push({
      target: currentTargetString, 
      rating: currentRating
    });
    if (currentRating > ratings[bestMatchIndex].rating) {
      bestMatchIndex = i
    }
  }
  const bestMatch = ratings[bestMatchIndex]
  return {
    ratings, 
    bestMatch, 
    bestMatchIndex 
  };
}

module.exports = {
	onLoad,
	find
}
// *chemicals library*
var chedb = [
  {
    "id": "1",
    "formula": "(CH3COO)2Ca",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>2</sub>Ca<sup></sup>",
    "vietnamese_name": "canxi acetat"
  },
  {
    "id": "2",
    "formula": "(NH2)2CO",
    "formatted_formula": "(NH<sub>2</sub>)<sub>2</sub>CO<sup></sup>",
    "vietnamese_name": "ure"
  },
  {
    "id": "3",
    "formula": "(NH4)2CO3",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "amoni cacbonat"
  },
  {
    "id": "4",
    "formula": "(NH4)2Cr2O7",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>Cr<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "amoni cromat"
  },
  {
    "id": "5",
    "formula": "(NH4)2SO4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "amoni sulfat"
  },
  {
    "id": "6",
    "formula": "(NH4)3PO4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "amoni photphat"
  },
  {
    "id": "7",
    "formula": "Ag",
    "formatted_formula": "Ag<sup></sup>",
    "vietnamese_name": "bạc"
  },
  {
    "id": "8",
    "formula": "Ag2O",
    "formatted_formula": "Ag<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "bạc oxit"
  },
  {
    "id": "9",
    "formula": "AgBr",
    "formatted_formula": "AgBr<sup></sup>",
    "vietnamese_name": "bạc bromua"
  },
  {
    "id": "10",
    "formula": "AgCl",
    "formatted_formula": "AgCl<sup></sup>",
    "vietnamese_name": "bạc clorua"
  },
  {
    "id": "11",
    "formula": "AgNO3",
    "formatted_formula": "AgNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "bạc nitrat"
  },
  {
    "id": "12",
    "formula": "AgOH",
    "formatted_formula": "AgOH<sup></sup>",
    "vietnamese_name": "bạc hidroxit"
  },
  {
    "id": "13",
    "formula": "Al",
    "formatted_formula": "Al<sup></sup>",
    "vietnamese_name": "Nhôm"
  },
  {
    "id": "14",
    "formula": "Al(OH)3",
    "formatted_formula": "Al(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm hiroxit"
  },
  {
    "id": "15",
    "formula": "Al2(CO3)2",
    "formatted_formula": "Al<sub>2</sub>(CO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Nhôm cacbonat"
  },
  {
    "id": "16",
    "formula": "Al2(SO4)3",
    "formatted_formula": "Al<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm sunfat"
  },
  {
    "id": "17",
    "formula": "Al2O3",
    "formatted_formula": "Al<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm oxit"
  },
  {
    "id": "18",
    "formula": "Al2S3",
    "formatted_formula": "Al<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm sulfua"
  },
  {
    "id": "20",
    "formula": "AlCl3",
    "formatted_formula": "AlCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm clorua"
  },
  {
    "id": "21",
    "formula": "AlN",
    "formatted_formula": "AlN<sup></sup>",
    "vietnamese_name": "Nhôm nitrua"
  },
  {
    "id": "22",
    "formula": "Au",
    "formatted_formula": "Au<sup></sup>",
    "vietnamese_name": "vàng"
  },
  {
    "id": "23",
    "formula": "Ba(NO3)2",
    "formatted_formula": "Ba(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari nitrat"
  },
  {
    "id": "24",
    "formula": "BaCl2",
    "formatted_formula": "BaCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari clorua"
  },
  {
    "id": "25",
    "formula": "BaO",
    "formatted_formula": "BaO<sup></sup>",
    "vietnamese_name": "Bari oxit"
  },
  {
    "id": "26",
    "formula": "Br2",
    "formatted_formula": "Br<sub>2</sub><sup></sup>",
    "vietnamese_name": "brom"
  },
  {
    "id": "27",
    "formula": "C",
    "formatted_formula": "C<sup></sup>",
    "vietnamese_name": "cacbon"
  },
  {
    "id": "28",
    "formula": "C2H2",
    "formatted_formula": "C<sub>2</sub>H<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axetilen"
  },
  {
    "id": "29",
    "formula": "C2H4",
    "formatted_formula": "C<sub>2</sub>H<sub>4</sub><sup></sup>",
    "vietnamese_name": "etilen (eten)"
  },
  {
    "id": "30",
    "formula": "C2H4Br2",
    "formatted_formula": "C<sub>2</sub>H<sub>4</sub>Br<sub>2</sub><sup></sup>",
    "vietnamese_name": "etyl bromua"
  },
  {
    "id": "31",
    "formula": "C2H5OH",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OH<sup></sup>",
    "vietnamese_name": "rượu etylic"
  },
  {
    "id": "32",
    "formula": "C2H6",
    "formatted_formula": "C<sub>2</sub>H<sub>6</sub><sup></sup>",
    "vietnamese_name": "etan"
  },
  {
    "id": "33",
    "formula": "C4H6",
    "formatted_formula": "C<sub>4</sub>H<sub>6</sub><sup></sup>",
    "vietnamese_name": "n-butin"
  },
  {
    "id": "34",
    "formula": "C4H8",
    "formatted_formula": "C<sub>4</sub>H<sub>8</sub><sup></sup>",
    "vietnamese_name": "but-1-en"
  },
  {
    "id": "35",
    "formula": "C6H12O6",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "glucose"
  },
  {
    "id": "36",
    "formula": "C6H5Cl",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>Cl<sup></sup>",
    "vietnamese_name": "clorua benzen"
  },
  {
    "id": "37",
    "formula": "C6H5NH2",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "anilin"
  },
  {
    "id": "38",
    "formula": "C6H5NH3Cl",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>NH<sub>3</sub>Cl<sup></sup>",
    "vietnamese_name": "phenylamoni clorua"
  },
  {
    "id": "39",
    "formula": "C6H5OH",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>OH<sup></sup>",
    "vietnamese_name": "Phenol"
  },
  {
    "id": "40",
    "formula": "C6H5ONa",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>ONa<sup></sup>",
    "vietnamese_name": "Natri Phenolat"
  },
  {
    "id": "41",
    "formula": "C6H6",
    "formatted_formula": "C<sub>6</sub>H<sub>6</sub><sup></sup>",
    "vietnamese_name": "benzen"
  },
  {
    "id": "42",
    "formula": "Ca",
    "formatted_formula": "Ca<sup></sup>",
    "vietnamese_name": "canxi"
  },
  {
    "id": "43",
    "formula": "Ca(H2PO4)2",
    "formatted_formula": "Ca(H<sub>2</sub>PO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi dihirophotphat"
  },
  {
    "id": "44",
    "formula": "Ca(HCO3)2",
    "formatted_formula": "Ca(HCO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi hirocacbonat"
  },
  {
    "id": "45",
    "formula": "Ca(NO3)2",
    "formatted_formula": "Ca(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi nitrat"
  },
  {
    "id": "46",
    "formula": "Ca(OH)2",
    "formatted_formula": "Ca(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi hidroxit"
  },
  {
    "id": "47",
    "formula": "Ca3(PO4)2",
    "formatted_formula": "Ca<sub>3</sub>(PO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi photphat"
  },
  {
    "id": "48",
    "formula": "Ca3N2",
    "formatted_formula": "Ca<sub>3</sub>N<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi nitrua"
  },
  {
    "id": "49",
    "formula": "Ca3P2",
    "formatted_formula": "Ca<sub>3</sub>P<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi photphua"
  },
  {
    "id": "50",
    "formula": "CaC2",
    "formatted_formula": "CaC<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi cacbua"
  },
  {
    "id": "53",
    "formula": "CaCO3",
    "formatted_formula": "CaCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "canxi cacbonat"
  },
  {
    "id": "54",
    "formula": "CaF2",
    "formatted_formula": "CaF<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi florua"
  },
  {
    "id": "55",
    "formula": "CaO",
    "formatted_formula": "CaO<sup></sup>",
    "vietnamese_name": "canxi oxit"
  },
  {
    "id": "56",
    "formula": "CaO.SiO2",
    "formatted_formula": "CaO.SiO<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi mêtasilicat"
  },
  {
    "id": "57",
    "formula": "CaOCl2",
    "formatted_formula": "CaOCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "canxi hipoclorit"
  },
  {
    "id": "58",
    "formula": "CdCl2",
    "formatted_formula": "CdCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadimi clorua"
  },
  {
    "id": "59",
    "formula": "CH3CHO",
    "formatted_formula": "CH<sub>3</sub>CHO<sup></sup>",
    "vietnamese_name": "Andehit axetic"
  },
  {
    "id": "60",
    "formula": "CH3Cl",
    "formatted_formula": "CH<sub>3</sub>Cl<sup></sup>",
    "vietnamese_name": "metyl clorua"
  },
  {
    "id": "61",
    "formula": "CH3COCH3",
    "formatted_formula": "CH<sub>3</sub>COCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axeton"
  },
  {
    "id": "62",
    "formula": "CH3COOH",
    "formatted_formula": "CH<sub>3</sub>COOH<sup></sup>",
    "vietnamese_name": "acid acetic"
  },
  {
    "id": "63",
    "formula": "CH3COONa",
    "formatted_formula": "CH<sub>3</sub>COONa<sup></sup>",
    "vietnamese_name": "natri acetat"
  },
  {
    "id": "64",
    "formula": "CH3OH",
    "formatted_formula": "CH<sub>3</sub>OH<sup></sup>",
    "vietnamese_name": "metanol"
  },
  {
    "id": "65",
    "formula": "CH4",
    "formatted_formula": "CH<sub>4</sub><sup></sup>",
    "vietnamese_name": "metan"
  },
  {
    "id": "67",
    "formula": "Cl2",
    "formatted_formula": "Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "clo"
  },
  {
    "id": "68",
    "formula": "CO",
    "formatted_formula": "CO<sup></sup>",
    "vietnamese_name": "cacbon oxit"
  },
  {
    "id": "70",
    "formula": "Cr",
    "formatted_formula": "Cr<sup></sup>",
    "vietnamese_name": "crom"
  },
  {
    "id": "71",
    "formula": "Cu",
    "formatted_formula": "Cu<sup></sup>",
    "vietnamese_name": "đồng"
  },
  {
    "id": "72",
    "formula": "Cu(NO3)2",
    "formatted_formula": "Cu(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng nitrat"
  },
  {
    "id": "73",
    "formula": "Cu(OH)2",
    "formatted_formula": "Cu(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng (II) hidroxit"
  },
  {
    "id": "75",
    "formula": "CuO",
    "formatted_formula": "CuO<sup></sup>",
    "vietnamese_name": "Đồng (II) oxit"
  },
  {
    "id": "76",
    "formula": "CuS",
    "formatted_formula": "CuS<sup></sup>",
    "vietnamese_name": "Đồng sulfat"
  },
  {
    "id": "77",
    "formula": "F2",
    "formatted_formula": "F<sub>2</sub><sup></sup>",
    "vietnamese_name": "flo"
  },
  {
    "id": "78",
    "formula": "Fe",
    "formatted_formula": "Fe<sup></sup>",
    "vietnamese_name": "sắt"
  },
  {
    "id": "79",
    "formula": "Fe(NO3)2",
    "formatted_formula": "Fe(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "sắt (II) nitrat"
  },
  {
    "id": "81",
    "formula": "Fe2(CO3)3",
    "formatted_formula": "Fe<sub>2</sub>(CO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "sắt (III) cacbonat"
  },
  {
    "id": "82",
    "formula": "Fe2(SO4)3",
    "formatted_formula": "Fe<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "sắt (III) sulfat"
  },
  {
    "id": "83",
    "formula": "Fe2O3",
    "formatted_formula": "Fe<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "sắt (III) oxit"
  },
  {
    "id": "85",
    "formula": "FeCl2",
    "formatted_formula": "FeCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "sắt (II) clorua"
  },
  {
    "id": "87",
    "formula": "FeCO3",
    "formatted_formula": "FeCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "sắt (II) cacbonat"
  },
  {
    "id": "88",
    "formula": "FeO",
    "formatted_formula": "FeO<sup></sup>",
    "vietnamese_name": "sắt (II) oxit "
  },
  {
    "id": "89",
    "formula": "FeS",
    "formatted_formula": "FeS<sup></sup>",
    "vietnamese_name": "sắt (II) sulfua"
  },
  {
    "id": "90",
    "formula": "FeS2",
    "formatted_formula": "FeS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Pyrit sắt"
  },
  {
    "id": "91",
    "formula": "H2",
    "formatted_formula": "H<sub>2</sub><sup></sup>",
    "vietnamese_name": "hidro"
  },
  {
    "id": "92",
    "formula": "H2O",
    "formatted_formula": "H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "nước"
  },
  {
    "id": "93",
    "formula": "H2O2",
    "formatted_formula": "H<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "oxi già"
  },
  {
    "id": "94",
    "formula": "H2S",
    "formatted_formula": "H<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "hidro sulfua"
  },
  {
    "id": "96",
    "formula": "H2SO4",
    "formatted_formula": "H<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "axit sulfuric"
  },
  {
    "id": "98",
    "formula": "H4P2O7",
    "formatted_formula": "H<sub>4</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "axit điphotphoric"
  },
  {
    "id": "100",
    "formula": "HCHO",
    "formatted_formula": "HCHO<sup></sup>",
    "vietnamese_name": "Andehit formic(formaldehit)"
  },
  {
    "id": "101",
    "formula": "HCl",
    "formatted_formula": "HCl<sup></sup>",
    "vietnamese_name": "axit clohidric"
  },
  {
    "id": "105",
    "formula": "Hg",
    "formatted_formula": "Hg<sup></sup>",
    "vietnamese_name": "thủy ngân"
  },
  {
    "id": "106",
    "formula": "Hg(NO3)2",
    "formatted_formula": "Hg(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "thủy ngân nitrat"
  },
  {
    "id": "107",
    "formula": "Hg(OH)2",
    "formatted_formula": "Hg(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "thủy ngân hidroxit"
  },
  {
    "id": "108",
    "formula": "HgO",
    "formatted_formula": "HgO<sup></sup>",
    "vietnamese_name": "thủy ngân oxit"
  },
  {
    "id": "109",
    "formula": "HI",
    "formatted_formula": "HI<sup></sup>",
    "vietnamese_name": "axit iodic"
  },
  {
    "id": "110",
    "formula": "HNO3",
    "formatted_formula": "HNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "axit nitric"
  },
  {
    "id": "111",
    "formula": "HONO2",
    "formatted_formula": "HONO<sub>2</sub><sup></sup>",
    "vietnamese_name": "axit nitric"
  },
  {
    "id": "112",
    "formula": "I2",
    "formatted_formula": "I<sub>2</sub><sup></sup>",
    "vietnamese_name": "Iot"
  },
  {
    "id": "113",
    "formula": "K",
    "formatted_formula": "K<sup></sup>",
    "vietnamese_name": "kali"
  },
  {
    "id": "114",
    "formula": "K2CO3",
    "formatted_formula": "K<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "kali cacbonat"
  },
  {
    "id": "115",
    "formula": "K2Cr2O7",
    "formatted_formula": "K<sub>2</sub>Cr<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Kali dicromat"
  },
  {
    "id": "116",
    "formula": "K2O",
    "formatted_formula": "K<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "kali oxit"
  },
  {
    "id": "117",
    "formula": "K2S",
    "formatted_formula": "K<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "kali sulfua"
  },
  {
    "id": "118",
    "formula": "K2S2O8",
    "formatted_formula": "K<sub>2</sub>S<sub>2</sub>O<sub>8</sub><sup></sup>",
    "vietnamese_name": "Kali disulfat"
  },
  {
    "id": "119",
    "formula": "K3PO4",
    "formatted_formula": "K<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "kali photphat"
  },
  {
    "id": "120",
    "formula": "KBr",
    "formatted_formula": "KBr<sup></sup>",
    "vietnamese_name": "kali bromua"
  },
  {
    "id": "121",
    "formula": "KCl",
    "formatted_formula": "KCl<sup></sup>",
    "vietnamese_name": "kali clorua"
  },
  {
    "id": "122",
    "formula": "KClO3",
    "formatted_formula": "KClO<sub>3</sub><sup></sup>",
    "vietnamese_name": "kali clorat"
  },
  {
    "id": "123",
    "formula": "KI",
    "formatted_formula": "KI<sup></sup>",
    "vietnamese_name": "kali iodua"
  },
  {
    "id": "124",
    "formula": "KMnO4",
    "formatted_formula": "KMnO<sub>4</sub><sup></sup>",
    "vietnamese_name": "kali pemanganat"
  },
  {
    "id": "125",
    "formula": "KNO2",
    "formatted_formula": "KNO<sub>2</sub><sup></sup>",
    "vietnamese_name": "kali nitrit"
  },
  {
    "id": "126",
    "formula": "KNO3",
    "formatted_formula": "KNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "kali nitrat"
  },
  {
    "id": "127",
    "formula": "KOH",
    "formatted_formula": "KOH<sup></sup>",
    "vietnamese_name": "kali hidroxit"
  },
  {
    "id": "128",
    "formula": "Li",
    "formatted_formula": "Li<sup></sup>",
    "vietnamese_name": "liti"
  },
  {
    "id": "129",
    "formula": "Mg",
    "formatted_formula": "Mg<sup></sup>",
    "vietnamese_name": "magie"
  },
  {
    "id": "130",
    "formula": "Mg(NO3)2",
    "formatted_formula": "Mg(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "magie nitrat"
  },
  {
    "id": "131",
    "formula": "Mg(OH)2",
    "formatted_formula": "Mg(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "magie hidroxit"
  },
  {
    "id": "132",
    "formula": "MgCO3",
    "formatted_formula": "MgCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Magie cacbonat"
  },
  {
    "id": "133",
    "formula": "Mn",
    "formatted_formula": "Mn<sup></sup>",
    "vietnamese_name": "Mangan"
  },
  {
    "id": "134",
    "formula": "MnO2",
    "formatted_formula": "MnO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Mangan oxit"
  },
  {
    "id": "135",
    "formula": "MnSO4",
    "formatted_formula": "MnSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Mangan sulfat"
  },
  {
    "id": "136",
    "formula": "N2",
    "formatted_formula": "N<sub>2</sub><sup></sup>",
    "vietnamese_name": "nitơ"
  },
  {
    "id": "137",
    "formula": "N2O5",
    "formatted_formula": "N<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "dinitơ pentaoxit"
  },
  {
    "id": "138",
    "formula": "Na",
    "formatted_formula": "Na<sup></sup>",
    "vietnamese_name": "natri"
  },
  {
    "id": "139",
    "formula": "Na2CO3",
    "formatted_formula": "Na<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "natri cacbonat"
  },
  {
    "id": "140",
    "formula": "Na2HPO4",
    "formatted_formula": "Na<sub>2</sub>HPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "natri dihidro photphat"
  },
  {
    "id": "141",
    "formula": "Na2O",
    "formatted_formula": "Na<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "natri oxit"
  },
  {
    "id": "142",
    "formula": "Na2S",
    "formatted_formula": "Na<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "natri sulfua"
  },
  {
    "id": "143",
    "formula": "Na2S2O3",
    "formatted_formula": "Na<sub>2</sub>S<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "natri thiosulfat"
  },
  {
    "id": "144",
    "formula": "Na2SiO3",
    "formatted_formula": "Na<sub>2</sub>SiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "natri silicat"
  },
  {
    "id": "145",
    "formula": "Na2SO3",
    "formatted_formula": "Na<sub>2</sub>SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "natri sulfit"
  },
  {
    "id": "146",
    "formula": "Na2SO4",
    "formatted_formula": "Na<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "natri sulfat"
  },
  {
    "id": "147",
    "formula": "Na3PO4",
    "formatted_formula": "Na<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "natri photphat"
  },
  {
    "id": "149",
    "formula": "NaCH3COO",
    "formatted_formula": "NaCH<sub>3</sub>COO<sup></sup>",
    "vietnamese_name": "Natri axetat"
  },
  {
    "id": "150",
    "formula": "NaCl",
    "formatted_formula": "NaCl<sup></sup>",
    "vietnamese_name": "Natri Clorua"
  },
  {
    "id": "151",
    "formula": "NaClO",
    "formatted_formula": "NaClO<sup></sup>",
    "vietnamese_name": "Natri hypoclorit"
  },
  {
    "id": "152",
    "formula": "NaHCO3",
    "formatted_formula": "NaHCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "natri hidrocacbonat"
  },
  {
    "id": "153",
    "formula": "NaI",
    "formatted_formula": "NaI<sup></sup>",
    "vietnamese_name": "natri iodua"
  },
  {
    "id": "154",
    "formula": "NaNO2",
    "formatted_formula": "NaNO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri nitrit"
  },
  {
    "id": "155",
    "formula": "NaNO3",
    "formatted_formula": "NaNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri Nitrat"
  },
  {
    "id": "156",
    "formula": "NaOH",
    "formatted_formula": "NaOH<sup></sup>",
    "vietnamese_name": "natri hidroxit"
  },
  {
    "id": "157",
    "formula": "NH3",
    "formatted_formula": "NH<sub>3</sub><sup></sup>",
    "vietnamese_name": "amoniac"
  },
  {
    "id": "158",
    "formula": "NH4Cl",
    "formatted_formula": "NH<sub>4</sub>Cl<sup></sup>",
    "vietnamese_name": "amoni clorua"
  },
  {
    "id": "159",
    "formula": "NH4NO2",
    "formatted_formula": "NH<sub>4</sub>NO<sub>2</sub><sup></sup>",
    "vietnamese_name": "amoni nitrit"
  },
  {
    "id": "160",
    "formula": "NH4NO3",
    "formatted_formula": "NH<sub>4</sub>NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "amoni nitrat"
  },
  {
    "id": "161",
    "formula": "NO",
    "formatted_formula": "NO<sup></sup>",
    "vietnamese_name": "nitơ oxit"
  },
  {
    "id": "162",
    "formula": "NO2",
    "formatted_formula": "NO<sub>2</sub><sup></sup>",
    "vietnamese_name": "nitơ dioxit"
  },
  {
    "id": "163",
    "formula": "O2",
    "formatted_formula": "O<sub>2</sub><sup></sup>",
    "vietnamese_name": "oxi"
  },
  {
    "id": "164",
    "formula": "O3",
    "formatted_formula": "O<sub>3</sub><sup></sup>",
    "vietnamese_name": "ozon"
  },
  {
    "id": "165",
    "formula": "P",
    "formatted_formula": "P<sup></sup>",
    "vietnamese_name": "photpho"
  },
  {
    "id": "166",
    "formula": "P2O5",
    "formatted_formula": "P<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "diphotpho penta oxit"
  },
  {
    "id": "167",
    "formula": "Pb(NO3)2",
    "formatted_formula": "Pb(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "chì nitrat"
  },
  {
    "id": "168",
    "formula": "Pb(OH)2",
    "formatted_formula": "Pb(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "chì hidroxit"
  },
  {
    "id": "170",
    "formula": "PH3",
    "formatted_formula": "PH<sub>3</sub><sup></sup>",
    "vietnamese_name": "photphin"
  },
  {
    "id": "171",
    "formula": "PI3",
    "formatted_formula": "PI<sub>3</sub><sup></sup>",
    "vietnamese_name": "photpho tri iod"
  },
  {
    "id": "172",
    "formula": "Pt",
    "formatted_formula": "Pt<sup></sup>",
    "vietnamese_name": "platin"
  },
  {
    "id": "173",
    "formula": "S",
    "formatted_formula": "S<sup></sup>",
    "vietnamese_name": "sulfua"
  },
  {
    "id": "174",
    "formula": "Si",
    "formatted_formula": "Si<sup></sup>",
    "vietnamese_name": "silic"
  },
  {
    "id": "175",
    "formula": "SiO2",
    "formatted_formula": "SiO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Silic dioxit"
  },
  {
    "id": "176",
    "formula": "Sn(OH)2",
    "formatted_formula": "Sn(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thiếc(II) hidroxit"
  },
  {
    "id": "177",
    "formula": "SO2",
    "formatted_formula": "SO<sub>2</sub><sup></sup>",
    "vietnamese_name": "lưu hùynh dioxit"
  },
  {
    "id": "178",
    "formula": "SO3",
    "formatted_formula": "SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "sulfuarơ"
  },
  {
    "id": "179",
    "formula": "Zn",
    "formatted_formula": "Zn<sup></sup>",
    "vietnamese_name": "kẽm"
  },
  {
    "id": "180",
    "formula": "Zn3P2",
    "formatted_formula": "Zn<sub>3</sub>P<sub>2</sub><sup></sup>",
    "vietnamese_name": "kẽm photphua"
  },
  {
    "id": "181",
    "formula": "ZnO",
    "formatted_formula": "ZnO<sup></sup>",
    "vietnamese_name": "kẽm oxit"
  },
  {
    "id": "182",
    "formula": "ZnS",
    "formatted_formula": "ZnS<sup></sup>",
    "vietnamese_name": "kẽm sulfua"
  },
  {
    "id": "183",
    "formula": "ZnSO4",
    "formatted_formula": "ZnSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "kẽm sulfat"
  },
  {
    "id": "184",
    "formula": "ZnCl2",
    "formatted_formula": "ZnCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kẽm clorua"
  },
  {
    "id": "185",
    "formula": "N2O4",
    "formatted_formula": "N<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Nitơ tetraoxit"
  },
  {
    "id": "186",
    "formula": "N2O",
    "formatted_formula": "N<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đinitơoxit (khí cười)"
  },
  {
    "id": "187",
    "formula": "HNO2",
    "formatted_formula": "HNO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit nitrit"
  },
  {
    "id": "188",
    "formula": "NiO",
    "formatted_formula": "NiO<sup></sup>",
    "vietnamese_name": "Niken oxit"
  },
  {
    "id": "189",
    "formula": "CrO3",
    "formatted_formula": "CrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom trioxit"
  },
  {
    "id": "190",
    "formula": "Mn2O7",
    "formatted_formula": "Mn<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Mangan(VII) oxit"
  },
  {
    "id": "192",
    "formula": "Ni(OH)3",
    "formatted_formula": "Ni(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nike(III) hidroxit"
  },
  {
    "id": "193",
    "formula": "Li2O",
    "formatted_formula": "Li<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Liti oxit"
  },
  {
    "id": "194",
    "formula": "Ba",
    "formatted_formula": "Ba<sup></sup>",
    "vietnamese_name": "Bari"
  },
  {
    "id": "195",
    "formula": "TiO2",
    "formatted_formula": "TiO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Titan(IV) oxit"
  },
  {
    "id": "196",
    "formula": "TiCl4",
    "formatted_formula": "TiCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Titan(IV) clorua"
  },
  {
    "id": "197",
    "formula": "Be(OH)2",
    "formatted_formula": "Be(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Beri hidroxit"
  },
  {
    "id": "198",
    "formula": "Mg(HCO3)2",
    "formatted_formula": "Mg(HCO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie bicarbonat"
  },
  {
    "id": "199",
    "formula": "NH4OH",
    "formatted_formula": "NH<sub>4</sub>OH<sup></sup>",
    "vietnamese_name": "Amoni hidroxit"
  },
  {
    "id": "200",
    "formula": "NaAlO2",
    "formatted_formula": "NaAlO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri aluminat"
  },
  {
    "id": "201",
    "formula": "PbO",
    "formatted_formula": "PbO<sup></sup>",
    "vietnamese_name": "Chì(II) oxit"
  },
  {
    "id": "202",
    "formula": "FeSO4",
    "formatted_formula": "FeSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) sunfat"
  },
  {
    "id": "203",
    "formula": "MnO",
    "formatted_formula": "MnO<sup></sup>",
    "vietnamese_name": "Mangan(II) oxit"
  },
  {
    "id": "206",
    "formula": "MgCl2",
    "formatted_formula": "MgCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie clorua"
  },
  {
    "id": "207",
    "formula": "MgO",
    "formatted_formula": "MgO<sup></sup>",
    "vietnamese_name": "Magie oxit"
  },
  {
    "id": "208",
    "formula": "BeCl2",
    "formatted_formula": "BeCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Berili clorua"
  },
  {
    "id": "209",
    "formula": "Be",
    "formatted_formula": "Be<sup></sup>",
    "vietnamese_name": "Berili"
  },
  {
    "id": "210",
    "formula": "BeO",
    "formatted_formula": "BeO<sup></sup>",
    "vietnamese_name": "Berili oxit"
  },
  {
    "id": "211",
    "formula": "Be(NO3)2",
    "formatted_formula": "Be(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Berili nitrat"
  },
  {
    "id": "212",
    "formula": "H2ZnO2",
    "formatted_formula": "H<sub>2</sub>ZnO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit zincic"
  },
  {
    "id": "213",
    "formula": "HAlO2.H2O",
    "formatted_formula": "HAlO<sub>2</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit Aluminic hidrat"
  },
  {
    "id": "214",
    "formula": "Cu2O",
    "formatted_formula": "Cu<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng(I) oxit"
  },
  {
    "id": "215",
    "formula": "Zn(OH)2",
    "formatted_formula": "Zn(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kẽm hidroxit"
  },
  {
    "id": "216",
    "formula": "PdCl2",
    "formatted_formula": "PdCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Paladi(II) clorua"
  },
  {
    "id": "217",
    "formula": "Ag2CO3",
    "formatted_formula": "Ag<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bạc cabonat"
  },
  {
    "id": "218",
    "formula": "Ba(OH)2",
    "formatted_formula": "Ba(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari hidroxit"
  },
  {
    "id": "219",
    "formula": "(NH4)2S",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Amoni sunfua"
  },
  {
    "id": "220",
    "formula": "NH4HCO3",
    "formatted_formula": "NH<sub>4</sub>HCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni bicacbonat"
  },
  {
    "id": "221",
    "formula": "NaHSO3",
    "formatted_formula": "NaHSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri bisulfit"
  },
  {
    "id": "223",
    "formula": "Cr2O3",
    "formatted_formula": "Cr<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) oxit"
  },
  {
    "id": "224",
    "formula": "Cr(OH)3",
    "formatted_formula": "Cr(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cromi(III) hidroxit"
  },
  {
    "id": "225",
    "formula": "NaCrO2",
    "formatted_formula": "NaCrO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri cromat"
  },
  {
    "id": "226",
    "formula": "CuFeS2",
    "formatted_formula": "CuFeS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chalcopyrit"
  },
  {
    "id": "227",
    "formula": "K2SO3",
    "formatted_formula": "K<sub>2</sub>SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali sunfit"
  },
  {
    "id": "228",
    "formula": "K2SO4",
    "formatted_formula": "K<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali sunfat"
  },
  {
    "id": "229",
    "formula": "KClO",
    "formatted_formula": "KClO<sup></sup>",
    "vietnamese_name": "Kali hypoclorit"
  },
  {
    "id": "230",
    "formula": "Cu2S",
    "formatted_formula": "Cu<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Đồng(I) sunfua"
  },
  {
    "id": "231",
    "formula": "Fe(NO3)3",
    "formatted_formula": "Fe(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(III) nitrat"
  },
  {
    "id": "232",
    "formula": "Ag2SO4",
    "formatted_formula": "Ag<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Bạc sunfat"
  },
  {
    "id": "233",
    "formula": "Cr(OH)2",
    "formatted_formula": "Cr(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom(II) Hidroxit"
  },
  {
    "id": "234",
    "formula": "Al(NO3)3",
    "formatted_formula": "Al(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm nitrat"
  },
  {
    "id": "235",
    "formula": "PCl3",
    "formatted_formula": "PCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Photpho (III) clorua"
  },
  {
    "id": "236",
    "formula": "H3PO3",
    "formatted_formula": "H<sub>3</sub>PO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit phosphonic"
  },
  {
    "id": "238",
    "formula": "KAlO2",
    "formatted_formula": "KAlO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kai Aluminat"
  },
  {
    "id": "239",
    "formula": "AgCl3Cu2",
    "formatted_formula": "AgCl<sub>3</sub>Cu<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "240",
    "formula": "AgClO4",
    "formatted_formula": "AgClO<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "241",
    "formula": "AgF",
    "formatted_formula": "AgF<sup></sup>",
    "vietnamese_name": "silver fluoride"
  },
  {
    "id": "242",
    "formula": "AgF2",
    "formatted_formula": "AgF<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "243",
    "formula": "AgI",
    "formatted_formula": "AgI<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "244",
    "formula": "AgIO3",
    "formatted_formula": "AgIO<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "245",
    "formula": "AgMnO4",
    "formatted_formula": "AgMnO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Bạc permanganat"
  },
  {
    "id": "246",
    "formula": "AgN3",
    "formatted_formula": "AgN<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bạc azua"
  },
  {
    "id": "247",
    "formula": "AgONC",
    "formatted_formula": "AgONC<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "249",
    "formula": "Ag2C2",
    "formatted_formula": "Ag<sub>2</sub>C<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "250",
    "formula": "Ag2C2O4",
    "formatted_formula": "Ag<sub>2</sub>C<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "251",
    "formula": "Ag2Cl2",
    "formatted_formula": "Ag<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "252",
    "formula": "Ag2CrO4",
    "formatted_formula": "Ag<sub>2</sub>CrO<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "255",
    "formula": "Ag2MoO4",
    "formatted_formula": "Ag<sub>2</sub>MoO<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "256",
    "formula": "Ag2SeO3",
    "formatted_formula": "Ag<sub>2</sub>SeO<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "257",
    "formula": "Ag2SeO4",
    "formatted_formula": "Ag<sub>2</sub>SeO<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "259",
    "formula": "Ag3Br2",
    "formatted_formula": "Ag<sub>3</sub>Br<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "260",
    "formula": "Ag3Br3",
    "formatted_formula": "Ag<sub>3</sub>Br<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "261",
    "formula": "Ag3Cl3",
    "formatted_formula": "Ag<sub>3</sub>Cl<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "262",
    "formula": "Ag3I3",
    "formatted_formula": "Ag<sub>3</sub>I<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "263",
    "formula": "Ag3PO4",
    "formatted_formula": "Ag<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Bạc phosphat"
  },
  {
    "id": "264",
    "formula": "AlBO",
    "formatted_formula": "AlBO<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "265",
    "formula": "AlBO2",
    "formatted_formula": "AlBO<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "266",
    "formula": "AlBr",
    "formatted_formula": "AlBr<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "267",
    "formula": "AlBr3",
    "formatted_formula": "AlBr<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "268",
    "formula": "AlClF",
    "formatted_formula": "AlClF<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "269",
    "formula": "AlClF2",
    "formatted_formula": "AlClF<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "270",
    "formula": "AlClO",
    "formatted_formula": "AlClO<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "271",
    "formula": "AlCl2F",
    "formatted_formula": "AlCl<sub>2</sub>F<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "272",
    "formula": "AlCl4Cs",
    "formatted_formula": "AlCl<sub>4</sub>Cs<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "273",
    "formula": "AlCl4K",
    "formatted_formula": "AlCl<sub>4</sub>K<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "274",
    "formula": "AlCl4Na",
    "formatted_formula": "AlCl<sub>4</sub>Na<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "275",
    "formula": "AlCl4Rb",
    "formatted_formula": "AlCl<sub>4</sub>Rb<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "276",
    "formula": "AlCl6K3",
    "formatted_formula": "AlCl<sub>6</sub>K<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "277",
    "formula": "AlCl6Na3",
    "formatted_formula": "AlCl<sub>6</sub>Na<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "278",
    "formula": "AlFO",
    "formatted_formula": "AlFO<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "279",
    "formula": "AlF2",
    "formatted_formula": "AlF<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "280",
    "formula": "AlF",
    "formatted_formula": "AlF<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "281",
    "formula": "AlF2O",
    "formatted_formula": "AlF<sub>2</sub>O<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "282",
    "formula": "AlF3",
    "formatted_formula": "AlF<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "283",
    "formula": "AlF4K",
    "formatted_formula": "AlF<sub>4</sub>K<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "284",
    "formula": "AlF4Li",
    "formatted_formula": "AlF<sub>4</sub>Li<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "285",
    "formula": "AlF6K3",
    "formatted_formula": "AlF<sub>6</sub>K<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "286",
    "formula": "AlF6Li3",
    "formatted_formula": "AlF<sub>6</sub>Li<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "287",
    "formula": "AlF6Na3",
    "formatted_formula": "AlF<sub>6</sub>Na<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "288",
    "formula": "AlGaInP",
    "formatted_formula": "AlGaInP<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "289",
    "formula": "AlI",
    "formatted_formula": "AlI<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "290",
    "formula": "AlI3",
    "formatted_formula": "AlI<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "291",
    "formula": "AlLiO2",
    "formatted_formula": "AlLiO<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "293",
    "formula": "AlNaO2",
    "formatted_formula": "AlNaO<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "294",
    "formula": "AlOSi",
    "formatted_formula": "AlOSi<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "295",
    "formula": "AlO",
    "formatted_formula": "AlO<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "297",
    "formula": "AlP",
    "formatted_formula": "AlP<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "298",
    "formula": "AlTe",
    "formatted_formula": "AlTe<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "299",
    "formula": "AlTe2",
    "formatted_formula": "AlTe<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "301",
    "formula": "C2H5I",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>I<sup></sup>",
    "vietnamese_name": "Ety I-ot dua"
  },
  {
    "id": "302",
    "formula": "C3H8",
    "formatted_formula": "C<sub>3</sub>H<sub>8</sub><sup></sup>",
    "vietnamese_name": "Propan"
  },
  {
    "id": "303",
    "formula": "C3H8O3S",
    "formatted_formula": "C<sub>3</sub>H<sub>8</sub>O<sub>3</sub>S<sup></sup>",
    "vietnamese_name": "Sulfurous acid ethyl methyl"
  },
  {
    "id": "304",
    "formula": "C3H8N4O2",
    "formatted_formula": "C<sub>3</sub>H<sub>8</sub>N<sub>4</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diureidometan"
  },
  {
    "id": "305",
    "formula": "C3H8NO4P",
    "formatted_formula": "C<sub>3</sub>H<sub>8</sub>NO<sub>4</sub>P<sup></sup>",
    "vietnamese_name": "Carbamoylphosphonic acid hydrogen ethyl"
  },
  {
    "id": "306",
    "formula": "C3H8Hg",
    "formatted_formula": "C<sub>3</sub>H<sub>8</sub>Hg<sup></sup>",
    "vietnamese_name": "Ethylmethylmercury(II)"
  },
  {
    "id": "307",
    "formula": "C3H7OH",
    "formatted_formula": "C<sub>3</sub>H<sub>7</sub>OH<sup></sup>",
    "vietnamese_name": "2-Propanol"
  },
  {
    "id": "308",
    "formula": "C3H8O",
    "formatted_formula": "C<sub>3</sub>H<sub>8</sub>O<sup></sup>",
    "vietnamese_name": "1-Propanol"
  },
  {
    "id": "309",
    "formula": "C3H8S",
    "formatted_formula": "C<sub>3</sub>H<sub>8</sub>S<sup></sup>",
    "vietnamese_name": "Metylthioetan"
  },
  {
    "id": "310",
    "formula": "C3H5(OH)3",
    "formatted_formula": "C<sub>3</sub>H<sub>5</sub>(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Glycerin"
  },
  {
    "id": "311",
    "formula": "C3H6(OH)2",
    "formatted_formula": "C<sub>3</sub>H<sub>6</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Methyl glycol"
  },
  {
    "id": "312",
    "formula": "H2NNHCO2CH2CH3",
    "formatted_formula": "H<sub>2</sub>NNHCO<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ethyl N-aminocacbamat"
  },
  {
    "id": "313",
    "formula": "C20H36",
    "formatted_formula": "C<sub>2</sub><sub>0</sub>H<sub>3</sub><sub>6</sub><sup></sup>",
    "vietnamese_name": "(3Z,6Z,9Z)-3,6,9-Icosatriene"
  },
  {
    "id": "314",
    "formula": "C20H30O2",
    "formatted_formula": "C<sub>2</sub><sub>0</sub>H<sub>3</sub><sub>0</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit sylvic"
  },
  {
    "id": "318",
    "formula": "CCl2F2",
    "formatted_formula": "CCl<sub>2</sub>F<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diclorodiflorometan"
  },
  {
    "id": "319",
    "formula": "CCl4",
    "formatted_formula": "CCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cacbon tetraclorua"
  },
  {
    "id": "321",
    "formula": "CFCl2CF2Cl",
    "formatted_formula": "CFCl<sub>2</sub>CF<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "CFC-113"
  },
  {
    "id": "322",
    "formula": "CHCl3",
    "formatted_formula": "CHCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Chloroform"
  },
  {
    "id": "323",
    "formula": "CH2CO",
    "formatted_formula": "CH<sub>2</sub>CO<sup></sup>",
    "vietnamese_name": "Keten"
  },
  {
    "id": "324",
    "formula": "CH2CHCHCH2",
    "formatted_formula": "CH<sub>2</sub>CHCHCH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Butadiene;Divinyl"
  },
  {
    "id": "325",
    "formula": "CH2ClCOOH",
    "formatted_formula": "CH<sub>2</sub>ClCOOH<sup></sup>",
    "vietnamese_name": "Clorua Acetic Axit"
  },
  {
    "id": "326",
    "formula": "CH2Cl2",
    "formatted_formula": "CH<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diclo Methan"
  },
  {
    "id": "327",
    "formula": "CH2O",
    "formatted_formula": "CH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Methanal"
  },
  {
    "id": "328",
    "formula": "CH2OHCH2OH",
    "formatted_formula": "CH<sub>2</sub>OHCH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Etylen glycol"
  },
  {
    "id": "329",
    "formula": "CH3CCH",
    "formatted_formula": "CH<sub>3</sub>CCH<sup></sup>",
    "vietnamese_name": "Propyne"
  },
  {
    "id": "331",
    "formula": "CH3CHCHCH3",
    "formatted_formula": "CH<sub>3</sub>CHCHCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1-Metylcyclopropan"
  },
  {
    "id": "332",
    "formula": "CH3CHCH2",
    "formatted_formula": "CH<sub>3</sub>CHCH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cyclopropan"
  },
  {
    "id": "333",
    "formula": "CH3CH2Br",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "Bromoetan"
  },
  {
    "id": "334",
    "formula": "CH3CH2CH2CH2OH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "t-Butyl alcohol"
  },
  {
    "id": "335",
    "formula": "CH3CH2CH2OH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "1-Propanol"
  },
  {
    "id": "336",
    "formula": "CH3CH2CONH2",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CONH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Propionamide"
  },
  {
    "id": "337",
    "formula": "CH3CH2COOH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit propionic"
  },
  {
    "id": "338",
    "formula": "CH3CH2OCH2CH3",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>OCH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Diethyl ete"
  },
  {
    "id": "339",
    "formula": "CH3CH2OH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Etanol"
  },
  {
    "id": "340",
    "formula": "CH3(CH2)16COOH",
    "formatted_formula": "CH<sub>3</sub>(CH<sub>2</sub>)<sub>1</sub><sub>6</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit stearic"
  },
  {
    "id": "341",
    "formula": "CH3COCl",
    "formatted_formula": "CH<sub>3</sub>COCl<sup></sup>",
    "vietnamese_name": "2-Cloroetylen oxit"
  },
  {
    "id": "345",
    "formula": "CH3CONH2",
    "formatted_formula": "CH<sub>3</sub>CONH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit acetimidic"
  },
  {
    "id": "346",
    "formula": "CH3COOCHCH2",
    "formatted_formula": "CH<sub>3</sub>COOCHCH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Vinyl axetat"
  },
  {
    "id": "348",
    "formula": "CH3COOCH2C6H5",
    "formatted_formula": "CH<sub>3</sub>COOCH<sub>2</sub>C<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Benzyl axetat"
  },
  {
    "id": "349",
    "formula": "CH3COO(CH2)2CH(CH3)2",
    "formatted_formula": "CH<sub>3</sub>COO(CH<sub>2</sub>)<sub>2</sub>CH(CH<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Isoamyl Axetat"
  },
  {
    "id": "350",
    "formula": "CH3I",
    "formatted_formula": "CH<sub>3</sub>I<sup></sup>",
    "vietnamese_name": "Iodometan"
  },
  {
    "id": "351",
    "formula": "CH3OCH3",
    "formatted_formula": "CH<sub>3</sub>OCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dimetyl ete"
  },
  {
    "id": "352",
    "formula": "CH3SCH3",
    "formatted_formula": "CH<sub>3</sub>SCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dimetyl sunfua"
  },
  {
    "id": "353",
    "formula": "CH3SH",
    "formatted_formula": "CH<sub>3</sub>SH<sup></sup>",
    "vietnamese_name": "Metyl mercaptan"
  },
  {
    "id": "354",
    "formula": "(CH3)2CHOH",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>CHOH<sup></sup>",
    "vietnamese_name": "2-Propanol"
  },
  {
    "id": "355",
    "formula": "(CH3)2CO",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>CO<sup></sup>",
    "vietnamese_name": "Axeton"
  },
  {
    "id": "356",
    "formula": "(CH3)2C2O4",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>C<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Diaxetyl peroxit"
  },
  {
    "id": "357",
    "formula": "(CH3)2NNH2",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>NNH<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,1-Dimetylhydrazin"
  },
  {
    "id": "359",
    "formula": "COCl2",
    "formatted_formula": "COCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Phosgen"
  },
  {
    "id": "361",
    "formula": "CO2",
    "formatted_formula": "CO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cacbon dioxit"
  },
  {
    "id": "362",
    "formula": "CO3",
    "formatted_formula": "CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ion cacbonat"
  },
  {
    "id": "363",
    "formula": "C2H5NH2",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Etanamin"
  },
  {
    "id": "365",
    "formula": "C3N3(OH)3",
    "formatted_formula": "C<sub>3</sub>N<sub>3</sub>(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit cyanuric"
  },
  {
    "id": "366",
    "formula": "C3N12",
    "formatted_formula": "C<sub>3</sub>N<sub>1</sub><sub>2</sub><sup></sup>",
    "vietnamese_name": "Cyanuric triazide"
  },
  {
    "id": "368",
    "formula": "C3H7NO3",
    "formatted_formula": "C<sub>3</sub>H<sub>7</sub>NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Propyl nitrat"
  },
  {
    "id": "372",
    "formula": "C4H7BrO2",
    "formatted_formula": "C<sub>4</sub>H<sub>7</sub>BrO<sub>2</sub><sup></sup>",
    "vietnamese_name": "2-Bromoetyl axetat"
  },
  {
    "id": "373",
    "formula": "C4H7NO4",
    "formatted_formula": "C<sub>4</sub>H<sub>7</sub>NO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Diglycin"
  },
  {
    "id": "374",
    "formula": "C4H8N2O3",
    "formatted_formula": "C<sub>4</sub>H<sub>8</sub>N<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Methylazoxymethyl acetate"
  },
  {
    "id": "375",
    "formula": "C4H8O",
    "formatted_formula": "C<sub>4</sub>H<sub>8</sub>O<sup></sup>",
    "vietnamese_name": "Cyclopropylmethanol"
  },
  {
    "id": "376",
    "formula": "C4H9NO3",
    "formatted_formula": "C<sub>4</sub>H<sub>9</sub>NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Butyl nitrat"
  },
  {
    "id": "379",
    "formula": "C5H4NCOOH",
    "formatted_formula": "C<sub>5</sub>H<sub>4</sub>NCOOH<sup></sup>",
    "vietnamese_name": "Axit nicotinic"
  },
  {
    "id": "380",
    "formula": "C5H5N",
    "formatted_formula": "C<sub>5</sub>H<sub>5</sub>N<sup></sup>",
    "vietnamese_name": "Pyridin"
  },
  {
    "id": "381",
    "formula": "C5H9NO2",
    "formatted_formula": "C<sub>5</sub>H<sub>9</sub>NO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit 2-pyrrolidinecarboxylic"
  },
  {
    "id": "383",
    "formula": "C5H9NO4",
    "formatted_formula": "C<sub>5</sub>H<sub>9</sub>NO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit 2-Aminopentanedioic"
  },
  {
    "id": "384",
    "formula": "C5H10",
    "formatted_formula": "C<sub>5</sub>H<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Cyclopentan; pent-1-en"
  },
  {
    "id": "385",
    "formula": "C5H10N2O3",
    "formatted_formula": "C<sub>5</sub>H<sub>1</sub><sub>0</sub>N<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Methyl(1-acetoxyethyl)nitrosamine"
  },
  {
    "id": "386",
    "formula": "C5H10O4",
    "formatted_formula": "C<sub>5</sub>H<sub>1</sub><sub>0</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "alpha-Monoacetin"
  },
  {
    "id": "387",
    "formula": "C5H11NO2",
    "formatted_formula": "C<sub>5</sub>H<sub>1</sub><sub>1</sub>NO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit 2-aminoisovaleric"
  },
  {
    "id": "388",
    "formula": "C5H11NO2S",
    "formatted_formula": "C<sub>5</sub>H<sub>1</sub><sub>1</sub>NO<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Axit 2-Amino-4-(metylthio)butanoic"
  },
  {
    "id": "389",
    "formula": "C5H12",
    "formatted_formula": "C<sub>5</sub>H<sub>1</sub><sub>2</sub><sup></sup>",
    "vietnamese_name": "Pentan"
  },
  {
    "id": "390",
    "formula": "C6F5COOH",
    "formatted_formula": "C<sub>6</sub>F<sub>5</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit pentaflorobenzoic"
  },
  {
    "id": "391",
    "formula": "C6H4O2",
    "formatted_formula": "C<sub>6</sub>H<sub>4</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "p-Quinon"
  },
  {
    "id": "392",
    "formula": "C6H5CHO",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CHO<sup></sup>",
    "vietnamese_name": "Benzandehit"
  },
  {
    "id": "393",
    "formula": "C6H5CH2OH",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Benzyl alcohol"
  },
  {
    "id": "394",
    "formula": "C6H5COCl",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COCl<sup></sup>",
    "vietnamese_name": "Benzoyl clorua"
  },
  {
    "id": "395",
    "formula": "C6H5COOH",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit benzoic"
  },
  {
    "id": "396",
    "formula": "C6H5F",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>F<sup></sup>",
    "vietnamese_name": "1-Florobenzen"
  },
  {
    "id": "397",
    "formula": "C6H13NO2",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>3</sub>NO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Carbamic acid amyl"
  },
  {
    "id": "398",
    "formula": "C6H14N2O2",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>4</sub>N<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "sec-Butyl(metoxymetyl)nitrosoamin"
  },
  {
    "id": "400",
    "formula": "C7H16",
    "formatted_formula": "C<sub>7</sub>H<sub>1</sub><sub>6</sub><sup></sup>",
    "vietnamese_name": "Heptan"
  },
  {
    "id": "402",
    "formula": "C8H9NO2",
    "formatted_formula": "C<sub>8</sub>H<sub>9</sub>NO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Piperonylamine"
  },
  {
    "id": "403",
    "formula": "C8H18",
    "formatted_formula": "C<sub>8</sub>H<sub>1</sub><sub>8</sub><sup></sup>",
    "vietnamese_name": "octan"
  },
  {
    "id": "404",
    "formula": "C9H8O4",
    "formatted_formula": "C<sub>9</sub>H<sub>8</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "2-Acetoxymethyl-p-benzoquinone"
  },
  {
    "id": "405",
    "formula": "C9H11NO2",
    "formatted_formula": "C<sub>9</sub>H<sub>1</sub><sub>1</sub>NO<sub>2</sub><sup></sup>",
    "vietnamese_name": "2-Pyridineacetic acid ethyl"
  },
  {
    "id": "406",
    "formula": "C9H11NO3",
    "formatted_formula": "C<sub>9</sub>H<sub>1</sub><sub>1</sub>NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Adrenalone"
  },
  {
    "id": "407",
    "formula": "C9H20",
    "formatted_formula": "C<sub>9</sub>H<sub>2</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "nonan"
  },
  {
    "id": "408",
    "formula": "C10H8",
    "formatted_formula": "C<sub>1</sub><sub>0</sub>H<sub>8</sub><sup></sup>",
    "vietnamese_name": "Naphthene"
  },
  {
    "id": "409",
    "formula": "C10H14O",
    "formatted_formula": "C<sub>1</sub><sub>0</sub>H<sub>1</sub><sub>4</sub>O<sup></sup>",
    "vietnamese_name": "Isopropylbenzyl ete"
  },
  {
    "id": "410",
    "formula": "C10H15ON",
    "formatted_formula": "C<sub>1</sub><sub>0</sub>H<sub>1</sub><sub>5</sub>ON<sup></sup>",
    "vietnamese_name": "Veritol"
  },
  {
    "id": "411",
    "formula": "C10H16O",
    "formatted_formula": "C<sub>1</sub><sub>0</sub>H<sub>1</sub><sub>6</sub>O<sup></sup>",
    "vietnamese_name": "2-Cyclopentylcyclopentanone"
  },
  {
    "id": "412",
    "formula": "C10H22",
    "formatted_formula": "C<sub>1</sub><sub>0</sub>H<sub>2</sub><sub>2</sub><sup></sup>",
    "vietnamese_name": "đecan"
  },
  {
    "id": "414",
    "formula": "C11H12N2O2",
    "formatted_formula": "C<sub>1</sub><sub>1</sub>H<sub>1</sub><sub>2</sub>N<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit anpha-Amino-1H-indole-2-propionic"
  },
  {
    "id": "415",
    "formula": "C11H24",
    "formatted_formula": "C<sub>1</sub><sub>1</sub>H<sub>2</sub><sub>4</sub><sup></sup>",
    "vietnamese_name": "Undecan"
  },
  {
    "id": "416",
    "formula": "C12H10",
    "formatted_formula": "C<sub>1</sub><sub>2</sub>H<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Acenaphthene"
  },
  {
    "id": "417",
    "formula": "C12H22O11",
    "formatted_formula": "C<sub>1</sub><sub>2</sub>H<sub>2</sub><sub>2</sub>O<sub>1</sub><sub>1</sub><sup></sup>",
    "vietnamese_name": "Mantozơ"
  },
  {
    "id": "418",
    "formula": "C12H26",
    "formatted_formula": "C<sub>1</sub><sub>2</sub>H<sub>2</sub><sub>6</sub><sup></sup>",
    "vietnamese_name": "n-Dodecan"
  },
  {
    "id": "419",
    "formula": "C13H10O",
    "formatted_formula": "C<sub>1</sub><sub>3</sub>H<sub>1</sub><sub>0</sub>O<sup></sup>",
    "vietnamese_name": "Benzophenon"
  },
  {
    "id": "420",
    "formula": "C13H12O",
    "formatted_formula": "C<sub>1</sub><sub>3</sub>H<sub>1</sub><sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Benzhydrol"
  },
  {
    "id": "421",
    "formula": "C13H28",
    "formatted_formula": "C<sub>1</sub><sub>3</sub>H<sub>2</sub><sub>8</sub><sup></sup>",
    "vietnamese_name": "n-Tridecan"
  },
  {
    "id": "422",
    "formula": "C14H10",
    "formatted_formula": "C<sub>1</sub><sub>4</sub>H<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Phenanthrene"
  },
  {
    "id": "423",
    "formula": "C14H18N2O5",
    "formatted_formula": "C<sub>1</sub><sub>4</sub>H<sub>1</sub><sub>8</sub>N<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Dinitroacetophenone"
  },
  {
    "id": "425",
    "formula": "C20H42",
    "formatted_formula": "C<sub>2</sub><sub>0</sub>H<sub>4</sub><sub>2</sub><sup></sup>",
    "vietnamese_name": "Icosane"
  },
  {
    "id": "426",
    "formula": "C21H36N7O16P3S",
    "formatted_formula": "C<sub>2</sub><sub>1</sub>H<sub>3</sub><sub>6</sub>N<sub>7</sub>O<sub>1</sub><sub>6</sub>P<sub>3</sub>S<sup></sup>",
    "vietnamese_name": "Coenzyme A"
  },
  {
    "id": "427",
    "formula": "Ca(CHO2)2",
    "formatted_formula": "Ca(CHO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi format"
  },
  {
    "id": "428",
    "formula": "Ca(C2H3O2)2",
    "formatted_formula": "Ca(C<sub>2</sub>H<sub>3</sub>O<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi axetat"
  },
  {
    "id": "429",
    "formula": "CaC2O4",
    "formatted_formula": "CaC<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi oxalat"
  },
  {
    "id": "430",
    "formula": "CaCl2",
    "formatted_formula": "CaCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi diclorua"
  },
  {
    "id": "432",
    "formula": "Ca(H2PO2)2",
    "formatted_formula": "Ca(H<sub>2</sub>PO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi photphinat"
  },
  {
    "id": "433",
    "formula": "CaMoO4",
    "formatted_formula": "CaMoO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi molybdat"
  },
  {
    "id": "434",
    "formula": "Ca(NO2)2",
    "formatted_formula": "Ca(NO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi nitrit"
  },
  {
    "id": "435",
    "formula": "Ca(NbO3)2",
    "formatted_formula": "Ca(NbO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi metaniobat"
  },
  {
    "id": "436",
    "formula": "CaCl2O2",
    "formatted_formula": "CaCl<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi hypoclorit"
  },
  {
    "id": "437",
    "formula": "Ca(ClO3)2",
    "formatted_formula": "Ca(ClO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi clorat"
  },
  {
    "id": "438",
    "formula": "Ca(ClO4)2",
    "formatted_formula": "Ca(ClO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi perclorat"
  },
  {
    "id": "439",
    "formula": "CaH2",
    "formatted_formula": "CaH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi hidrua"
  },
  {
    "id": "440",
    "formula": "CaI2",
    "formatted_formula": "CaI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi iodua"
  },
  {
    "id": "441",
    "formula": "Ca(IO3)2",
    "formatted_formula": "Ca(IO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi iodat"
  },
  {
    "id": "442",
    "formula": "CaO2",
    "formatted_formula": "CaO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi peroxit"
  },
  {
    "id": "443",
    "formula": "CaS",
    "formatted_formula": "CaS<sup></sup>",
    "vietnamese_name": "Canxi sunfua"
  },
  {
    "id": "444",
    "formula": "CaSO4",
    "formatted_formula": "CaSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi sunfat"
  },
  {
    "id": "445",
    "formula": "CaSe",
    "formatted_formula": "CaSe<sup></sup>",
    "vietnamese_name": "Canxi selenua"
  },
  {
    "id": "446",
    "formula": "CaSeO3",
    "formatted_formula": "CaSeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Canxi selenit"
  },
  {
    "id": "447",
    "formula": "CaSeO4",
    "formatted_formula": "CaSeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi selenat"
  },
  {
    "id": "448",
    "formula": "CaSiO3",
    "formatted_formula": "CaSiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Canxi metasilicat"
  },
  {
    "id": "450",
    "formula": "CaTe",
    "formatted_formula": "CaTe<sup></sup>",
    "vietnamese_name": "Canxi telurua"
  },
  {
    "id": "451",
    "formula": "CaTeO3",
    "formatted_formula": "CaTeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Canxi telurit"
  },
  {
    "id": "452",
    "formula": "CaTeO4",
    "formatted_formula": "CaTeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi metatelurat"
  },
  {
    "id": "454",
    "formula": "CaWO4",
    "formatted_formula": "CaWO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi tungstat"
  },
  {
    "id": "456",
    "formula": "CdBr2",
    "formatted_formula": "CdBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmi bromua"
  },
  {
    "id": "457",
    "formula": "Cd(CN)2",
    "formatted_formula": "Cd(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmi cyanua"
  },
  {
    "id": "458",
    "formula": "CdCO3",
    "formatted_formula": "CdCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cadmi cacbonat"
  },
  {
    "id": "459",
    "formula": "Cd(C2H3O2)2",
    "formatted_formula": "Cd(C<sub>2</sub>H<sub>3</sub>O<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmi axetat"
  },
  {
    "id": "460",
    "formula": "CdCrO4",
    "formatted_formula": "CdCrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cadmi cromat"
  },
  {
    "id": "461",
    "formula": "CdF2",
    "formatted_formula": "CdF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmi florua"
  },
  {
    "id": "462",
    "formula": "CdI2",
    "formatted_formula": "CdI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmi iodua"
  },
  {
    "id": "463",
    "formula": "Cd(IO3)2",
    "formatted_formula": "Cd(IO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmi iodat"
  },
  {
    "id": "464",
    "formula": "CdMoO4",
    "formatted_formula": "CdMoO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cadmi molybdat(VI)"
  },
  {
    "id": "466",
    "formula": "Cd(NO3)2",
    "formatted_formula": "Cd(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmi nitrat"
  },
  {
    "id": "468",
    "formula": "Cd(N3)2",
    "formatted_formula": "Cd(N<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmi azua"
  },
  {
    "id": "469",
    "formula": "CdO",
    "formatted_formula": "CdO<sup></sup>",
    "vietnamese_name": "Cadmi oxit"
  },
  {
    "id": "470",
    "formula": "Cd(OH)2",
    "formatted_formula": "Cd(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmi hidroxit"
  },
  {
    "id": "471",
    "formula": "CdS",
    "formatted_formula": "CdS<sup></sup>",
    "vietnamese_name": "Cadmi sunfua"
  },
  {
    "id": "472",
    "formula": "CdSO3",
    "formatted_formula": "CdSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cadmi sunfit"
  },
  {
    "id": "474",
    "formula": "CdSO4",
    "formatted_formula": "CdSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cadmi sunfat"
  },
  {
    "id": "475",
    "formula": "CdSb",
    "formatted_formula": "CdSb<sup></sup>",
    "vietnamese_name": "Cadmi antimonua"
  },
  {
    "id": "476",
    "formula": "CdSe",
    "formatted_formula": "CdSe<sup></sup>",
    "vietnamese_name": "Cadmi selenua"
  },
  {
    "id": "477",
    "formula": "CdSeO3",
    "formatted_formula": "CdSeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cadmi selenit"
  },
  {
    "id": "480",
    "formula": "CdSiO3",
    "formatted_formula": "CdSiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cadmi metasilicat"
  },
  {
    "id": "481",
    "formula": "CdTe",
    "formatted_formula": "CdTe<sup></sup>",
    "vietnamese_name": "Cadmi telurua"
  },
  {
    "id": "482",
    "formula": "CdTeO4",
    "formatted_formula": "CdTeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cadmi telurat"
  },
  {
    "id": "483",
    "formula": "CdWO4",
    "formatted_formula": "CdWO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi tungstat"
  },
  {
    "id": "484",
    "formula": "ClO2",
    "formatted_formula": "ClO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Clo dioxit"
  },
  {
    "id": "485",
    "formula": "CeBr3",
    "formatted_formula": "CeBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ceri(III) bromua"
  },
  {
    "id": "486",
    "formula": "CeC",
    "formatted_formula": "CeC<sup></sup>",
    "vietnamese_name": "Ceri monocacbua"
  },
  {
    "id": "487",
    "formula": "CeCl3",
    "formatted_formula": "CeCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ceri(III) clorua"
  },
  {
    "id": "488",
    "formula": "CeF3",
    "formatted_formula": "CeF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ceri(III) florua"
  },
  {
    "id": "489",
    "formula": "CeF4",
    "formatted_formula": "CeF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Ceri(IV) florua"
  },
  {
    "id": "490",
    "formula": "CeI2",
    "formatted_formula": "CeI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Ceri(II) iodua"
  },
  {
    "id": "491",
    "formula": "CeI3",
    "formatted_formula": "CeI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ceri(III) iodua"
  },
  {
    "id": "492",
    "formula": "CeN",
    "formatted_formula": "CeN<sup></sup>",
    "vietnamese_name": "Xeri nitrua"
  },
  {
    "id": "493",
    "formula": "CeO2",
    "formatted_formula": "CeO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Ceri oxit"
  },
  {
    "id": "494",
    "formula": "CeS",
    "formatted_formula": "CeS<sup></sup>",
    "vietnamese_name": "Ceri monosufua"
  },
  {
    "id": "495",
    "formula": "Ce(SO4)2",
    "formatted_formula": "Ce(SO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Ceri(IV) sunfat"
  },
  {
    "id": "496",
    "formula": "CeSi2",
    "formatted_formula": "CeSi<sub>2</sub><sup></sup>",
    "vietnamese_name": "Ceri disilicua"
  },
  {
    "id": "497",
    "formula": "Ce2O3",
    "formatted_formula": "Ce<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ceri(III) oxit"
  },
  {
    "id": "498",
    "formula": "Ce2S3",
    "formatted_formula": "Ce<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ceri(III) sunfua"
  },
  {
    "id": "499",
    "formula": "ClF",
    "formatted_formula": "ClF<sup></sup>",
    "vietnamese_name": "Clo florua"
  },
  {
    "id": "500",
    "formula": "ClF3",
    "formatted_formula": "ClF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Clo triflorua"
  },
  {
    "id": "501",
    "formula": "ClF5",
    "formatted_formula": "ClF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Clo pentaflorua"
  },
  {
    "id": "502",
    "formula": "ClO3F",
    "formatted_formula": "ClO<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Percloryl florua"
  },
  {
    "id": "503",
    "formula": "Cl2O3",
    "formatted_formula": "Cl<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Diclo trioxit"
  },
  {
    "id": "504",
    "formula": "Cl2O6",
    "formatted_formula": "Cl<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Cloryl perclorat"
  },
  {
    "id": "505",
    "formula": "Cl2O7",
    "formatted_formula": "Cl<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Diclo heptoxit"
  },
  {
    "id": "506",
    "formula": "CoAl2O4",
    "formatted_formula": "CoAl<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban(II) aluminat"
  },
  {
    "id": "507",
    "formula": "CoAs",
    "formatted_formula": "CoAs<sup></sup>",
    "vietnamese_name": "Monocoban monoarsenua"
  },
  {
    "id": "508",
    "formula": "CoB",
    "formatted_formula": "CoB<sup></sup>",
    "vietnamese_name": "Coban monoborua"
  },
  {
    "id": "509",
    "formula": "CoBr2",
    "formatted_formula": "CoBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) bromua"
  },
  {
    "id": "510",
    "formula": "Co(CN)2",
    "formatted_formula": "Co(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) cyanua"
  },
  {
    "id": "511",
    "formula": "Co(C2H3O2)2",
    "formatted_formula": "Co(C<sub>2</sub>H<sub>3</sub>O<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) axetat"
  },
  {
    "id": "512",
    "formula": "Co(C2H3O2)3",
    "formatted_formula": "Co(C<sub>2</sub>H<sub>3</sub>O<sub>2</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Coban(III) triaxetat"
  },
  {
    "id": "513",
    "formula": "CoC2O4",
    "formatted_formula": "CoC<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban(II) oxalat"
  },
  {
    "id": "514",
    "formula": "Co(ClO4)2",
    "formatted_formula": "Co(ClO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) perclorat"
  },
  {
    "id": "515",
    "formula": "CoCrO4",
    "formatted_formula": "CoCrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban cromat"
  },
  {
    "id": "516",
    "formula": "CoF2",
    "formatted_formula": "CoF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) florua"
  },
  {
    "id": "517",
    "formula": "CoF3",
    "formatted_formula": "CoF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Coban(III) florua"
  },
  {
    "id": "518",
    "formula": "Co(IO3)2",
    "formatted_formula": "Co(IO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) iodat"
  },
  {
    "id": "519",
    "formula": "CoI2",
    "formatted_formula": "CoI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) iodua"
  },
  {
    "id": "520",
    "formula": "CoMoO4",
    "formatted_formula": "CoMoO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban(II) molybdat"
  },
  {
    "id": "521",
    "formula": "Co(NO3)2",
    "formatted_formula": "Co(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) nitrat"
  },
  {
    "id": "522",
    "formula": "Co(OH)2",
    "formatted_formula": "Co(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) hidroxit"
  },
  {
    "id": "523",
    "formula": "Co(OH)3",
    "formatted_formula": "Co(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Coban(III) hidroxit"
  },
  {
    "id": "524",
    "formula": "CoS",
    "formatted_formula": "CoS<sup></sup>",
    "vietnamese_name": "Coban sunfua"
  },
  {
    "id": "525",
    "formula": "CoS2",
    "formatted_formula": "CoS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban disunfua"
  },
  {
    "id": "526",
    "formula": "CoSe",
    "formatted_formula": "CoSe<sup></sup>",
    "vietnamese_name": "Coban(II) selenua"
  },
  {
    "id": "527",
    "formula": "CoSeO3",
    "formatted_formula": "CoSeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Coban selenit"
  },
  {
    "id": "528",
    "formula": "CoTe",
    "formatted_formula": "CoTe<sup></sup>",
    "vietnamese_name": "Coban monotelurua"
  },
  {
    "id": "529",
    "formula": "Co2SiO4",
    "formatted_formula": "Co<sub>2</sub>SiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban silicat"
  },
  {
    "id": "530",
    "formula": "Co2TiO4",
    "formatted_formula": "Co<sub>2</sub>TiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban titanat(IV)"
  },
  {
    "id": "531",
    "formula": "CrBr2",
    "formatted_formula": "CrBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom(II) bromua"
  },
  {
    "id": "532",
    "formula": "CrBr3",
    "formatted_formula": "CrBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) bromua"
  },
  {
    "id": "533",
    "formula": "CrCl2",
    "formatted_formula": "CrCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom(II) clorua"
  },
  {
    "id": "534",
    "formula": "CrCl3",
    "formatted_formula": "CrCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) clorua"
  },
  {
    "id": "535",
    "formula": "CrF2",
    "formatted_formula": "CrF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom(II) florua"
  },
  {
    "id": "536",
    "formula": "CrF3",
    "formatted_formula": "CrF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) florua"
  },
  {
    "id": "537",
    "formula": "CrF4",
    "formatted_formula": "CrF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Crom(IV) florua"
  },
  {
    "id": "538",
    "formula": "CrF5",
    "formatted_formula": "CrF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Crom(V) florua"
  },
  {
    "id": "539",
    "formula": "CrF6",
    "formatted_formula": "CrF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Crom(VI) florua"
  },
  {
    "id": "540",
    "formula": "CrI2",
    "formatted_formula": "CrI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom(II) iodua"
  },
  {
    "id": "541",
    "formula": "CrI3",
    "formatted_formula": "CrI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) iodua"
  },
  {
    "id": "543",
    "formula": "Cr(NO3)3",
    "formatted_formula": "Cr(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) nitrat"
  },
  {
    "id": "544",
    "formula": "Cr(NO2)3",
    "formatted_formula": "Cr(NO<sub>2</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) nitrit"
  },
  {
    "id": "545",
    "formula": "CrO42−",
    "formatted_formula": "CrO<sub>4</sub><sub>2</sub>−<sup></sup>",
    "vietnamese_name": "Cromat ion"
  },
  {
    "id": "546",
    "formula": "CrO2Cl2",
    "formatted_formula": "CrO<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cromyl clorua"
  },
  {
    "id": "548",
    "formula": "CrPO4",
    "formatted_formula": "CrPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Crom(III) orthophotphat"
  },
  {
    "id": "549",
    "formula": "CrSb",
    "formatted_formula": "CrSb<sup></sup>",
    "vietnamese_name": "Crom monoantimonua"
  },
  {
    "id": "550",
    "formula": "Cr2S3",
    "formatted_formula": "Cr<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) sunfua"
  },
  {
    "id": "551",
    "formula": "Cr2Te3",
    "formatted_formula": "Cr<sub>2</sub>Te<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dicrom tritelurua"
  },
  {
    "id": "552",
    "formula": "Cr3As2",
    "formatted_formula": "Cr<sub>3</sub>As<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom(II) Arsenua"
  },
  {
    "id": "553",
    "formula": "CsF",
    "formatted_formula": "CsF<sup></sup>",
    "vietnamese_name": "Cezi florua"
  },
  {
    "id": "554",
    "formula": "CsClO4",
    "formatted_formula": "CsClO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cezi perclorat"
  },
  {
    "id": "555",
    "formula": "CsClO3",
    "formatted_formula": "CsClO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cezi clorat"
  },
  {
    "id": "556",
    "formula": "CsCl",
    "formatted_formula": "CsCl<sup></sup>",
    "vietnamese_name": "Cezi clorua"
  },
  {
    "id": "557",
    "formula": "CsC2H3O2",
    "formatted_formula": "CsC<sub>2</sub>H<sub>3</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xezi axetat"
  },
  {
    "id": "558",
    "formula": "CsCN",
    "formatted_formula": "CsCN<sup></sup>",
    "vietnamese_name": "Xezi thiocyanat"
  },
  {
    "id": "560",
    "formula": "CsBrO3",
    "formatted_formula": "CsBrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cezi bromat"
  },
  {
    "id": "561",
    "formula": "CsBr",
    "formatted_formula": "CsBr<sup></sup>",
    "vietnamese_name": "Cesi bromua"
  },
  {
    "id": "562",
    "formula": "CsBO2",
    "formatted_formula": "CsBO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cezi Metaborat"
  },
  {
    "id": "563",
    "formula": "Cr3Si2",
    "formatted_formula": "Cr<sub>3</sub>Si<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tricrom disilicua"
  },
  {
    "id": "564",
    "formula": "Cr3Sb2",
    "formatted_formula": "Cr<sub>3</sub>Sb<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom(II) Antimonua"
  },
  {
    "id": "565",
    "formula": "Cr3C2",
    "formatted_formula": "Cr<sub>3</sub>C<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tricrom dicacbua"
  },
  {
    "id": "566",
    "formula": "CsI",
    "formatted_formula": "CsI<sup></sup>",
    "vietnamese_name": "Cezi iodua"
  },
  {
    "id": "567",
    "formula": "CsI3",
    "formatted_formula": "CsI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cezi triiodua"
  },
  {
    "id": "568",
    "formula": "CsNH2",
    "formatted_formula": "CsNH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cezi amit"
  },
  {
    "id": "569",
    "formula": "CsNO3",
    "formatted_formula": "CsNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cezi nitrat"
  },
  {
    "id": "570",
    "formula": "CsN3",
    "formatted_formula": "CsN<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cezi azua"
  },
  {
    "id": "571",
    "formula": "CsNbO3",
    "formatted_formula": "CsNbO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xezi metaniobat"
  },
  {
    "id": "572",
    "formula": "CsOH",
    "formatted_formula": "CsOH<sup></sup>",
    "vietnamese_name": "Xezi hidroxit"
  },
  {
    "id": "573",
    "formula": "CsO2",
    "formatted_formula": "CsO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xezi Superoxit"
  },
  {
    "id": "574",
    "formula": "Cs2S",
    "formatted_formula": "Cs<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Cezi Sunfua"
  },
  {
    "id": "575",
    "formula": "CCsNS",
    "formatted_formula": "CCsNS<sup></sup>",
    "vietnamese_name": "Xeri thiocyanat"
  },
  {
    "id": "576",
    "formula": "CsSeO4",
    "formatted_formula": "CsSeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi selenat"
  },
  {
    "id": "577",
    "formula": "CsTaO3",
    "formatted_formula": "CsTaO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xezi metatantalat"
  },
  {
    "id": "578",
    "formula": "Cs2CO3",
    "formatted_formula": "Cs<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xezi cacbonat"
  },
  {
    "id": "579",
    "formula": "Cs2C2O4",
    "formatted_formula": "Cs<sub>2</sub>C<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi oxalat"
  },
  {
    "id": "580",
    "formula": "Cs2CrO4",
    "formatted_formula": "Cs<sub>2</sub>CrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi cromat"
  },
  {
    "id": "581",
    "formula": "Cs2Cr2O7",
    "formatted_formula": "Cs<sub>2</sub>Cr<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Xezi bicromat"
  },
  {
    "id": "582",
    "formula": "Cs2HPO4",
    "formatted_formula": "Cs<sub>2</sub>HPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi hidro orthophotphat"
  },
  {
    "id": "583",
    "formula": "Cs2MoO4",
    "formatted_formula": "Cs<sub>2</sub>MoO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi orthomolybdat"
  },
  {
    "id": "584",
    "formula": "Cs2O",
    "formatted_formula": "Cs<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Xezi oxit"
  },
  {
    "id": "585",
    "formula": "Cs2SO3",
    "formatted_formula": "Cs<sub>2</sub>SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xezi sunfit"
  },
  {
    "id": "586",
    "formula": "Cs2SO4",
    "formatted_formula": "Cs<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi sunfat"
  },
  {
    "id": "587",
    "formula": "Cs2SiO3",
    "formatted_formula": "Cs<sub>2</sub>SiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xezi Metasilicat"
  },
  {
    "id": "588",
    "formula": "Cs2TeO4",
    "formatted_formula": "Cs<sub>2</sub>TeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dixezi metatelurat"
  },
  {
    "id": "589",
    "formula": "Cs2TiO3",
    "formatted_formula": "Cs<sub>2</sub>TiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xezi titanat"
  },
  {
    "id": "590",
    "formula": "Cs2WO4",
    "formatted_formula": "Cs<sub>2</sub>WO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi tungstat"
  },
  {
    "id": "591",
    "formula": "Cs3PO4",
    "formatted_formula": "Cs<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi photphat"
  },
  {
    "id": "592",
    "formula": "Cs3VO4",
    "formatted_formula": "Cs<sub>3</sub>VO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi Orthovanadat"
  },
  {
    "id": "593",
    "formula": "Cu(BrO3)2.6H2O",
    "formatted_formula": "Cu(BrO<sub>3</sub>)<sub>2</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng(II) bromat  hexahidrat"
  },
  {
    "id": "594",
    "formula": "CuBr2",
    "formatted_formula": "CuBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) bromua"
  },
  {
    "id": "595",
    "formula": "CuBr",
    "formatted_formula": "CuBr<sup></sup>",
    "vietnamese_name": "Đồng(I) bromua"
  },
  {
    "id": "596",
    "formula": "CuC2O4",
    "formatted_formula": "CuC<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Đồng oxalat"
  },
  {
    "id": "598",
    "formula": "CuCl",
    "formatted_formula": "CuCl<sup></sup>",
    "vietnamese_name": "Đồng(I) clorua"
  },
  {
    "id": "599",
    "formula": "Cu(ClO3)2.6H2O",
    "formatted_formula": "Cu(ClO<sub>3</sub>)<sub>2</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng(II) clorat hexahidrat"
  },
  {
    "id": "600",
    "formula": "CuCl2",
    "formatted_formula": "CuCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) clorua"
  },
  {
    "id": "601",
    "formula": "CuFe2O4",
    "formatted_formula": "CuFe<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cuprospinel"
  },
  {
    "id": "602",
    "formula": "CuFe2S3",
    "formatted_formula": "CuFe<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cubanite"
  },
  {
    "id": "603",
    "formula": "[Cu(H2O)4]SO4.H2O",
    "formatted_formula": "[Cu(H<sub>2</sub>O)<sub>4</sub>]SO<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Tetraaquacopper(II) sulfate hydrate"
  },
  {
    "id": "604",
    "formula": "CuI",
    "formatted_formula": "CuI<sup></sup>",
    "vietnamese_name": "Đồng(I) iodua"
  },
  {
    "id": "605",
    "formula": "CuIO3",
    "formatted_formula": "CuIO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đồng(I) iodat"
  },
  {
    "id": "606",
    "formula": "Cu(IO3)2",
    "formatted_formula": "Cu(IO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đổng(II) iodat"
  },
  {
    "id": "607",
    "formula": "CuMoO4",
    "formatted_formula": "CuMoO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) molybdat"
  },
  {
    "id": "608",
    "formula": "Cu(NO3)2.3H2O",
    "formatted_formula": "Cu(NO<sub>3</sub>)<sub>2</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng(II) nitrat trihidrat"
  },
  {
    "id": "610",
    "formula": "Cu(NbO3)2",
    "formatted_formula": "Cu(NbO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) Orthoniobat"
  },
  {
    "id": "611",
    "formula": "CuSCN",
    "formatted_formula": "CuSCN<sup></sup>",
    "vietnamese_name": "Đồng(I) thiocyanat"
  },
  {
    "id": "612",
    "formula": "CuSO4",
    "formatted_formula": "CuSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) sunfat"
  },
  {
    "id": "614",
    "formula": "CuSe",
    "formatted_formula": "CuSe<sup></sup>",
    "vietnamese_name": "Đồng(II) selenua"
  },
  {
    "id": "615",
    "formula": "CuSeO3.2H2O",
    "formatted_formula": "CuSeO<sub>3</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng(II) selenat dihidrat"
  },
  {
    "id": "616",
    "formula": "CuSeO4.5H2O",
    "formatted_formula": "CuSeO<sub>4</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng(II) selenat pentahidrat"
  },
  {
    "id": "617",
    "formula": "CuSiO3",
    "formatted_formula": "CuSiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) silicat"
  },
  {
    "id": "619",
    "formula": "CuTeO3",
    "formatted_formula": "CuTeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) telurit"
  },
  {
    "id": "620",
    "formula": "CuTiO3",
    "formatted_formula": "CuTiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) Metatitanat"
  },
  {
    "id": "621",
    "formula": "Cu(VO3)2",
    "formatted_formula": "Cu(VO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) Metavanadat"
  },
  {
    "id": "622",
    "formula": "CuWO4",
    "formatted_formula": "CuWO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) tungstat"
  },
  {
    "id": "623",
    "formula": "Cu2CO3(OH)2",
    "formatted_formula": "Cu<sub>2</sub>CO<sub>3</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Malachite"
  },
  {
    "id": "624",
    "formula": "Cu2Se",
    "formatted_formula": "Cu<sub>2</sub>Se<sup></sup>",
    "vietnamese_name": "Đồng(I) selenua"
  },
  {
    "id": "625",
    "formula": "Cu2Te",
    "formatted_formula": "Cu<sub>2</sub>Te<sup></sup>",
    "vietnamese_name": "Đồng(I) telurua"
  },
  {
    "id": "626",
    "formula": "Cu3As",
    "formatted_formula": "Cu<sub>3</sub>As<sup></sup>",
    "vietnamese_name": "Đồng(I) arsenua"
  },
  {
    "id": "627",
    "formula": "Cu3P",
    "formatted_formula": "Cu<sub>3</sub>P<sup></sup>",
    "vietnamese_name": "Đồng(I) photphua"
  },
  {
    "id": "628",
    "formula": "Cu3(PO4)2",
    "formatted_formula": "Cu<sub>3</sub>(PO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) photphat"
  },
  {
    "id": "629",
    "formula": "Cu3Sb",
    "formatted_formula": "Cu<sub>3</sub>Sb<sup></sup>",
    "vietnamese_name": "Đồng(I) antimonua"
  },
  {
    "id": "630",
    "formula": "Cu9S5",
    "formatted_formula": "Cu<sub>9</sub>S<sub>5</sub><sup></sup>",
    "vietnamese_name": "Digenite"
  },
  {
    "id": "631",
    "formula": "Cu3Zn2",
    "formatted_formula": "Cu<sub>3</sub>Zn<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng thau"
  },
  {
    "id": "632",
    "formula": "DBr",
    "formatted_formula": "DBr<sup></sup>",
    "vietnamese_name": "Hidro bromua (1D)"
  },
  {
    "id": "633",
    "formula": "DI",
    "formatted_formula": "DI<sup></sup>",
    "vietnamese_name": "Hidro iodua (1D)"
  },
  {
    "id": "634",
    "formula": "DLi",
    "formatted_formula": "DLi<sup></sup>",
    "vietnamese_name": "Liti hidrua (D)"
  },
  {
    "id": "635",
    "formula": "DNa",
    "formatted_formula": "DNa<sup></sup>",
    "vietnamese_name": "Natri hidrua (D)"
  },
  {
    "id": "636",
    "formula": "D2O",
    "formatted_formula": "D<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nước nặng"
  },
  {
    "id": "638",
    "formula": "Br3Dy",
    "formatted_formula": "Br<sub>3</sub>Dy<sup></sup>",
    "vietnamese_name": "Dysprosi tribromua"
  },
  {
    "id": "639",
    "formula": "DyCl2",
    "formatted_formula": "DyCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dysprosi diclorua"
  },
  {
    "id": "640",
    "formula": "DyCl3",
    "formatted_formula": "DyCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dysprosi triclorua"
  },
  {
    "id": "641",
    "formula": "DySi2",
    "formatted_formula": "DySi<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dysprosi Disilicua"
  },
  {
    "id": "642",
    "formula": "Dy2O3",
    "formatted_formula": "Dy<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Didysprosi trioxit"
  },
  {
    "id": "643",
    "formula": "Dy2S3",
    "formatted_formula": "Dy<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Didysprosi trisunfua"
  },
  {
    "id": "644",
    "formula": "CeB6",
    "formatted_formula": "CeB<sub>6</sub><sup></sup>",
    "vietnamese_name": "Xeri hexaborua"
  },
  {
    "id": "645",
    "formula": "CeCl2",
    "formatted_formula": "CeCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Ceri diclorua"
  },
  {
    "id": "648",
    "formula": "CeC3",
    "formatted_formula": "CeC<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xeri tricacbua"
  },
  {
    "id": "650",
    "formula": "CeS3",
    "formatted_formula": "CeS<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xeri trisunfua"
  },
  {
    "id": "651",
    "formula": "ClOClO3",
    "formatted_formula": "ClOClO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Clo perclorat"
  },
  {
    "id": "652",
    "formula": "CoAs2",
    "formatted_formula": "CoAs<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban diasenua"
  },
  {
    "id": "653",
    "formula": "CoCr2O4",
    "formatted_formula": "CoCr<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban cromit"
  },
  {
    "id": "654",
    "formula": "Co(NO3)3",
    "formatted_formula": "Co(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Coban(III) nitrat"
  },
  {
    "id": "655",
    "formula": "CoSb",
    "formatted_formula": "CoSb<sup></sup>",
    "vietnamese_name": "Coban monoantimonua"
  },
  {
    "id": "656",
    "formula": "CoTiO3",
    "formatted_formula": "CoTiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Coban titanat"
  },
  {
    "id": "657",
    "formula": "CoWO4",
    "formatted_formula": "CoWO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban tungstat"
  },
  {
    "id": "658",
    "formula": "Co2B",
    "formatted_formula": "Co<sub>2</sub>B<sup></sup>",
    "vietnamese_name": "Coban borua"
  },
  {
    "id": "659",
    "formula": "Co2SO4",
    "formatted_formula": "Co<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban(III) sunfat"
  },
  {
    "id": "660",
    "formula": "Co2S3",
    "formatted_formula": "Co<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Coban(III) sunfua"
  },
  {
    "id": "661",
    "formula": "Co2SnO4",
    "formatted_formula": "Co<sub>2</sub>SnO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban(II) Stannat"
  },
  {
    "id": "662",
    "formula": "Co3(Fe(CN)6)2",
    "formatted_formula": "Co<sub>3</sub>(Fe(CN)<sub>6</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cobalt Hexacyanoiron(III)"
  },
  {
    "id": "663",
    "formula": "CrCl4",
    "formatted_formula": "CrCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Crom tetraclorua"
  },
  {
    "id": "664",
    "formula": "CrO2",
    "formatted_formula": "CrO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom(IV) oxit"
  },
  {
    "id": "665",
    "formula": "CrVO4",
    "formatted_formula": "CrVO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Crom(III) Orthovanadat"
  },
  {
    "id": "666",
    "formula": "Cr2(SO4)3",
    "formatted_formula": "Cr<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) sunfat"
  },
  {
    "id": "667",
    "formula": "Cr2Se3",
    "formatted_formula": "Cr<sub>2</sub>Se<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) Selenua"
  },
  {
    "id": "668",
    "formula": "Cr2(TeO4)3",
    "formatted_formula": "Cr<sub>2</sub>(TeO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) Telurat"
  },
  {
    "id": "669",
    "formula": "CsBr3",
    "formatted_formula": "CsBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xezi tribromua"
  },
  {
    "id": "670",
    "formula": "CsSCN",
    "formatted_formula": "CsSCN<sup></sup>",
    "vietnamese_name": "Xezi thiocyanat"
  },
  {
    "id": "671",
    "formula": "CuTe",
    "formatted_formula": "CuTe<sup></sup>",
    "vietnamese_name": "Đồng(II) telurua"
  },
  {
    "id": "672",
    "formula": "DyBr3",
    "formatted_formula": "DyBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dysprosi bromua"
  },
  {
    "id": "673",
    "formula": "ErF",
    "formatted_formula": "ErF<sup></sup>",
    "vietnamese_name": "Erbi monoflorua"
  },
  {
    "id": "674",
    "formula": "ErF2",
    "formatted_formula": "ErF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Erbi diflorua"
  },
  {
    "id": "677",
    "formula": "C12H6O2",
    "formatted_formula": "C<sub>1</sub><sub>2</sub>H<sub>6</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Acênat Quy-non"
  },
  {
    "id": "678",
    "formula": "ErF3",
    "formatted_formula": "ErF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Erbi triflorua"
  },
  {
    "id": "679",
    "formula": "ErI3",
    "formatted_formula": "ErI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Erbi triiodua"
  },
  {
    "id": "680",
    "formula": "ErI4Na",
    "formatted_formula": "ErI<sub>4</sub>Na<sup></sup>",
    "vietnamese_name": "Erbi natri tetraiodua"
  },
  {
    "id": "681",
    "formula": "ErO",
    "formatted_formula": "ErO<sup></sup>",
    "vietnamese_name": "Erbi monoxit"
  },
  {
    "id": "682",
    "formula": "EuF",
    "formatted_formula": "EuF<sup></sup>",
    "vietnamese_name": "Europi monoflorua"
  },
  {
    "id": "683",
    "formula": "EuF3",
    "formatted_formula": "EuF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Europi(III) florua"
  },
  {
    "id": "684",
    "formula": "EuI2",
    "formatted_formula": "EuI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Europi(II) iodua"
  },
  {
    "id": "685",
    "formula": "EuNbO2",
    "formatted_formula": "EuNbO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Europi niobi dioxit"
  },
  {
    "id": "686",
    "formula": "EuNb2O6",
    "formatted_formula": "EuNb<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Europi(II) Niobat"
  },
  {
    "id": "687",
    "formula": "EuO",
    "formatted_formula": "EuO<sup></sup>",
    "vietnamese_name": "Europi monooxit"
  },
  {
    "id": "688",
    "formula": "EuO2V",
    "formatted_formula": "EuO<sub>2</sub>V<sup></sup>",
    "vietnamese_name": "Europi vanadi oxit"
  },
  {
    "id": "689",
    "formula": "EuO3Ti",
    "formatted_formula": "EuO<sub>3</sub>Ti<sup></sup>",
    "vietnamese_name": "Europi titan trioxit"
  },
  {
    "id": "690",
    "formula": "EuO3V",
    "formatted_formula": "EuO<sub>3</sub>V<sup></sup>",
    "vietnamese_name": "Europi metavanadat"
  },
  {
    "id": "691",
    "formula": "EuO4W",
    "formatted_formula": "EuO<sub>4</sub>W<sup></sup>",
    "vietnamese_name": "Europi tungsten tetraoxit"
  },
  {
    "id": "692",
    "formula": "EuS",
    "formatted_formula": "EuS<sup></sup>",
    "vietnamese_name": "Europi(II) sunfua"
  },
  {
    "id": "694",
    "formula": "EuS2",
    "formatted_formula": "EuS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Europi disunfua"
  },
  {
    "id": "695",
    "formula": "Eu2O",
    "formatted_formula": "Eu<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Europi(III) oxit"
  },
  {
    "id": "696",
    "formula": "Eu2O2",
    "formatted_formula": "Eu<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Europi oxit"
  },
  {
    "id": "697",
    "formula": "Eu2S",
    "formatted_formula": "Eu<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Dieuropi sunfua"
  },
  {
    "id": "698",
    "formula": "Eu2S2",
    "formatted_formula": "Eu<sub>2</sub>S<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dieuropi disunfua"
  },
  {
    "id": "700",
    "formula": "FGa",
    "formatted_formula": "FGa<sup></sup>",
    "vietnamese_name": "FGa"
  },
  {
    "id": "701",
    "formula": "FGaO",
    "formatted_formula": "FGaO<sup></sup>",
    "vietnamese_name": "Gali monoflorua monoxit"
  },
  {
    "id": "702",
    "formula": "FGd",
    "formatted_formula": "FGd<sup></sup>",
    "vietnamese_name": "Gadolini monoflorua"
  },
  {
    "id": "703",
    "formula": "FGe",
    "formatted_formula": "FGe<sup></sup>",
    "vietnamese_name": "Gecmani florua"
  },
  {
    "id": "704",
    "formula": "FHg",
    "formatted_formula": "FHg<sup></sup>",
    "vietnamese_name": "Thủy ngân florua"
  },
  {
    "id": "705",
    "formula": "FHo",
    "formatted_formula": "FHo<sup></sup>",
    "vietnamese_name": "Holmi monoflorua"
  },
  {
    "id": "706",
    "formula": "FI",
    "formatted_formula": "FI<sup></sup>",
    "vietnamese_name": "Iot monoflorua"
  },
  {
    "id": "707",
    "formula": "FI2",
    "formatted_formula": "FI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Flo diiodua"
  },
  {
    "id": "708",
    "formula": "FIn",
    "formatted_formula": "FIn<sup></sup>",
    "vietnamese_name": "Indi(I) florua"
  },
  {
    "id": "709",
    "formula": "FLa",
    "formatted_formula": "FLa<sup></sup>",
    "vietnamese_name": "Lantan monoflorua"
  },
  {
    "id": "710",
    "formula": "FLi",
    "formatted_formula": "FLi<sup></sup>",
    "vietnamese_name": "Liti florua"
  },
  {
    "id": "712",
    "formula": "FLi2",
    "formatted_formula": "FLi<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diliti monoflorua"
  },
  {
    "id": "713",
    "formula": "FMg",
    "formatted_formula": "FMg<sup></sup>",
    "vietnamese_name": "Magie monoflorua"
  },
  {
    "id": "714",
    "formula": "FMn",
    "formatted_formula": "FMn<sup></sup>",
    "vietnamese_name": "Mangan monoflorua"
  },
  {
    "id": "715",
    "formula": "FMnO3",
    "formatted_formula": "FMnO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Mangan trioxit florua"
  },
  {
    "id": "716",
    "formula": "FMo",
    "formatted_formula": "FMo<sup></sup>",
    "vietnamese_name": "Molypden monoflorua"
  },
  {
    "id": "717",
    "formula": "FN",
    "formatted_formula": "FN<sup></sup>",
    "vietnamese_name": "Nitơ monoflorua"
  },
  {
    "id": "718",
    "formula": "FNO",
    "formatted_formula": "FNO<sup></sup>",
    "vietnamese_name": "Nitrosyl florua"
  },
  {
    "id": "719",
    "formula": "FNO2",
    "formatted_formula": "FNO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Flo Nitrit"
  },
  {
    "id": "720",
    "formula": "FNO3",
    "formatted_formula": "FNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Flo Nitrat"
  },
  {
    "id": "721",
    "formula": "FNS",
    "formatted_formula": "FNS<sup></sup>",
    "vietnamese_name": "Thiazyl florua"
  },
  {
    "id": "722",
    "formula": "FNa",
    "formatted_formula": "FNa<sup></sup>",
    "vietnamese_name": "Natri florua"
  },
  {
    "id": "723",
    "formula": "FNa2",
    "formatted_formula": "FNa<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dinatri monoflorua"
  },
  {
    "id": "724",
    "formula": "FNd",
    "formatted_formula": "FNd<sup></sup>",
    "vietnamese_name": "Neodymi monoflorua"
  },
  {
    "id": "725",
    "formula": "FO",
    "formatted_formula": "FO<sup></sup>",
    "vietnamese_name": "Monooxi monoforua"
  },
  {
    "id": "726",
    "formula": "FOTi",
    "formatted_formula": "FOTi<sup></sup>",
    "vietnamese_name": "Titan florua oxit"
  },
  {
    "id": "727",
    "formula": "FO2",
    "formatted_formula": "FO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dioxi monoflorua"
  },
  {
    "id": "728",
    "formula": "FO3S",
    "formatted_formula": "FO<sub>3</sub>S<sup></sup>",
    "vietnamese_name": "Florosunfit"
  },
  {
    "id": "729",
    "formula": "FPS",
    "formatted_formula": "FPS<sup></sup>",
    "vietnamese_name": "Thiophosphoryl florua"
  },
  {
    "id": "730",
    "formula": "FPS2",
    "formatted_formula": "FPS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Phosphenodithioic florua"
  },
  {
    "id": "731",
    "formula": "FPb",
    "formatted_formula": "FPb<sup></sup>",
    "vietnamese_name": "Chì monoflorua"
  },
  {
    "id": "732",
    "formula": "FPu",
    "formatted_formula": "FPu<sup></sup>",
    "vietnamese_name": "Plutoni monoflorua"
  },
  {
    "id": "733",
    "formula": "FRb",
    "formatted_formula": "FRb<sup></sup>",
    "vietnamese_name": "Rubidi florua"
  },
  {
    "id": "734",
    "formula": "F2S2",
    "formatted_formula": "F<sub>2</sub>S<sub>2</sub><sup></sup>",
    "vietnamese_name": "Lưu huỳnh monoflorua"
  },
  {
    "id": "735",
    "formula": "FSc",
    "formatted_formula": "FSc<sup></sup>",
    "vietnamese_name": "Scandi monoflorua"
  },
  {
    "id": "736",
    "formula": "FSm",
    "formatted_formula": "FSm<sup></sup>",
    "vietnamese_name": "Samari monoflorua"
  },
  {
    "id": "737",
    "formula": "FSn",
    "formatted_formula": "FSn<sup></sup>",
    "vietnamese_name": "Thiếc monoflorua"
  },
  {
    "id": "738",
    "formula": "FSr",
    "formatted_formula": "FSr<sup></sup>",
    "vietnamese_name": "Stronti monoflorua"
  },
  {
    "id": "739",
    "formula": "FTh",
    "formatted_formula": "FTh<sup></sup>",
    "vietnamese_name": "Thori monoflorua"
  },
  {
    "id": "740",
    "formula": "FTl",
    "formatted_formula": "FTl<sup></sup>",
    "vietnamese_name": "Tali(I) florua"
  },
  {
    "id": "741",
    "formula": "FW",
    "formatted_formula": "FW<sup></sup>",
    "vietnamese_name": "Tungsten monoflorua"
  },
  {
    "id": "742",
    "formula": "FXe",
    "formatted_formula": "FXe<sup></sup>",
    "vietnamese_name": "Xenon monoflorua"
  },
  {
    "id": "743",
    "formula": "FY",
    "formatted_formula": "FY<sup></sup>",
    "vietnamese_name": "Yttri monoflorua"
  },
  {
    "id": "744",
    "formula": "FZr",
    "formatted_formula": "FZr<sup></sup>",
    "vietnamese_name": "Zirconi monoflorua"
  },
  {
    "id": "746",
    "formula": "F2Fe",
    "formatted_formula": "F<sub>2</sub>Fe<sup></sup>",
    "vietnamese_name": "Sắt(II) florua"
  },
  {
    "id": "747",
    "formula": "F2Ga",
    "formatted_formula": "F<sub>2</sub>Ga<sup></sup>",
    "vietnamese_name": "Gali diflorua"
  },
  {
    "id": "748",
    "formula": "F2Gd",
    "formatted_formula": "F<sub>2</sub>Gd<sup></sup>",
    "vietnamese_name": "Gadolini diflorua"
  },
  {
    "id": "749",
    "formula": "F2Ge",
    "formatted_formula": "F<sub>2</sub>Ge<sup></sup>",
    "vietnamese_name": "Germani(II) florua"
  },
  {
    "id": "750",
    "formula": "F2GeO",
    "formatted_formula": "F<sub>2</sub>GeO<sup></sup>",
    "vietnamese_name": "Difluorogermanone"
  },
  {
    "id": "751",
    "formula": "F2Hg",
    "formatted_formula": "F<sub>2</sub>Hg<sup></sup>",
    "vietnamese_name": "Thủy ngân(II) florua"
  },
  {
    "id": "752",
    "formula": "F2Hg2",
    "formatted_formula": "F<sub>2</sub>Hg<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(I) florua"
  },
  {
    "id": "753",
    "formula": "F2Ho",
    "formatted_formula": "F<sub>2</sub>Ho<sup></sup>",
    "vietnamese_name": "Holmi diflorua"
  },
  {
    "id": "754",
    "formula": "F2IP",
    "formatted_formula": "F<sub>2</sub>IP<sup></sup>",
    "vietnamese_name": "Difloroiodophosphin"
  },
  {
    "id": "755",
    "formula": "F2K2",
    "formatted_formula": "F<sub>2</sub>K<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dikali diflorua"
  },
  {
    "id": "756",
    "formula": "F2Kr",
    "formatted_formula": "F<sub>2</sub>Kr<sup></sup>",
    "vietnamese_name": "Krypton diflorua"
  },
  {
    "id": "757",
    "formula": "F2La",
    "formatted_formula": "F<sub>2</sub>La<sup></sup>",
    "vietnamese_name": "Lantan diflorua"
  },
  {
    "id": "758",
    "formula": "F2Li2",
    "formatted_formula": "F<sub>2</sub>Li<sub>2</sub><sup></sup>",
    "vietnamese_name": "Liti florua"
  },
  {
    "id": "759",
    "formula": "F2Mg",
    "formatted_formula": "F<sub>2</sub>Mg<sup></sup>",
    "vietnamese_name": "Magie florua"
  },
  {
    "id": "760",
    "formula": "F2Mn",
    "formatted_formula": "F<sub>2</sub>Mn<sup></sup>",
    "vietnamese_name": "Mangan diflorua"
  },
  {
    "id": "762",
    "formula": "F2MoO2",
    "formatted_formula": "F<sub>2</sub>MoO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Molybden diflorua dioxit"
  },
  {
    "id": "763",
    "formula": "F2Mo",
    "formatted_formula": "F<sub>2</sub>Mo<sup></sup>",
    "vietnamese_name": "Molybden diflorua"
  },
  {
    "id": "764",
    "formula": "F2N",
    "formatted_formula": "F<sub>2</sub>N<sup></sup>",
    "vietnamese_name": "Difluoroamino radical"
  },
  {
    "id": "765",
    "formula": "F2N2O",
    "formatted_formula": "F<sub>2</sub>N<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nitrosodifluoroamine"
  },
  {
    "id": "766",
    "formula": "F2Na2",
    "formatted_formula": "F<sub>2</sub>Na<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dinatri diflorua"
  },
  {
    "id": "767",
    "formula": "F2Nd",
    "formatted_formula": "F<sub>2</sub>Nd<sup></sup>",
    "vietnamese_name": "Neodymi diflorua"
  },
  {
    "id": "768",
    "formula": "F2Ni",
    "formatted_formula": "F<sub>2</sub>Ni<sup></sup>",
    "vietnamese_name": "Niken diflorua"
  },
  {
    "id": "769",
    "formula": "F2O",
    "formatted_formula": "F<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Flo monoxit"
  },
  {
    "id": "770",
    "formula": "F2OS",
    "formatted_formula": "F<sub>2</sub>OS<sup></sup>",
    "vietnamese_name": "Thionyl florua"
  },
  {
    "id": "771",
    "formula": "F2OSi",
    "formatted_formula": "F<sub>2</sub>OSi<sup></sup>",
    "vietnamese_name": "Diflorooxosilan"
  },
  {
    "id": "772",
    "formula": "F2OTi",
    "formatted_formula": "F<sub>2</sub>OTi<sup></sup>",
    "vietnamese_name": "Titan(IV) diflorua oxit"
  },
  {
    "id": "773",
    "formula": "F2O2",
    "formatted_formula": "F<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Peroxy diflorua"
  },
  {
    "id": "774",
    "formula": "F2O2S",
    "formatted_formula": "F<sub>2</sub>O<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Sunfuryl florua"
  },
  {
    "id": "775",
    "formula": "F2O2W",
    "formatted_formula": "F<sub>2</sub>O<sub>2</sub>W<sup></sup>",
    "vietnamese_name": "Tungsten diflorua dioxit"
  },
  {
    "id": "777",
    "formula": "F2P",
    "formatted_formula": "F<sub>2</sub>P<sup></sup>",
    "vietnamese_name": "Photpho diflorua"
  },
  {
    "id": "778",
    "formula": "F2Pb",
    "formatted_formula": "F<sub>2</sub>Pb<sup></sup>",
    "vietnamese_name": "Chì diflorua"
  },
  {
    "id": "779",
    "formula": "F2Pt",
    "formatted_formula": "F<sub>2</sub>Pt<sup></sup>",
    "vietnamese_name": "Platin diflorua"
  },
  {
    "id": "780",
    "formula": "F3Fe",
    "formatted_formula": "F<sub>3</sub>Fe<sup></sup>",
    "vietnamese_name": "Sắt(III) triflorua"
  },
  {
    "id": "781",
    "formula": "F2Zr",
    "formatted_formula": "F<sub>2</sub>Zr<sup></sup>",
    "vietnamese_name": "Zirconi diflorua"
  },
  {
    "id": "782",
    "formula": "F2Zn",
    "formatted_formula": "F<sub>2</sub>Zn<sup></sup>",
    "vietnamese_name": "Kẽm florua"
  },
  {
    "id": "783",
    "formula": "F3Ga",
    "formatted_formula": "F<sub>3</sub>Ga<sup></sup>",
    "vietnamese_name": "Gali triflorua"
  },
  {
    "id": "784",
    "formula": "F3Gd",
    "formatted_formula": "F<sub>3</sub>Gd<sup></sup>",
    "vietnamese_name": "Gadolini triflorua"
  },
  {
    "id": "785",
    "formula": "F3Ho",
    "formatted_formula": "F<sub>3</sub>Ho<sup></sup>",
    "vietnamese_name": "Holmi triflorua"
  },
  {
    "id": "786",
    "formula": "F3La",
    "formatted_formula": "F<sub>3</sub>La<sup></sup>",
    "vietnamese_name": "Lantan triflorua"
  },
  {
    "id": "787",
    "formula": "F3Li3",
    "formatted_formula": "F<sub>3</sub>Li<sub>3</sub><sup></sup>",
    "vietnamese_name": "Triliti triflorua"
  },
  {
    "id": "788",
    "formula": "F3Lu",
    "formatted_formula": "F<sub>3</sub>Lu<sup></sup>",
    "vietnamese_name": "Luteti triflorua"
  },
  {
    "id": "789",
    "formula": "F3Mn",
    "formatted_formula": "F<sub>3</sub>Mn<sup></sup>",
    "vietnamese_name": "Mangan(III) triflorua"
  },
  {
    "id": "790",
    "formula": "F3Mo",
    "formatted_formula": "F<sub>3</sub>Mo<sup></sup>",
    "vietnamese_name": "Molybden triflorua"
  },
  {
    "id": "791",
    "formula": "F3MoO",
    "formatted_formula": "F<sub>3</sub>MoO<sup></sup>",
    "vietnamese_name": "Molybden triflorua oxit"
  },
  {
    "id": "792",
    "formula": "F3MoS",
    "formatted_formula": "F<sub>3</sub>MoS<sup></sup>",
    "vietnamese_name": "Molybden triflorua sunfua"
  },
  {
    "id": "793",
    "formula": "F3N",
    "formatted_formula": "F<sub>3</sub>N<sup></sup>",
    "vietnamese_name": "Nitơ triflorua"
  },
  {
    "id": "794",
    "formula": "F3NO",
    "formatted_formula": "F<sub>3</sub>NO<sup></sup>",
    "vietnamese_name": "Trifloroamin oxit"
  },
  {
    "id": "795",
    "formula": "F3NO2S",
    "formatted_formula": "F<sub>3</sub>NO<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Difluoroaminosulfonyl fluoride"
  },
  {
    "id": "796",
    "formula": "F3NO3S",
    "formatted_formula": "F<sub>3</sub>NO<sub>3</sub>S<sup></sup>",
    "vietnamese_name": "Difluoraminooxysulfonyl fluoride"
  },
  {
    "id": "797",
    "formula": "F3NS",
    "formatted_formula": "F<sub>3</sub>NS<sup></sup>",
    "vietnamese_name": "Thiazyl triflorua"
  },
  {
    "id": "798",
    "formula": "F3NaSn",
    "formatted_formula": "F<sub>3</sub>NaSn<sup></sup>",
    "vietnamese_name": "Natri triflorostannat"
  },
  {
    "id": "799",
    "formula": "F3Nd",
    "formatted_formula": "F<sub>3</sub>Nd<sup></sup>",
    "vietnamese_name": "Neodymi triflorua"
  },
  {
    "id": "800",
    "formula": "F3OP",
    "formatted_formula": "F<sub>3</sub>OP<sup></sup>",
    "vietnamese_name": "Phosphoryl triflorua"
  },
  {
    "id": "802",
    "formula": "F3OTa",
    "formatted_formula": "F<sub>3</sub>OTa<sup></sup>",
    "vietnamese_name": "Tantali monoxit triflorua"
  },
  {
    "id": "803",
    "formula": "F3OV",
    "formatted_formula": "F<sub>3</sub>OV<sup></sup>",
    "vietnamese_name": "Vanadi(V) triflorua oxit"
  },
  {
    "id": "804",
    "formula": "F3P",
    "formatted_formula": "F<sub>3</sub>P<sup></sup>",
    "vietnamese_name": "Photpho triflorua"
  },
  {
    "id": "805",
    "formula": "F3PS",
    "formatted_formula": "F<sub>3</sub>PS<sup></sup>",
    "vietnamese_name": "Photpho thioflorua"
  },
  {
    "id": "806",
    "formula": "F3Pr",
    "formatted_formula": "F<sub>3</sub>Pr<sup></sup>",
    "vietnamese_name": "Praseodymi triflorua"
  },
  {
    "id": "807",
    "formula": "F3Pu",
    "formatted_formula": "F<sub>3</sub>Pu<sup></sup>",
    "vietnamese_name": "Plutoni triflorua"
  },
  {
    "id": "808",
    "formula": "F3Rh",
    "formatted_formula": "F<sub>3</sub>Rh<sup></sup>",
    "vietnamese_name": "Rhodi(III) triflorua"
  },
  {
    "id": "809",
    "formula": "F3S",
    "formatted_formula": "F<sub>3</sub>S<sup></sup>",
    "vietnamese_name": "Lưu huỳnh triflorua"
  },
  {
    "id": "810",
    "formula": "F3SW",
    "formatted_formula": "F<sub>3</sub>SW<sup></sup>",
    "vietnamese_name": "Tungsten triflorua monosunfua"
  },
  {
    "id": "811",
    "formula": "F3Sb",
    "formatted_formula": "F<sub>3</sub>Sb<sup></sup>",
    "vietnamese_name": "Antimon triflorua"
  },
  {
    "id": "812",
    "formula": "F3Sc",
    "formatted_formula": "F<sub>3</sub>Sc<sup></sup>",
    "vietnamese_name": "Scandi triflorua"
  },
  {
    "id": "813",
    "formula": "F3Si",
    "formatted_formula": "F<sub>3</sub>Si<sup></sup>",
    "vietnamese_name": "Trifluorosilyl radical"
  },
  {
    "id": "814",
    "formula": "F3Sm",
    "formatted_formula": "F<sub>3</sub>Sm<sup></sup>",
    "vietnamese_name": "Samari(III) triflorua"
  },
  {
    "id": "815",
    "formula": "F3Tb",
    "formatted_formula": "F<sub>3</sub>Tb<sup></sup>",
    "vietnamese_name": "Terbi triflorua"
  },
  {
    "id": "816",
    "formula": "F3Th",
    "formatted_formula": "F<sub>3</sub>Th<sup></sup>",
    "vietnamese_name": "Thori triflorua"
  },
  {
    "id": "817",
    "formula": "F3Ti",
    "formatted_formula": "F<sub>3</sub>Ti<sup></sup>",
    "vietnamese_name": "Titani triflorua"
  },
  {
    "id": "818",
    "formula": "F3Tl",
    "formatted_formula": "F<sub>3</sub>Tl<sup></sup>",
    "vietnamese_name": "Thali(III) florua"
  },
  {
    "id": "819",
    "formula": "F3Tm",
    "formatted_formula": "F<sub>3</sub>Tm<sup></sup>",
    "vietnamese_name": "Thuli triflorua"
  },
  {
    "id": "820",
    "formula": "F3W",
    "formatted_formula": "F<sub>3</sub>W<sup></sup>",
    "vietnamese_name": "Tungsten triflorua"
  },
  {
    "id": "821",
    "formula": "F3Y",
    "formatted_formula": "F<sub>3</sub>Y<sup></sup>",
    "vietnamese_name": "Yttri triflorua"
  },
  {
    "id": "822",
    "formula": "F3Yb",
    "formatted_formula": "F<sub>3</sub>Yb<sup></sup>",
    "vietnamese_name": "Yterbi(III) florua"
  },
  {
    "id": "823",
    "formula": "F3Zr",
    "formatted_formula": "F<sub>3</sub>Zr<sup></sup>",
    "vietnamese_name": "Zirconi triflorua"
  },
  {
    "id": "824",
    "formula": "F4Ge",
    "formatted_formula": "F<sub>4</sub>Ge<sup></sup>",
    "vietnamese_name": "Germani(IV) tetraflorua"
  },
  {
    "id": "825",
    "formula": "F4Ge2",
    "formatted_formula": "F<sub>4</sub>Ge<sub>2</sub><sup></sup>",
    "vietnamese_name": "Digermani tetraflorua"
  },
  {
    "id": "826",
    "formula": "F4Hf",
    "formatted_formula": "F<sub>4</sub>Hf<sup></sup>",
    "vietnamese_name": "Hafni tetraflorua"
  },
  {
    "id": "827",
    "formula": "F4Mg2",
    "formatted_formula": "F<sub>4</sub>Mg<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dimagie tetraflorua"
  },
  {
    "id": "828",
    "formula": "F4MoO",
    "formatted_formula": "F<sub>4</sub>MoO<sup></sup>",
    "vietnamese_name": "Molybden tetraflorua oxit"
  },
  {
    "id": "829",
    "formula": "F4MoS",
    "formatted_formula": "F<sub>4</sub>MoS<sup></sup>",
    "vietnamese_name": "Molybden tetraflorua monosunfua"
  },
  {
    "id": "830",
    "formula": "F4N2",
    "formatted_formula": "F<sub>4</sub>N<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetraflorohydrazin"
  },
  {
    "id": "831",
    "formula": "F4Na2Sn",
    "formatted_formula": "F<sub>4</sub>Na<sub>2</sub>Sn<sup></sup>",
    "vietnamese_name": "Dinatri tetraflorostannat"
  },
  {
    "id": "832",
    "formula": "F4OOs",
    "formatted_formula": "F<sub>4</sub>OOs<sup></sup>",
    "vietnamese_name": "Osmi oxit tetraflorua"
  },
  {
    "id": "833",
    "formula": "F4OP2",
    "formatted_formula": "F<sub>4</sub>OP<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diphotpho tetraflorua"
  },
  {
    "id": "834",
    "formula": "F4ORe",
    "formatted_formula": "F<sub>4</sub>ORe<sup></sup>",
    "vietnamese_name": "Rheni(VI) tetraflorua oxit"
  },
  {
    "id": "835",
    "formula": "F4OS",
    "formatted_formula": "F<sub>4</sub>OS<sup></sup>",
    "vietnamese_name": "Thionyl tetraflorua"
  },
  {
    "id": "836",
    "formula": "F4OW",
    "formatted_formula": "F<sub>4</sub>OW<sup></sup>",
    "vietnamese_name": "Tungsten oxitetraflorua"
  },
  {
    "id": "837",
    "formula": "F4OXe",
    "formatted_formula": "F<sub>4</sub>OXe<sup></sup>",
    "vietnamese_name": "Xenon oxitetraflorua"
  },
  {
    "id": "838",
    "formula": "F4P2",
    "formatted_formula": "F<sub>4</sub>P<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetrafloro diphotphin"
  },
  {
    "id": "839",
    "formula": "F4Pb",
    "formatted_formula": "F<sub>4</sub>Pb<sup></sup>",
    "vietnamese_name": "Chì tetraflorua"
  },
  {
    "id": "840",
    "formula": "F4Pt",
    "formatted_formula": "F<sub>4</sub>Pt<sup></sup>",
    "vietnamese_name": "Platin tetraflorua"
  },
  {
    "id": "841",
    "formula": "F4Pu",
    "formatted_formula": "F<sub>4</sub>Pu<sup></sup>",
    "vietnamese_name": "Plutoni tetraflorua"
  },
  {
    "id": "842",
    "formula": "F4S",
    "formatted_formula": "F<sub>4</sub>S<sup></sup>",
    "vietnamese_name": "Lưu huỳnh tetraflorua"
  },
  {
    "id": "843",
    "formula": "F4SW",
    "formatted_formula": "F<sub>4</sub>SW<sup></sup>",
    "vietnamese_name": "Tungsten tetraflorua monosunfua"
  },
  {
    "id": "844",
    "formula": "F4Se",
    "formatted_formula": "F<sub>4</sub>Se<sup></sup>",
    "vietnamese_name": "Selen(IV) florua"
  },
  {
    "id": "845",
    "formula": "F4Si",
    "formatted_formula": "F<sub>4</sub>Si<sup></sup>",
    "vietnamese_name": "Silic tetraflorua"
  },
  {
    "id": "846",
    "formula": "F4Sn2",
    "formatted_formula": "F<sub>4</sub>Sn<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đithiếc tetraflorua"
  },
  {
    "id": "847",
    "formula": "F4Ti",
    "formatted_formula": "F<sub>4</sub>Ti<sup></sup>",
    "vietnamese_name": "Titan tetraflorua"
  },
  {
    "id": "848",
    "formula": "F4U",
    "formatted_formula": "F<sub>4</sub>U<sup></sup>",
    "vietnamese_name": "Urani tetraflorua"
  },
  {
    "id": "849",
    "formula": "F4W",
    "formatted_formula": "F<sub>4</sub>W<sup></sup>",
    "vietnamese_name": "Tungsten tetraflorua"
  },
  {
    "id": "850",
    "formula": "F4Xe",
    "formatted_formula": "F<sub>4</sub>Xe<sup></sup>",
    "vietnamese_name": "Xenon(IV) tetraflorua"
  },
  {
    "id": "851",
    "formula": "F4Zr",
    "formatted_formula": "F<sub>4</sub>Zr<sup></sup>",
    "vietnamese_name": "Zirconi tetraflorua"
  },
  {
    "id": "852",
    "formula": "F5I",
    "formatted_formula": "F<sub>5</sub>I<sup></sup>",
    "vietnamese_name": "Iot pentaflorua"
  },
  {
    "id": "853",
    "formula": "F5Mo",
    "formatted_formula": "F<sub>5</sub>Mo<sup></sup>",
    "vietnamese_name": "Molybden pentaflorua"
  },
  {
    "id": "854",
    "formula": "F5ORe",
    "formatted_formula": "F<sub>5</sub>ORe<sup></sup>",
    "vietnamese_name": "Rheni pentaflorua oxit"
  },
  {
    "id": "855",
    "formula": "F5P",
    "formatted_formula": "F<sub>5</sub>P<sup></sup>",
    "vietnamese_name": "Lưu huỳnh pentaflorua"
  },
  {
    "id": "856",
    "formula": "F5Pu",
    "formatted_formula": "F<sub>5</sub>Pu<sup></sup>",
    "vietnamese_name": "Plutoni pentaflorua"
  },
  {
    "id": "857",
    "formula": "F5S",
    "formatted_formula": "F<sub>5</sub>S<sup></sup>",
    "vietnamese_name": "Lưu huỳnh pentaflorua"
  },
  {
    "id": "858",
    "formula": "F5Sb",
    "formatted_formula": "F<sub>5</sub>Sb<sup></sup>",
    "vietnamese_name": "Antimon pentaflorua"
  },
  {
    "id": "859",
    "formula": "F5Ta",
    "formatted_formula": "F<sub>5</sub>Ta<sup></sup>",
    "vietnamese_name": "Tantali(V) florua"
  },
  {
    "id": "860",
    "formula": "F5U",
    "formatted_formula": "F<sub>5</sub>U<sup></sup>",
    "vietnamese_name": "Urani pentaflorua"
  },
  {
    "id": "861",
    "formula": "F5W",
    "formatted_formula": "F<sub>5</sub>W<sup></sup>",
    "vietnamese_name": "Wolfram pentaforua"
  },
  {
    "id": "862",
    "formula": "F6Fe2",
    "formatted_formula": "F<sub>6</sub>Fe<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đisắt hexaflorua"
  },
  {
    "id": "863",
    "formula": "F6Mo",
    "formatted_formula": "F<sub>6</sub>Mo<sup></sup>",
    "vietnamese_name": "Molybden hexaflorua"
  },
  {
    "id": "864",
    "formula": "F6NP3",
    "formatted_formula": "F<sub>6</sub>NP<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nitrilotris(difluorophosphine)"
  },
  {
    "id": "865",
    "formula": "F6Os",
    "formatted_formula": "F<sub>6</sub>Os<sup></sup>",
    "vietnamese_name": "Osmi hexaflorua"
  },
  {
    "id": "866",
    "formula": "F6Pu",
    "formatted_formula": "F<sub>6</sub>Pu<sup></sup>",
    "vietnamese_name": "Plutoni hexaflorua"
  },
  {
    "id": "867",
    "formula": "F6Re",
    "formatted_formula": "F<sub>6</sub>Re<sup></sup>",
    "vietnamese_name": "Rheni(VI)hexaflorua"
  },
  {
    "id": "868",
    "formula": "F6S",
    "formatted_formula": "F<sub>6</sub>S<sup></sup>",
    "vietnamese_name": "Lưu huỳnh hexaflorua"
  },
  {
    "id": "869",
    "formula": "F6Se",
    "formatted_formula": "F<sub>6</sub>Se<sup></sup>",
    "vietnamese_name": "Selen(VI) florua"
  },
  {
    "id": "870",
    "formula": "F6Si2",
    "formatted_formula": "F<sub>6</sub>Si<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexaflorodisilan"
  },
  {
    "id": "871",
    "formula": "F6Sn3",
    "formatted_formula": "F<sub>6</sub>Sn<sub>3</sub><sup></sup>",
    "vietnamese_name": "Trithiếc hexaflorua"
  },
  {
    "id": "872",
    "formula": "F6Te",
    "formatted_formula": "F<sub>6</sub>Te<sup></sup>",
    "vietnamese_name": "Teluri hexaflorua"
  },
  {
    "id": "873",
    "formula": "F6U",
    "formatted_formula": "F<sub>6</sub>U<sup></sup>",
    "vietnamese_name": "Urani hexaflorua"
  },
  {
    "id": "874",
    "formula": "F6W",
    "formatted_formula": "F<sub>6</sub>W<sup></sup>",
    "vietnamese_name": "Wolfram(VI)hexaflorua"
  },
  {
    "id": "875",
    "formula": "F6Xe",
    "formatted_formula": "F<sub>6</sub>Xe<sup></sup>",
    "vietnamese_name": "Xenon hexaflorua"
  },
  {
    "id": "876",
    "formula": "F7I",
    "formatted_formula": "F<sub>7</sub>I<sup></sup>",
    "vietnamese_name": "Iot heptaflorua"
  },
  {
    "id": "877",
    "formula": "F7NS",
    "formatted_formula": "F<sub>7</sub>NS<sup></sup>",
    "vietnamese_name": "Pentaflorosunfanyldifloroamin"
  },
  {
    "id": "878",
    "formula": "F7Re",
    "formatted_formula": "F<sub>7</sub>Re<sup></sup>",
    "vietnamese_name": "Rheni(VII) florua"
  },
  {
    "id": "879",
    "formula": "F8Si3",
    "formatted_formula": "F<sub>8</sub>Si<sub>3</sub><sup></sup>",
    "vietnamese_name": "Octaflorotrisilan"
  },
  {
    "id": "880",
    "formula": "F10Mo2",
    "formatted_formula": "F<sub>1</sub><sub>0</sub>Mo<sub>2</sub><sup></sup>",
    "vietnamese_name": "Molybden florua"
  },
  {
    "id": "881",
    "formula": "F10S2",
    "formatted_formula": "F<sub>1</sub><sub>0</sub>S<sub>2</sub><sup></sup>",
    "vietnamese_name": "Disulfur decafluoride"
  },
  {
    "id": "882",
    "formula": "F15Mo3",
    "formatted_formula": "F<sub>1</sub><sub>5</sub>Mo<sub>3</sub><sup></sup>",
    "vietnamese_name": "Molybden fluorua"
  },
  {
    "id": "883",
    "formula": "FeAsS",
    "formatted_formula": "FeAsS<sup></sup>",
    "vietnamese_name": "Arsenopyrite"
  },
  {
    "id": "884",
    "formula": "FeBr2",
    "formatted_formula": "FeBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt dibromua"
  },
  {
    "id": "885",
    "formula": "FeBr3",
    "formatted_formula": "FeBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(III) tribromua"
  },
  {
    "id": "886",
    "formula": "FeBr3.6H2O",
    "formatted_formula": "FeBr<sub>3</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Sắt(III) bromua hexahidrat"
  },
  {
    "id": "889",
    "formula": "FeC2O4",
    "formatted_formula": "FeC<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) oxalat"
  },
  {
    "id": "890",
    "formula": "FeC5O5",
    "formatted_formula": "FeC<sub>5</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Sắt pentacacbonyl"
  },
  {
    "id": "891",
    "formula": "FeC10H10",
    "formatted_formula": "FeC<sub>1</sub><sub>0</sub>H<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Ferrocene"
  },
  {
    "id": "893",
    "formula": "FeCl3",
    "formatted_formula": "FeCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt triclorua"
  },
  {
    "id": "895",
    "formula": "FeF2.4H2O",
    "formatted_formula": "FeF<sub>2</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Sắt(II) florua tetrahidrat"
  },
  {
    "id": "896",
    "formula": "FeI",
    "formatted_formula": "FeI<sup></sup>",
    "vietnamese_name": "Sắt monoiodua"
  },
  {
    "id": "897",
    "formula": "FeI2",
    "formatted_formula": "FeI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) iodua"
  },
  {
    "id": "898",
    "formula": "FeI2.4H2O",
    "formatted_formula": "FeI<sub>2</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Sắt(II) iodua tetrahidrat"
  },
  {
    "id": "899",
    "formula": "FeI3",
    "formatted_formula": "FeI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(III) triiodua"
  },
  {
    "id": "900",
    "formula": "FeMoO4",
    "formatted_formula": "FeMoO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) Molybdat"
  },
  {
    "id": "902",
    "formula": "FeO2",
    "formatted_formula": "FeO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt đioxit"
  },
  {
    "id": "903",
    "formula": "FeO2H",
    "formatted_formula": "FeO<sub>2</sub>H<sup></sup>",
    "vietnamese_name": "Goethite"
  },
  {
    "id": "904",
    "formula": "FeO2H.nH2O",
    "formatted_formula": "FeO<sub>2</sub>H.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Goethite hidrat"
  },
  {
    "id": "905",
    "formula": "Fe(OH)2",
    "formatted_formula": "Fe(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) hidroxit"
  },
  {
    "id": "906",
    "formula": "Fe(OH)3",
    "formatted_formula": "Fe(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(III) hidroxit"
  },
  {
    "id": "907",
    "formula": "FeO4S",
    "formatted_formula": "FeO<sub>4</sub>S<sup></sup>",
    "vietnamese_name": "Sắt sunfat"
  },
  {
    "id": "908",
    "formula": "FeO8H4P2",
    "formatted_formula": "FeO<sub>8</sub>H<sub>4</sub>P<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) Dihidro Photphat"
  },
  {
    "id": "909",
    "formula": "FeP",
    "formatted_formula": "FeP<sup></sup>",
    "vietnamese_name": "Sắt(III) photphua"
  },
  {
    "id": "912",
    "formula": "FeSe",
    "formatted_formula": "FeSe<sup></sup>",
    "vietnamese_name": "Sắt(II) selenua"
  },
  {
    "id": "913",
    "formula": "FeTe",
    "formatted_formula": "FeTe<sup></sup>",
    "vietnamese_name": "Sắt(II) telurua"
  },
  {
    "id": "914",
    "formula": "FeTiO3",
    "formatted_formula": "FeTiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) titanat"
  },
  {
    "id": "915",
    "formula": "FeVO4",
    "formatted_formula": "FeVO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sắt vanadi oxit"
  },
  {
    "id": "916",
    "formula": "FeWO4",
    "formatted_formula": "FeWO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) tungstat(VI)"
  },
  {
    "id": "917",
    "formula": "FeZrO3",
    "formatted_formula": "FeZrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "sắt(II) metazirconat"
  },
  {
    "id": "918",
    "formula": "Fe2I2",
    "formatted_formula": "Fe<sub>2</sub>I<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đisắt diiodua"
  },
  {
    "id": "919",
    "formula": "Fe2I4",
    "formatted_formula": "Fe<sub>2</sub>I<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) tetraiodua"
  },
  {
    "id": "923",
    "formula": "Fe2O12S3",
    "formatted_formula": "Fe<sub>2</sub>O<sub>1</sub><sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(III) sunfat"
  },
  {
    "id": "924",
    "formula": "Fe2O12W3",
    "formatted_formula": "Fe<sub>2</sub>O<sub>1</sub><sub>2</sub>W<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt tungstat"
  },
  {
    "id": "925",
    "formula": "Fe2P",
    "formatted_formula": "Fe<sub>2</sub>P<sup></sup>",
    "vietnamese_name": "Đisắt photphua"
  },
  {
    "id": "926",
    "formula": "Fe2SiO4",
    "formatted_formula": "Fe<sub>2</sub>SiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "sắt(II) orthosilicat"
  },
  {
    "id": "927",
    "formula": "Fe3H2Na2O45Si",
    "formatted_formula": "Fe<sub>3</sub>H<sub>2</sub>Na<sub>2</sub>O<sub>4</sub><sub>5</sub>Si<sup></sup>",
    "vietnamese_name": "Crocidolite asbestos"
  },
  {
    "id": "929",
    "formula": "Fe3P",
    "formatted_formula": "Fe<sub>3</sub>P<sup></sup>",
    "vietnamese_name": "Trisắt photphua"
  },
  {
    "id": "931",
    "formula": "FP",
    "formatted_formula": "FP<sup></sup>",
    "vietnamese_name": "Photpho monoflorua"
  },
  {
    "id": "932",
    "formula": "FTi",
    "formatted_formula": "FTi<sup></sup>",
    "vietnamese_name": "Titan florua"
  },
  {
    "id": "933",
    "formula": "F2Pu",
    "formatted_formula": "F<sub>2</sub>Pu<sup></sup>",
    "vietnamese_name": "Plutoni diflorua"
  },
  {
    "id": "934",
    "formula": "F2S",
    "formatted_formula": "F<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Lưu huỳnh diflorua"
  },
  {
    "id": "935",
    "formula": "F2SW",
    "formatted_formula": "F<sub>2</sub>SW<sup></sup>",
    "vietnamese_name": "Tungsten diflorua monosunfua"
  },
  {
    "id": "937",
    "formula": "F2S2W",
    "formatted_formula": "F<sub>2</sub>S<sub>2</sub>W<sup></sup>",
    "vietnamese_name": "Tungsten diflorua monosunfua"
  },
  {
    "id": "938",
    "formula": "F2Sc",
    "formatted_formula": "F<sub>2</sub>Sc<sup></sup>",
    "vietnamese_name": "Difluoroscandio radical"
  },
  {
    "id": "939",
    "formula": "F2Se",
    "formatted_formula": "F<sub>2</sub>Se<sup></sup>",
    "vietnamese_name": "Selen diflorua"
  },
  {
    "id": "940",
    "formula": "F2Si",
    "formatted_formula": "F<sub>2</sub>Si<sup></sup>",
    "vietnamese_name": "Silic diflorua"
  },
  {
    "id": "941",
    "formula": "F2Sn",
    "formatted_formula": "F<sub>2</sub>Sn<sup></sup>",
    "vietnamese_name": "Thiếc(II) florua"
  },
  {
    "id": "942",
    "formula": "F2Sr",
    "formatted_formula": "F<sub>2</sub>Sr<sup></sup>",
    "vietnamese_name": "Stronti florua"
  },
  {
    "id": "943",
    "formula": "F2Th",
    "formatted_formula": "F<sub>2</sub>Th<sup></sup>",
    "vietnamese_name": "Thori diflorua"
  },
  {
    "id": "944",
    "formula": "F2Ti",
    "formatted_formula": "F<sub>2</sub>Ti<sup></sup>",
    "vietnamese_name": "Titan diflorua"
  },
  {
    "id": "945",
    "formula": "F2Tl2",
    "formatted_formula": "F<sub>2</sub>Tl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dithali diflorua"
  },
  {
    "id": "946",
    "formula": "F2W",
    "formatted_formula": "F<sub>2</sub>W<sup></sup>",
    "vietnamese_name": "Tungsten diflorua"
  },
  {
    "id": "947",
    "formula": "F2Xe",
    "formatted_formula": "F<sub>2</sub>Xe<sup></sup>",
    "vietnamese_name": "Xenon(II) diflorua"
  },
  {
    "id": "948",
    "formula": "F2Y",
    "formatted_formula": "F<sub>2</sub>Y<sup></sup>",
    "vietnamese_name": "Yterbi(II) florua"
  },
  {
    "id": "950",
    "formula": "AlPO4",
    "formatted_formula": "AlPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Nhôm phosphat"
  },
  {
    "id": "951",
    "formula": "Bi2(SO4)5",
    "formatted_formula": "Bi<sub>2</sub>(SO<sub>4</sub>)<sub>5</sub><sup></sup>",
    "vietnamese_name": "Đibitmut pentasunfat"
  },
  {
    "id": "954",
    "formula": "F6La2",
    "formatted_formula": "F<sub>6</sub>La<sub>2</sub><sup></sup>",
    "vietnamese_name": "Lantan(III) florua dime"
  },
  {
    "id": "956",
    "formula": "GaAs",
    "formatted_formula": "GaAs<sup></sup>",
    "vietnamese_name": "Gali arsenua"
  },
  {
    "id": "957",
    "formula": "GaAsO4",
    "formatted_formula": "GaAsO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Gali arsenat"
  },
  {
    "id": "958",
    "formula": "GaBr3",
    "formatted_formula": "GaBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Gali tribromua"
  },
  {
    "id": "959",
    "formula": "Ga(C2H3O2)3",
    "formatted_formula": "Ga(C<sub>2</sub>H<sub>3</sub>O<sub>2</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Gali(III) Axetat"
  },
  {
    "id": "960",
    "formula": "GaCl2",
    "formatted_formula": "GaCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Gali diclorua"
  },
  {
    "id": "961",
    "formula": "GaCl3",
    "formatted_formula": "GaCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Gali triclorua"
  },
  {
    "id": "962",
    "formula": "GaI2",
    "formatted_formula": "GaI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Gali(II) iodua"
  },
  {
    "id": "963",
    "formula": "GaI3",
    "formatted_formula": "GaI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Gali triiodua"
  },
  {
    "id": "965",
    "formula": "GaN",
    "formatted_formula": "GaN<sup></sup>",
    "vietnamese_name": "Gali nitrua"
  },
  {
    "id": "966",
    "formula": "Ga(OH)3",
    "formatted_formula": "Ga(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Gali trihydroxit"
  },
  {
    "id": "967",
    "formula": "GaPO4",
    "formatted_formula": "GaPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Gali phosphat"
  },
  {
    "id": "968",
    "formula": "GaSb",
    "formatted_formula": "GaSb<sup></sup>",
    "vietnamese_name": "Gali antimonua"
  },
  {
    "id": "969",
    "formula": "GaTe",
    "formatted_formula": "GaTe<sup></sup>",
    "vietnamese_name": "Gali telurua"
  },
  {
    "id": "970",
    "formula": "Ga2O3",
    "formatted_formula": "Ga<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Gali(III) oxit"
  },
  {
    "id": "971",
    "formula": "Ga2(SO4)3.18H2O",
    "formatted_formula": "Ga<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub>.18H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Gali(III) sunfat octadecahidrat\t"
  },
  {
    "id": "972",
    "formula": "Ga2S3",
    "formatted_formula": "Ga<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đigali trisunfua"
  },
  {
    "id": "973",
    "formula": "Ga2Te3",
    "formatted_formula": "Ga<sub>2</sub>Te<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đigali tritelurua"
  },
  {
    "id": "974",
    "formula": "GeBr4",
    "formatted_formula": "GeBr<sub>4</sub><sup></sup>",
    "vietnamese_name": "Germani(IV) bromua"
  },
  {
    "id": "975",
    "formula": "GeH3COOH",
    "formatted_formula": "GeH<sub>3</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit 2-germaaxetic"
  },
  {
    "id": "976",
    "formula": "GeI2",
    "formatted_formula": "GeI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Germani(II) iodua"
  },
  {
    "id": "977",
    "formula": "GeI4",
    "formatted_formula": "GeI<sub>4</sub><sup></sup>",
    "vietnamese_name": "Germani(IV) iodua"
  },
  {
    "id": "978",
    "formula": "GeO",
    "formatted_formula": "GeO<sup></sup>",
    "vietnamese_name": "Germani(II) oxit"
  },
  {
    "id": "979",
    "formula": "HAt",
    "formatted_formula": "HAt<sup></sup>",
    "vietnamese_name": "Astatin"
  },
  {
    "id": "981",
    "formula": "HCCH",
    "formatted_formula": "HCCH<sup></sup>",
    "vietnamese_name": "Acetylen"
  },
  {
    "id": "982",
    "formula": "HCN",
    "formatted_formula": "HCN<sup></sup>",
    "vietnamese_name": "Hidro cyanua"
  },
  {
    "id": "983",
    "formula": "HCONH2",
    "formatted_formula": "HCONH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Methanamide"
  },
  {
    "id": "984",
    "formula": "HCOO−",
    "formatted_formula": "HCOO−<sup></sup>",
    "vietnamese_name": "Ion format"
  },
  {
    "id": "986",
    "formula": "HCOONH4",
    "formatted_formula": "HCOONH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Ammoni format"
  },
  {
    "id": "987",
    "formula": "HCO3−",
    "formatted_formula": "HCO<sub>3</sub>−<sup></sup>",
    "vietnamese_name": "Ion hidro cacbonat"
  },
  {
    "id": "988",
    "formula": "HC3H5O3",
    "formatted_formula": "HC<sub>3</sub>H<sub>5</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit 2-methoxyaxetic"
  },
  {
    "id": "989",
    "formula": "HC5H5N+",
    "formatted_formula": "HC<sub>5</sub>H<sub>5</sub>N<sup>+</sup>",
    "vietnamese_name": "Pyridinium ion"
  },
  {
    "id": "990",
    "formula": "HC6H7O6",
    "formatted_formula": "HC<sub>6</sub>H<sub>7</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit isoascorbic"
  },
  {
    "id": "991",
    "formula": "HC9H7O4",
    "formatted_formula": "HC<sub>9</sub>H<sub>7</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit phenylmalonic"
  },
  {
    "id": "992",
    "formula": "HC12H17ON4SCl2",
    "formatted_formula": "HC<sub>1</sub><sub>2</sub>H<sub>1</sub><sub>7</sub>ON<sub>4</sub>SCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thiamin hidroclorua"
  },
  {
    "id": "995",
    "formula": "HClO2",
    "formatted_formula": "HClO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit clorơ"
  },
  {
    "id": "996",
    "formula": "HClO3",
    "formatted_formula": "HClO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit cloric"
  },
  {
    "id": "997",
    "formula": "HClO4",
    "formatted_formula": "HClO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit percloric"
  },
  {
    "id": "998",
    "formula": "HDO",
    "formatted_formula": "HDO<sup></sup>",
    "vietnamese_name": "đơteri proti ôxít (nước bán nặng)"
  },
  {
    "id": "1001",
    "formula": "HIO3",
    "formatted_formula": "HIO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit iodic"
  },
  {
    "id": "1004",
    "formula": "HN3",
    "formatted_formula": "HN<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit triazoic"
  },
  {
    "id": "1005",
    "formula": "HOCl",
    "formatted_formula": "HOCl<sup></sup>",
    "vietnamese_name": "Axit hipoclorơ"
  },
  {
    "id": "1006",
    "formula": "HOF",
    "formatted_formula": "HOF<sup></sup>",
    "vietnamese_name": "Hypofluorous acid"
  },
  {
    "id": "1007",
    "formula": "HOOCCOOH",
    "formatted_formula": "HOOCCOOH<sup></sup>",
    "vietnamese_name": "Axit oxalic"
  },
  {
    "id": "1008",
    "formula": "HPO42−",
    "formatted_formula": "HPO<sub>4</sub><sub>2</sub>−<sup></sup>",
    "vietnamese_name": "Ion hidro phosphat"
  },
  {
    "id": "1009",
    "formula": "HSO3−",
    "formatted_formula": "HSO<sub>3</sub>−<sup></sup>",
    "vietnamese_name": "Ion hidro sunfit"
  },
  {
    "id": "1010",
    "formula": "HSO4−",
    "formatted_formula": "HSO<sub>4</sub>−<sup></sup>",
    "vietnamese_name": "Ion hidro sunfat"
  },
  {
    "id": "1011",
    "formula": "HTO",
    "formatted_formula": "HTO<sup></sup>",
    "vietnamese_name": "Nước <sup>3</sup>H"
  },
  {
    "id": "1013",
    "formula": "H2C(CH)CN",
    "formatted_formula": "H<sub>2</sub>C(CH)CN<sup></sup>",
    "vietnamese_name": "Acrylonitrile"
  },
  {
    "id": "1014",
    "formula": "H2CO",
    "formatted_formula": "H<sub>2</sub>CO<sup></sup>",
    "vietnamese_name": "Methanal"
  },
  {
    "id": "1015",
    "formula": "H2CO3",
    "formatted_formula": "H<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit cacbonic"
  },
  {
    "id": "1016",
    "formula": "H2C2O4",
    "formatted_formula": "H<sub>2</sub>C<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit oxalic"
  },
  {
    "id": "1017",
    "formula": "H2C4H4O6",
    "formatted_formula": "H<sub>2</sub>C<sub>4</sub>H<sub>4</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit tartaric"
  },
  {
    "id": "1018",
    "formula": "H2C8H4O4",
    "formatted_formula": "H<sub>2</sub>C<sub>8</sub>H<sub>4</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit m-phthalic"
  },
  {
    "id": "1019",
    "formula": "H2CrO4",
    "formatted_formula": "H<sub>2</sub>CrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit cromic"
  },
  {
    "id": "1020",
    "formula": "H2NCH2COOH",
    "formatted_formula": "H<sub>2</sub>NCH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Glycin"
  },
  {
    "id": "1021",
    "formula": "H2NNH2",
    "formatted_formula": "H<sub>2</sub>NNH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hydrazin"
  },
  {
    "id": "1024",
    "formula": "H2PO4−",
    "formatted_formula": "H<sub>2</sub>PO<sub>4</sub>−<sup></sup>",
    "vietnamese_name": "Ion dihidro phosphat"
  },
  {
    "id": "1026",
    "formula": "H2SO3",
    "formatted_formula": "H<sub>2</sub>SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit sulfurơ"
  },
  {
    "id": "1028",
    "formula": "H2S2O7",
    "formatted_formula": "H<sub>2</sub>S<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Axit disunfuric"
  },
  {
    "id": "1030",
    "formula": "H2SeO3",
    "formatted_formula": "H<sub>2</sub>SeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit selenơ"
  },
  {
    "id": "1031",
    "formula": "H2SeO4",
    "formatted_formula": "H<sub>2</sub>SeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit selenic"
  },
  {
    "id": "1033",
    "formula": "H2TeO3",
    "formatted_formula": "H<sub>2</sub>TeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit telurơ"
  },
  {
    "id": "1034",
    "formula": "H2TiO3",
    "formatted_formula": "H<sub>2</sub>TiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit metatitanic"
  },
  {
    "id": "1035",
    "formula": "H3AsO4",
    "formatted_formula": "H<sub>3</sub>AsO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit arsenic"
  },
  {
    "id": "1036",
    "formula": "H3CCH2CH3",
    "formatted_formula": "H<sub>3</sub>CCH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Propan"
  },
  {
    "id": "1037",
    "formula": "+H3NCH2COO-",
    "formatted_formula": "+H<sub>3</sub>NCH<sub>2</sub>COO<sup>-</sup>",
    "vietnamese_name": "glycine zwitterion"
  },
  {
    "id": "1038",
    "formula": "H3O+",
    "formatted_formula": "H<sub>3</sub>O<sup>+</sup>",
    "vietnamese_name": "Hydronium ion"
  },
  {
    "id": "1040",
    "formula": "H4XeO6",
    "formatted_formula": "H<sub>4</sub>XeO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit perxenic"
  },
  {
    "id": "1041",
    "formula": "H6TeO6",
    "formatted_formula": "H<sub>6</sub>TeO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit teluric"
  },
  {
    "id": "1042",
    "formula": "HfBr4",
    "formatted_formula": "HfBr<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hafni tetrabromua"
  },
  {
    "id": "1043",
    "formula": "HfF4",
    "formatted_formula": "HfF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hafni(IV) florua"
  },
  {
    "id": "1044",
    "formula": "HfOCl2.8H2O",
    "formatted_formula": "HfOCl<sub>2</sub>.8H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hafnium(IV) oxiclorua octahydrat"
  },
  {
    "id": "1045",
    "formula": "HfOH(C2H3O2)3",
    "formatted_formula": "HfOH(C<sub>2</sub>H<sub>3</sub>O<sub>2</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hafni(IV) axetate, basic"
  },
  {
    "id": "1046",
    "formula": "Hf(SO4)2",
    "formatted_formula": "Hf(SO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hafni(IV) sunfat"
  },
  {
    "id": "1047",
    "formula": "Hg(BrO3)2.2H2O",
    "formatted_formula": "Hg(BrO<sub>3</sub>)<sub>2</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thủy ngân(II) bromat dihidrat"
  },
  {
    "id": "1048",
    "formula": "HgBr2",
    "formatted_formula": "HgBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) bromua"
  },
  {
    "id": "1049",
    "formula": "Hg(C2H3O2)2",
    "formatted_formula": "Hg(C<sub>2</sub>H<sub>3</sub>O<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) axetat"
  },
  {
    "id": "1050",
    "formula": "Hg(C7H5O2)2.H2O",
    "formatted_formula": "Hg(C<sub>7</sub>H<sub>5</sub>O<sub>2</sub>)<sub>2</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thủy ngân(II) benzoat monohidrat"
  },
  {
    "id": "1051",
    "formula": "HgClO4.4H2O",
    "formatted_formula": "HgClO<sub>4</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thủy ngân(I) perclorat tetrahidrat"
  },
  {
    "id": "1052",
    "formula": "Hg(ClO4)2.3H2O",
    "formatted_formula": "Hg(ClO<sub>4</sub>)<sub>2</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thủy ngân(II) perclorat trihidrat"
  },
  {
    "id": "1053",
    "formula": "HgCl2",
    "formatted_formula": "HgCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) clorua"
  },
  {
    "id": "1054",
    "formula": "Hg(IO3)2",
    "formatted_formula": "Hg(IO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) iodat"
  },
  {
    "id": "1055",
    "formula": "HgI2",
    "formatted_formula": "HgI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) iodua"
  },
  {
    "id": "1056",
    "formula": "Hg(NO3)2.H2O",
    "formatted_formula": "Hg(NO<sub>3</sub>)<sub>2</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thủy ngân(II) nitrat monohidrat"
  },
  {
    "id": "1057",
    "formula": "Hg(CNO)2",
    "formatted_formula": "Hg(CNO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) fulminat"
  },
  {
    "id": "1059",
    "formula": "HgS",
    "formatted_formula": "HgS<sup></sup>",
    "vietnamese_name": "Thủy ngân(II) sunfua"
  },
  {
    "id": "1060",
    "formula": "Hg(SCN)2",
    "formatted_formula": "Hg(SCN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) thiocyanat"
  },
  {
    "id": "1061",
    "formula": "HgSe",
    "formatted_formula": "HgSe<sup></sup>",
    "vietnamese_name": "Thủy ngân(II) selenua"
  },
  {
    "id": "1062",
    "formula": "HgSeO3",
    "formatted_formula": "HgSeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) selenit"
  },
  {
    "id": "1063",
    "formula": "HgTe",
    "formatted_formula": "HgTe<sup></sup>",
    "vietnamese_name": "Thủy ngân(II) telurua"
  },
  {
    "id": "1064",
    "formula": "HgTeO3",
    "formatted_formula": "HgTeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) telurit"
  },
  {
    "id": "1065",
    "formula": "HgWO4",
    "formatted_formula": "HgWO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) tungstat"
  },
  {
    "id": "1066",
    "formula": "Hg2Br2",
    "formatted_formula": "Hg<sub>2</sub>Br<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(I) bromua"
  },
  {
    "id": "1067",
    "formula": "Hg2Cl2",
    "formatted_formula": "Hg<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(I) clorua"
  },
  {
    "id": "1068",
    "formula": "Hg3(AsO4)2",
    "formatted_formula": "Hg<sub>3</sub>(AsO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) orthoarsenat"
  },
  {
    "id": "1069",
    "formula": "IBr",
    "formatted_formula": "IBr<sup></sup>",
    "vietnamese_name": "Iot bromua"
  },
  {
    "id": "1070",
    "formula": "IBr3",
    "formatted_formula": "IBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Iot tribromua"
  },
  {
    "id": "1071",
    "formula": "ICl",
    "formatted_formula": "ICl<sup></sup>",
    "vietnamese_name": "Iot clorua"
  },
  {
    "id": "1073",
    "formula": "ICl3",
    "formatted_formula": "ICl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Iot triclorua"
  },
  {
    "id": "1074",
    "formula": "IO3−",
    "formatted_formula": "IO<sub>3</sub>−<sup></sup>",
    "vietnamese_name": "Ion iodat"
  },
  {
    "id": "1076",
    "formula": "I3−",
    "formatted_formula": "I<sub>3</sub>−<sup></sup>",
    "vietnamese_name": "Ion triiodua"
  },
  {
    "id": "1077",
    "formula": "InBr",
    "formatted_formula": "InBr<sup></sup>",
    "vietnamese_name": "Indi bromua"
  },
  {
    "id": "1078",
    "formula": "InBrI2",
    "formatted_formula": "InBrI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Indi(III) bromodiiodua"
  },
  {
    "id": "1079",
    "formula": "InBr2I",
    "formatted_formula": "InBr<sub>2</sub>I<sup></sup>",
    "vietnamese_name": "Indi(III) dibromoiodua"
  },
  {
    "id": "1080",
    "formula": "InCl",
    "formatted_formula": "InCl<sup></sup>",
    "vietnamese_name": "Indi clorua"
  },
  {
    "id": "1081",
    "formula": "InCl2",
    "formatted_formula": "InCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Indi(II) clorua"
  },
  {
    "id": "1082",
    "formula": "InCl3",
    "formatted_formula": "InCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi triclorua"
  },
  {
    "id": "1084",
    "formula": "InI",
    "formatted_formula": "InI<sup></sup>",
    "vietnamese_name": "Indi iodua"
  },
  {
    "id": "1085",
    "formula": "In(IO3)3",
    "formatted_formula": "In(IO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi(III) iodat"
  },
  {
    "id": "1086",
    "formula": "InI2",
    "formatted_formula": "InI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Indi diiodua"
  },
  {
    "id": "1087",
    "formula": "InI3",
    "formatted_formula": "InI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi(III) iodua"
  },
  {
    "id": "1088",
    "formula": "In(NO3)3·4.5H2O",
    "formatted_formula": "In(NO<sub>3</sub>)<sub>3</sub>·<sub>4</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Indi(III) nitrat tetrahemihidrat\t"
  },
  {
    "id": "1089",
    "formula": "In(OH)3",
    "formatted_formula": "In(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi(III) hidroxit"
  },
  {
    "id": "1090",
    "formula": "InP",
    "formatted_formula": "InP<sup></sup>",
    "vietnamese_name": "Indi phosphua"
  },
  {
    "id": "1091",
    "formula": "InPO4",
    "formatted_formula": "InPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Indi(III) orthophosphat"
  },
  {
    "id": "1092",
    "formula": "InS\t",
    "formatted_formula": "InS\t<sup></sup>",
    "vietnamese_name": "Indi sunfua"
  },
  {
    "id": "1093",
    "formula": "InSb",
    "formatted_formula": "InSb<sup></sup>",
    "vietnamese_name": "Indi antimonua"
  },
  {
    "id": "1094",
    "formula": "InTe",
    "formatted_formula": "InTe<sup></sup>",
    "vietnamese_name": "Indi telurua"
  },
  {
    "id": "1095",
    "formula": "In2O3",
    "formatted_formula": "In<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi(III) oxit"
  },
  {
    "id": "1097",
    "formula": "In2(SO4)3.H2O",
    "formatted_formula": "In<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Indi(III) sunfat monohidrat"
  },
  {
    "id": "1098",
    "formula": "In2S3",
    "formatted_formula": "In<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Diindi trisunfua"
  },
  {
    "id": "1099",
    "formula": "In2Se3",
    "formatted_formula": "In<sub>2</sub>Se<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi(III) selenua"
  },
  {
    "id": "1100",
    "formula": "In2Te3",
    "formatted_formula": "In<sub>2</sub>Te<sub>3</sub><sup></sup>",
    "vietnamese_name": "Diindi tritelurua"
  },
  {
    "id": "1101",
    "formula": "K2MnO4",
    "formatted_formula": "K<sub>2</sub>MnO<sub>4</sub><sup></sup>",
    "vietnamese_name": "kali manganat"
  },
  {
    "id": "1103",
    "formula": "C3H5(OH)2OCuOC3H5(OH)2",
    "formatted_formula": "C<sub>3</sub>H<sub>5</sub>(OH)<sub>2</sub>OCuOC<sub>3</sub>H<sub>5</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "đồng(II) glixerat"
  },
  {
    "id": "1104",
    "formula": "MgSO4",
    "formatted_formula": "MgSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Magie sunfat"
  },
  {
    "id": "1105",
    "formula": "C2H5Cl",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>Cl<sup></sup>",
    "vietnamese_name": "Cloroetan"
  },
  {
    "id": "1106",
    "formula": "Na2CrO4",
    "formatted_formula": "Na<sub>2</sub>CrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri cromat"
  },
  {
    "id": "1107",
    "formula": "NaHSO4",
    "formatted_formula": "NaHSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri hidro sunfat"
  },
  {
    "id": "1108",
    "formula": "C4H10",
    "formatted_formula": "C<sub>4</sub>H<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Butan"
  },
  {
    "id": "1110",
    "formula": "SiF4",
    "formatted_formula": "SiF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Silic tetraflorua"
  },
  {
    "id": "1111",
    "formula": "Na2B4O7",
    "formatted_formula": "Na<sub>2</sub>B<sub>4</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Natri tetraborat"
  },
  {
    "id": "1112",
    "formula": "NaBO2",
    "formatted_formula": "NaBO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri metaborat"
  },
  {
    "id": "1113",
    "formula": "B2O3",
    "formatted_formula": "B<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Boron trioxit"
  },
  {
    "id": "1114",
    "formula": "MgI2",
    "formatted_formula": "MgI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie iodua"
  },
  {
    "id": "1115",
    "formula": "As2S3",
    "formatted_formula": "As<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Arsen trisunfua"
  },
  {
    "id": "1116",
    "formula": "(NH4)3AsO4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>3</sub>AsO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni arsenat"
  },
  {
    "id": "1117",
    "formula": "PbS",
    "formatted_formula": "PbS<sup></sup>",
    "vietnamese_name": "Chì(II) sunfua"
  },
  {
    "id": "1118",
    "formula": "PbSO4",
    "formatted_formula": "PbSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Chì(II) sunfat"
  },
  {
    "id": "1119",
    "formula": "BaO2",
    "formatted_formula": "BaO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari peroxit"
  },
  {
    "id": "1120",
    "formula": "Na2O2",
    "formatted_formula": "Na<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri peroxit"
  },
  {
    "id": "1121",
    "formula": "BaCO3",
    "formatted_formula": "BaCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bari cacbonat"
  },
  {
    "id": "1122",
    "formula": "C6H2OH(NO2)3",
    "formatted_formula": "C<sub>6</sub>H<sub>2</sub>OH(NO<sub>2</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit picric"
  },
  {
    "id": "1123",
    "formula": "(NH4)2S2O3",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>S<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni thiosunfat"
  },
  {
    "id": "1124",
    "formula": "NH4HSO4",
    "formatted_formula": "NH<sub>4</sub>HSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni hidro sunfat"
  },
  {
    "id": "1125",
    "formula": "CH3COONH4",
    "formatted_formula": "CH<sub>3</sub>COONH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni axetat"
  },
  {
    "id": "1126",
    "formula": "CH3-CCl3",
    "formatted_formula": "CH<sub>3</sub>-CCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "1,1,1-triclo etan"
  },
  {
    "id": "1127",
    "formula": "CH3CH2ONa",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>ONa<sup></sup>",
    "vietnamese_name": "Sodium ethoxide"
  },
  {
    "id": "1129",
    "formula": "C2H5ONa",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>ONa<sup></sup>",
    "vietnamese_name": "Sodium ethoxide"
  },
  {
    "id": "1130",
    "formula": "C6H5Br",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>Br<sup></sup>",
    "vietnamese_name": "Bromobenzen"
  },
  {
    "id": "1131",
    "formula": "Ag(NH3)2OH",
    "formatted_formula": "Ag(NH<sub>3</sub>)<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Diamminesilver(I) hydroxide"
  },
  {
    "id": "1132",
    "formula": "NaH",
    "formatted_formula": "NaH<sup></sup>",
    "vietnamese_name": "Natri hydrua"
  },
  {
    "id": "1133",
    "formula": "H2NCH2COONa",
    "formatted_formula": "H<sub>2</sub>NCH<sub>2</sub>COONa<sup></sup>",
    "vietnamese_name": "Natri aminoaxetat"
  },
  {
    "id": "1134",
    "formula": "(HOOCCH2NH3)2SO4",
    "formatted_formula": "(HOOCCH<sub>2</sub>NH<sub>3</sub>)<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Glycine sulfuric acid"
  },
  {
    "id": "1135",
    "formula": "SnCl2",
    "formatted_formula": "SnCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thiếc(II) clorua"
  },
  {
    "id": "1136",
    "formula": "SnSO4",
    "formatted_formula": "SnSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thiếc(II) sunfat"
  },
  {
    "id": "1137",
    "formula": "C2H5OC2H5",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Dietyl ete"
  },
  {
    "id": "1138",
    "formula": "KHSO4",
    "formatted_formula": "KHSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali hidro sunfat"
  },
  {
    "id": "1141",
    "formula": "Cu3Fe2",
    "formatted_formula": "Cu<sub>3</sub>Fe<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tricopper diiron"
  },
  {
    "id": "1142",
    "formula": "K2CrO4",
    "formatted_formula": "K<sub>2</sub>CrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali cromat"
  },
  {
    "id": "1143",
    "formula": "KHCO3",
    "formatted_formula": "KHCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali hidro cacbonat"
  },
  {
    "id": "1144",
    "formula": "CH3NH3Cl",
    "formatted_formula": "CH<sub>3</sub>NH<sub>3</sub>Cl<sup></sup>",
    "vietnamese_name": "Aminometan hidroclorua"
  },
  {
    "id": "1145",
    "formula": "CH3NH2",
    "formatted_formula": "CH<sub>3</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Aminometan"
  },
  {
    "id": "1146",
    "formula": "CH3CH(NH3Cl)COOH ",
    "formatted_formula": "CH<sub>3</sub>CH(NH<sub>3</sub>Cl)COOH <sup></sup>",
    "vietnamese_name": "2-ammoniumchloride propanoic"
  },
  {
    "id": "1147",
    "formula": "(CH3CH(NH3Cl)COO)2Ba",
    "formatted_formula": "(CH<sub>3</sub>CH(NH<sub>3</sub>Cl)COO)<sub>2</sub>Ba<sup></sup>",
    "vietnamese_name": "Bari 2-amonicloruapropanat"
  },
  {
    "id": "1148",
    "formula": "CH3COOC2H5",
    "formatted_formula": "CH<sub>3</sub>COOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Etyl axetat"
  },
  {
    "id": "1150",
    "formula": "(Ag(NH3)2)OH",
    "formatted_formula": "(Ag(NH<sub>3</sub>)<sub>2</sub>)OH<sup></sup>",
    "vietnamese_name": "Diamminesilver(I) hydroxide"
  },
  {
    "id": "1151",
    "formula": "(CH3COO)2Ba",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>2</sub>Ba<sup></sup>",
    "vietnamese_name": "Bari axetat"
  },
  {
    "id": "1152",
    "formula": "C8H10",
    "formatted_formula": "C<sub>8</sub>H<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "p-xilen"
  },
  {
    "id": "1153",
    "formula": "C7H6O2",
    "formatted_formula": "C<sub>7</sub>H<sub>6</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit benzoic"
  },
  {
    "id": "1154",
    "formula": "KOOC-COOK",
    "formatted_formula": "KOOC-COOK<sup></sup>",
    "vietnamese_name": "Kali oxalat"
  },
  {
    "id": "1155",
    "formula": "SnCl4",
    "formatted_formula": "SnCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thiếc(IV) clorua"
  },
  {
    "id": "1156",
    "formula": "C6H5COOK",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COOK<sup></sup>",
    "vietnamese_name": "Kali benzoat"
  },
  {
    "id": "1157",
    "formula": "LiOH",
    "formatted_formula": "LiOH<sup></sup>",
    "vietnamese_name": "Liti hydroxit"
  },
  {
    "id": "1158",
    "formula": "Na2S2O7",
    "formatted_formula": "Na<sub>2</sub>S<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "natri pyrosulfat"
  },
  {
    "id": "1159",
    "formula": "B",
    "formatted_formula": "B<sup></sup>",
    "vietnamese_name": "Bo"
  },
  {
    "id": "1160",
    "formula": "LiNH2",
    "formatted_formula": "LiNH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Lithium amide"
  },
  {
    "id": "1161",
    "formula": "KClO2",
    "formatted_formula": "KClO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali clorit"
  },
  {
    "id": "1162",
    "formula": "Na2Cr2O7",
    "formatted_formula": "Na<sub>2</sub>Cr<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Natri dicromat"
  },
  {
    "id": "1163",
    "formula": "BaCrO4",
    "formatted_formula": "BaCrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Bari cromat"
  },
  {
    "id": "1164",
    "formula": "Pb",
    "formatted_formula": "Pb<sup></sup>",
    "vietnamese_name": "Chì"
  },
  {
    "id": "1165",
    "formula": "(CH3COO)2Mg",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>2</sub>Mg<sup></sup>",
    "vietnamese_name": "Magie axetat"
  },
  {
    "id": "1166",
    "formula": "Ni",
    "formatted_formula": "Ni<sup></sup>",
    "vietnamese_name": "Niken"
  },
  {
    "id": "1167",
    "formula": "NiCl2",
    "formatted_formula": "NiCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Niken(II) clorua"
  },
  {
    "id": "1168",
    "formula": "(CH3COO)2Cu",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": "Đồng(II) axetat"
  },
  {
    "id": "1169",
    "formula": "(CH3COO)2Fe",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>2</sub>Fe<sup></sup>",
    "vietnamese_name": "Sắt(II) axetat"
  },
  {
    "id": "1170",
    "formula": "Na2S4O6",
    "formatted_formula": "Na<sub>2</sub>S<sub>4</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri tetrathionat"
  },
  {
    "id": "1171",
    "formula": "NaF",
    "formatted_formula": "NaF<sup></sup>",
    "vietnamese_name": "Natri florua"
  },
  {
    "id": "1172",
    "formula": "Ag2S",
    "formatted_formula": "Ag<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Bạc sunfua"
  },
  {
    "id": "1173",
    "formula": "BaSO4",
    "formatted_formula": "BaSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Bari sunfat"
  },
  {
    "id": "1174",
    "formula": "CH3Br",
    "formatted_formula": "CH<sub>3</sub>Br<sup></sup>",
    "vietnamese_name": "Metyl Bromua"
  },
  {
    "id": "1175",
    "formula": "KCN",
    "formatted_formula": "KCN<sup></sup>",
    "vietnamese_name": "Kali Xyanua"
  },
  {
    "id": "1176",
    "formula": "CH3CN",
    "formatted_formula": "CH<sub>3</sub>CN<sup></sup>",
    "vietnamese_name": "Metyl Xyanua"
  },
  {
    "id": "1177",
    "formula": "CF4",
    "formatted_formula": "CF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cacbon tetraflorua"
  },
  {
    "id": "1178",
    "formula": "S2Cl2",
    "formatted_formula": "S<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Disulfua diclorua"
  },
  {
    "id": "1179",
    "formula": "CS2",
    "formatted_formula": "CS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cacbon disunfua"
  },
  {
    "id": "1182",
    "formula": "C7H5N3O6",
    "formatted_formula": "C<sub>7</sub>H<sub>5</sub>N<sub>3</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Thuốc nổ TNT"
  },
  {
    "id": "1184",
    "formula": "CH3COOC3H7",
    "formatted_formula": "CH<sub>3</sub>COOC<sub>3</sub>H<sub>7</sub><sup></sup>",
    "vietnamese_name": "Propyl axetat"
  },
  {
    "id": "1185",
    "formula": "Mg3(PO4)2",
    "formatted_formula": "Mg<sub>3</sub>(PO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie phosphat"
  },
  {
    "id": "1186",
    "formula": "V2O5",
    "formatted_formula": "V<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Vanadi (V) oxít"
  },
  {
    "id": "1187",
    "formula": "V2O4",
    "formatted_formula": "V<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Vanadi (IV) oxít"
  },
  {
    "id": "1188",
    "formula": "B(OCH3)3",
    "formatted_formula": "B(OCH<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Trimetyl borat"
  },
  {
    "id": "1189",
    "formula": "NaBH4",
    "formatted_formula": "NaBH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri borohydrua"
  },
  {
    "id": "1190",
    "formula": "NaOCH3",
    "formatted_formula": "NaOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri metoxit"
  },
  {
    "id": "1191",
    "formula": "SO2Cl2",
    "formatted_formula": "SO<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sunfuryl clorua"
  },
  {
    "id": "1192",
    "formula": "POCl3",
    "formatted_formula": "POCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Phosphoryl triclorua"
  },
  {
    "id": "1193",
    "formula": "Sr",
    "formatted_formula": "Sr<sup></sup>",
    "vietnamese_name": "Stronti"
  },
  {
    "id": "1194",
    "formula": "SrI2",
    "formatted_formula": "SrI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Stronti iốt"
  },
  {
    "id": "1195",
    "formula": "SrCO3",
    "formatted_formula": "SrCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Stronti carbonat"
  },
  {
    "id": "1196",
    "formula": "H2SiF6",
    "formatted_formula": "H<sub>2</sub>SiF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit hexaflorosilicic"
  },
  {
    "id": "1197",
    "formula": "Sb",
    "formatted_formula": "Sb<sup></sup>",
    "vietnamese_name": "Antimon"
  },
  {
    "id": "1198",
    "formula": "Sb2O3",
    "formatted_formula": "Sb<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Antimon (III) ôxit"
  },
  {
    "id": "1200",
    "formula": "SbF3",
    "formatted_formula": "SbF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Antimon(III) florua"
  },
  {
    "id": "1201",
    "formula": "SbF5",
    "formatted_formula": "SbF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Antimon(V) florua"
  },
  {
    "id": "1202",
    "formula": "SbCl5",
    "formatted_formula": "SbCl<sub>5</sub><sup></sup>",
    "vietnamese_name": "Antimon(V) clorua"
  },
  {
    "id": "1203",
    "formula": "C6H5CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Toluen"
  },
  {
    "id": "1204",
    "formula": "C6H4CH3COONa",
    "formatted_formula": "C<sub>6</sub>H<sub>4</sub>CH<sub>3</sub>COONa<sup></sup>",
    "vietnamese_name": "Natri phenylaxetat"
  },
  {
    "id": "1205",
    "formula": "C6H5CN",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CN<sup></sup>",
    "vietnamese_name": "Benzonitrile"
  },
  {
    "id": "1206",
    "formula": "CH2CHCl",
    "formatted_formula": "CH<sub>2</sub>CHCl<sup></sup>",
    "vietnamese_name": "Vinyl clorua"
  },
  {
    "id": "1207",
    "formula": "CHCl2CH2Cl",
    "formatted_formula": "CHCl<sub>2</sub>CH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "1,1,2-Tricloroetan"
  },
  {
    "id": "1208",
    "formula": "CH3CHCl2",
    "formatted_formula": "CH<sub>3</sub>CHCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,1-Dicloroetan"
  },
  {
    "id": "1209",
    "formula": "CH2CCl2",
    "formatted_formula": "CH<sub>2</sub>CCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,1-Dicloroeten"
  },
  {
    "id": "1210",
    "formula": "SnO2",
    "formatted_formula": "SnO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thiếc (IV) oxit"
  },
  {
    "id": "1211",
    "formula": "Sn",
    "formatted_formula": "Sn<sup></sup>",
    "vietnamese_name": "Thiếc"
  },
  {
    "id": "1212",
    "formula": "C6H5NO2",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>NO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Nitrobenzen"
  },
  {
    "id": "1213",
    "formula": "SOBr2",
    "formatted_formula": "SOBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thionyl bromua"
  },
  {
    "id": "1214",
    "formula": "C6H5CHBrCH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CHBrCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "(1-Bromoetyl)benzen"
  },
  {
    "id": "1216",
    "formula": "NH2NH2",
    "formatted_formula": "NH<sub>2</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hydrazin"
  },
  {
    "id": "1217",
    "formula": "Fe3C",
    "formatted_formula": "Fe<sub>3</sub>C<sup></sup>",
    "vietnamese_name": "Cacbua Sắt"
  },
  {
    "id": "1218",
    "formula": "SCl4",
    "formatted_formula": "SCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Lưu huỳnh tetraclorua"
  },
  {
    "id": "1219",
    "formula": "C6H2CH3(NO2)3",
    "formatted_formula": "C<sub>6</sub>H<sub>2</sub>CH<sub>3</sub>(NO<sub>2</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Thuốc nổ TNT"
  },
  {
    "id": "1220",
    "formula": "C6H5CH2NH2",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH<sub>2</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Benzylamin"
  },
  {
    "id": "1221",
    "formula": "H3BO3",
    "formatted_formula": "H<sub>3</sub>BO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit boric"
  },
  {
    "id": "1222",
    "formula": "BCl3",
    "formatted_formula": "BCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bo(III) clorua"
  },
  {
    "id": "1223",
    "formula": "CH3CH2NH2",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Etylamin"
  },
  {
    "id": "1224",
    "formula": "ClCH2COOH",
    "formatted_formula": "ClCH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit cloroaxetic"
  },
  {
    "id": "1225",
    "formula": "SbCl3",
    "formatted_formula": "SbCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Antimon triclorua"
  },
  {
    "id": "1226",
    "formula": "Na2S2O4",
    "formatted_formula": "Na<sub>2</sub>S<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri dithionit"
  },
  {
    "id": "1228",
    "formula": "KClO4",
    "formatted_formula": "KClO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali perclorat"
  },
  {
    "id": "1229",
    "formula": "NaClO4",
    "formatted_formula": "NaClO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri perclorat"
  },
  {
    "id": "1230",
    "formula": "C3H6",
    "formatted_formula": "C<sub>3</sub>H<sub>6</sub><sup></sup>",
    "vietnamese_name": "Propen"
  },
  {
    "id": "1231",
    "formula": "CH3C(CH3)(OH)CHCH2",
    "formatted_formula": "CH<sub>3</sub>C(CH<sub>3</sub>)(OH)CHCH<sub>2</sub><sup></sup>",
    "vietnamese_name": "2-metyl-3-buten-2-ol"
  },
  {
    "id": "1232",
    "formula": "Ag(NH3)2Cl",
    "formatted_formula": "Ag(NH<sub>3</sub>)<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Diamminesilver(I) chloride"
  },
  {
    "id": "1233",
    "formula": "Ba(AlO2)2",
    "formatted_formula": "Ba(AlO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari aluminat"
  },
  {
    "id": "1234",
    "formula": "Ca(AlO2)2",
    "formatted_formula": "Ca(AlO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Monocanxi aluminat"
  },
  {
    "id": "1235",
    "formula": "AuCl3",
    "formatted_formula": "AuCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Vàng(III) clorua"
  },
  {
    "id": "1237",
    "formula": "Ba3(PO4)2",
    "formatted_formula": "Ba<sub>3</sub>(PO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari photphat"
  },
  {
    "id": "1238",
    "formula": "Na2BeO2",
    "formatted_formula": "Na<sub>2</sub>BeO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri berilat"
  },
  {
    "id": "1239",
    "formula": "C6H2Br3NH2",
    "formatted_formula": "C<sub>6</sub>H<sub>2</sub>Br<sub>3</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "2,4,6-Tribromoanilin"
  },
  {
    "id": "1240",
    "formula": "C6H2Br3OH",
    "formatted_formula": "C<sub>6</sub>H<sub>2</sub>Br<sub>3</sub>OH<sup></sup>",
    "vietnamese_name": "2,4,6-Tribromophenol"
  },
  {
    "id": "1241",
    "formula": "HBrO3",
    "formatted_formula": "HBrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit bromic(V)"
  },
  {
    "id": "1242",
    "formula": "HBrO",
    "formatted_formula": "HBrO<sup></sup>",
    "vietnamese_name": "Axit bromic(I)"
  },
  {
    "id": "1244",
    "formula": "HNH-CH2-COOH",
    "formatted_formula": "HNH-CH<sub>2</sub>-COOH<sup></sup>",
    "vietnamese_name": "Glixin"
  },
  {
    "id": "1245",
    "formula": "C17H35COOH",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>5</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit Stearic"
  },
  {
    "id": "1246",
    "formula": "SiC",
    "formatted_formula": "SiC<sup></sup>",
    "vietnamese_name": "Silic cacbua"
  },
  {
    "id": "1247",
    "formula": "Ca(C17H35COO)2",
    "formatted_formula": "Ca(C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>5</sub>COO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi Stearat"
  },
  {
    "id": "1248",
    "formula": "C2H4(OH)2",
    "formatted_formula": "C<sub>2</sub>H<sub>4</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Etilen glicol"
  },
  {
    "id": "1249",
    "formula": "C6H6Cl6",
    "formatted_formula": "C<sub>6</sub>H<sub>6</sub>Cl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Lindane"
  },
  {
    "id": "1250",
    "formula": "C6H5CH2Cl",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Benzyl clorua"
  },
  {
    "id": "1251",
    "formula": "C6H12",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexen; hex-1-en"
  },
  {
    "id": "1252",
    "formula": "Ti",
    "formatted_formula": "Ti<sup></sup>",
    "vietnamese_name": "Titan"
  },
  {
    "id": "1253",
    "formula": "CaHPO4",
    "formatted_formula": "CaHPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi hidro photphat"
  },
  {
    "id": "1254",
    "formula": "CaSO3",
    "formatted_formula": "CaSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Caxi sunfit"
  },
  {
    "id": "1255",
    "formula": "Na2O.CaO.6SiO2",
    "formatted_formula": "Na<sub>2</sub>O.CaO.6SiO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri canxi silicat"
  },
  {
    "id": "1256",
    "formula": "BF3",
    "formatted_formula": "BF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bo triflorua"
  },
  {
    "id": "1257",
    "formula": "Ca2SiO4.4H2O",
    "formatted_formula": "Ca<sub>2</sub>SiO<sub>4</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Dicanxi silicat tetrahidrat"
  },
  {
    "id": "1258",
    "formula": "HBO2",
    "formatted_formula": "HBO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit metaboric"
  },
  {
    "id": "1259",
    "formula": "CH3CHOHCH3",
    "formatted_formula": "CH<sub>3</sub>CHOHCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-Propanol"
  },
  {
    "id": "1262",
    "formula": "NOCl",
    "formatted_formula": "NOCl<sup></sup>",
    "vietnamese_name": "Nitrosyl clorua"
  },
  {
    "id": "1263",
    "formula": "PCl5",
    "formatted_formula": "PCl<sub>5</sub><sup></sup>",
    "vietnamese_name": "Photpho pentaclorua"
  },
  {
    "id": "1265",
    "formula": "Cr(CO)3",
    "formatted_formula": "Cr(CO)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom tricacbonyl"
  },
  {
    "id": "1266",
    "formula": "HCOONa",
    "formatted_formula": "HCOONa<sup></sup>",
    "vietnamese_name": "Natri format"
  },
  {
    "id": "1268",
    "formula": "[Cu(NH3)4](OH)2",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>4</sub>](OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetraamminecopper(II) hydroxide"
  },
  {
    "id": "1269",
    "formula": "[Cu(NH3)4]Cl2",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>4</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetraamminecuprate(II) dichloride"
  },
  {
    "id": "1270",
    "formula": "[Cu(NH3)4]SO4",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>4</sub>]SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Tetraamminecopper(II) sulfate"
  },
  {
    "id": "1272",
    "formula": "SF6",
    "formatted_formula": "SF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Lưu huỳnh hexaflorua"
  },
  {
    "id": "1274",
    "formula": "K4[Fe(CN)6]",
    "formatted_formula": "K<sub>4</sub>[Fe(CN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Potassium ferrocyanide"
  },
  {
    "id": "1275",
    "formula": "Fe4[Fe(CN)6]3",
    "formatted_formula": "Fe<sub>4</sub>[Fe(CN)<sub>6</sub>]<sub>3</sub><sup></sup>",
    "vietnamese_name": "Iron(III) ferrocyanide"
  },
  {
    "id": "1276",
    "formula": "FeSiO3",
    "formatted_formula": "FeSiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) metasilicat"
  },
  {
    "id": "1278",
    "formula": "Fe(SO4)3",
    "formatted_formula": "Fe(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) sunfat"
  },
  {
    "id": "1279",
    "formula": "CH3COOCH3",
    "formatted_formula": "CH<sub>3</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl axetat"
  },
  {
    "id": "1280",
    "formula": "KH",
    "formatted_formula": "KH<sup></sup>",
    "vietnamese_name": "Kali hidrua"
  },
  {
    "id": "1281",
    "formula": "Mn3O4",
    "formatted_formula": "Mn<sub>3</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Mangan (III) oxit"
  },
  {
    "id": "1282",
    "formula": "K3MnO4",
    "formatted_formula": "K<sub>3</sub>MnO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali hypomanganat"
  },
  {
    "id": "1283",
    "formula": "MgC2",
    "formatted_formula": "MgC<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie Cacbua"
  },
  {
    "id": "1284",
    "formula": "Li2C2",
    "formatted_formula": "Li<sub>2</sub>C<sub>2</sub><sup></sup>",
    "vietnamese_name": "Liti Cacbua"
  },
  {
    "id": "1285",
    "formula": "K2SiO3",
    "formatted_formula": "K<sub>2</sub>SiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali metasilicat"
  },
  {
    "id": "1286",
    "formula": "HMnO4",
    "formatted_formula": "HMnO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit pemanganic"
  },
  {
    "id": "1287",
    "formula": "BeSO4",
    "formatted_formula": "BeSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Beri sulfat"
  },
  {
    "id": "1288",
    "formula": "Li2S",
    "formatted_formula": "Li<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Liti sunfua"
  },
  {
    "id": "1289",
    "formula": "BeS",
    "formatted_formula": "BeS<sup></sup>",
    "vietnamese_name": "Beri sulfua"
  },
  {
    "id": "1290",
    "formula": "Na2ZnO2",
    "formatted_formula": "Na<sub>2</sub>ZnO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri zincat"
  },
  {
    "id": "1291",
    "formula": "NaH2PO4",
    "formatted_formula": "NaH<sub>2</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali dihidro photphat"
  },
  {
    "id": "1292",
    "formula": "Zn3(PO4)2",
    "formatted_formula": "Zn<sub>3</sub>(PO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kẽm photphat"
  },
  {
    "id": "1293",
    "formula": "HPO3",
    "formatted_formula": "HPO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit meta-phosphoric"
  },
  {
    "id": "1294",
    "formula": "MnBr2",
    "formatted_formula": "MnBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magan bromua"
  },
  {
    "id": "1295",
    "formula": "PtCl2",
    "formatted_formula": "PtCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Platin(II) clorua"
  },
  {
    "id": "1296",
    "formula": "MnCl2",
    "formatted_formula": "MnCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Mangan(II) diclorua"
  },
  {
    "id": "1297",
    "formula": "MnI2",
    "formatted_formula": "MnI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magan iodua"
  },
  {
    "id": "1298",
    "formula": "MgS",
    "formatted_formula": "MgS<sup></sup>",
    "vietnamese_name": "Magie sunfua"
  },
  {
    "id": "1299",
    "formula": "BaS",
    "formatted_formula": "BaS<sup></sup>",
    "vietnamese_name": "Bari sulfua"
  },
  {
    "id": "1300",
    "formula": "Bi2O3",
    "formatted_formula": "Bi<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut trioxit"
  },
  {
    "id": "1301",
    "formula": "Bi",
    "formatted_formula": "Bi<sup></sup>",
    "vietnamese_name": "Bitmut"
  },
  {
    "id": "1302",
    "formula": "B4C",
    "formatted_formula": "B<sub>4</sub>C<sup></sup>",
    "vietnamese_name": "Bo cacbua"
  },
  {
    "id": "1303",
    "formula": "TiC",
    "formatted_formula": "TiC<sup></sup>",
    "vietnamese_name": "Titan cabua"
  },
  {
    "id": "1304",
    "formula": "Ca(HSO3)2",
    "formatted_formula": "Ca(HSO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi bisulfit"
  },
  {
    "id": "1305",
    "formula": "BaSO3",
    "formatted_formula": "BaSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bari sulfit"
  },
  {
    "id": "1306",
    "formula": "Ba(ClO)2",
    "formatted_formula": "Ba(ClO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari hypoclorit"
  },
  {
    "id": "1307",
    "formula": "C6H5OCH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>OCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metoxibenzen"
  },
  {
    "id": "1308",
    "formula": "(C6H5NH3)2SO4",
    "formatted_formula": "(C<sub>6</sub>H<sub>5</sub>NH<sub>3</sub>)<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Phenylamoni sunfat"
  },
  {
    "id": "1309",
    "formula": "(-CH2CHCl-)n",
    "formatted_formula": "(-CH<sub>2</sub>CHCl-)n<sup></sup>",
    "vietnamese_name": "Polyvinyl clorua"
  },
  {
    "id": "1310",
    "formula": "K2ZnO2",
    "formatted_formula": "K<sub>2</sub>ZnO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali zincat"
  },
  {
    "id": "1311",
    "formula": "KSH",
    "formatted_formula": "KSH<sup></sup>",
    "vietnamese_name": "Kali hidrosunfua"
  },
  {
    "id": "1312",
    "formula": "Li3N",
    "formatted_formula": "Li<sub>3</sub>N<sup></sup>",
    "vietnamese_name": "Liti nitrua"
  },
  {
    "id": "1313",
    "formula": "Mg3N2",
    "formatted_formula": "Mg<sub>3</sub>N<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie nirua"
  },
  {
    "id": "1314",
    "formula": "Mg2Si",
    "formatted_formula": "Mg<sub>2</sub>Si<sup></sup>",
    "vietnamese_name": "Magie silicua"
  },
  {
    "id": "1315",
    "formula": "MnSiO3",
    "formatted_formula": "MnSiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Mangan(II) Silicat"
  },
  {
    "id": "1316",
    "formula": "RbOH",
    "formatted_formula": "RbOH<sup></sup>",
    "vietnamese_name": "Rubidi hidroxit"
  },
  {
    "id": "1317",
    "formula": "Na2PbO2",
    "formatted_formula": "Na<sub>2</sub>PbO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri plumbit"
  },
  {
    "id": "1318",
    "formula": "Rb2S",
    "formatted_formula": "Rb<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Rubidi sunfua"
  },
  {
    "id": "1319",
    "formula": "[Zn(NH3)4](OH)2",
    "formatted_formula": "[Zn(NH<sub>3</sub>)<sub>4</sub>](OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetraamminezinc(II) hydroxide"
  },
  {
    "id": "1320",
    "formula": "[Zn(NH3)4]Cl2",
    "formatted_formula": "[Zn(NH<sub>3</sub>)<sub>4</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetraamminezinc(II) chloride"
  },
  {
    "id": "1321",
    "formula": "Zn(NH3)4SO4",
    "formatted_formula": "Zn(NH<sub>3</sub>)<sub>4</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hexamminezinc(II) sulfate"
  },
  {
    "id": "1322",
    "formula": "CsSH",
    "formatted_formula": "CsSH<sup></sup>",
    "vietnamese_name": "Xezi hidro sunfua"
  },
  {
    "id": "1323",
    "formula": "P2O3",
    "formatted_formula": "P<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Photpho trioxit"
  },
  {
    "id": "1324",
    "formula": "P2S5",
    "formatted_formula": "P<sub>2</sub>S<sub>5</sub><sup></sup>",
    "vietnamese_name": "Photpho pentasunfua"
  },
  {
    "id": "1325",
    "formula": "Fe2O3.nH2O",
    "formatted_formula": "Fe<sub>2</sub>O<sub>3</sub>.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Sắt(III) oxit ngậm nước"
  },
  {
    "id": "1326",
    "formula": "RbSH",
    "formatted_formula": "RbSH<sup></sup>",
    "vietnamese_name": "Rubidi hidro sunfua"
  },
  {
    "id": "1327",
    "formula": "LiSH",
    "formatted_formula": "LiSH<sup></sup>",
    "vietnamese_name": "Liti hidrosunfua"
  },
  {
    "id": "1328",
    "formula": "NaSH",
    "formatted_formula": "NaSH<sup></sup>",
    "vietnamese_name": "Natri hidrosunfua"
  },
  {
    "id": "1329",
    "formula": "C6H4CH3OH",
    "formatted_formula": "C<sub>6</sub>H<sub>4</sub>CH<sub>3</sub>OH<sup></sup>",
    "vietnamese_name": "p-cresol "
  },
  {
    "id": "1330",
    "formula": "C6H5COCH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axetophenon"
  },
  {
    "id": "1331",
    "formula": "C6H5CHOHCH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CHOHCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Alpha-Metylbenzyl ancol"
  },
  {
    "id": "1332",
    "formula": "XeF6",
    "formatted_formula": "XeF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Xenon hexaflorua"
  },
  {
    "id": "1333",
    "formula": "XeOF4",
    "formatted_formula": "XeOF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xenon oxitetraflorua"
  },
  {
    "id": "1334",
    "formula": "XeF4",
    "formatted_formula": "XeF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xenon Tetraflorua"
  },
  {
    "id": "1335",
    "formula": "XeO3",
    "formatted_formula": "XeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xenon trioxit"
  },
  {
    "id": "1336",
    "formula": "SF4",
    "formatted_formula": "SF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Lưu huỳnh(IV) florua"
  },
  {
    "id": "1337",
    "formula": "H2S2O4",
    "formatted_formula": "H<sub>2</sub>S<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dithionous acid"
  },
  {
    "id": "1338",
    "formula": "K3As",
    "formatted_formula": "K<sub>3</sub>As<sup></sup>",
    "vietnamese_name": "Kali arsenua"
  },
  {
    "id": "1339",
    "formula": "H3As",
    "formatted_formula": "H<sub>3</sub>As<sup></sup>",
    "vietnamese_name": "Arsine"
  },
  {
    "id": "1340",
    "formula": "H3Sb",
    "formatted_formula": "H<sub>3</sub>Sb<sup></sup>",
    "vietnamese_name": "Antimon trihidrua"
  },
  {
    "id": "1341",
    "formula": "K3Sb",
    "formatted_formula": "K<sub>3</sub>Sb<sup></sup>",
    "vietnamese_name": "Kali antimonua"
  },
  {
    "id": "1342",
    "formula": "Si(OH)4",
    "formatted_formula": "Si(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit Orthosilicic"
  },
  {
    "id": "1343",
    "formula": "(COONa)2",
    "formatted_formula": "(COONa)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri oxalat"
  },
  {
    "id": "1344",
    "formula": "(COOH)2",
    "formatted_formula": "(COOH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit oxalic"
  },
  {
    "id": "1345",
    "formula": "NH4ClO4",
    "formatted_formula": "NH<sub>4</sub>ClO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni perclorat"
  },
  {
    "id": "1346",
    "formula": "Na3Sb",
    "formatted_formula": "Na<sub>3</sub>Sb<sup></sup>",
    "vietnamese_name": "Trikali antimonua"
  },
  {
    "id": "1347",
    "formula": "ZnS2O4",
    "formatted_formula": "ZnS<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "kẽm dithionơ"
  },
  {
    "id": "1348",
    "formula": "NH4Br",
    "formatted_formula": "NH<sub>4</sub>Br<sup></sup>",
    "vietnamese_name": "Amoni bromua"
  },
  {
    "id": "1349",
    "formula": "C2H5COOC3H7",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COOC<sub>3</sub>H<sub>7</sub><sup></sup>",
    "vietnamese_name": "Propyl propionat"
  },
  {
    "id": "1350",
    "formula": "BaC2",
    "formatted_formula": "BaC<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari cacbua"
  },
  {
    "id": "1351",
    "formula": "C6H5CHCH2",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CHCH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Styren"
  },
  {
    "id": "1352",
    "formula": "Na3As",
    "formatted_formula": "Na<sub>3</sub>As<sup></sup>",
    "vietnamese_name": "Natri Arsenua"
  },
  {
    "id": "1353",
    "formula": "SiCl4",
    "formatted_formula": "SiCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Silic tetraclorua"
  },
  {
    "id": "1354",
    "formula": "Xe",
    "formatted_formula": "Xe<sup></sup>",
    "vietnamese_name": "Xenon"
  },
  {
    "id": "1355",
    "formula": "(NHCH2CO)n",
    "formatted_formula": "(NHCH<sub>2</sub>CO)n<sup></sup>",
    "vietnamese_name": "Polyglycine"
  },
  {
    "id": "1356",
    "formula": "FeSiO2",
    "formatted_formula": "FeSiO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) silicat"
  },
  {
    "id": "1357",
    "formula": "RCH2OH",
    "formatted_formula": "RCH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Ancol"
  },
  {
    "id": "1358",
    "formula": "RCOONa",
    "formatted_formula": "RCOONa<sup></sup>",
    "vietnamese_name": "Muối natri cacboxylat"
  },
  {
    "id": "1359",
    "formula": "CuCO3.Cu(OH)2",
    "formatted_formula": "CuCO<sub>3</sub>.Cu(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Copper(II) carbonate basic"
  },
  {
    "id": "1360",
    "formula": "K2SO4.Cr2(SO4)3.24H2O",
    "formatted_formula": "K<sub>2</sub>SO<sub>4</sub>.Cr<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub>.24H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Phèn Crom-Kali"
  },
  {
    "id": "1362",
    "formula": "Ca(ClO)2",
    "formatted_formula": "Ca(ClO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi hypoclorit"
  },
  {
    "id": "1365",
    "formula": "C2H5Br",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>Br<sup></sup>",
    "vietnamese_name": "Bromoetan"
  },
  {
    "id": "1366",
    "formula": "NaClO3",
    "formatted_formula": "NaClO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri clorat"
  },
  {
    "id": "1367",
    "formula": "NaClO2",
    "formatted_formula": "NaClO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri clorit"
  },
  {
    "id": "1368",
    "formula": "Ba(ClO2)2",
    "formatted_formula": "Ba(ClO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari clorit"
  },
  {
    "id": "1369",
    "formula": "H2SO4.nSO3",
    "formatted_formula": "H<sub>2</sub>SO<sub>4</sub>.nSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Oleum"
  },
  {
    "id": "1370",
    "formula": "H2SO4.(n-1)SO3",
    "formatted_formula": "H<sub>2</sub>SO<sub>4</sub>.(n-<sub>1</sub>)SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Oleum"
  },
  {
    "id": "1371",
    "formula": "H2SO4.11H2O",
    "formatted_formula": "H<sub>2</sub>SO<sub>4</sub>.11H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit sunfuric undecahidrat"
  },
  {
    "id": "1373",
    "formula": "[Cu(NO3)4](OH)2",
    "formatted_formula": "[Cu(NO<sub>3</sub>)<sub>4</sub>](OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetranitratecopper(II) hydroxide"
  },
  {
    "id": "1374",
    "formula": "N2O3",
    "formatted_formula": "N<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dinitơ trioxit"
  },
  {
    "id": "1376",
    "formula": "SiH4",
    "formatted_formula": "SiH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Silan"
  },
  {
    "id": "1377",
    "formula": "Ca2SiO4",
    "formatted_formula": "Ca<sub>2</sub>SiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi Silicat"
  },
  {
    "id": "1378",
    "formula": "CaO.Al2O3",
    "formatted_formula": "CaO.Al<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đinhôm canxi tetraoxit"
  },
  {
    "id": "1379",
    "formula": "Na[Cr(OH)4]",
    "formatted_formula": "Na[Cr(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium tetrahydroxycromate(III)"
  },
  {
    "id": "1380",
    "formula": "Ca3(AlO3)2",
    "formatted_formula": "Ca<sub>3</sub>(AlO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tricanxi aluminat"
  },
  {
    "id": "1381",
    "formula": "Ca3(AlO3)2 .6H2O",
    "formatted_formula": "Ca<sub>3</sub>(AlO<sub>3</sub>)<sub>2</sub> .6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Tricanxi aluminat hexahidrat"
  },
  {
    "id": "1382",
    "formula": "H2Cr2O7",
    "formatted_formula": "H<sub>2</sub>Cr<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Axit dicromic"
  },
  {
    "id": "1383",
    "formula": "O",
    "formatted_formula": "O<sup></sup>",
    "vietnamese_name": "Oxi"
  },
  {
    "id": "1384",
    "formula": "Ca3(AlO3)2.6H2O",
    "formatted_formula": "Ca<sub>3</sub>(AlO<sub>3</sub>)<sub>2</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Tricanxi aluminat hexahidrat"
  },
  {
    "id": "1385",
    "formula": "FONO2",
    "formatted_formula": "FONO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Flo nitrat"
  },
  {
    "id": "1386",
    "formula": "KF",
    "formatted_formula": "KF<sup></sup>",
    "vietnamese_name": "Potassium fluoride"
  },
  {
    "id": "1387",
    "formula": "INO3",
    "formatted_formula": "INO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Iot nitrat"
  },
  {
    "id": "1388",
    "formula": "KBrO3",
    "formatted_formula": "KBrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali bromat"
  },
  {
    "id": "1389",
    "formula": "Pb(HSO4)2",
    "formatted_formula": "Pb(HSO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì(II) hidrosunfat"
  },
  {
    "id": "1390",
    "formula": "[Fe(NO)]SO4",
    "formatted_formula": "[Fe(NO)]SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Nitrosyliron (II) sulfate"
  },
  {
    "id": "1391",
    "formula": "NaNH2",
    "formatted_formula": "NaNH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri amit"
  },
  {
    "id": "1392",
    "formula": "Na2N",
    "formatted_formula": "Na<sub>2</sub>N<sup></sup>",
    "vietnamese_name": "Đinatri nitrua"
  },
  {
    "id": "1393",
    "formula": "Na2NH",
    "formatted_formula": "Na<sub>2</sub>NH<sup></sup>",
    "vietnamese_name": "Natri imidua"
  },
  {
    "id": "1395",
    "formula": "Mg3P2",
    "formatted_formula": "Mg<sub>3</sub>P<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie photphua"
  },
  {
    "id": "1396",
    "formula": "POBr3",
    "formatted_formula": "POBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Phosphoryl bromua"
  },
  {
    "id": "1397",
    "formula": "FeF3",
    "formatted_formula": "FeF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(III) florua"
  },
  {
    "id": "1398",
    "formula": "AuF3",
    "formatted_formula": "AuF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Vàng(III) florua"
  },
  {
    "id": "1400",
    "formula": "K2Cr2O4 ",
    "formatted_formula": "K<sub>2</sub>Cr<sub>2</sub>O<sub>4</sub> <sup></sup>",
    "vietnamese_name": "Kali cromat"
  },
  {
    "id": "1401",
    "formula": "LiAlH4",
    "formatted_formula": "LiAlH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti tetrahidroaluminat"
  },
  {
    "id": "1402",
    "formula": "LiCl",
    "formatted_formula": "LiCl<sup></sup>",
    "vietnamese_name": "Liti clorua"
  },
  {
    "id": "1403",
    "formula": "[Cu(NH3)2]Cl",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>2</sub>]Cl<sup></sup>",
    "vietnamese_name": "Diamminecopper(I) chloride"
  },
  {
    "id": "1404",
    "formula": "Na2[Zn(OH)4]",
    "formatted_formula": "Na<sub>2</sub>[Zn(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Natri kẽm(II)tetrahiđroxit"
  },
  {
    "id": "1405",
    "formula": "KIO",
    "formatted_formula": "KIO<sup></sup>",
    "vietnamese_name": "Kali hypoiodit"
  },
  {
    "id": "1406",
    "formula": "Si3N4",
    "formatted_formula": "Si<sub>3</sub>N<sub>4</sub><sup></sup>",
    "vietnamese_name": "Trisilic tetranitrua"
  },
  {
    "id": "1407",
    "formula": "SiI4",
    "formatted_formula": "SiI<sub>4</sub><sup></sup>",
    "vietnamese_name": "Silic tetraiodua"
  },
  {
    "id": "1408",
    "formula": "Na3N",
    "formatted_formula": "Na<sub>3</sub>N<sup></sup>",
    "vietnamese_name": "Natri nitrua"
  },
  {
    "id": "1409",
    "formula": "CrN",
    "formatted_formula": "CrN<sup></sup>",
    "vietnamese_name": "Crom(III) nitrua"
  },
  {
    "id": "1410",
    "formula": "Fe(CrO2)2",
    "formatted_formula": "Fe(CrO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chromite"
  },
  {
    "id": "1411",
    "formula": "CrO",
    "formatted_formula": "CrO<sup></sup>",
    "vietnamese_name": "Crom(II) Oxit"
  },
  {
    "id": "1412",
    "formula": "NaHF2",
    "formatted_formula": "NaHF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri biflorua"
  },
  {
    "id": "1413",
    "formula": "FeCu2S2",
    "formatted_formula": "FeCu<sub>2</sub>S<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dicopper iron disulfide"
  },
  {
    "id": "1414",
    "formula": "KHS",
    "formatted_formula": "KHS<sup></sup>",
    "vietnamese_name": "Kali hiđrosunfua"
  },
  {
    "id": "1415",
    "formula": "NaHS",
    "formatted_formula": "NaHS<sup></sup>",
    "vietnamese_name": "Natri hiđrosunfua"
  },
  {
    "id": "1418",
    "formula": "C2Ag2",
    "formatted_formula": "C<sub>2</sub>Ag<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bạc acetylua"
  },
  {
    "id": "1419",
    "formula": "[Ag(NH3)2]OH",
    "formatted_formula": "[Ag(NH<sub>3</sub>)<sub>2</sub>]OH<sup></sup>",
    "vietnamese_name": "diamminesilver(I) hydroxide"
  },
  {
    "id": "1420",
    "formula": "PbCl2",
    "formatted_formula": "PbCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì(II) clorua"
  },
  {
    "id": "1421",
    "formula": "Ca(CN)2",
    "formatted_formula": "Ca(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi cyanua"
  },
  {
    "id": "1422",
    "formula": "NaKS",
    "formatted_formula": "NaKS<sup></sup>",
    "vietnamese_name": "Kali natri sunfua"
  },
  {
    "id": "1423",
    "formula": "Cu2FeS2",
    "formatted_formula": "Cu<sub>2</sub>FeS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dicopper iron disulfide"
  },
  {
    "id": "1425",
    "formula": "fructozo",
    "formatted_formula": "fructozo<sup></sup>",
    "vietnamese_name": "fructozo"
  },
  {
    "id": "1426",
    "formula": "glucozo",
    "formatted_formula": "glucozo<sup></sup>",
    "vietnamese_name": "glucozo"
  },
  {
    "id": "1427",
    "formula": "HCOOC2H5",
    "formatted_formula": "HCOOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Ethyl format"
  },
  {
    "id": "1428",
    "formula": "CH3COOK",
    "formatted_formula": "CH<sub>3</sub>COOK<sup></sup>",
    "vietnamese_name": "Kali axetat"
  },
  {
    "id": "1432",
    "formula": "C2H2O4",
    "formatted_formula": "C<sub>2</sub>H<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit oxalic"
  },
  {
    "id": "1435",
    "formula": "ROH",
    "formatted_formula": "ROH<sup></sup>",
    "vietnamese_name": "Rượu"
  },
  {
    "id": "1436",
    "formula": "CH3ONa",
    "formatted_formula": "CH<sub>3</sub>ONa<sup></sup>",
    "vietnamese_name": "Natri methoxit"
  },
  {
    "id": "1437",
    "formula": "RONa",
    "formatted_formula": "RONa<sup></sup>",
    "vietnamese_name": "Natri ankanoxit"
  },
  {
    "id": "1438",
    "formula": "CH3COOC6H5",
    "formatted_formula": "CH<sub>3</sub>COOC<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "phenyl axetat"
  },
  {
    "id": "1439",
    "formula": "Fe2S3",
    "formatted_formula": "Fe<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(III) sunfua"
  },
  {
    "id": "1441",
    "formula": "CHF2Cl",
    "formatted_formula": "CHF<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Clorodiflorometan"
  },
  {
    "id": "1442",
    "formula": "C4H6Cl2",
    "formatted_formula": "C<sub>4</sub>H<sub>6</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,4-Dicloro-2-buten"
  },
  {
    "id": "1443",
    "formula": "CH2=CH2",
    "formatted_formula": "CH<sub>2</sub>=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Êtilen"
  },
  {
    "id": "1444",
    "formula": "CH3-CH2-OH",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-OH<sup></sup>",
    "vietnamese_name": "Êtanol"
  },
  {
    "id": "1445",
    "formula": "CH3-CHO",
    "formatted_formula": "CH<sub>3</sub>-CHO<sup></sup>",
    "vietnamese_name": "Axetaldehyde"
  },
  {
    "id": "1446",
    "formula": "CnH2n+2",
    "formatted_formula": "CnH<sub>2</sub>n+<sub>2</sub><sup></sup>",
    "vietnamese_name": "Ankan"
  },
  {
    "id": "1448",
    "formula": "KIO4",
    "formatted_formula": "KIO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali periodat"
  },
  {
    "id": "1449",
    "formula": "LiH",
    "formatted_formula": "LiH<sup></sup>",
    "vietnamese_name": "Liti hiđrua"
  },
  {
    "id": "1450",
    "formula": "ClCH2CH2Cl",
    "formatted_formula": "ClCH<sub>2</sub>CH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "1,2-dicloroethan"
  },
  {
    "id": "1451",
    "formula": "CF2=CF2",
    "formatted_formula": "CF<sub>2</sub>=CF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetrafloroetylen"
  },
  {
    "id": "1452",
    "formula": "CH3-COOH",
    "formatted_formula": "CH<sub>3</sub>-COOH<sup></sup>",
    "vietnamese_name": "Axit axetic"
  },
  {
    "id": "1453",
    "formula": "HCOOR",
    "formatted_formula": "HCOOR<sup></sup>",
    "vietnamese_name": "Format este"
  },
  {
    "id": "1454",
    "formula": "NH4OCOCH3",
    "formatted_formula": "NH<sub>4</sub>OCOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni axetat"
  },
  {
    "id": "1457",
    "formula": "R-SO3H",
    "formatted_formula": "R-SO<sub>3</sub>H<sup></sup>",
    "vietnamese_name": "Axit sulfonic"
  },
  {
    "id": "1458",
    "formula": "CH2BrCH2CH2Br",
    "formatted_formula": "CH<sub>2</sub>BrCH<sub>2</sub>CH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "1 3-dibromopropan"
  },
  {
    "id": "1459",
    "formula": "ZnBr2",
    "formatted_formula": "ZnBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kẽm bromua"
  },
  {
    "id": "1461",
    "formula": "CnH2n",
    "formatted_formula": "CnH<sub>2</sub>n<sup></sup>",
    "vietnamese_name": "Anken"
  },
  {
    "id": "1462",
    "formula": "CnH2n+1Cl",
    "formatted_formula": "CnH<sub>2</sub>n+<sub>1</sub>Cl<sup></sup>",
    "vietnamese_name": "ethyl clorua"
  },
  {
    "id": "1463",
    "formula": "CnH2n-6",
    "formatted_formula": "CnH<sub>2</sub>n-<sub>6</sub><sup></sup>",
    "vietnamese_name": "hiđrocacbon thơm"
  },
  {
    "id": "1464",
    "formula": "CnH2n-7Br",
    "formatted_formula": "CnH<sub>2</sub>n-<sub>7</sub>Br<sup></sup>",
    "vietnamese_name": "Bromua"
  },
  {
    "id": "1465",
    "formula": "CH3CH2CH2CH3",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": " Butan"
  },
  {
    "id": "1466",
    "formula": "CH3CH2CH2CH2Cl",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "1-clorobutan"
  },
  {
    "id": "1467",
    "formula": "CH3CH2CHClCH3",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CHClCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-Clorobutan"
  },
  {
    "id": "1470",
    "formula": "Zn(NO3)2",
    "formatted_formula": "Zn(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kẽm nitrat"
  },
  {
    "id": "1471",
    "formula": "Hg(CH3COO)2",
    "formatted_formula": "Hg(CH<sub>3</sub>COO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) axetat"
  },
  {
    "id": "1472",
    "formula": "Al(CH3COO)3",
    "formatted_formula": "Al(CH<sub>3</sub>COO)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm axetat"
  },
  {
    "id": "1473",
    "formula": "Ca(SO4)",
    "formatted_formula": "Ca(SO<sub>4</sub>)<sup></sup>",
    "vietnamese_name": "Canxi sunfat"
  },
  {
    "id": "1474",
    "formula": "Ag(NO3)",
    "formatted_formula": "Ag(NO<sub>3</sub>)<sup></sup>",
    "vietnamese_name": "Bạc nitrat"
  },
  {
    "id": "1475",
    "formula": "Al2",
    "formatted_formula": "Al<sub>2</sub><sup></sup>",
    "vietnamese_name": "nhôm dime"
  },
  {
    "id": "1476",
    "formula": "Al3",
    "formatted_formula": "Al<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm trime"
  },
  {
    "id": "1477",
    "formula": "ClBr2",
    "formatted_formula": "ClBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "dibromoclorua"
  },
  {
    "id": "1478",
    "formula": "All3",
    "formatted_formula": "All<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm(III) iodua"
  },
  {
    "id": "1479",
    "formula": "Hgl2",
    "formatted_formula": "Hgl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) iodua"
  },
  {
    "id": "1480",
    "formula": "Al2(SiO3)3",
    "formatted_formula": "Al<sub>2</sub>(SiO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm silicat khan"
  },
  {
    "id": "1481",
    "formula": "Al(PO4)",
    "formatted_formula": "Al(PO<sub>4</sub>)<sup></sup>",
    "vietnamese_name": "Nhôm phosphat"
  },
  {
    "id": "1482",
    "formula": "Cu(SO4)",
    "formatted_formula": "Cu(SO<sub>4</sub>)<sup></sup>",
    "vietnamese_name": "Đồng sunphat"
  },
  {
    "id": "1484",
    "formula": "Cr2(SiO3)3",
    "formatted_formula": "Cr<sub>2</sub>(SiO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Crom(III) silicat"
  },
  {
    "id": "1485",
    "formula": "AgO2",
    "formatted_formula": "AgO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bạc peroxit"
  },
  {
    "id": "1486",
    "formula": "As",
    "formatted_formula": "As<sup></sup>",
    "vietnamese_name": "Asen"
  },
  {
    "id": "1487",
    "formula": "As2O3",
    "formatted_formula": "As<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Asen trioxit"
  },
  {
    "id": "1489",
    "formula": "Mg(CH3COO)2",
    "formatted_formula": "Mg(CH<sub>3</sub>COO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie axetat"
  },
  {
    "id": "1490",
    "formula": "H",
    "formatted_formula": "H<sup></sup>",
    "vietnamese_name": "Hiđro"
  },
  {
    "id": "1491",
    "formula": "C2S",
    "formatted_formula": "C<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Dicacbon sunfua"
  },
  {
    "id": "1492",
    "formula": "P4O10",
    "formatted_formula": "P<sub>4</sub>O<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Phospho pentoxit"
  },
  {
    "id": "1493",
    "formula": "MgBr",
    "formatted_formula": "MgBr<sup></sup>",
    "vietnamese_name": "Magie bromua"
  },
  {
    "id": "1494",
    "formula": "CaBr2",
    "formatted_formula": "CaBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi bromua"
  },
  {
    "id": "1495",
    "formula": "(CHO)2",
    "formatted_formula": "(CHO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Ethanedial"
  },
  {
    "id": "1496",
    "formula": "CH3OCHCH2",
    "formatted_formula": "CH<sub>3</sub>OCHCH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Metylvinyl ete"
  },
  {
    "id": "1498",
    "formula": "C2H3COOH",
    "formatted_formula": "C<sub>2</sub>H<sub>3</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit acrylic"
  },
  {
    "id": "1499",
    "formula": "C2H3COOC2H5",
    "formatted_formula": "C<sub>2</sub>H<sub>3</sub>COOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Etyl acrylat"
  },
  {
    "id": "1500",
    "formula": "C2H3Cl",
    "formatted_formula": "C<sub>2</sub>H<sub>3</sub>Cl<sup></sup>",
    "vietnamese_name": "Vinyl clorua"
  },
  {
    "id": "1501",
    "formula": "C2H3CN",
    "formatted_formula": "C<sub>2</sub>H<sub>3</sub>CN<sup></sup>",
    "vietnamese_name": "vinyl cyanua"
  },
  {
    "id": "1502",
    "formula": "HO(CH3)CHCCCH(CH3)OH",
    "formatted_formula": "HO(CH<sub>3</sub>)CHCCCH(CH<sub>3</sub>)OH<sup></sup>",
    "vietnamese_name": "3-Hexyne-2,5-diol"
  },
  {
    "id": "1503",
    "formula": "HOCH2CCCH2OH",
    "formatted_formula": "HOCH<sub>2</sub>CCCH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Butynediol"
  },
  {
    "id": "1504",
    "formula": "(RCOO)3C3H5",
    "formatted_formula": "(RCOO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Chất béo"
  },
  {
    "id": "1505",
    "formula": "C6H5SO3H",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>SO<sub>3</sub>H<sup></sup>",
    "vietnamese_name": "Axit benzenesulfonic"
  },
  {
    "id": "1506",
    "formula": "(CH3CO)2O",
    "formatted_formula": "(CH<sub>3</sub>CO)<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axetic anhydrit"
  },
  {
    "id": "1507",
    "formula": "C6H5I",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>I<sup></sup>",
    "vietnamese_name": "Iodobenzene"
  },
  {
    "id": "1508",
    "formula": "C6H5CH2Br",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "Benzyl bromua"
  },
  {
    "id": "1510",
    "formula": "BN",
    "formatted_formula": "BN<sup></sup>",
    "vietnamese_name": "Bo nitrua"
  },
  {
    "id": "1512",
    "formula": "Na3[AlF6]",
    "formatted_formula": "Na<sub>3</sub>[AlF<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Natri hexafloroaluminat"
  },
  {
    "id": "1513",
    "formula": "P4",
    "formatted_formula": "P<sub>4</sub><sup></sup>",
    "vietnamese_name": "Tetraphospho"
  },
  {
    "id": "1514",
    "formula": "Li3P",
    "formatted_formula": "Li<sub>3</sub>P<sup></sup>",
    "vietnamese_name": "Liti Phosphua"
  },
  {
    "id": "1515",
    "formula": "RbCl",
    "formatted_formula": "RbCl<sup></sup>",
    "vietnamese_name": "Rubiđi clorua"
  },
  {
    "id": "1516",
    "formula": "Rb",
    "formatted_formula": "Rb<sup></sup>",
    "vietnamese_name": "Rubiđi"
  },
  {
    "id": "1517",
    "formula": "SCl2",
    "formatted_formula": "SCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sulfur dichloride"
  },
  {
    "id": "1518",
    "formula": "FeSi",
    "formatted_formula": "FeSi<sup></sup>",
    "vietnamese_name": "Sắt silicua"
  },
  {
    "id": "1519",
    "formula": "CaO2. 8H2O",
    "formatted_formula": "CaO<sub>2</sub>. <sub>8</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi peroxit octahidrat"
  },
  {
    "id": "1520",
    "formula": "B2S3",
    "formatted_formula": "B<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dibo trisunfua"
  },
  {
    "id": "1521",
    "formula": "NaAlCl4",
    "formatted_formula": "NaAlCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri tetracloroaluminat"
  },
  {
    "id": "1522",
    "formula": "K2S2O7",
    "formatted_formula": "K<sub>2</sub>S<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Đikali đisunfat"
  },
  {
    "id": "1524",
    "formula": "Pd",
    "formatted_formula": "Pd<sup></sup>",
    "vietnamese_name": "Paladi"
  },
  {
    "id": "1525",
    "formula": "K2SiF6",
    "formatted_formula": "K<sub>2</sub>SiF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali hexaflorosilicat"
  },
  {
    "id": "1526",
    "formula": "K3AlF6",
    "formatted_formula": "K<sub>3</sub>AlF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali Hexafloroaluminat"
  },
  {
    "id": "1527",
    "formula": "KNH2",
    "formatted_formula": "KNH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali amua"
  },
  {
    "id": "1528",
    "formula": "Zn(NH2)2",
    "formatted_formula": "Zn(NH<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kẽm diamua"
  },
  {
    "id": "1529",
    "formula": "P4O6",
    "formatted_formula": "P<sub>4</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Phospho trioxit"
  },
  {
    "id": "1530",
    "formula": "KH2PO2",
    "formatted_formula": "KH<sub>2</sub>PO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali hypophosphit"
  },
  {
    "id": "1531",
    "formula": "PH4ClO4",
    "formatted_formula": "PH<sub>4</sub>ClO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Phosphonium Perchlorate"
  },
  {
    "id": "1532",
    "formula": "CH3COOOH",
    "formatted_formula": "CH<sub>3</sub>COOOH<sup></sup>",
    "vietnamese_name": "Axit axetic"
  },
  {
    "id": "1533",
    "formula": "C2H5(C5H3N)CH3",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>(C<sub>5</sub>H<sub>3</sub>N)CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "5-Etyl-2-metylpyridin"
  },
  {
    "id": "1534",
    "formula": "CH2CHCHO",
    "formatted_formula": "CH<sub>2</sub>CHCHO<sup></sup>",
    "vietnamese_name": "Acrolein"
  },
  {
    "id": "1535",
    "formula": "(CH3)3C6H3",
    "formatted_formula": "(CH<sub>3</sub>)<sub>3</sub>C<sub>6</sub>H<sub>3</sub><sup></sup>",
    "vietnamese_name": "Mesitylene"
  },
  {
    "id": "1536",
    "formula": "CHCC(CH3)2OH",
    "formatted_formula": "CHCC(CH<sub>3</sub>)<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "2-Methyl-3-butyn-2-ol"
  },
  {
    "id": "1537",
    "formula": "(CH3)2C(OH)CN",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>C(OH)CN<sup></sup>",
    "vietnamese_name": "Acetone cyanohydrin"
  },
  {
    "id": "1539",
    "formula": "CH3COCH2I",
    "formatted_formula": "CH<sub>3</sub>COCH<sub>2</sub>I<sup></sup>",
    "vietnamese_name": "1-Iodo-2-propanon"
  },
  {
    "id": "1541",
    "formula": "CH3CONHC2H5",
    "formatted_formula": "CH<sub>3</sub>CONHC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "N-Ethylacetamide"
  },
  {
    "id": "1542",
    "formula": "Cs",
    "formatted_formula": "Cs<sup></sup>",
    "vietnamese_name": "Xêzi"
  },
  {
    "id": "1543",
    "formula": "C2H3COOCH3",
    "formatted_formula": "C<sub>2</sub>H<sub>3</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl acrylat"
  },
  {
    "id": "1544",
    "formula": "C2H3OCH3",
    "formatted_formula": "C<sub>2</sub>H<sub>3</sub>OCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl vinyl ete"
  },
  {
    "id": "1545",
    "formula": "C2H3F",
    "formatted_formula": "C<sub>2</sub>H<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Vinyl florua"
  },
  {
    "id": "1546",
    "formula": "NH2SO3H",
    "formatted_formula": "NH<sub>2</sub>SO<sub>3</sub>H<sup></sup>",
    "vietnamese_name": "Axit sunfamic"
  },
  {
    "id": "1548",
    "formula": "NaBrO3",
    "formatted_formula": "NaBrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri bromua"
  },
  {
    "id": "1549",
    "formula": "(C2H5O)2SO2",
    "formatted_formula": "(C<sub>2</sub>H<sub>5</sub>O)<sub>2</sub>SO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dietyl sunfat"
  },
  {
    "id": "1550",
    "formula": "C6H5COOCH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl benzoat"
  },
  {
    "id": "1551",
    "formula": "C6H5CH(CH3)OH",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH(CH<sub>3</sub>)OH<sup></sup>",
    "vietnamese_name": "1-Phenylethanol"
  },
  {
    "id": "1552",
    "formula": "HO(CH2)2CN",
    "formatted_formula": "HO(CH<sub>2</sub>)<sub>2</sub>CN<sup></sup>",
    "vietnamese_name": "3-Hydroxypropionitrile"
  },
  {
    "id": "1553",
    "formula": "C2H5COOH",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit propionic"
  },
  {
    "id": "1554",
    "formula": "C2H5COOCH2CH2CH3",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COOCH<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Propyl propanoat"
  },
  {
    "id": "1555",
    "formula": "SOF2",
    "formatted_formula": "SOF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thionyl florua"
  },
  {
    "id": "1556",
    "formula": "Al(C2H5)3",
    "formatted_formula": "Al(C<sub>2</sub>H<sub>5</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Triethylaluminum"
  },
  {
    "id": "1557",
    "formula": "BH3",
    "formatted_formula": "BH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Boran"
  },
  {
    "id": "1560",
    "formula": "C5H9Br",
    "formatted_formula": "C<sub>5</sub>H<sub>9</sub>Br<sup></sup>",
    "vietnamese_name": "5-Bromo-1-penten"
  },
  {
    "id": "1561",
    "formula": "Ba(HCO3)2 ",
    "formatted_formula": "Ba(HCO<sub>3</sub>)<sub>2</sub> <sup></sup>",
    "vietnamese_name": "Bari Bicacbonat"
  },
  {
    "id": "1563",
    "formula": "H3PO4",
    "formatted_formula": "H<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "axit photphoric"
  },
  {
    "id": "1564",
    "formula": "HCOOCH3",
    "formatted_formula": "HCOOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl format"
  },
  {
    "id": "1565",
    "formula": "(HCOO)2Ca",
    "formatted_formula": "(HCOO)<sub>2</sub>Ca<sup></sup>",
    "vietnamese_name": "Canxi format"
  },
  {
    "id": "1566",
    "formula": "C2H5CN",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>CN<sup></sup>",
    "vietnamese_name": "Etyl cyanua"
  },
  {
    "id": "1567",
    "formula": "Ca(HSO4)2",
    "formatted_formula": "Ca(HSO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi hidro sunfat"
  },
  {
    "id": "1569",
    "formula": "(NH4)2HPO4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>HPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni phosphat dibasic"
  },
  {
    "id": "1570",
    "formula": "ZnCO3",
    "formatted_formula": "ZnCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kẽm cacbonat"
  },
  {
    "id": "1571",
    "formula": "HCOOK",
    "formatted_formula": "HCOOK<sup></sup>",
    "vietnamese_name": "Kali format"
  },
  {
    "id": "1572",
    "formula": "C2H5COONa",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COONa<sup></sup>",
    "vietnamese_name": "Natri propionat"
  },
  {
    "id": "1573",
    "formula": "KO2",
    "formatted_formula": "KO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali dioxit"
  },
  {
    "id": "1575",
    "formula": "HgF2",
    "formatted_formula": "HgF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân florua"
  },
  {
    "id": "1576",
    "formula": "(C17H35COO)3C3H5",
    "formatted_formula": "(C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>5</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Stearin"
  },
  {
    "id": "1577",
    "formula": "NO2Cl",
    "formatted_formula": "NO<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Nitroxyl clorua"
  },
  {
    "id": "1578",
    "formula": "KAg(CN)2",
    "formatted_formula": "KAg(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Potassium dicyanoargentate(I)"
  },
  {
    "id": "1579",
    "formula": "N2H4.H2SO4",
    "formatted_formula": "N<sub>2</sub>H<sub>4</sub>.H<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydrazin hidro sunfat"
  },
  {
    "id": "1580",
    "formula": "NH2OH",
    "formatted_formula": "NH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Hydroxyamin"
  },
  {
    "id": "1581",
    "formula": "SeO2",
    "formatted_formula": "SeO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Selen(IV) dioxit"
  },
  {
    "id": "1582",
    "formula": "Se",
    "formatted_formula": "Se<sup></sup>",
    "vietnamese_name": "Selen"
  },
  {
    "id": "1583",
    "formula": "C6H5CH2CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Etylbenzen"
  },
  {
    "id": "1584",
    "formula": "BiH3O3",
    "formatted_formula": "BiH<sub>3</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut trihidroxit"
  },
  {
    "id": "1585",
    "formula": "(NH4)2Cr2O4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>Cr<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni cromat"
  },
  {
    "id": "1587",
    "formula": "NH4(NH2COO)",
    "formatted_formula": "NH<sub>4</sub>(NH<sub>2</sub>COO)<sup></sup>",
    "vietnamese_name": "Amoni cacbamat"
  },
  {
    "id": "1588",
    "formula": "BeCO3",
    "formatted_formula": "BeCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Beri cacbonat"
  },
  {
    "id": "1589",
    "formula": "(NH4)2Be(CO3)2",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>Be(CO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diammonium beryllium dicarbonate"
  },
  {
    "id": "1590",
    "formula": "HBr",
    "formatted_formula": "HBr<sup></sup>",
    "vietnamese_name": "Hidro bromua"
  },
  {
    "id": "1592",
    "formula": "CH3COOAg",
    "formatted_formula": "CH<sub>3</sub>COOAg<sup></sup>",
    "vietnamese_name": "Bạc axetat"
  },
  {
    "id": "1593",
    "formula": "C6H12O7",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Axit Gluconic"
  },
  {
    "id": "1594",
    "formula": "C12H22O12",
    "formatted_formula": "C<sub>1</sub><sub>2</sub>H<sub>2</sub><sub>2</sub>O<sub>1</sub><sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit lactobionic"
  },
  {
    "id": "1595",
    "formula": "Ag(NH3)2Br",
    "formatted_formula": "Ag(NH<sub>3</sub>)<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "Diamminesilver(I) Bromide"
  },
  {
    "id": "1596",
    "formula": "AgSNC",
    "formatted_formula": "AgSNC<sup></sup>",
    "vietnamese_name": "Bạc thiocyanat"
  },
  {
    "id": "1597",
    "formula": "(SCN)2",
    "formatted_formula": "(SCN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thiocyanogen"
  },
  {
    "id": "1598",
    "formula": "Na3[Ag(S2O3)2]",
    "formatted_formula": "Na<sub>3</sub>[Ag(S<sub>2</sub>O<sub>3</sub>)<sub>2</sub>]<sup></sup>",
    "vietnamese_name": "sodium bis(thiosulfato)argentate(I)"
  },
  {
    "id": "1600",
    "formula": "AgBrO3",
    "formatted_formula": "AgBrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bạc bromat"
  },
  {
    "id": "1601",
    "formula": "LiNO2",
    "formatted_formula": "LiNO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Liti nitrit"
  },
  {
    "id": "1602",
    "formula": "AgNO2",
    "formatted_formula": "AgNO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bạc nitrit"
  },
  {
    "id": "1603",
    "formula": "NH4OCN",
    "formatted_formula": "NH<sub>4</sub>OCN<sup></sup>",
    "vietnamese_name": "Amoni cyanat"
  },
  {
    "id": "1604",
    "formula": "AgOCN",
    "formatted_formula": "AgOCN<sup></sup>",
    "vietnamese_name": "Bạc cyanat"
  },
  {
    "id": "1605",
    "formula": "LiNO3",
    "formatted_formula": "LiNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Liti nitrat"
  },
  {
    "id": "1606",
    "formula": "AgCN",
    "formatted_formula": "AgCN<sup></sup>",
    "vietnamese_name": "Bạc cyanua"
  },
  {
    "id": "1607",
    "formula": "NaCN",
    "formatted_formula": "NaCN<sup></sup>",
    "vietnamese_name": "Natri cyanua"
  },
  {
    "id": "1608",
    "formula": "NaN3",
    "formatted_formula": "NaN<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri azua"
  },
  {
    "id": "1609",
    "formula": "AlO(OH)",
    "formatted_formula": "AlO(OH)<sup></sup>",
    "vietnamese_name": "Axit metaaluminic"
  },
  {
    "id": "1610",
    "formula": "NaAl(OH)4",
    "formatted_formula": "NaAl(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sodium tetrahydroxyaluminate"
  },
  {
    "id": "1611",
    "formula": "KAl(OH)4",
    "formatted_formula": "KAl(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Potassium  tetrahydroxyaluminate"
  },
  {
    "id": "1612",
    "formula": "HF",
    "formatted_formula": "HF<sup></sup>",
    "vietnamese_name": "Axit Hidrofloric"
  },
  {
    "id": "1614",
    "formula": "Al2(SO4)3 . 18 H2O",
    "formatted_formula": "Al<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub> . <sub>1</sub><sub>8</sub> H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nhôm sunfat octadecahidrat"
  },
  {
    "id": "1615",
    "formula": "[Al(H2O)6]3+",
    "formatted_formula": "[Al(H<sub>2</sub>O)<sub>6</sub>]<sup>3+</sup>",
    "vietnamese_name": "Aluminium hexaaqua complex ion"
  },
  {
    "id": "1616",
    "formula": "(SO4)2-",
    "formatted_formula": "(SO<sub>4</sub>)<sup>2-</sup>",
    "vietnamese_name": "Ion sunfat"
  },
  {
    "id": "1617",
    "formula": "BeAl2O4",
    "formatted_formula": "BeAl<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Beri aluminat"
  },
  {
    "id": "1618",
    "formula": "MgAl2O4",
    "formatted_formula": "MgAl<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Spinel"
  },
  {
    "id": "1620",
    "formula": "NH4AlCl4",
    "formatted_formula": "NH<sub>4</sub>AlCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Ammonium tetrachloroaluminate"
  },
  {
    "id": "1621",
    "formula": "AlCl(OH)2",
    "formatted_formula": "AlCl(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri aluminat dihidrat"
  },
  {
    "id": "1624",
    "formula": "Ba(NO2)2",
    "formatted_formula": "Ba(NO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari nitrit"
  },
  {
    "id": "1625",
    "formula": "BaCl2.2H2O",
    "formatted_formula": "BaCl<sub>2</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Bari clorua dihidrat"
  },
  {
    "id": "1626",
    "formula": "BaSiO3",
    "formatted_formula": "BaSiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bari metasilicat"
  },
  {
    "id": "1627",
    "formula": "BaH2",
    "formatted_formula": "BaH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari hidrua"
  },
  {
    "id": "1628",
    "formula": "BeBr2",
    "formatted_formula": "BeBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Beri bromua"
  },
  {
    "id": "1629",
    "formula": "LiBr",
    "formatted_formula": "LiBr<sup></sup>",
    "vietnamese_name": "Liti bromua"
  },
  {
    "id": "1630",
    "formula": "BrF",
    "formatted_formula": "BrF<sup></sup>",
    "vietnamese_name": "Brom florua"
  },
  {
    "id": "1631",
    "formula": "NiBr2",
    "formatted_formula": "NiBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Niken bromua"
  },
  {
    "id": "1632",
    "formula": "Na2C2",
    "formatted_formula": "Na<sub>2</sub>C<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri cacbua"
  },
  {
    "id": "1634",
    "formula": "K[Pt(C2H4)Cl3]",
    "formatted_formula": "K[Pt(C<sub>2</sub>H<sub>4</sub>)Cl<sub>3</sub>]<sup></sup>",
    "vietnamese_name": "Muối Xayze"
  },
  {
    "id": "1635",
    "formula": "K2PtCl4",
    "formatted_formula": "K<sub>2</sub>PtCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali tetracloroplatinat (II)"
  },
  {
    "id": "1636",
    "formula": "Pt(OH)2",
    "formatted_formula": "Pt(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Platin(II) dihidroxit"
  },
  {
    "id": "1637",
    "formula": "Pt(NH3)4Cl2",
    "formatted_formula": "Pt(NH<sub>3</sub>)<sub>4</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetraaminplatin(II) clorua"
  },
  {
    "id": "1638",
    "formula": "CHBr3",
    "formatted_formula": "CHBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bromoform"
  },
  {
    "id": "1639",
    "formula": "C2H5OLi",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OLi<sup></sup>",
    "vietnamese_name": "Liti etanolat"
  },
  {
    "id": "1640",
    "formula": "LiHS",
    "formatted_formula": "LiHS<sup></sup>",
    "vietnamese_name": "Liti hidro sunfua"
  },
  {
    "id": "1641",
    "formula": "C2H5OK",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OK<sup></sup>",
    "vietnamese_name": "Kali etanolat"
  },
  {
    "id": "1642",
    "formula": "D2S",
    "formatted_formula": "D<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Hidro sunfua (D<sub>2</sub>)"
  },
  {
    "id": "1643",
    "formula": "Al(OD)3",
    "formatted_formula": "Al(OD)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm hidroxit"
  },
  {
    "id": "1644",
    "formula": "BeC2",
    "formatted_formula": "BeC<sub>2</sub><sup></sup>",
    "vietnamese_name": "Beri axetylua"
  },
  {
    "id": "1645",
    "formula": "Be2C",
    "formatted_formula": "Be<sub>2</sub>C<sup></sup>",
    "vietnamese_name": "Beri carbua"
  },
  {
    "id": "1646",
    "formula": "H2SO4.H2O",
    "formatted_formula": "H<sub>2</sub>SO<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit sunfuric hidrat"
  },
  {
    "id": "1647",
    "formula": "CCl3COOH",
    "formatted_formula": "CCl<sub>3</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit tricloroaxetic"
  },
  {
    "id": "1648",
    "formula": "C6H5OK",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>OK<sup></sup>",
    "vietnamese_name": "Kali phenolat"
  },
  {
    "id": "1649",
    "formula": "C6H5COONa",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COONa<sup></sup>",
    "vietnamese_name": "Natri benzoat"
  },
  {
    "id": "1650",
    "formula": "Cr(C6H6)2",
    "formatted_formula": "Cr(C<sub>6</sub>H<sub>6</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom di(benzene)"
  },
  {
    "id": "1651",
    "formula": "Cr(CO)6",
    "formatted_formula": "Cr(CO)<sub>6</sub><sup></sup>",
    "vietnamese_name": "Crom hexacarbonyl"
  },
  {
    "id": "1652",
    "formula": "Ca(HPO4)2",
    "formatted_formula": "Ca(HPO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi dihidrophosphat"
  },
  {
    "id": "1653",
    "formula": "Ca(PO3)2",
    "formatted_formula": "Ca(PO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi metaphosphat"
  },
  {
    "id": "1654",
    "formula": "Ca(H2PO4)2.H2O",
    "formatted_formula": "Ca(H<sub>2</sub>PO<sub>4</sub>)<sub>2</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi superphosphat hidrat"
  },
  {
    "id": "1655",
    "formula": "Ca(NO3)2.4H2O",
    "formatted_formula": "Ca(NO<sub>3</sub>)<sub>2</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi nitrat tetrahydrat"
  },
  {
    "id": "1656",
    "formula": "[Ca(H2O)6]2+",
    "formatted_formula": "[Ca(H<sub>2</sub>O)<sub>6</sub>]<sup>2+</sup>",
    "vietnamese_name": "Ion canxi(II)hexaaqua"
  },
  {
    "id": "1657",
    "formula": "(NO3)-",
    "formatted_formula": "(NO<sub>3</sub>)<sup>-</sup>",
    "vietnamese_name": "Ion nitrat"
  },
  {
    "id": "1658",
    "formula": "LiF",
    "formatted_formula": "LiF<sup></sup>",
    "vietnamese_name": "Liti florua"
  },
  {
    "id": "1659",
    "formula": "NH4F",
    "formatted_formula": "NH<sub>4</sub>F<sup></sup>",
    "vietnamese_name": "Amoni florua"
  },
  {
    "id": "1660",
    "formula": "U",
    "formatted_formula": "U<sup></sup>",
    "vietnamese_name": "Urani"
  },
  {
    "id": "1661",
    "formula": "UF3",
    "formatted_formula": "UF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Urani(III) florua"
  },
  {
    "id": "1662",
    "formula": "PF5",
    "formatted_formula": "PF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Phospho pentaflorua"
  },
  {
    "id": "1663",
    "formula": "CaTiO3",
    "formatted_formula": "CaTiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Canxi titanat(IV)"
  },
  {
    "id": "1664",
    "formula": "Cd(NH3)2Cl2",
    "formatted_formula": "Cd(NH<sub>3</sub>)<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cadmium diammindichloride"
  },
  {
    "id": "1665",
    "formula": "H2[CdCl4]",
    "formatted_formula": "H<sub>2</sub>[CdCl<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Paladi (II) hidro clorua"
  },
  {
    "id": "1666",
    "formula": "Cd",
    "formatted_formula": "Cd<sup></sup>",
    "vietnamese_name": "Cadmi"
  },
  {
    "id": "1668",
    "formula": "HCOOLi",
    "formatted_formula": "HCOOLi<sup></sup>",
    "vietnamese_name": "Lithi format"
  },
  {
    "id": "1669",
    "formula": "Li2CO3",
    "formatted_formula": "Li<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Liti cacbonat"
  },
  {
    "id": "1670",
    "formula": "Cu(NO3)2.6H2O",
    "formatted_formula": "Cu(NO<sub>3</sub>)<sub>2</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng(II) nitrat hexahidrat"
  },
  {
    "id": "1671",
    "formula": "[Cu(NH3)4](NO3)2",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>4</sub>](NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetraamminkupfer(II)-nitrat"
  },
  {
    "id": "1672",
    "formula": "Hg2(NO3)2",
    "formatted_formula": "Hg<sub>2</sub>(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(I) nitrat"
  },
  {
    "id": "1673",
    "formula": "(CuOH)2SO4",
    "formatted_formula": "(CuOH)<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Copper(II)hydroxyl sulfate"
  },
  {
    "id": "1674",
    "formula": "Na2CuO2",
    "formatted_formula": "Na<sub>2</sub>CuO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri cuprit"
  },
  {
    "id": "1675",
    "formula": "K2Cu(CN)4",
    "formatted_formula": "K<sub>2</sub>Cu(CN)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali teracyanocuprat(II)"
  },
  {
    "id": "1676",
    "formula": "Fe(CO)5",
    "formatted_formula": "Fe(CO)<sub>5</sub><sup></sup>",
    "vietnamese_name": "Sắt pentacacbonyl"
  },
  {
    "id": "1677",
    "formula": "Fe2(CO)9",
    "formatted_formula": "Fe<sub>2</sub>(CO)<sub>9</sub><sup></sup>",
    "vietnamese_name": "Diiron nonacacbonyl"
  },
  {
    "id": "1678",
    "formula": "Fe3(CO)12",
    "formatted_formula": "Fe<sub>3</sub>(CO)<sub>1</sub><sub>2</sub><sup></sup>",
    "vietnamese_name": "Triiron dodecacarbonyl"
  },
  {
    "id": "1679",
    "formula": "Na2[Fe(CO)4]",
    "formatted_formula": "Na<sub>2</sub>[Fe(CO)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Dinatri tetracarbonylferrat"
  },
  {
    "id": "1680",
    "formula": "H2Fe(CO)4",
    "formatted_formula": "H<sub>2</sub>Fe(CO)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Iron tetracarbonyl hydride"
  },
  {
    "id": "1681",
    "formula": "FeO(OH)",
    "formatted_formula": "FeO(OH)<sup></sup>",
    "vietnamese_name": "Goethit"
  },
  {
    "id": "1682",
    "formula": "Fe2ZnO4",
    "formatted_formula": "Fe<sub>2</sub>ZnO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Iron zinc oxide"
  },
  {
    "id": "1683",
    "formula": "Na5FeO4",
    "formatted_formula": "Na<sub>5</sub>FeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri Oxoferrat(III) "
  },
  {
    "id": "1685",
    "formula": "Fe3(PO4)2",
    "formatted_formula": "Fe<sub>3</sub>(PO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) phosphat"
  },
  {
    "id": "1686",
    "formula": "FeCl2.4H2O",
    "formatted_formula": "FeCl<sub>2</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Sắt(II) clorua tetrahidrat"
  },
  {
    "id": "1687",
    "formula": "Na[Fe(CO)4H]",
    "formatted_formula": "Na[Fe(CO)<sub>4</sub>H]<sup></sup>",
    "vietnamese_name": "Iron tetracarbonyl hydride sodium"
  },
  {
    "id": "1688",
    "formula": "CdCl2.  2,5H2O",
    "formatted_formula": "CdCl<sub>2</sub>.  <sub>2</sub>,<sub>5</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Cadmi clorua hemipentahidrat"
  },
  {
    "id": "1689",
    "formula": "Fe3O4.2H2O",
    "formatted_formula": "Fe<sub>3</sub>O<sub>4</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Sắt(II,III) oxit dihidrat"
  },
  {
    "id": "1690",
    "formula": "FeCr2O4",
    "formatted_formula": "FeCr<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Chromite"
  },
  {
    "id": "1691",
    "formula": "FeClOH",
    "formatted_formula": "FeClOH<sup></sup>",
    "vietnamese_name": "Iron(II) chloride hydroxide"
  },
  {
    "id": "1692",
    "formula": "Fe(CH3COO)2",
    "formatted_formula": "Fe(CH<sub>3</sub>COO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) axetat"
  },
  {
    "id": "1693",
    "formula": "B(OH)3",
    "formatted_formula": "B(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit boric"
  },
  {
    "id": "1694",
    "formula": "HO2",
    "formatted_formula": "HO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hydroperoxy radical"
  },
  {
    "id": "1695",
    "formula": "Te",
    "formatted_formula": "Te<sup></sup>",
    "vietnamese_name": "Telua"
  },
  {
    "id": "1696",
    "formula": "HCOOH",
    "formatted_formula": "HCOOH<sup></sup>",
    "vietnamese_name": "Axit formic"
  },
  {
    "id": "1697",
    "formula": "NaHO2",
    "formatted_formula": "NaHO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sodium hydrogen peroxide"
  },
  {
    "id": "1698",
    "formula": "NH4HS",
    "formatted_formula": "NH<sub>4</sub>HS<sup></sup>",
    "vietnamese_name": "Amoni hidrosulfua"
  },
  {
    "id": "1699",
    "formula": "S2",
    "formatted_formula": "S<sub>2</sub><sup></sup>",
    "vietnamese_name": "Lưu huỳnh dime"
  },
  {
    "id": "1700",
    "formula": "H2S2O2",
    "formatted_formula": "H<sub>2</sub>S<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit thiosunfurơ"
  },
  {
    "id": "1701",
    "formula": "Ca(HF2)2 . 6H2O",
    "formatted_formula": "Ca(HF<sub>2</sub>)<sub>2</sub> . <sub>6</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi biflorua hexahidrat"
  },
  {
    "id": "1702",
    "formula": "Fe(NO)4",
    "formatted_formula": "Fe(NO)<sub>4</sub><sup></sup>",
    "vietnamese_name": "tetranitrosyl iron"
  },
  {
    "id": "1703",
    "formula": "H2O2.2H2O",
    "formatted_formula": "H<sub>2</sub>O<sub>2</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hidro peroxit dihidrat"
  },
  {
    "id": "1705",
    "formula": "H2SO5",
    "formatted_formula": "H<sub>2</sub>SO<sub>5</sub><sup></sup>",
    "vietnamese_name": "Axit Caro"
  },
  {
    "id": "1706",
    "formula": "U(OH)4",
    "formatted_formula": "U(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Urani(IV) hidroxit"
  },
  {
    "id": "1707",
    "formula": "Am",
    "formatted_formula": "Am<sup></sup>",
    "vietnamese_name": "Americi"
  },
  {
    "id": "1708",
    "formula": "Am(OH)4",
    "formatted_formula": "Am(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Americi(IV) tetrahidroxit"
  },
  {
    "id": "1709",
    "formula": "Ca(HS)2",
    "formatted_formula": "Ca(HS)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi dihidrosunfua"
  },
  {
    "id": "1710",
    "formula": "(N2H6)SO4",
    "formatted_formula": "(N<sub>2</sub>H<sub>6</sub>)SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydrazin sunfat"
  },
  {
    "id": "1711",
    "formula": "N2H4",
    "formatted_formula": "N<sub>2</sub>H<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydrazin"
  },
  {
    "id": "1712",
    "formula": "H2S2O6",
    "formatted_formula": "H<sub>2</sub>S<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit dithionic"
  },
  {
    "id": "1713",
    "formula": "(NH3OH)2SO4",
    "formatted_formula": "(NH<sub>3</sub>OH)<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydroxylamin sunfat"
  },
  {
    "id": "1714",
    "formula": "(NH3OH)HSO4",
    "formatted_formula": "(NH<sub>3</sub>OH)HSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydroxylamin sulfat"
  },
  {
    "id": "1715",
    "formula": "(N2H5)2SO4",
    "formatted_formula": "(N<sub>2</sub>H<sub>5</sub>)<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydrazin(I) sunfat"
  },
  {
    "id": "1716",
    "formula": "(NH4)2H2P2O7",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>H<sub>2</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Amoni dihidro pyrophosphat"
  },
  {
    "id": "1717",
    "formula": "H4P2O8",
    "formatted_formula": "H<sub>4</sub>P<sub>2</sub>O<sub>8</sub><sup></sup>",
    "vietnamese_name": "Peroxydiphosphoricacid"
  },
  {
    "id": "1718",
    "formula": "HAuCl4",
    "formatted_formula": "HAuCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit cloroauric"
  },
  {
    "id": "1719",
    "formula": "N2H5Cl",
    "formatted_formula": "N<sub>2</sub>H<sub>5</sub>Cl<sup></sup>",
    "vietnamese_name": "Hydrazin dihidroclorua"
  },
  {
    "id": "1720",
    "formula": "NH3OHCl",
    "formatted_formula": "NH<sub>3</sub>OHCl<sup></sup>",
    "vietnamese_name": "Hydroxyamin hidroclorua"
  },
  {
    "id": "1721",
    "formula": "PH4Cl",
    "formatted_formula": "PH<sub>4</sub>Cl<sup></sup>",
    "vietnamese_name": "Clorophosphoran"
  },
  {
    "id": "1722",
    "formula": "RhCl3",
    "formatted_formula": "RhCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rhodi(III) clorua"
  },
  {
    "id": "1723",
    "formula": "Rh",
    "formatted_formula": "Rh<sup></sup>",
    "vietnamese_name": "Rhodi"
  },
  {
    "id": "1724",
    "formula": "C2H7NHCl",
    "formatted_formula": "C<sub>2</sub>H<sub>7</sub>NHCl<sup></sup>",
    "vietnamese_name": "Dimetylamin hidroclorua"
  },
  {
    "id": "1725",
    "formula": "C2H7N",
    "formatted_formula": "C<sub>2</sub>H<sub>7</sub>N<sup></sup>",
    "vietnamese_name": "Etanamin"
  },
  {
    "id": "1726",
    "formula": "N2H6Cl2",
    "formatted_formula": "N<sub>2</sub>H<sub>6</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hydrazin dihidroclorua"
  },
  {
    "id": "1727",
    "formula": "Hg(CN)2",
    "formatted_formula": "Hg(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân cyanua"
  },
  {
    "id": "1728",
    "formula": "HgCrO4",
    "formatted_formula": "HgCrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân cromat"
  },
  {
    "id": "1729",
    "formula": "KSCN",
    "formatted_formula": "KSCN<sup></sup>",
    "vietnamese_name": "Kali thiocyanat"
  },
  {
    "id": "1730",
    "formula": "CHNS",
    "formatted_formula": "CHNS<sup></sup>",
    "vietnamese_name": "Axit thiocyanic"
  },
  {
    "id": "1731",
    "formula": "H2[Hg(SCN)4]",
    "formatted_formula": "H<sub>2</sub>[Hg(SCN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Hydrogen Mercury Tetrathiocyanate"
  },
  {
    "id": "1732",
    "formula": "K2[Hg(CN)4]",
    "formatted_formula": "K<sub>2</sub>[Hg(CN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Dipotassium Mercury tetracyanide"
  },
  {
    "id": "1733",
    "formula": "(Hg2N)OH.2H2O",
    "formatted_formula": "(Hg<sub>2</sub>N)OH.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nitridodimercury hydroxide"
  },
  {
    "id": "1734",
    "formula": "Cl2O",
    "formatted_formula": "Cl<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Diclo monooxit"
  },
  {
    "id": "1735",
    "formula": "(NH3OH)NO3",
    "formatted_formula": "(NH<sub>3</sub>OH)NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hydroxylamoni nitrat"
  },
  {
    "id": "1736",
    "formula": "N2H5NO3",
    "formatted_formula": "N<sub>2</sub>H<sub>5</sub>NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nitric acid hydrazine"
  },
  {
    "id": "1737",
    "formula": "NOHSO4",
    "formatted_formula": "NOHSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Nitrosyl hidrosunfat"
  },
  {
    "id": "1738",
    "formula": "N2H6(NO3)2",
    "formatted_formula": "N<sub>2</sub>H<sub>6</sub>(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dinitric acid hydrazine"
  },
  {
    "id": "1739",
    "formula": "RbNO3",
    "formatted_formula": "RbNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rubidi nitrat"
  },
  {
    "id": "1740",
    "formula": "Ho",
    "formatted_formula": "Ho<sup></sup>",
    "vietnamese_name": "Holmi"
  },
  {
    "id": "1741",
    "formula": "Ho(NO3)3",
    "formatted_formula": "Ho(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Holmi nitrat"
  },
  {
    "id": "1742",
    "formula": "K2O2",
    "formatted_formula": "K<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali peroxit"
  },
  {
    "id": "1743",
    "formula": "Ag2Cr2O7",
    "formatted_formula": "Ag<sub>2</sub>Cr<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Bạc dicromat"
  },
  {
    "id": "1744",
    "formula": "Tl2Cr2O7",
    "formatted_formula": "Tl<sub>2</sub>Cr<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Tali dicromat"
  },
  {
    "id": "1746",
    "formula": "K2CO3.1,5 H2O",
    "formatted_formula": "K<sub>2</sub>CO<sub>3</sub>.1,<sub>5</sub> H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kali cacbonat sesquihidrat"
  },
  {
    "id": "1747",
    "formula": "K2S2",
    "formatted_formula": "K<sub>2</sub>S<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dikali disunfua"
  },
  {
    "id": "1749",
    "formula": "K2SiS3",
    "formatted_formula": "K<sub>2</sub>SiS<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dipotassium Silicon disulfide "
  },
  {
    "id": "1750",
    "formula": "K2S.5H2O",
    "formatted_formula": "K<sub>2</sub>S.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Dikali sunfua pentahidrat"
  },
  {
    "id": "1751",
    "formula": "K2S2O6",
    "formatted_formula": "K<sub>2</sub>S<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali dithionat"
  },
  {
    "id": "1752",
    "formula": "K3PO4.7H2O",
    "formatted_formula": "K<sub>3</sub>PO<sub>4</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kali phosphat heptahidrat"
  },
  {
    "id": "1754",
    "formula": "K2HPO4",
    "formatted_formula": "K<sub>2</sub>HPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dikali hidro phosphat"
  },
  {
    "id": "1756",
    "formula": "Li3PO4",
    "formatted_formula": "Li<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti phosphat"
  },
  {
    "id": "1757",
    "formula": "KBrO4",
    "formatted_formula": "KBrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali percromat"
  },
  {
    "id": "1758",
    "formula": "KHSO3",
    "formatted_formula": "KHSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali hiđrosunfit"
  },
  {
    "id": "1759",
    "formula": "KHO2",
    "formatted_formula": "KHO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali Hidroperoxy"
  },
  {
    "id": "1760",
    "formula": "ScCl3",
    "formatted_formula": "ScCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Scandi clorua"
  },
  {
    "id": "1761",
    "formula": "K3ScCl6",
    "formatted_formula": "K<sub>3</sub>ScCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali scandi clorua"
  },
  {
    "id": "1762",
    "formula": "ZrCl4",
    "formatted_formula": "ZrCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Zirconi tetraclorua"
  },
  {
    "id": "1763",
    "formula": "K2ZrCl6",
    "formatted_formula": "K<sub>2</sub>ZrCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali hexaclorozirconat"
  },
  {
    "id": "1764",
    "formula": "HfCl4",
    "formatted_formula": "HfCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hafni tetraclorua"
  },
  {
    "id": "1765",
    "formula": "K2HfCl6",
    "formatted_formula": "K<sub>2</sub>HfCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Potassium hexachlorohafnate"
  },
  {
    "id": "1766",
    "formula": "K2PtCl6",
    "formatted_formula": "K<sub>2</sub>PtCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali hexacloroplatinat(IV)"
  },
  {
    "id": "1767",
    "formula": "PtCl4",
    "formatted_formula": "PtCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Platin tetrachlorit"
  },
  {
    "id": "1768",
    "formula": "ThCl4",
    "formatted_formula": "ThCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thori tetraclorua"
  },
  {
    "id": "1769",
    "formula": "K2ThCl6",
    "formatted_formula": "K<sub>2</sub>ThCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali hexaclorothorat"
  },
  {
    "id": "1770",
    "formula": "Ba(ClO3)2",
    "formatted_formula": "Ba(ClO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari clorat"
  },
  {
    "id": "1771",
    "formula": "Ba(IO3)2",
    "formatted_formula": "Ba(IO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari iodat"
  },
  {
    "id": "1773",
    "formula": "(NH4)2SO3",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni sunfit"
  },
  {
    "id": "1774",
    "formula": "Na2SeO4",
    "formatted_formula": "Na<sub>2</sub>SeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri selenat"
  },
  {
    "id": "1775",
    "formula": "Na2SeO3",
    "formatted_formula": "Na<sub>2</sub>SeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri selenit"
  },
  {
    "id": "1776",
    "formula": "TeO2",
    "formatted_formula": "TeO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Telua dioxit"
  },
  {
    "id": "1777",
    "formula": "Na4P2O7",
    "formatted_formula": "Na<sub>4</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Natri pyrophosphat"
  },
  {
    "id": "1778",
    "formula": "Mg2P2O7",
    "formatted_formula": "Mg<sub>2</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Magie Pyrophosphat"
  },
  {
    "id": "1779",
    "formula": "K[Cr(OH)4]",
    "formatted_formula": "K[Cr(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "kali tetrahydroxocrom(III)"
  },
  {
    "id": "1780",
    "formula": "K3[Fe(OH)6]",
    "formatted_formula": "K<sub>3</sub>[Fe(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Kali hexahydroxoferrat(III)"
  },
  {
    "id": "1781",
    "formula": "K3[FeCN)6]",
    "formatted_formula": "K<sub>3</sub>[FeCN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Kali ferricyanua"
  },
  {
    "id": "1782",
    "formula": "KNO3.(1-2)HNO3",
    "formatted_formula": "KNO<sub>3</sub>.(<sub>1</sub>-<sub>2</sub>)HNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali nitrat (1-2) axit nitric"
  },
  {
    "id": "1783",
    "formula": "CsNO2",
    "formatted_formula": "CsNO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xezi nitrit"
  },
  {
    "id": "1784",
    "formula": "CsNO3.HNO3",
    "formatted_formula": "CsNO<sub>3</sub>.HNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xezi nitrat. axit nitric"
  },
  {
    "id": "1785",
    "formula": "[K(H2O)6]OH",
    "formatted_formula": "[K(H<sub>2</sub>O)<sub>6</sub>]OH<sup></sup>",
    "vietnamese_name": "Hexaaquapotassium hydroxide"
  },
  {
    "id": "1786",
    "formula": "Mg(NO3)2.6H2O",
    "formatted_formula": "Mg(NO<sub>3</sub>)<sub>2</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Magie nitrat hexahidrat"
  },
  {
    "id": "1787",
    "formula": "[Mg(H2O)6](NO3)2",
    "formatted_formula": "[Mg(H<sub>2</sub>O)<sub>6</sub>](NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexaaquamagnesium(II) nitrate"
  },
  {
    "id": "1788",
    "formula": "Mg(OH)NO3",
    "formatted_formula": "Mg(OH)NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Magie monohydroxit mononitrat"
  },
  {
    "id": "1789",
    "formula": "Mg2CO3(OH)2",
    "formatted_formula": "Mg<sub>2</sub>CO<sub>3</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie cacbonat dihydroxit"
  },
  {
    "id": "1790",
    "formula": "MgCO3.5H2O",
    "formatted_formula": "MgCO<sub>3</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Magie cacbonat pentahidrat"
  },
  {
    "id": "1791",
    "formula": "MgF2",
    "formatted_formula": "MgF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie florua"
  },
  {
    "id": "1792",
    "formula": "Na2MnO4",
    "formatted_formula": "Na<sub>2</sub>MnO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri manganat"
  },
  {
    "id": "1793",
    "formula": "NaMnO4",
    "formatted_formula": "NaMnO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri permanganat"
  },
  {
    "id": "1794",
    "formula": "Ba(HS)2",
    "formatted_formula": "Ba(HS)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari hidrosunfua"
  },
  {
    "id": "1795",
    "formula": "Mn(NO3)2",
    "formatted_formula": "Mn(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Mangan nitrat"
  },
  {
    "id": "1796",
    "formula": "MnO2.nH2O",
    "formatted_formula": "MnO<sub>2</sub>.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Mangan dioxit hidrat"
  },
  {
    "id": "1797",
    "formula": "MnS2O6",
    "formatted_formula": "MnS<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Mangan dithionat"
  },
  {
    "id": "1798",
    "formula": "MnSO2",
    "formatted_formula": "MnSO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magan(II) Hyposunfit"
  },
  {
    "id": "1799",
    "formula": "Mn(OH)2",
    "formatted_formula": "Mn(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Mangan dihidroxit"
  },
  {
    "id": "1800",
    "formula": "HNO4",
    "formatted_formula": "HNO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit peroxynitric"
  },
  {
    "id": "1801",
    "formula": "Na2CO3.10H2O",
    "formatted_formula": "Na<sub>2</sub>CO<sub>3</sub>.10H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri cacbonat decahidrat"
  },
  {
    "id": "1802",
    "formula": "NaO2",
    "formatted_formula": "NaO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri dioxit"
  },
  {
    "id": "1803",
    "formula": "Na2HPO4.12H2O",
    "formatted_formula": "Na<sub>2</sub>HPO<sub>4</sub>.12H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Dinatri hidrophosphat 12hidrat"
  },
  {
    "id": "1804",
    "formula": "Na3NO4",
    "formatted_formula": "Na<sub>3</sub>NO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri Orthonitrat"
  },
  {
    "id": "1807",
    "formula": "K3NO4",
    "formatted_formula": "K<sub>3</sub>NO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali orthonitrat"
  },
  {
    "id": "1808",
    "formula": "Na4BeO3",
    "formatted_formula": "Na<sub>4</sub>BeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Tetranatri beri trioxit"
  },
  {
    "id": "1809",
    "formula": "Na2SiS3",
    "formatted_formula": "Na<sub>2</sub>SiS<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri metasilicat"
  },
  {
    "id": "1810",
    "formula": "Na2S.9H2O",
    "formatted_formula": "Na<sub>2</sub>S.9H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri sunfua nonahidrat"
  },
  {
    "id": "1811",
    "formula": "Sb2S3",
    "formatted_formula": "Sb<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Stibnite"
  },
  {
    "id": "1812",
    "formula": "Na3SbS3",
    "formatted_formula": "Na<sub>3</sub>SbS<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri thioantimonit"
  },
  {
    "id": "1813",
    "formula": "CH3COCH2Br",
    "formatted_formula": "CH<sub>3</sub>COCH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "Bromoaxeton"
  },
  {
    "id": "1814",
    "formula": "Na2S2O5",
    "formatted_formula": "Na<sub>2</sub>S<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Natri pyrosulfit"
  },
  {
    "id": "1815",
    "formula": "Na2S2O3.5H2O",
    "formatted_formula": "Na<sub>2</sub>S<sub>2</sub>O<sub>3</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri thiosunfat pentahidrat"
  },
  {
    "id": "1816",
    "formula": "Na2S5",
    "formatted_formula": "Na<sub>2</sub>S<sub>5</sub><sup></sup>",
    "vietnamese_name": "Dinatri pentasunfua"
  },
  {
    "id": "1817",
    "formula": "H2S2O3",
    "formatted_formula": "H<sub>2</sub>S<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit thiosunfuric"
  },
  {
    "id": "1818",
    "formula": "HSO3Cl",
    "formatted_formula": "HSO<sub>3</sub>Cl<sup></sup>",
    "vietnamese_name": "Axit clorosulfuric"
  },
  {
    "id": "1819",
    "formula": "S2O5Cl2",
    "formatted_formula": "S<sub>2</sub>O<sub>5</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Pyrosulfuryl clorua"
  },
  {
    "id": "1820",
    "formula": "Na2Sx",
    "formatted_formula": "Na<sub>2</sub>Sx<sup></sup>",
    "vietnamese_name": "Natri polysunfua"
  },
  {
    "id": "1822",
    "formula": "Na4SiO4",
    "formatted_formula": "Na<sub>4</sub>SiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri silicat"
  },
  {
    "id": "1823",
    "formula": "Na2SiO3.9H2O",
    "formatted_formula": "Na<sub>2</sub>SiO<sub>3</sub>.9H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri metasilicat nonahidrat"
  },
  {
    "id": "1824",
    "formula": "Na2SO3Se",
    "formatted_formula": "Na<sub>2</sub>SO<sub>3</sub>Se<sup></sup>",
    "vietnamese_name": "Natri selenosunfat"
  },
  {
    "id": "1825",
    "formula": "Na2SO3.7H2O",
    "formatted_formula": "Na<sub>2</sub>SO<sub>3</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri sunfit heptahidrat"
  },
  {
    "id": "1826",
    "formula": "Na3PO4.12H2O",
    "formatted_formula": "Na<sub>3</sub>PO<sub>4</sub>.12H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Trinatri phosphat dodecahidrat"
  },
  {
    "id": "1827",
    "formula": "Na3PO3S",
    "formatted_formula": "Na<sub>3</sub>PO<sub>3</sub>S<sup></sup>",
    "vietnamese_name": "Natri phosphorothioat"
  },
  {
    "id": "1828",
    "formula": "PSCl3",
    "formatted_formula": "PSCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Phospho sulfoclorua"
  },
  {
    "id": "1829",
    "formula": "NaBr.2H2O",
    "formatted_formula": "NaBr.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri bromua dihidrat"
  },
  {
    "id": "1830",
    "formula": "Na2H2P2O7",
    "formatted_formula": "Na<sub>2</sub>H<sub>2</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Natri dihidro pyrophosphat"
  },
  {
    "id": "1831",
    "formula": "Na2H2P2O6",
    "formatted_formula": "Na<sub>2</sub>H<sub>2</sub>P<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri dihidro hypophosphat"
  },
  {
    "id": "1832",
    "formula": "NaBrO",
    "formatted_formula": "NaBrO<sup></sup>",
    "vietnamese_name": "Natri hypobromua"
  },
  {
    "id": "1833",
    "formula": "NaIO3",
    "formatted_formula": "NaIO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri iodat"
  },
  {
    "id": "1834",
    "formula": "NaIO",
    "formatted_formula": "NaIO<sup></sup>",
    "vietnamese_name": "Natri Hypoiodit"
  },
  {
    "id": "1835",
    "formula": "Na2[Mg(OH)4]",
    "formatted_formula": "Na<sub>2</sub>[Mg(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Tetraaquamagnesium(II) sodium"
  },
  {
    "id": "1836",
    "formula": "Pb2P2O6",
    "formatted_formula": "Pb<sub>2</sub>P<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Chì hypophosphat"
  },
  {
    "id": "1837",
    "formula": "Na4P2O6",
    "formatted_formula": "Na<sub>4</sub>P<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri hypophosphat"
  },
  {
    "id": "1838",
    "formula": "Pb(CH3COO)2",
    "formatted_formula": "Pb(CH<sub>3</sub>COO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì axetat"
  },
  {
    "id": "1839",
    "formula": "NO2NH2",
    "formatted_formula": "NO<sub>2</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Nitroamin"
  },
  {
    "id": "1840",
    "formula": "Cr2(CH3COO)4.2H2O",
    "formatted_formula": "Cr<sub>2</sub>(CH<sub>3</sub>COO)<sub>4</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Crom(II) axetat hidrat"
  },
  {
    "id": "1841",
    "formula": "GeH4",
    "formatted_formula": "GeH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Germani tetrahidrua"
  },
  {
    "id": "1842",
    "formula": "GeO2",
    "formatted_formula": "GeO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Germani(IV) oxit"
  },
  {
    "id": "1843",
    "formula": "Na3[Co(NO2)6]",
    "formatted_formula": "Na<sub>3</sub>[Co(NO<sub>2</sub>)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Natri hexanitritocobanat(III)"
  },
  {
    "id": "1845",
    "formula": "Br-",
    "formatted_formula": "Br<sup>-</sup>",
    "vietnamese_name": "Bromua"
  },
  {
    "id": "1846",
    "formula": "(S2O3)2-",
    "formatted_formula": "(S<sub>2</sub>O<sub>3</sub>)<sup>2-</sup>",
    "vietnamese_name": "Thiosunfat"
  },
  {
    "id": "1847",
    "formula": "NaCuCl2",
    "formatted_formula": "NaCuCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sodium copper dichloride "
  },
  {
    "id": "1848",
    "formula": "NaCl.2H2O",
    "formatted_formula": "NaCl.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hydrohalite"
  },
  {
    "id": "1849",
    "formula": "Na[AlOH]4",
    "formatted_formula": "Na[AlOH]<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri tetrahydroxyaluminat"
  },
  {
    "id": "1850",
    "formula": "[Na(NH3)4]I",
    "formatted_formula": "[Na(NH<sub>3</sub>)<sub>4</sub>]I<sup></sup>",
    "vietnamese_name": "Tetramminesodium iodide"
  },
  {
    "id": "1851",
    "formula": "NaI.2H2O",
    "formatted_formula": "NaI.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri iodua dihidrat"
  },
  {
    "id": "1852",
    "formula": "Na4N2O4",
    "formatted_formula": "Na<sub>4</sub>N<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri nitroxylat"
  },
  {
    "id": "1853",
    "formula": "NO2F",
    "formatted_formula": "NO<sub>2</sub>F<sup></sup>",
    "vietnamese_name": "Nitryl florua"
  },
  {
    "id": "1855",
    "formula": "NaB(OH)4",
    "formatted_formula": "NaB(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri metaborat dihidrat"
  },
  {
    "id": "1857",
    "formula": "OH-",
    "formatted_formula": "OH<sup>-</sup>",
    "vietnamese_name": "Ion hidroxit"
  },
  {
    "id": "1858",
    "formula": "Li2NH",
    "formatted_formula": "Li<sub>2</sub>NH<sup></sup>",
    "vietnamese_name": "Lithium imide"
  },
  {
    "id": "1859",
    "formula": "(NH4)HF2",
    "formatted_formula": "(NH<sub>4</sub>)HF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Amoni hidroflorua"
  },
  {
    "id": "1860",
    "formula": "PN(NH2)2",
    "formatted_formula": "PN(NH<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Aminodiiminophosphoran"
  },
  {
    "id": "1861",
    "formula": "PN2H",
    "formatted_formula": "PN<sub>2</sub>H<sup></sup>",
    "vietnamese_name": "Phospham"
  },
  {
    "id": "1862",
    "formula": "[Zn(H2O)2(NH3)2]Cl2",
    "formatted_formula": "[Zn(H<sub>2</sub>O)<sub>2</sub>(NH<sub>3</sub>)<sub>2</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diaquadiamminezincate(II) chloride"
  },
  {
    "id": "1863",
    "formula": "TcCl4",
    "formatted_formula": "TcCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Tecneti(IV) clorua"
  },
  {
    "id": "1864",
    "formula": "(NH4)2[TcCl6]",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>[TcCl<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Amoni hexaclorotecneti(IV)"
  },
  {
    "id": "1865",
    "formula": "NOF",
    "formatted_formula": "NOF<sup></sup>",
    "vietnamese_name": "Nitrosyl florua"
  },
  {
    "id": "1866",
    "formula": "D3PO4",
    "formatted_formula": "D<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit phosphoric -d<sub>3</sub>"
  },
  {
    "id": "1867",
    "formula": "Pb(SCN)2",
    "formatted_formula": "Pb(SCN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì(II) thiocyanat"
  },
  {
    "id": "1868",
    "formula": "NH4SCN",
    "formatted_formula": "NH<sub>4</sub>SCN<sup></sup>",
    "vietnamese_name": "Amoni sunfocyanua"
  },
  {
    "id": "1869",
    "formula": "PbCO3",
    "formatted_formula": "PbCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Chì cacbonat"
  },
  {
    "id": "1870",
    "formula": "Pb(N3)2",
    "formatted_formula": "Pb(N<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì azua"
  },
  {
    "id": "1871",
    "formula": "Na2[Pb(OH)4]",
    "formatted_formula": "Na<sub>2</sub>[Pb(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium tetrahydroxyplumbate(II)"
  },
  {
    "id": "1872",
    "formula": "K2PbO2",
    "formatted_formula": "K<sub>2</sub>PbO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali plumbit"
  },
  {
    "id": "1873",
    "formula": "PbO2",
    "formatted_formula": "PbO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì(IV) oxit"
  },
  {
    "id": "1874",
    "formula": "PBr5",
    "formatted_formula": "PBr<sub>5</sub><sup></sup>",
    "vietnamese_name": "Phospho(V)pentabromua"
  },
  {
    "id": "1875",
    "formula": "PBr3",
    "formatted_formula": "PBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Phospho bromua"
  },
  {
    "id": "1876",
    "formula": "PBr3O",
    "formatted_formula": "PBr<sub>3</sub>O<sup></sup>",
    "vietnamese_name": "Phosphoryl bromua"
  },
  {
    "id": "1877",
    "formula": "H3PO2",
    "formatted_formula": "H<sub>3</sub>PO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit phosphinic"
  },
  {
    "id": "1878",
    "formula": "PH4I",
    "formatted_formula": "PH<sub>4</sub>I<sup></sup>",
    "vietnamese_name": "Phosphonium iodide"
  },
  {
    "id": "1879",
    "formula": "Ni(PH3)4",
    "formatted_formula": "Ni(PH<sub>3</sub>)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Tetraphosphin niken"
  },
  {
    "id": "1881",
    "formula": "Li2SiO3",
    "formatted_formula": "Li<sub>2</sub>SiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Liti metasilicat"
  },
  {
    "id": "1882",
    "formula": "SiO",
    "formatted_formula": "SiO<sup></sup>",
    "vietnamese_name": "Silic oxit"
  },
  {
    "id": "1883",
    "formula": "MgSiO3",
    "formatted_formula": "MgSiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Magie metasilicat"
  },
  {
    "id": "1884",
    "formula": "Be2SiO4",
    "formatted_formula": "Be<sub>2</sub>SiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Beri silicat"
  },
  {
    "id": "1885",
    "formula": "Li4SiO4",
    "formatted_formula": "Li<sub>4</sub>SiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti orthosilicat"
  },
  {
    "id": "1886",
    "formula": "ZnSiO3",
    "formatted_formula": "ZnSiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kẽm metasilicat"
  },
  {
    "id": "1887",
    "formula": "SiO2.nH2O",
    "formatted_formula": "SiO<sub>2</sub>.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "silica hidrat"
  },
  {
    "id": "1888",
    "formula": "SnO",
    "formatted_formula": "SnO<sup></sup>",
    "vietnamese_name": "Thiếc oxit"
  },
  {
    "id": "1889",
    "formula": "Na2[Sn(OH)6]",
    "formatted_formula": "Na<sub>2</sub>[Sn(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Sodium hexahydroxostannate(IV)"
  },
  {
    "id": "1890",
    "formula": "HSnCl3",
    "formatted_formula": "HSnCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Trichlorostannane"
  },
  {
    "id": "1891",
    "formula": "N2H4.H2O",
    "formatted_formula": "N<sub>2</sub>H<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hydrazin hidrat"
  },
  {
    "id": "1892",
    "formula": "K3[Cr(OH)6]",
    "formatted_formula": "K<sub>3</sub>[Cr(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Kali hexahydroxochromat"
  },
  {
    "id": "1893",
    "formula": "K2[Sn(OH)6]",
    "formatted_formula": "K<sub>2</sub>[Sn(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Potassium stannate(IV)"
  },
  {
    "id": "1894",
    "formula": "Ba(HSO4)2",
    "formatted_formula": "Ba(HSO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari Bisunfat"
  },
  {
    "id": "1896",
    "formula": "CuF2",
    "formatted_formula": "CuF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) florua"
  },
  {
    "id": "1897",
    "formula": "HSO3F",
    "formatted_formula": "HSO<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Axit florosunfuric"
  },
  {
    "id": "1898",
    "formula": "SO2F2",
    "formatted_formula": "SO<sub>2</sub>F<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sunfonyl diflorua"
  },
  {
    "id": "1899",
    "formula": "KSO2F",
    "formatted_formula": "KSO<sub>2</sub>F<sup></sup>",
    "vietnamese_name": "Fluorosulfurous acid potassium salt"
  },
  {
    "id": "1900",
    "formula": "NaSO2F",
    "formatted_formula": "NaSO<sub>2</sub>F<sup></sup>",
    "vietnamese_name": "Natri florosunfit"
  },
  {
    "id": "1901",
    "formula": "D2SO4",
    "formatted_formula": "D<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit sunfuric (D<sub>2</sub>)"
  },
  {
    "id": "1902",
    "formula": "HSO3NH2",
    "formatted_formula": "HSO<sub>3</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit sunfamidic"
  },
  {
    "id": "1903",
    "formula": "LiSO3F",
    "formatted_formula": "LiSO<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Liti floridosunfat"
  },
  {
    "id": "1904",
    "formula": "ZnSO3",
    "formatted_formula": "ZnSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kẽm sunfit"
  },
  {
    "id": "1905",
    "formula": "Zn2SiO4",
    "formatted_formula": "Zn<sub>2</sub>SiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kẽm silicat(IV)"
  },
  {
    "id": "1906",
    "formula": "ZnSO4.7H2O",
    "formatted_formula": "ZnSO<sub>4</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kẽm sunfat heptahidrat"
  },
  {
    "id": "1907",
    "formula": "Zn(HSO4)2",
    "formatted_formula": "Zn(HSO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kẽm Hidro Sunfat"
  },
  {
    "id": "1908",
    "formula": "[Zn(NH3)6]Cl2",
    "formatted_formula": "[Zn(NH<sub>3</sub>)<sub>6</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexamminezinc chloride"
  },
  {
    "id": "1909",
    "formula": "ZnCl2.1,5H2O",
    "formatted_formula": "ZnCl<sub>2</sub>.1,<sub>5</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kẽm clorua sesquihidrat"
  },
  {
    "id": "1910",
    "formula": "Bi(NO3)3",
    "formatted_formula": "Bi(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut nitrat"
  },
  {
    "id": "1911",
    "formula": "BiCl3",
    "formatted_formula": "BiCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut clorua"
  },
  {
    "id": "1912",
    "formula": "Bi2(SO4)3",
    "formatted_formula": "Bi<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut(III) sunfat"
  },
  {
    "id": "1913",
    "formula": "Bi2S3",
    "formatted_formula": "Bi<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut(III) sunfua"
  },
  {
    "id": "1914",
    "formula": "Na2N2O2",
    "formatted_formula": "Na<sub>2</sub>N<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri hyponitrit"
  },
  {
    "id": "1915",
    "formula": "Ni(OH)2",
    "formatted_formula": "Ni(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Niken(II)dihidroxit"
  },
  {
    "id": "1916",
    "formula": "Ni2SiO4",
    "formatted_formula": "Ni<sub>2</sub>SiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Niken silicat"
  },
  {
    "id": "1917",
    "formula": "Na2NiO2",
    "formatted_formula": "Na<sub>2</sub>NiO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sodium nickelite"
  },
  {
    "id": "1918",
    "formula": "NiSO4",
    "formatted_formula": "NiSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Niken(II) sunfat"
  },
  {
    "id": "1919",
    "formula": "Ni(NO3)2",
    "formatted_formula": "Ni(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Niken nitrat"
  },
  {
    "id": "1920",
    "formula": "NiS",
    "formatted_formula": "NiS<sup></sup>",
    "vietnamese_name": "Niken(II) sunfua"
  },
  {
    "id": "1921",
    "formula": "CrCl2O2",
    "formatted_formula": "CrCl<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chromyl clorua"
  },
  {
    "id": "1922",
    "formula": "(NH4)2CrO4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>CrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni cromat"
  },
  {
    "id": "1923",
    "formula": "MnCO3",
    "formatted_formula": "MnCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Mangan cacbonat"
  },
  {
    "id": "1924",
    "formula": "NiF2",
    "formatted_formula": "NiF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Niken diflorua"
  },
  {
    "id": "1925",
    "formula": "NiOOH",
    "formatted_formula": "NiOOH<sup></sup>",
    "vietnamese_name": "Nickel oxyhydroxide"
  },
  {
    "id": "1926",
    "formula": "[Ni(NH3)6](OH)2",
    "formatted_formula": "[Ni(NH<sub>3</sub>)<sub>6</sub>](OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexamminenickel (II) hydroxide"
  },
  {
    "id": "1927",
    "formula": "[Ni(NH3)6]Cl2",
    "formatted_formula": "[Ni(NH<sub>3</sub>)<sub>6</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexamminenickel(II) Chloride"
  },
  {
    "id": "1928",
    "formula": "Li2O2",
    "formatted_formula": "Li<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Peroxydilithium"
  },
  {
    "id": "1929",
    "formula": "Li2SeO4",
    "formatted_formula": "Li<sub>2</sub>SeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti selenat"
  },
  {
    "id": "1930",
    "formula": "SeO3",
    "formatted_formula": "SeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Selen trioxit"
  },
  {
    "id": "1931",
    "formula": "Se2O5",
    "formatted_formula": "Se<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Diselen pentoxit"
  },
  {
    "id": "1932",
    "formula": "K2SeO4",
    "formatted_formula": "K<sub>2</sub>SeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali selenat"
  },
  {
    "id": "1933",
    "formula": "Ti(SO4)O",
    "formatted_formula": "Ti(SO<sub>4</sub>)O<sup></sup>",
    "vietnamese_name": "Titanium(IV) oxysulfate"
  },
  {
    "id": "1935",
    "formula": "BeF2",
    "formatted_formula": "BeF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Beri florua"
  },
  {
    "id": "1936",
    "formula": "H2BeF4",
    "formatted_formula": "H<sub>2</sub>BeF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydrogen fluorberyllate"
  },
  {
    "id": "1937",
    "formula": "Be2CO3(OH)2",
    "formatted_formula": "Be<sub>2</sub>CO<sub>3</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Beri cacbonat dihidroxit"
  },
  {
    "id": "1938",
    "formula": "Na[Al(H2O)2(OH)4]",
    "formatted_formula": "Na[Al(H<sub>2</sub>O)<sub>2</sub>(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium diaquatetrahydroxyaluminate ((III)"
  },
  {
    "id": "1939",
    "formula": "PbSiO3",
    "formatted_formula": "PbSiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Chì metasilicat"
  },
  {
    "id": "1940",
    "formula": "Pb3O4",
    "formatted_formula": "Pb<sub>3</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Chì(II,IV) oxit"
  },
  {
    "id": "1941",
    "formula": "Fe2(SO4)O",
    "formatted_formula": "Fe<sub>2</sub>(SO<sub>4</sub>)O<sup></sup>",
    "vietnamese_name": "Sắt oxisunfat"
  },
  {
    "id": "1942",
    "formula": "FeSO4.7H2O",
    "formatted_formula": "FeSO<sub>4</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Sắt(II) sunfat heptahidrat"
  },
  {
    "id": "1943",
    "formula": "[Fe(H2O)5(NO)]SO4",
    "formatted_formula": "[Fe(H<sub>2</sub>O)<sub>5</sub>(NO)]SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Pentaaquanitrosyliron(I) sulphate"
  },
  {
    "id": "1944",
    "formula": "CaSO4.0,5H2O",
    "formatted_formula": "CaSO<sub>4</sub>.0,<sub>5</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi sunfat hemihidrat"
  },
  {
    "id": "1945",
    "formula": "CaSO4.2H2O",
    "formatted_formula": "CaSO<sub>4</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi sunfat dihidrat"
  },
  {
    "id": "1946",
    "formula": "CaCN2",
    "formatted_formula": "CaCN<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi cyanamua"
  },
  {
    "id": "1947",
    "formula": "H2CN2",
    "formatted_formula": "H<sub>2</sub>CN<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cyanamua"
  },
  {
    "id": "1948",
    "formula": "[Mg(NH3)6]Cl2",
    "formatted_formula": "[Mg(NH<sub>3</sub>)<sub>6</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexaminmagie (II) clorua"
  },
  {
    "id": "1949",
    "formula": "MgCl(OH)",
    "formatted_formula": "MgCl(OH)<sup></sup>",
    "vietnamese_name": "Magnesium chloride hydroxide"
  },
  {
    "id": "1950",
    "formula": "BeH2",
    "formatted_formula": "BeH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Beri hydrua"
  },
  {
    "id": "1951",
    "formula": "BeCl(OH)",
    "formatted_formula": "BeCl(OH)<sup></sup>",
    "vietnamese_name": "Beryllium chloride hydroxide"
  },
  {
    "id": "1952",
    "formula": "Be(NO3)OH",
    "formatted_formula": "Be(NO<sub>3</sub>)OH<sup></sup>",
    "vietnamese_name": "Beryllium  hydroxide nitrate"
  },
  {
    "id": "1953",
    "formula": "Na2[Be(OH)4]",
    "formatted_formula": "Na<sub>2</sub>[Be(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium tetrahydroxidoberyllate"
  },
  {
    "id": "1954",
    "formula": "Be(NH4)PO4",
    "formatted_formula": "Be(NH<sub>4</sub>)PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Berryllium Ammonium Phosphate "
  },
  {
    "id": "1955",
    "formula": "[Cu(NH3)2]OH",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>2</sub>]OH<sup></sup>",
    "vietnamese_name": "Diamminecopper (I) hydroxide"
  },
  {
    "id": "1956",
    "formula": "PdCl2.2H2O",
    "formatted_formula": "PdCl<sub>2</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Paladi(II) clorua dihidrat"
  },
  {
    "id": "1957",
    "formula": "Pd(H2O)2Cl2",
    "formatted_formula": "Pd(H<sub>2</sub>O)<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diaquapalladium(II) chloride"
  },
  {
    "id": "1958",
    "formula": "[Zn(NH3)6](OH)2",
    "formatted_formula": "[Zn(NH<sub>3</sub>)<sub>6</sub>](OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexamminezinc hydroxide"
  },
  {
    "id": "1959",
    "formula": "PdI2",
    "formatted_formula": "PdI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Paladi diiodua"
  },
  {
    "id": "1960",
    "formula": "PdS",
    "formatted_formula": "PdS<sup></sup>",
    "vietnamese_name": "Paladi sunfua"
  },
  {
    "id": "1961",
    "formula": "Pd(OH)2",
    "formatted_formula": "Pd(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Paladi(II) hidroxit"
  },
  {
    "id": "1962",
    "formula": "(NH4)2SnS3",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>SnS<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ammonium trithiostannate(IV)"
  },
  {
    "id": "1963",
    "formula": "Pd(NH3)2Cl2",
    "formatted_formula": "Pd(NH<sub>3</sub>)<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diamminedichloropalladium"
  },
  {
    "id": "1965",
    "formula": "SnS2",
    "formatted_formula": "SnS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thiếc(IV)disunfua"
  },
  {
    "id": "1966",
    "formula": "KCrO2",
    "formatted_formula": "KCrO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali cromat(III)"
  },
  {
    "id": "1967",
    "formula": "HCrO2",
    "formatted_formula": "HCrO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chromous acid"
  },
  {
    "id": "1968",
    "formula": "Cr(OH)3.nH2O",
    "formatted_formula": "Cr(OH)<sub>3</sub>.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Crom(III) hidroxit hidrat"
  },
  {
    "id": "1969",
    "formula": "Na3[Cr(OH)6]",
    "formatted_formula": "Na<sub>3</sub>[Cr(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Sodium hexahydroxychromate (III)"
  },
  {
    "id": "1970",
    "formula": "K2CrO3",
    "formatted_formula": "K<sub>2</sub>CrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali cromat(IV)"
  },
  {
    "id": "1971",
    "formula": "K3CrO3",
    "formatted_formula": "K<sub>3</sub>CrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali cromat(III)"
  },
  {
    "id": "1972",
    "formula": "Na3CrO3",
    "formatted_formula": "Na<sub>3</sub>CrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri cromat(III)"
  },
  {
    "id": "1973",
    "formula": "K2S2O3",
    "formatted_formula": "K<sub>2</sub>S<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali thiosunfat"
  },
  {
    "id": "1974",
    "formula": "K2S2O5",
    "formatted_formula": "K<sub>2</sub>S<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Kali pyrosunfit"
  },
  {
    "id": "1975",
    "formula": "(NH4)3AsS4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>3</sub>AsS<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni thioarsenat"
  },
  {
    "id": "1976",
    "formula": "(NH4)2Sx",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>Sx<sup></sup>",
    "vietnamese_name": "Amoni polysunfua"
  },
  {
    "id": "1978",
    "formula": "(NH4)3AsS3",
    "formatted_formula": "(NH<sub>4</sub>)<sub>3</sub>AsS<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni thioarsenit"
  },
  {
    "id": "1980",
    "formula": "K2RuO4",
    "formatted_formula": "K<sub>2</sub>RuO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali ruthenat"
  },
  {
    "id": "1981",
    "formula": "RuO4",
    "formatted_formula": "RuO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Rutheni tetraoxit"
  },
  {
    "id": "1982",
    "formula": "Os",
    "formatted_formula": "Os<sup></sup>",
    "vietnamese_name": "Osmi"
  },
  {
    "id": "1983",
    "formula": "K2[OsO2(OH)4]",
    "formatted_formula": "K<sub>2</sub>[OsO<sub>2</sub>(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Kali osmat(VI)"
  },
  {
    "id": "1984",
    "formula": "KRuO4",
    "formatted_formula": "KRuO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali perruthenat"
  },
  {
    "id": "1985",
    "formula": "KCu(CN)2",
    "formatted_formula": "KCu(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dicyanocopper(I) potassium"
  },
  {
    "id": "1986",
    "formula": "CSO",
    "formatted_formula": "CSO<sup></sup>",
    "vietnamese_name": "Carbonyl sunfua"
  },
  {
    "id": "1987",
    "formula": "K2FeO4",
    "formatted_formula": "K<sub>2</sub>FeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Potassium ferrate(VI)"
  },
  {
    "id": "1988",
    "formula": "Al(NO3)3.9H2O",
    "formatted_formula": "Al(NO<sub>3</sub>)<sub>3</sub>.9H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nhôm nitrat nonahidrat"
  },
  {
    "id": "1990",
    "formula": "NO3-",
    "formatted_formula": "NO<sub>3</sub><sup>-</sup>",
    "vietnamese_name": "Ion nitrat"
  },
  {
    "id": "1991",
    "formula": "P2",
    "formatted_formula": "P<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diphosphorus"
  },
  {
    "id": "1992",
    "formula": "H4P2O6",
    "formatted_formula": "H<sub>4</sub>P<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit hypophosphoric"
  },
  {
    "id": "1993",
    "formula": "H4P2O5",
    "formatted_formula": "H<sub>4</sub>P<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Axit Pyrophotphorơ"
  },
  {
    "id": "1994",
    "formula": "Na2HPO3",
    "formatted_formula": "Na<sub>2</sub>HPO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri hidro phosphit"
  },
  {
    "id": "1995",
    "formula": "NaH2PO3",
    "formatted_formula": "NaH<sub>2</sub>PO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri dihidro phosphit"
  },
  {
    "id": "1996",
    "formula": "KOH.2H2O",
    "formatted_formula": "KOH.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kali hidroxit dihidrat"
  },
  {
    "id": "1997",
    "formula": "AgClO3",
    "formatted_formula": "AgClO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bạc clorat"
  },
  {
    "id": "1998",
    "formula": "Ag2F",
    "formatted_formula": "Ag<sub>2</sub>F<sup></sup>",
    "vietnamese_name": "Bạc(0,I) florua"
  },
  {
    "id": "1999",
    "formula": "AgPF6",
    "formatted_formula": "AgPF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Silver hexafluorophosphate"
  },
  {
    "id": "2000",
    "formula": "AgF.2H2O",
    "formatted_formula": "AgF.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Bạc(I) florua dihidrat"
  },
  {
    "id": "2002",
    "formula": "K[AgF4]",
    "formatted_formula": "K[AgF<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "potassium tetrafluoroargentate"
  },
  {
    "id": "2003",
    "formula": "XeF2",
    "formatted_formula": "XeF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xenon florua"
  },
  {
    "id": "2004",
    "formula": "K2AgF4",
    "formatted_formula": "K<sub>2</sub>AgF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Diotassium tetrafuoroargenate"
  },
  {
    "id": "2007",
    "formula": "HAtO3",
    "formatted_formula": "HAtO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Perastatic acid"
  },
  {
    "id": "2010",
    "formula": "Na2Te",
    "formatted_formula": "Na<sub>2</sub>Te<sup></sup>",
    "vietnamese_name": "Natri telurua"
  },
  {
    "id": "2014",
    "formula": "Al2Br6",
    "formatted_formula": "Al<sub>2</sub>Br<sub>6</sub><sup></sup>",
    "vietnamese_name": "Nhôm bromua[dime]"
  },
  {
    "id": "2015",
    "formula": "CBr4",
    "formatted_formula": "CBr<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cacbon tetrabromua"
  },
  {
    "id": "2016",
    "formula": "H3AlF6",
    "formatted_formula": "H<sub>3</sub>AlF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Nhôm hidro florua"
  },
  {
    "id": "2017",
    "formula": "AlF3.H2O",
    "formatted_formula": "AlF<sub>3</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nhôm florua monohydrat"
  },
  {
    "id": "2018",
    "formula": "NH4AlF4",
    "formatted_formula": "NH<sub>4</sub>AlF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Ammonium tetrafluoroaluminate"
  },
  {
    "id": "2019",
    "formula": "NaAlF4",
    "formatted_formula": "NaAlF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sodium tetrafluoroaluminate"
  },
  {
    "id": "2020",
    "formula": "Na3AlF6",
    "formatted_formula": "Na<sub>3</sub>AlF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri hexafloroaluminat"
  },
  {
    "id": "2022",
    "formula": "Al2Te3",
    "formatted_formula": "Al<sub>2</sub>Te<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dinhôm tritelurua"
  },
  {
    "id": "2023",
    "formula": "H2Se",
    "formatted_formula": "H<sub>2</sub>Se<sup></sup>",
    "vietnamese_name": "Dihidro selenua"
  },
  {
    "id": "2024",
    "formula": "CSe2",
    "formatted_formula": "CSe<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cabon diselenua"
  },
  {
    "id": "2025",
    "formula": "Al2Se3",
    "formatted_formula": "Al<sub>2</sub>Se<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm selenua"
  },
  {
    "id": "2026",
    "formula": "XeCl2",
    "formatted_formula": "XeCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xenon diclorua"
  },
  {
    "id": "2027",
    "formula": "Cf",
    "formatted_formula": "Cf<sup></sup>",
    "vietnamese_name": "Californi"
  },
  {
    "id": "2028",
    "formula": "CfCl3",
    "formatted_formula": "CfCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Californi clorua"
  },
  {
    "id": "2029",
    "formula": "C2H5COONH4",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COONH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni propionat"
  },
  {
    "id": "2031",
    "formula": "Co(OH)Cl",
    "formatted_formula": "Co(OH)Cl<sup></sup>",
    "vietnamese_name": "Coban hidroxit clorua"
  },
  {
    "id": "2033",
    "formula": "CoCl2.6H2O",
    "formatted_formula": "CoCl<sub>2</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Coban(II) clorua hexahidrat"
  },
  {
    "id": "2034",
    "formula": "Co2Cl(OH)3",
    "formatted_formula": "Co<sub>2</sub>Cl(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Coban clorua trihidroxit"
  },
  {
    "id": "2035",
    "formula": "[Co(NH3)6]Cl2",
    "formatted_formula": "[Co(NH<sub>3</sub>)<sub>6</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexaammine cobalt dichloride"
  },
  {
    "id": "2036",
    "formula": "CoO",
    "formatted_formula": "CoO<sup></sup>",
    "vietnamese_name": "Coban(II) oxit"
  },
  {
    "id": "2037",
    "formula": "C2N2",
    "formatted_formula": "C<sub>2</sub>N<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cyanogen"
  },
  {
    "id": "2038",
    "formula": "Co3O4",
    "formatted_formula": "Co<sub>3</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban(II,III) oxit"
  },
  {
    "id": "2039",
    "formula": "Cs3CoCl5",
    "formatted_formula": "Cs<sub>3</sub>CoCl<sub>5</sub><sup></sup>",
    "vietnamese_name": "tricaesium cobalt (II) pentachloride"
  },
  {
    "id": "2040",
    "formula": "(NH4)2C2O4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>C<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni oxalat"
  },
  {
    "id": "2041",
    "formula": "K2[Ni(CN)4]",
    "formatted_formula": "K<sub>2</sub>[Ni(CN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Potassium tetracyanidonickelate(II)"
  },
  {
    "id": "2042",
    "formula": "K2[Pt(CN)4]",
    "formatted_formula": "K<sub>2</sub>[Pt(CN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Kali tetracyanoplatinat (II)"
  },
  {
    "id": "2043",
    "formula": "Fe(C5H5)2",
    "formatted_formula": "Fe(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Ferrocene"
  },
  {
    "id": "2044",
    "formula": "AsF5",
    "formatted_formula": "AsF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Arsen(V) florua"
  },
  {
    "id": "2046",
    "formula": "AsF3",
    "formatted_formula": "AsF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Arsen triflorua"
  },
  {
    "id": "2047",
    "formula": "CaCl2.6H2O",
    "formatted_formula": "CaCl<sub>2</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi clorua hexahidrat"
  },
  {
    "id": "2048",
    "formula": "Ca(OH)Cl",
    "formatted_formula": "Ca(OH)Cl<sup></sup>",
    "vietnamese_name": "Calcium hydroxychloride"
  },
  {
    "id": "2049",
    "formula": "Ca(ClO)2.3H2O",
    "formatted_formula": "Ca(ClO)<sub>2</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi hypoclorit trihidrat"
  },
  {
    "id": "2050",
    "formula": "HClO",
    "formatted_formula": "HClO<sup></sup>",
    "vietnamese_name": "Hypochlorous acid"
  },
  {
    "id": "2051",
    "formula": "Mg(ClO4)2",
    "formatted_formula": "Mg(ClO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie perclorat"
  },
  {
    "id": "2052",
    "formula": "Ca2Si",
    "formatted_formula": "Ca<sub>2</sub>Si<sup></sup>",
    "vietnamese_name": "Dicalcium Silicon"
  },
  {
    "id": "2053",
    "formula": "CaO2.8H2O",
    "formatted_formula": "CaO<sub>2</sub>.8H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi peroxit octahidrat"
  },
  {
    "id": "2054",
    "formula": "CaCrO4",
    "formatted_formula": "CaCrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Canxi cromat"
  },
  {
    "id": "2055",
    "formula": "ZrSiO4",
    "formatted_formula": "ZrSiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Zirconi(IV) silicat"
  },
  {
    "id": "2056",
    "formula": "CaZrO3",
    "formatted_formula": "CaZrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Zirconic acid calcium salt"
  },
  {
    "id": "2057",
    "formula": "Cd2SiO4",
    "formatted_formula": "Cd<sub>2</sub>SiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Cadmi orthosilicat"
  },
  {
    "id": "2058",
    "formula": "K2CdO2",
    "formatted_formula": "K<sub>2</sub>CdO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali cadmiat"
  },
  {
    "id": "2059",
    "formula": "Na2[Cd(OH)4]",
    "formatted_formula": "Na<sub>2</sub>[Cd(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium tetrahydroxocadmium"
  },
  {
    "id": "2060",
    "formula": "[Cd(NH3)6](OH)2",
    "formatted_formula": "[Cd(NH<sub>3</sub>)<sub>6</sub>](OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexaminecadmium(II) hydroxide"
  },
  {
    "id": "2061",
    "formula": "Na4[Cd(OH)6]",
    "formatted_formula": "Na<sub>4</sub>[Cd(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Sodium hexahydroxocadmium(II)"
  },
  {
    "id": "2062",
    "formula": "[Cd(NH3)6]SO4",
    "formatted_formula": "[Cd(NH<sub>3</sub>)<sub>6</sub>]SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hexaminecadmium (II) sulfate"
  },
  {
    "id": "2063",
    "formula": "ClO2F",
    "formatted_formula": "ClO<sub>2</sub>F<sup></sup>",
    "vietnamese_name": "Cloryl florua"
  },
  {
    "id": "2064",
    "formula": "ClOF3",
    "formatted_formula": "ClOF<sub>3</sub><sup></sup>",
    "vietnamese_name": "chlorine oxide trifluoride"
  },
  {
    "id": "2065",
    "formula": "Na2S2O8",
    "formatted_formula": "Na<sub>2</sub>S<sub>2</sub>O<sub>8</sub><sup></sup>",
    "vietnamese_name": "Natri peroxodisunfat"
  },
  {
    "id": "2066",
    "formula": "NaClO2.3H2O",
    "formatted_formula": "NaClO<sub>2</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri clorit trihidrat"
  },
  {
    "id": "2067",
    "formula": "CeC2",
    "formatted_formula": "CeC<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xeri dicacbua"
  },
  {
    "id": "2068",
    "formula": "Ce",
    "formatted_formula": "Ce<sup></sup>",
    "vietnamese_name": "Xeri"
  },
  {
    "id": "2069",
    "formula": "CeCl3.7H2O",
    "formatted_formula": "CeCl<sub>3</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Xeri(III) clorua heptahidrat"
  },
  {
    "id": "2070",
    "formula": "Ce(OH)3",
    "formatted_formula": "Ce(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xeri(III) hidroxit"
  },
  {
    "id": "2071",
    "formula": "CeClO",
    "formatted_formula": "CeClO<sup></sup>",
    "vietnamese_name": "Cerium(III) chlorideoxide"
  },
  {
    "id": "2072",
    "formula": "Na2CeO3",
    "formatted_formula": "Na<sub>2</sub>CeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri xeri oxit"
  },
  {
    "id": "2073",
    "formula": "CeCO3OH",
    "formatted_formula": "CeCO<sub>3</sub>OH<sup></sup>",
    "vietnamese_name": "Xeri cacbonat hidroxit"
  },
  {
    "id": "2074",
    "formula": "Ce(NO3)3",
    "formatted_formula": "Ce(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xeri(III) nitrat"
  },
  {
    "id": "2075",
    "formula": "O2F2",
    "formatted_formula": "O<sub>2</sub>F<sub>2</sub><sup></sup>",
    "vietnamese_name": "Peroxy diflorua"
  },
  {
    "id": "2076",
    "formula": "ClO2F3",
    "formatted_formula": "ClO<sub>2</sub>F<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cloryl triflorua"
  },
  {
    "id": "2077",
    "formula": "NOF3",
    "formatted_formula": "NOF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nitơ triflorua oxit"
  },
  {
    "id": "2078",
    "formula": "KrF2",
    "formatted_formula": "KrF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Krypton diflorua"
  },
  {
    "id": "2079",
    "formula": "Kr",
    "formatted_formula": "Kr<sup></sup>",
    "vietnamese_name": "Krypton"
  },
  {
    "id": "2080",
    "formula": "HClO4.H2O",
    "formatted_formula": "HClO<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit percloric hidrat"
  },
  {
    "id": "2081",
    "formula": "I2O5",
    "formatted_formula": "I<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Diiot pentoxit"
  },
  {
    "id": "2083",
    "formula": "CoSO4",
    "formatted_formula": "CoSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban sunfat"
  },
  {
    "id": "2084",
    "formula": "Co2(CO)8",
    "formatted_formula": "Co<sub>2</sub>(CO)<sub>8</sub><sup></sup>",
    "vietnamese_name": "Dicobalt octacarbonyl"
  },
  {
    "id": "2085",
    "formula": "HCo(CO)4",
    "formatted_formula": "HCo(CO)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Coban tetracacbonyl hidrua"
  },
  {
    "id": "2086",
    "formula": "Co4(CO)12",
    "formatted_formula": "Co<sub>4</sub>(CO)<sub>1</sub><sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetracoban dodecacarbonyl"
  },
  {
    "id": "2087",
    "formula": "Na[Co(CO)4]",
    "formatted_formula": "Na[Co(CO)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Natri tetracarbonylcoban"
  },
  {
    "id": "2088",
    "formula": "Na(Hg)",
    "formatted_formula": "Na(Hg)<sup></sup>",
    "vietnamese_name": "Hỗn hống natri-thủy ngân"
  },
  {
    "id": "2089",
    "formula": "CoCO3",
    "formatted_formula": "CoCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Coban cacbonat"
  },
  {
    "id": "2090",
    "formula": "CoF2.4H2O",
    "formatted_formula": "CoF<sub>2</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Coban(II) florua tetrahidrat"
  },
  {
    "id": "2091",
    "formula": "CoO(OH)",
    "formatted_formula": "CoO(OH)<sup></sup>",
    "vietnamese_name": "Coban hidroxit oxit"
  },
  {
    "id": "2092",
    "formula": "[Co(NH3)6]F3",
    "formatted_formula": "[Co(NH<sub>3</sub>)<sub>6</sub>]F<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hexamincoban(III) florua"
  },
  {
    "id": "2094",
    "formula": "K3[Co(NO2)6]",
    "formatted_formula": "K<sub>3</sub>[Co(NO<sub>2</sub>)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Kali hexanitritocobanat(III)"
  },
  {
    "id": "2095",
    "formula": "Na2[Co(OH)4]",
    "formatted_formula": "Na<sub>2</sub>[Co(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Natri tetrahydroxocoban(II)"
  },
  {
    "id": "2096",
    "formula": "Co2CO3(OH)2",
    "formatted_formula": "Co<sub>2</sub>CO<sub>3</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "coban hidroxit cacbonat"
  },
  {
    "id": "2097",
    "formula": "[Cr(H2O)4]Cl2",
    "formatted_formula": "[Cr(H<sub>2</sub>O)<sub>4</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "tetraaquacrom(II) clorua"
  },
  {
    "id": "2098",
    "formula": "CsPF6",
    "formatted_formula": "CsPF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Xeri hexaflorophosphat"
  },
  {
    "id": "2099",
    "formula": "Cs2SiF6",
    "formatted_formula": "Cs<sub>2</sub>SiF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Xeri hexaflorosilicat"
  },
  {
    "id": "2100",
    "formula": "CsIF4",
    "formatted_formula": "CsIF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xeri tetrafloroiodat"
  },
  {
    "id": "2101",
    "formula": "SClF5",
    "formatted_formula": "SClF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Lưu huỳnh clorua pentaflorua"
  },
  {
    "id": "2102",
    "formula": "CsSO2F",
    "formatted_formula": "CsSO<sub>2</sub>F<sup></sup>",
    "vietnamese_name": "Xeri florosunfit"
  },
  {
    "id": "2103",
    "formula": "Cs3NiCl5",
    "formatted_formula": "Cs<sub>3</sub>NiCl<sub>5</sub><sup></sup>",
    "vietnamese_name": "Tricaesium Nickel(II) Pentachloride"
  },
  {
    "id": "2104",
    "formula": "Cs3Fe2Cl9",
    "formatted_formula": "Cs<sub>3</sub>Fe<sub>2</sub>Cl<sub>9</sub><sup></sup>",
    "vietnamese_name": "Cesium enneachlorodiferrate"
  },
  {
    "id": "2105",
    "formula": "Cs3Sb2Cl9",
    "formatted_formula": "Cs<sub>3</sub>Sb<sub>2</sub>Cl<sub>9</sub><sup></sup>",
    "vietnamese_name": "Cesium antimony nonachloride"
  },
  {
    "id": "2106",
    "formula": "CsH",
    "formatted_formula": "CsH<sup></sup>",
    "vietnamese_name": "Xezi hydrua"
  },
  {
    "id": "2107",
    "formula": "CsIBr2",
    "formatted_formula": "CsIBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xezi dibromo iodua"
  },
  {
    "id": "2108",
    "formula": "Cr2Si",
    "formatted_formula": "Cr<sub>2</sub>Si<sup></sup>",
    "vietnamese_name": "Dicrom silicua"
  },
  {
    "id": "2109",
    "formula": "At",
    "formatted_formula": "At<sup></sup>",
    "vietnamese_name": "Astatin"
  },
  {
    "id": "2110",
    "formula": "CsO3",
    "formatted_formula": "CsO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Cesium ozonide"
  },
  {
    "id": "2111",
    "formula": "NH4O3",
    "formatted_formula": "NH<sub>4</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ammonium ozonide"
  },
  {
    "id": "2112",
    "formula": "CsOH.H2O",
    "formatted_formula": "CsOH.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Xezi hidroxit monohidrat"
  },
  {
    "id": "2113",
    "formula": "CsHO2",
    "formatted_formula": "CsHO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Caesium(III) hydoxideoxide"
  },
  {
    "id": "2114",
    "formula": "Cs2O2",
    "formatted_formula": "Cs<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xezi peroxit"
  },
  {
    "id": "2115",
    "formula": "CsHS",
    "formatted_formula": "CsHS<sup></sup>",
    "vietnamese_name": "Xezi hidro sunfua"
  },
  {
    "id": "2116",
    "formula": "CH2OHCOOCH3",
    "formatted_formula": "CH<sub>2</sub>OHCOOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl glycolat"
  },
  {
    "id": "2117",
    "formula": "CH2OHCOONa",
    "formatted_formula": "CH<sub>2</sub>OHCOONa<sup></sup>",
    "vietnamese_name": "Natri glycollat"
  },
  {
    "id": "2118",
    "formula": "ClH3NCH2COOH",
    "formatted_formula": "ClH<sub>3</sub>NCH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Glycine hydrochloride"
  },
  {
    "id": "2119",
    "formula": "HOCH2COOH",
    "formatted_formula": "HOCH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit glycolic"
  },
  {
    "id": "2120",
    "formula": "H2NCH2COOC2H5",
    "formatted_formula": "H<sub>2</sub>NCH<sub>2</sub>COOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Etyl Aminoaxetat"
  },
  {
    "id": "2121",
    "formula": "Cs2S.4H2O",
    "formatted_formula": "Cs<sub>2</sub>S.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Xezi sunfua tetrahidrat"
  },
  {
    "id": "2122",
    "formula": "CsHSO4",
    "formatted_formula": "CsHSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xezi hidro sunfat"
  },
  {
    "id": "2123",
    "formula": "Cs2CO3.3,5H2O",
    "formatted_formula": "Cs<sub>2</sub>CO<sub>3</sub>.3,<sub>5</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Xezi cacbonat 3.5 hidrat"
  },
  {
    "id": "2124",
    "formula": "CsHCO3",
    "formatted_formula": "CsHCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xezi hidro cacbonat"
  },
  {
    "id": "2125",
    "formula": "CuF",
    "formatted_formula": "CuF<sup></sup>",
    "vietnamese_name": "Đồng(I) florua"
  },
  {
    "id": "2126",
    "formula": "[Cs(H2O)6]+",
    "formatted_formula": "[Cs(H<sub>2</sub>O)<sub>6</sub>]<sup>+</sup>",
    "vietnamese_name": "Hexaaqua cesium(I) ion"
  },
  {
    "id": "2127",
    "formula": "SO42-",
    "formatted_formula": "SO<sub>4</sub><sup>2-</sup>",
    "vietnamese_name": "Ion sunfat"
  },
  {
    "id": "2128",
    "formula": "AlCs(SO4)2.12H2O",
    "formatted_formula": "AlCs(SO<sub>4</sub>)<sub>2</sub>.12H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Aluminum cesium sulfate dodecahydrate"
  },
  {
    "id": "2129",
    "formula": "[CuOH]2CO3",
    "formatted_formula": "[CuOH]<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) hydroxycacbonat"
  },
  {
    "id": "2130",
    "formula": "Al2(SO4)3.6H2O",
    "formatted_formula": "Al<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nhôm sunfat hexahidrat"
  },
  {
    "id": "2131",
    "formula": "CuCO3",
    "formatted_formula": "CuCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) cacbonat"
  },
  {
    "id": "2132",
    "formula": "CuCN",
    "formatted_formula": "CuCN<sup></sup>",
    "vietnamese_name": "Đồng(I) cyanua"
  },
  {
    "id": "2133",
    "formula": "(CN)2",
    "formatted_formula": "(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cyanogen"
  },
  {
    "id": "2134",
    "formula": "[Cu(NH3)6]Cl2",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>6</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexaamminecopper(II) chloride"
  },
  {
    "id": "2135",
    "formula": "K[Cu(CN)2]",
    "formatted_formula": "K[Cu(CN)<sub>2</sub>]<sup></sup>",
    "vietnamese_name": "Dicyanidecopper (I) potassium"
  },
  {
    "id": "2136",
    "formula": "Cu2C",
    "formatted_formula": "Cu<sub>2</sub>C<sup></sup>",
    "vietnamese_name": "Đồng cacbua"
  },
  {
    "id": "2137",
    "formula": "[Cu(NH3)5]SO4",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>5</sub>]SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Pentaamminecopper(II) sulfate"
  },
  {
    "id": "2138",
    "formula": "CuSO4.5H2O",
    "formatted_formula": "CuSO<sub>4</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng sunfat pentahidrat"
  },
  {
    "id": "2139",
    "formula": "K2[Cu(CO3)2]",
    "formatted_formula": "K<sub>2</sub>[Cu(CO<sub>3</sub>)<sub>2</sub>]<sup></sup>",
    "vietnamese_name": "potassium bis(carbonato)cuprate(II)"
  },
  {
    "id": "2140",
    "formula": "[Cu(NH3)4]CO3",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>4</sub>]CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "tetraaminecopper (II) cacbonate"
  },
  {
    "id": "2141",
    "formula": "K2[Cu(CN)4]",
    "formatted_formula": "K<sub>2</sub>[Cu(CN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Potassium tetracyanocuprate(II) "
  },
  {
    "id": "2142",
    "formula": "Cu3(PO4)2.3H2O",
    "formatted_formula": "Cu<sub>3</sub>(PO<sub>4</sub>)<sub>2</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng(II) Phosphat Trihydrat"
  },
  {
    "id": "2143",
    "formula": "D2",
    "formatted_formula": "D<sub>2</sub><sup></sup>",
    "vietnamese_name": "Deuteri"
  },
  {
    "id": "2144",
    "formula": "HDSO4",
    "formatted_formula": "HDSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sunfuric acid D<sub>1</sub>"
  },
  {
    "id": "2145",
    "formula": "DCl",
    "formatted_formula": "DCl<sup></sup>",
    "vietnamese_name": "Deuteri clorua"
  },
  {
    "id": "2146",
    "formula": "DF",
    "formatted_formula": "DF<sup></sup>",
    "vietnamese_name": "Deuteri florua"
  },
  {
    "id": "2147",
    "formula": "LiOD",
    "formatted_formula": "LiOD<sup></sup>",
    "vietnamese_name": "Liti hidroxit (D)"
  },
  {
    "id": "2148",
    "formula": "HD",
    "formatted_formula": "HD<sup></sup>",
    "vietnamese_name": "Hidro–deuteri"
  },
  {
    "id": "2149",
    "formula": "Dy",
    "formatted_formula": "Dy<sup></sup>",
    "vietnamese_name": "Dysprosi"
  },
  {
    "id": "2152",
    "formula": "NF3",
    "formatted_formula": "NF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nitơ triflorua"
  },
  {
    "id": "2153",
    "formula": "CoSO4.7H2O",
    "formatted_formula": "CoSO<sub>4</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Coban sunfat heptahidrat"
  },
  {
    "id": "2154",
    "formula": "Co2SO4(OH)2",
    "formatted_formula": "Co<sub>2</sub>SO<sub>4</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban sunfat dihidroxit"
  },
  {
    "id": "2155",
    "formula": "[Co(NH3)6]SO4",
    "formatted_formula": "[Co(NH<sub>3</sub>)<sub>6</sub>]SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hexaamincoban(II) Sunfat"
  },
  {
    "id": "2156",
    "formula": "Co(CH3COO)2",
    "formatted_formula": "Co(CH<sub>3</sub>COO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban axetat"
  },
  {
    "id": "2157",
    "formula": "[Cr(NH3)6]2(SO4)3",
    "formatted_formula": "[Cr(NH<sub>3</sub>)<sub>6</sub>]<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hexamincrom(III) sunfat"
  },
  {
    "id": "2158",
    "formula": "Cr2(SO4)3.18H2O",
    "formatted_formula": "Cr<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub>.18H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Crom(III) sunfat octadecahidrat"
  },
  {
    "id": "2159",
    "formula": "CoSOH",
    "formatted_formula": "CoSOH<sup></sup>",
    "vietnamese_name": "Coban hidroxit sunfua"
  },
  {
    "id": "2160",
    "formula": "Cr2(SO4)3.6H2O",
    "formatted_formula": "Cr<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Crom(III) sunfat hidrat"
  },
  {
    "id": "2161",
    "formula": "CrSO4",
    "formatted_formula": "CrSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Crom(II) sunfat"
  },
  {
    "id": "2162",
    "formula": "Er",
    "formatted_formula": "Er<sup></sup>",
    "vietnamese_name": "Erbi"
  },
  {
    "id": "2163",
    "formula": "Er2O3",
    "formatted_formula": "Er<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Europi oxit"
  },
  {
    "id": "2164",
    "formula": "ErCl3",
    "formatted_formula": "ErCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Europi clorua"
  },
  {
    "id": "2165",
    "formula": "Er(OH)3",
    "formatted_formula": "Er(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Europi trihidroxit"
  },
  {
    "id": "2166",
    "formula": "Eu",
    "formatted_formula": "Eu<sup></sup>",
    "vietnamese_name": "Europi"
  },
  {
    "id": "2167",
    "formula": "Eu2O3",
    "formatted_formula": "Eu<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Europi(III) oxit"
  },
  {
    "id": "2168",
    "formula": "Eu(OH)3",
    "formatted_formula": "Eu(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Europi(III) hydroxit"
  },
  {
    "id": "2169",
    "formula": "EuCl3",
    "formatted_formula": "EuCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Europi(III) clorua"
  },
  {
    "id": "2170",
    "formula": "EuCl2",
    "formatted_formula": "EuCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Europi(II) clorua"
  },
  {
    "id": "2173",
    "formula": "EuBr3",
    "formatted_formula": "EuBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Europi(III) bromua"
  },
  {
    "id": "2174",
    "formula": "EuI3",
    "formatted_formula": "EuI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Europi triiodua"
  },
  {
    "id": "2175",
    "formula": "Li2SiF6",
    "formatted_formula": "Li<sub>2</sub>SiF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Liti hexaflorosilicat"
  },
  {
    "id": "2176",
    "formula": "Li4[HfF8]",
    "formatted_formula": "Li<sub>4</sub>[HfF<sub>8</sub>]<sup></sup>",
    "vietnamese_name": "Octafluorohafnium(IV) Lithium"
  },
  {
    "id": "2177",
    "formula": "F",
    "formatted_formula": "F<sup></sup>",
    "vietnamese_name": "Flo"
  },
  {
    "id": "2178",
    "formula": "AuF5",
    "formatted_formula": "AuF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Vàng pentaflorua"
  },
  {
    "id": "2179",
    "formula": "IF7",
    "formatted_formula": "IF<sub>7</sub><sup></sup>",
    "vietnamese_name": "Iot heptaflorua"
  },
  {
    "id": "2180",
    "formula": "PrCl3",
    "formatted_formula": "PrCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Praseodymi(III) clorua"
  },
  {
    "id": "2181",
    "formula": "PrF4",
    "formatted_formula": "PrF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Praseodymi tetraflorua"
  },
  {
    "id": "2182",
    "formula": "XeO2F2",
    "formatted_formula": "XeO<sub>2</sub>F<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xenon dioxidiflorua"
  },
  {
    "id": "2183",
    "formula": "LaCl3",
    "formatted_formula": "LaCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Lantan clorua"
  },
  {
    "id": "2184",
    "formula": "LaF3",
    "formatted_formula": "LaF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Lantan triflorua"
  },
  {
    "id": "2185",
    "formula": "La2O3",
    "formatted_formula": "La<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Lantan oxit"
  },
  {
    "id": "2186",
    "formula": "N2F4",
    "formatted_formula": "N<sub>2</sub>F<sub>4</sub><sup></sup>",
    "vietnamese_name": "Đinitơ tetraflorua"
  },
  {
    "id": "2187",
    "formula": "PF3",
    "formatted_formula": "PF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Phospho triflorua"
  },
  {
    "id": "2188",
    "formula": "ZnF2",
    "formatted_formula": "ZnF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kẽm florua"
  },
  {
    "id": "2189",
    "formula": "PCl2F3",
    "formatted_formula": "PCl<sub>2</sub>F<sub>3</sub><sup></sup>",
    "vietnamese_name": "Phospho diclorua triflorua"
  },
  {
    "id": "2190",
    "formula": "POF3",
    "formatted_formula": "POF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Phosphoryl triflorua"
  },
  {
    "id": "2191",
    "formula": "Ni(PF3)4",
    "formatted_formula": "Ni(PF<sub>3</sub>)<sub>4</sub><sup></sup>",
    "vietnamese_name": "tetrakis(trifluorophosphine)nickel"
  },
  {
    "id": "2192",
    "formula": "NaPF6",
    "formatted_formula": "NaPF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri hexaflorophosphat"
  },
  {
    "id": "2193",
    "formula": "GeF4",
    "formatted_formula": "GeF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Gecmani(IV) florua"
  },
  {
    "id": "2194",
    "formula": "Ge",
    "formatted_formula": "Ge<sup></sup>",
    "vietnamese_name": "Gecmani"
  },
  {
    "id": "2195",
    "formula": "GeCl4",
    "formatted_formula": "GeCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Germani(IV) clorua"
  },
  {
    "id": "2196",
    "formula": "GeS2",
    "formatted_formula": "GeS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Germani(IV) sunfua"
  },
  {
    "id": "2197",
    "formula": "C17H31COOH",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>1</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit linolenic"
  },
  {
    "id": "2198",
    "formula": "HfF4.3H2O",
    "formatted_formula": "HfF<sub>4</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hafni(IV) Florua trihidrat"
  },
  {
    "id": "2199",
    "formula": "HfO2",
    "formatted_formula": "HfO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hafni oxit"
  },
  {
    "id": "2200",
    "formula": "SiF2",
    "formatted_formula": "SiF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Silic diflorua"
  },
  {
    "id": "2201",
    "formula": "Na2SiF6",
    "formatted_formula": "Na<sub>2</sub>SiF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri hexaflorosilicat"
  },
  {
    "id": "2202",
    "formula": "RbF",
    "formatted_formula": "RbF<sup></sup>",
    "vietnamese_name": "Rubidi florua"
  },
  {
    "id": "2203",
    "formula": "Rb2SiF6",
    "formatted_formula": "Rb<sub>2</sub>SiF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Rubidi hexaflorosilicat"
  },
  {
    "id": "2204",
    "formula": "Rb2CO3",
    "formatted_formula": "Rb<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đirubidi cacbonat"
  },
  {
    "id": "2205",
    "formula": "Rb2O",
    "formatted_formula": "Rb<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Rubidi oxit "
  },
  {
    "id": "2206",
    "formula": "RbH",
    "formatted_formula": "RbH<sup></sup>",
    "vietnamese_name": "Rubidi hidrua"
  },
  {
    "id": "2207",
    "formula": "RbO2",
    "formatted_formula": "RbO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Rubidi dioxit"
  },
  {
    "id": "2208",
    "formula": "XeOF2",
    "formatted_formula": "XeOF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xenon oxit diflorua"
  },
  {
    "id": "2209",
    "formula": "PtF4",
    "formatted_formula": "PtF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Tetrafloroplatin(IV)"
  },
  {
    "id": "2210",
    "formula": "IF5",
    "formatted_formula": "IF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Iot pentaflorua"
  },
  {
    "id": "2211",
    "formula": "OsF6",
    "formatted_formula": "OsF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Osmi(VI) florua"
  },
  {
    "id": "2212",
    "formula": "UF4",
    "formatted_formula": "UF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Urani tetraflorua"
  },
  {
    "id": "2213",
    "formula": "UF6",
    "formatted_formula": "UF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Urani hexaflorua"
  },
  {
    "id": "2214",
    "formula": "UF5",
    "formatted_formula": "UF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Urani pentaflorua"
  },
  {
    "id": "2215",
    "formula": "UO2",
    "formatted_formula": "UO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Urani(IV) oxit"
  },
  {
    "id": "2216",
    "formula": "UO2F2\t",
    "formatted_formula": "UO<sub>2</sub>F<sub>2</sub>\t<sup></sup>",
    "vietnamese_name": "Uranyl(VI) florua"
  },
  {
    "id": "2217",
    "formula": "UO3",
    "formatted_formula": "UO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Urani(VI) oxit"
  },
  {
    "id": "2218",
    "formula": "U3O8",
    "formatted_formula": "U<sub>3</sub>O<sub>8</sub><sup></sup>",
    "vietnamese_name": "Triurani octaoxit"
  },
  {
    "id": "2219",
    "formula": "W",
    "formatted_formula": "W<sup></sup>",
    "vietnamese_name": "Wolfram"
  },
  {
    "id": "2220",
    "formula": "WO3",
    "formatted_formula": "WO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Wolfram(VI) trioxit"
  },
  {
    "id": "2221",
    "formula": "Na4XeO6\t",
    "formatted_formula": "Na<sub>4</sub>XeO<sub>6</sub>\t<sup></sup>",
    "vietnamese_name": "Natri Perxenat"
  },
  {
    "id": "2222",
    "formula": "H5IO6",
    "formatted_formula": "H<sub>5</sub>IO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit orthoperiodic"
  },
  {
    "id": "2223",
    "formula": "IOF5",
    "formatted_formula": "IOF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Iot pentaflorua oxit"
  },
  {
    "id": "2224",
    "formula": "Na3H2IO6",
    "formatted_formula": "Na<sub>3</sub>H<sub>2</sub>IO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri orthoperiodat"
  },
  {
    "id": "2225",
    "formula": "Re",
    "formatted_formula": "Re<sup></sup>",
    "vietnamese_name": "Rheni"
  },
  {
    "id": "2226",
    "formula": "ReF7",
    "formatted_formula": "ReF<sub>7</sub><sup></sup>",
    "vietnamese_name": "Rheni(VII) florua"
  },
  {
    "id": "2227",
    "formula": "HReO4",
    "formatted_formula": "HReO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit perrhenic(VII)"
  },
  {
    "id": "2228",
    "formula": "ReF4",
    "formatted_formula": "ReF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Rheni(IV) florua"
  },
  {
    "id": "2229",
    "formula": "ReO3F",
    "formatted_formula": "ReO<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Rheni florua trioxit"
  },
  {
    "id": "2230",
    "formula": "NaReO4",
    "formatted_formula": "NaReO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri perrhenat"
  },
  {
    "id": "2231",
    "formula": "C5H6",
    "formatted_formula": "C<sub>5</sub>H<sub>6</sub><sup></sup>",
    "vietnamese_name": "Cyclopentadien"
  },
  {
    "id": "2232",
    "formula": "NaC5H5",
    "formatted_formula": "NaC<sub>5</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Natri (2,4-Cyclopentadienyl) "
  },
  {
    "id": "2233",
    "formula": "Fe(HCO3)2",
    "formatted_formula": "Fe(HCO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) Bicacbonat"
  },
  {
    "id": "2234",
    "formula": "FeSO3",
    "formatted_formula": "FeSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) Sunfit"
  },
  {
    "id": "2235",
    "formula": "FeP2",
    "formatted_formula": "FeP<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sắt diphosphua"
  },
  {
    "id": "2236",
    "formula": "BiOOH",
    "formatted_formula": "BiOOH<sup></sup>",
    "vietnamese_name": "Bitmut oxithidroxit"
  },
  {
    "id": "2237",
    "formula": "BiF3",
    "formatted_formula": "BiF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut(III) florua"
  },
  {
    "id": "2238",
    "formula": "Bi(OH)3",
    "formatted_formula": "Bi(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut hidroxit"
  },
  {
    "id": "2239",
    "formula": "HBiCl4",
    "formatted_formula": "HBiCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydrotetrachloro- bismuthous acid"
  },
  {
    "id": "2240",
    "formula": "GaCl3.H2O",
    "formatted_formula": "GaCl<sub>3</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Gali triclorua monohidrat"
  },
  {
    "id": "2241",
    "formula": "GaClO",
    "formatted_formula": "GaClO<sup></sup>",
    "vietnamese_name": "Gali(III) clorua oxit"
  },
  {
    "id": "2242",
    "formula": "Ga",
    "formatted_formula": "Ga<sup></sup>",
    "vietnamese_name": "Gali"
  },
  {
    "id": "2243",
    "formula": "LiGaH4",
    "formatted_formula": "LiGaH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Lithium Tetrahydrogollote"
  },
  {
    "id": "2244",
    "formula": "GaOOH",
    "formatted_formula": "GaOOH<sup></sup>",
    "vietnamese_name": "Gali oxit hidroxit"
  },
  {
    "id": "2245",
    "formula": "NaGaO2",
    "formatted_formula": "NaGaO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri gali oxit"
  },
  {
    "id": "2246",
    "formula": "Ga(NO3)3",
    "formatted_formula": "Ga(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Gali trinitrat"
  },
  {
    "id": "2247",
    "formula": "Ga2O",
    "formatted_formula": "Ga<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đigali oxit"
  },
  {
    "id": "2248",
    "formula": "ZnGa2O4",
    "formatted_formula": "ZnGa<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kẽm galat"
  },
  {
    "id": "2249",
    "formula": "HNCS",
    "formatted_formula": "HNCS<sup></sup>",
    "vietnamese_name": "Axit thiocyanic"
  },
  {
    "id": "2250",
    "formula": "H2C2N2S3",
    "formatted_formula": "H<sub>2</sub>C<sub>2</sub>N<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "1,3,4-Thiadiazole-2,5-dithiol"
  },
  {
    "id": "2251",
    "formula": "Pt(CN)2",
    "formatted_formula": "Pt(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Platin(II)dicyanua"
  },
  {
    "id": "2252",
    "formula": "H2[Pt(CN)4]",
    "formatted_formula": "H<sub>2</sub>[Pt(CN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Dihidro tetracyanoplatinat (II)"
  },
  {
    "id": "2253",
    "formula": "CNCl",
    "formatted_formula": "CNCl<sup></sup>",
    "vietnamese_name": "Cloro cyanua"
  },
  {
    "id": "2254",
    "formula": "NH4ClO3",
    "formatted_formula": "NH<sub>4</sub>ClO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni clorat"
  },
  {
    "id": "2255",
    "formula": "NH3OHClO4",
    "formatted_formula": "NH<sub>3</sub>OHClO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydroxylamin perclorat"
  },
  {
    "id": "2256",
    "formula": "HI3O8",
    "formatted_formula": "HI<sub>3</sub>O<sub>8</sub><sup></sup>",
    "vietnamese_name": "Axit triperiodic"
  },
  {
    "id": "2257",
    "formula": "CH3COOCHCHC2H5",
    "formatted_formula": "CH<sub>3</sub>COOCHCHC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "1-butenyl axetat"
  },
  {
    "id": "2258",
    "formula": "C2H5CH2CHO",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>CH<sub>2</sub>CHO<sup></sup>",
    "vietnamese_name": "1-Butanal"
  },
  {
    "id": "2259",
    "formula": "CH3-CH=CH2",
    "formatted_formula": "CH<sub>3</sub>-CH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "1-Propen"
  },
  {
    "id": "2260",
    "formula": "C17H33COONa",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>3</sub>COONa<sup></sup>",
    "vietnamese_name": "Natri oleat"
  },
  {
    "id": "2261",
    "formula": "(C17H33COO)3C3H5",
    "formatted_formula": "(C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>3</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Triolein"
  },
  {
    "id": "2263",
    "formula": "ClO3",
    "formatted_formula": "ClO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Clo trioxit"
  },
  {
    "id": "2264",
    "formula": "NaBr",
    "formatted_formula": "NaBr<sup></sup>",
    "vietnamese_name": "Natri bromua"
  },
  {
    "id": "2265",
    "formula": "HIO",
    "formatted_formula": "HIO<sup></sup>",
    "vietnamese_name": "Hypoiodous acid"
  },
  {
    "id": "2266",
    "formula": "NH4N3",
    "formatted_formula": "NH<sub>4</sub>N<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni azua"
  },
  {
    "id": "2267",
    "formula": "NH4I3",
    "formatted_formula": "NH<sub>4</sub>I<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni triiodua"
  },
  {
    "id": "2269",
    "formula": "NH4ClO",
    "formatted_formula": "NH<sub>4</sub>ClO<sup></sup>",
    "vietnamese_name": "Hydroxylamoni clorua"
  },
  {
    "id": "2270",
    "formula": "NH2Cl",
    "formatted_formula": "NH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Monocloamin"
  },
  {
    "id": "2271",
    "formula": "Cl2.nH2O",
    "formatted_formula": "Cl<sub>2</sub>.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Clo hidrat"
  },
  {
    "id": "2272",
    "formula": "NCl3",
    "formatted_formula": "NCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nitơ clorua"
  },
  {
    "id": "2273",
    "formula": "(NH3OH)Cl",
    "formatted_formula": "(NH<sub>3</sub>OH)Cl<sup></sup>",
    "vietnamese_name": "Hydroxylamin hidroclorua"
  },
  {
    "id": "2274",
    "formula": "(NH3OH)N3",
    "formatted_formula": "(NH<sub>3</sub>OH)N<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hydroxylamin azua"
  },
  {
    "id": "2275",
    "formula": "KI3",
    "formatted_formula": "KI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali triiodua"
  },
  {
    "id": "2276",
    "formula": "H4PO4+",
    "formatted_formula": "H<sub>4</sub>PO<sub>4</sub><sup>+</sup>",
    "vietnamese_name": "Cation axit phosphoric"
  },
  {
    "id": "2277",
    "formula": "[Na(H2O)4]+",
    "formatted_formula": "[Na(H<sub>2</sub>O)<sub>4</sub>]<sup>+</sup>",
    "vietnamese_name": "Tetraaquasodium ion"
  },
  {
    "id": "2280",
    "formula": "As(HSO4)3",
    "formatted_formula": "As(HSO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Arsen (III) hidro sunfat"
  },
  {
    "id": "2281",
    "formula": "NaHSeO3",
    "formatted_formula": "NaHSeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri hidroselenit"
  },
  {
    "id": "2282",
    "formula": "SeCl4",
    "formatted_formula": "SeCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Selen(IV) clorua"
  },
  {
    "id": "2283",
    "formula": "Na2[Se(OH)6]",
    "formatted_formula": "Na<sub>2</sub>[Se(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Hexahydroxyselenate(VI) sodium"
  },
  {
    "id": "2284",
    "formula": "NaHSeO4",
    "formatted_formula": "NaHSeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri hiđroselenat"
  },
  {
    "id": "2285",
    "formula": "SeO42-",
    "formatted_formula": "SeO<sub>4</sub><sup>2-</sup>",
    "vietnamese_name": "Ion selenat"
  },
  {
    "id": "2286",
    "formula": "TeO3",
    "formatted_formula": "TeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Telua(VI) oxit"
  },
  {
    "id": "2287",
    "formula": "Na2TeO3",
    "formatted_formula": "Na<sub>2</sub>TeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri telurit"
  },
  {
    "id": "2288",
    "formula": "Na2TeO4.2H2O",
    "formatted_formula": "Na<sub>2</sub>TeO<sub>4</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri telurat dihidrat"
  },
  {
    "id": "2289",
    "formula": "SeOCl2",
    "formatted_formula": "SeOCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Selenylchloride"
  },
  {
    "id": "2290",
    "formula": "Se(OH)2Cl2",
    "formatted_formula": "Se(OH)<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "selenium dichloride dihydroxide"
  },
  {
    "id": "2291",
    "formula": "Ag2Te",
    "formatted_formula": "Ag<sub>2</sub>Te<sup></sup>",
    "vietnamese_name": "Bạc telurua"
  },
  {
    "id": "2292",
    "formula": "(C6H5)3Sb",
    "formatted_formula": "(C<sub>6</sub>H<sub>5</sub>)<sub>3</sub>Sb<sup></sup>",
    "vietnamese_name": "Triphenylstibine"
  },
  {
    "id": "2293",
    "formula": "Na2Se",
    "formatted_formula": "Na<sub>2</sub>Se<sup></sup>",
    "vietnamese_name": "Natri selenua"
  },
  {
    "id": "2294",
    "formula": "NaHSe",
    "formatted_formula": "NaHSe<sup></sup>",
    "vietnamese_name": "Natri biselenua"
  },
  {
    "id": "2295",
    "formula": "NaH2AsO4.H2O",
    "formatted_formula": "NaH<sub>2</sub>AsO<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri dihidroarsenat monohidrat"
  },
  {
    "id": "2296",
    "formula": "As2O5",
    "formatted_formula": "As<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Diarsen pentoxit"
  },
  {
    "id": "2297",
    "formula": "H3AsO4.0,5H2O",
    "formatted_formula": "H<sub>3</sub>AsO<sub>4</sub>.0,<sub>5</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit arsenic, hemihidrat"
  },
  {
    "id": "2298",
    "formula": "Na2HAsO4",
    "formatted_formula": "Na<sub>2</sub>HAsO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dinatri hiđroarsenat"
  },
  {
    "id": "2299",
    "formula": "As2S5",
    "formatted_formula": "As<sub>2</sub>S<sub>5</sub><sup></sup>",
    "vietnamese_name": "Diarsen pentasunfua"
  },
  {
    "id": "2300",
    "formula": "(NH4)3AsO4.3H2O",
    "formatted_formula": "(NH<sub>4</sub>)<sub>3</sub>AsO<sub>4</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Amoni arsenat trihidrat"
  },
  {
    "id": "2301",
    "formula": "H3AsO3",
    "formatted_formula": "H<sub>3</sub>AsO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit orthoarsenic"
  },
  {
    "id": "2303",
    "formula": "(PO3)-",
    "formatted_formula": "(PO<sub>3</sub>)<sup>-</sup>",
    "vietnamese_name": "Ion metaphosphat"
  },
  {
    "id": "2304",
    "formula": "SO3NH2−",
    "formatted_formula": "SO<sub>3</sub>NH<sub>2</sub>−<sup></sup>",
    "vietnamese_name": "Ion sunfamat"
  },
  {
    "id": "2305",
    "formula": "H3NSO3",
    "formatted_formula": "H<sub>3</sub>NSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit sunfamidic"
  },
  {
    "id": "2306",
    "formula": "NaH2NSO3",
    "formatted_formula": "NaH<sub>2</sub>NSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri sunfamat"
  },
  {
    "id": "2308",
    "formula": "HSO5-",
    "formatted_formula": "HSO<sub>5</sub><sup>-</sup>",
    "vietnamese_name": "Ion peroxymonosunfat"
  },
  {
    "id": "2309",
    "formula": "HPF6",
    "formatted_formula": "HPF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit hexaflorophosphoric"
  },
  {
    "id": "2310",
    "formula": "PF6-",
    "formatted_formula": "PF<sub>6</sub><sup>-</sup>",
    "vietnamese_name": "Hexaflorophosphat"
  },
  {
    "id": "2311",
    "formula": "(Cr2O7)2-",
    "formatted_formula": "(Cr<sub>2</sub>O<sub>7</sub>)<sup>2-</sup>",
    "vietnamese_name": "Anion dicromat"
  },
  {
    "id": "2312",
    "formula": "XeO4",
    "formatted_formula": "XeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xenon tetraoxit"
  },
  {
    "id": "2313",
    "formula": "H2TeO4",
    "formatted_formula": "H<sub>2</sub>TeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit metatelluric"
  },
  {
    "id": "2314",
    "formula": "Na2H4TeO6",
    "formatted_formula": "Na<sub>2</sub>H<sub>4</sub>TeO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Đinatri tellurat"
  },
  {
    "id": "2315",
    "formula": "Ba2XeO6",
    "formatted_formula": "Ba<sub>2</sub>XeO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Bari perxenat"
  },
  {
    "id": "2316",
    "formula": "Te(OH)6",
    "formatted_formula": "Te(OH)<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit telluric(VI)"
  },
  {
    "id": "2318",
    "formula": "XeO3F2",
    "formatted_formula": "XeO<sub>3</sub>F<sub>2</sub><sup></sup>",
    "vietnamese_name": "Xenon trioxidiflorua"
  },
  {
    "id": "2319",
    "formula": "XeO2F4",
    "formatted_formula": "XeO<sub>2</sub>F<sub>4</sub><sup></sup>",
    "vietnamese_name": "Xenon dioxitetraflorua"
  },
  {
    "id": "2320",
    "formula": "H2XeO4",
    "formatted_formula": "H<sub>2</sub>XeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit xenic"
  },
  {
    "id": "2321",
    "formula": "H6TeO6.4H2O\t",
    "formatted_formula": "H<sub>6</sub>TeO<sub>6</sub>.4H<sub>2</sub>O\t<sup></sup>",
    "vietnamese_name": "Axit telluric hexahidrat"
  },
  {
    "id": "2322",
    "formula": "K2H4TeO6",
    "formatted_formula": "K<sub>2</sub>H<sub>4</sub>TeO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Đikali tellurat"
  },
  {
    "id": "2323",
    "formula": "Na6TeO6",
    "formatted_formula": "Na<sub>6</sub>TeO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Hexanatri tellurat"
  },
  {
    "id": "2325",
    "formula": "HfI4",
    "formatted_formula": "HfI<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hafni(IV) iodua"
  },
  {
    "id": "2326",
    "formula": "Hg(NH3)2Cl2",
    "formatted_formula": "Hg(NH<sub>3</sub>)<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Mercury(II) diamine dichloride"
  },
  {
    "id": "2327",
    "formula": "Na2HgCl4",
    "formatted_formula": "Na<sub>2</sub>HgCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sodium tetrachloromercuriate"
  },
  {
    "id": "2328",
    "formula": "Hg2I2",
    "formatted_formula": "Hg<sub>2</sub>I<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(I) iodua"
  },
  {
    "id": "2329",
    "formula": "K2[HgI4]",
    "formatted_formula": "K<sub>2</sub>[HgI<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Potassium tetraiodomercurate(II)"
  },
  {
    "id": "2330",
    "formula": "NH4I",
    "formatted_formula": "NH<sub>4</sub>I<sup></sup>",
    "vietnamese_name": "Amoni iodua"
  },
  {
    "id": "2331",
    "formula": "HgSO4",
    "formatted_formula": "HgSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) sunfat"
  },
  {
    "id": "2332",
    "formula": "C3N4",
    "formatted_formula": "C<sub>3</sub>N<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dicyanodiazomethan"
  },
  {
    "id": "2334",
    "formula": "HSCN",
    "formatted_formula": "HSCN<sup></sup>",
    "vietnamese_name": "Axit sulfocyanic"
  },
  {
    "id": "2335",
    "formula": "(Hg2N)I",
    "formatted_formula": "(Hg<sub>2</sub>N)I<sup></sup>",
    "vietnamese_name": "Nitridodimercury iodide"
  },
  {
    "id": "2336",
    "formula": "Hg2SeO4",
    "formatted_formula": "Hg<sub>2</sub>SeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(I) Selenat"
  },
  {
    "id": "2337",
    "formula": "HgSeO4",
    "formatted_formula": "HgSeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) Selenat"
  },
  {
    "id": "2339",
    "formula": "H2SnCl6",
    "formatted_formula": "H<sub>2</sub>SnCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit hexaclorostannic"
  },
  {
    "id": "2340",
    "formula": "HgNH2Cl",
    "formatted_formula": "HgNH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Aminochloromercury(II)"
  },
  {
    "id": "2341",
    "formula": "HgSO4.2HgS",
    "formatted_formula": "HgSO<sub>4</sub>.2HgS<sup></sup>",
    "vietnamese_name": "Dithiotrimercuric sulphate"
  },
  {
    "id": "2342",
    "formula": "I2Cl6",
    "formatted_formula": "I<sub>2</sub>Cl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Iot triclorua dime"
  },
  {
    "id": "2343",
    "formula": "HICl2",
    "formatted_formula": "HICl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hidro monoiodua điclorua"
  },
  {
    "id": "2344",
    "formula": "[K(H2O)6]+",
    "formatted_formula": "[K(H<sub>2</sub>O)<sub>6</sub>]<sup>+</sup>",
    "vietnamese_name": "Hexaaquapotassium ion"
  },
  {
    "id": "2345",
    "formula": "In",
    "formatted_formula": "In<sup></sup>",
    "vietnamese_name": "Indi"
  },
  {
    "id": "2346",
    "formula": "InH3",
    "formatted_formula": "InH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi trihidrua"
  },
  {
    "id": "2347",
    "formula": "InClO",
    "formatted_formula": "InClO<sup></sup>",
    "vietnamese_name": "Indi(I) Hypoclorit"
  },
  {
    "id": "2348",
    "formula": "InCl3.4H2O",
    "formatted_formula": "InCl<sub>3</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Indi(III) clorua tetrahidrat"
  },
  {
    "id": "2349",
    "formula": "In(CN)3",
    "formatted_formula": "In(CN)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi(III)tricyanua"
  },
  {
    "id": "2350",
    "formula": "In(NO3)3",
    "formatted_formula": "In(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi(III) Nitrat"
  },
  {
    "id": "2351",
    "formula": "KIO3",
    "formatted_formula": "KIO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali iodat"
  },
  {
    "id": "2352",
    "formula": "NaInO2",
    "formatted_formula": "NaInO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri indat(III)"
  },
  {
    "id": "2353",
    "formula": "In2(SO4)3",
    "formatted_formula": "In<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Indi(III) sunfat"
  },
  {
    "id": "2354",
    "formula": "In2S",
    "formatted_formula": "In<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Điindi sunfua"
  },
  {
    "id": "2355",
    "formula": "InN",
    "formatted_formula": "InN<sup></sup>",
    "vietnamese_name": "Indi nitrua"
  },
  {
    "id": "2356",
    "formula": "R-H",
    "formatted_formula": "R-H<sup></sup>",
    "vietnamese_name": "Ankan"
  },
  {
    "id": "2362",
    "formula": "C2H5OCH3",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl etyl ete"
  },
  {
    "id": "2363",
    "formula": "C3H7Br",
    "formatted_formula": "C<sub>3</sub>H<sub>7</sub>Br<sup></sup>",
    "vietnamese_name": "1-Bromopropan"
  },
  {
    "id": "2364",
    "formula": "C3H6Br2",
    "formatted_formula": "C<sub>3</sub>H<sub>6</sub>Br<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,2-Dibromopropan"
  },
  {
    "id": "2365",
    "formula": "C4H8Br2",
    "formatted_formula": "C<sub>4</sub>H<sub>8</sub>Br<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,2-Dibromobutan"
  },
  {
    "id": "2366",
    "formula": "CH3CH(NH2)COOH",
    "formatted_formula": "CH<sub>3</sub>CH(NH<sub>2</sub>)COOH<sup></sup>",
    "vietnamese_name": "Axit 2-aminopropanoic"
  },
  {
    "id": "2367",
    "formula": "CH3CH(NH2)COONa",
    "formatted_formula": "CH<sub>3</sub>CH(NH<sub>2</sub>)COONa<sup></sup>",
    "vietnamese_name": "Natri 2-aminopropanat"
  },
  {
    "id": "2368",
    "formula": "C4H9Br",
    "formatted_formula": "C<sub>4</sub>H<sub>9</sub>Br<sup></sup>",
    "vietnamese_name": "1-Bromobutan"
  },
  {
    "id": "2369",
    "formula": "C2H5OBr",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OBr<sup></sup>",
    "vietnamese_name": "2-bromoetanol"
  },
  {
    "id": "2370",
    "formula": "H2PtCl6",
    "formatted_formula": "H<sub>2</sub>PtCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit hexacloroplatinic"
  },
  {
    "id": "2371",
    "formula": "H2PtCl4",
    "formatted_formula": "H<sub>2</sub>PtCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dihidro tetracloroplatinat(II)"
  },
  {
    "id": "2372",
    "formula": "MgCrO4",
    "formatted_formula": "MgCrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Magie cromat"
  },
  {
    "id": "2373",
    "formula": "[Mg(H2O)6]2+",
    "formatted_formula": "[Mg(H<sub>2</sub>O)<sub>6</sub>]<sup>2+</sup>",
    "vietnamese_name": "Tetraaquamagnesium(II) ion"
  },
  {
    "id": "2374",
    "formula": "MgSO4.7H2O",
    "formatted_formula": "MgSO<sub>4</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Magie sunfat heptahidrat"
  },
  {
    "id": "2375",
    "formula": "Mg(HSO4)2",
    "formatted_formula": "Mg(HSO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie hidrosunfat"
  },
  {
    "id": "2376",
    "formula": "NaHSO4.H2O",
    "formatted_formula": "NaHSO<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri bisunfat hidrat"
  },
  {
    "id": "2377",
    "formula": "Na(SO3NH2)",
    "formatted_formula": "Na(SO<sub>3</sub>NH<sub>2</sub>)<sup></sup>",
    "vietnamese_name": "Natri sunfamat"
  },
  {
    "id": "2378",
    "formula": "NH2-",
    "formatted_formula": "NH<sub>2</sub><sup>-</sup>",
    "vietnamese_name": "amin"
  },
  {
    "id": "2379",
    "formula": "NaB5O8",
    "formatted_formula": "NaB<sub>5</sub>O<sub>8</sub><sup></sup>",
    "vietnamese_name": "Natri pentaborat"
  },
  {
    "id": "2380",
    "formula": "Na2B4O7.10H2O",
    "formatted_formula": "Na<sub>2</sub>B<sub>4</sub>O<sub>7</sub>.10H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Borac"
  },
  {
    "id": "2381",
    "formula": "Na[B(OH)4]",
    "formatted_formula": "Na[B(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Natri tetrahydroxyborat"
  },
  {
    "id": "2382",
    "formula": "Co(BO2)2",
    "formatted_formula": "Co(BO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Coban(II) borat"
  },
  {
    "id": "2384",
    "formula": "B2H6",
    "formatted_formula": "B<sub>2</sub>H<sub>6</sub><sup></sup>",
    "vietnamese_name": "Diboran"
  },
  {
    "id": "2385",
    "formula": "Na3AsO3",
    "formatted_formula": "Na<sub>3</sub>AsO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri arsenit"
  },
  {
    "id": "2386",
    "formula": "Na3AsS3",
    "formatted_formula": "Na<sub>3</sub>AsS<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri thioarsenit"
  },
  {
    "id": "2387",
    "formula": "(NH4)3AsO3",
    "formatted_formula": "(NH<sub>4</sub>)<sub>3</sub>AsO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni Arsenit"
  },
  {
    "id": "2389",
    "formula": "H2PbCl4",
    "formatted_formula": "H<sub>2</sub>PbCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydrogen tetrachlorolead(II)"
  },
  {
    "id": "2390",
    "formula": "Ba(O3)2",
    "formatted_formula": "Ba(O<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari diozonit"
  },
  {
    "id": "2391",
    "formula": "BaS2O6",
    "formatted_formula": "BaS<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Bari dithionat"
  },
  {
    "id": "2392",
    "formula": "BaO2.8H2O",
    "formatted_formula": "BaO<sub>2</sub>.8H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Bari peroxit octahidrat"
  },
  {
    "id": "2393",
    "formula": "Na2O2.8H2O",
    "formatted_formula": "Na<sub>2</sub>O<sub>2</sub>.8H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri peroxit octahidrat"
  },
  {
    "id": "2394",
    "formula": "(NH4)2S2O7",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>S<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Amoni pyrosunfat"
  },
  {
    "id": "2395",
    "formula": "BaO4",
    "formatted_formula": "BaO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Bari tetraoxit"
  },
  {
    "id": "2396",
    "formula": "NH4HF2",
    "formatted_formula": "NH<sub>4</sub>HF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Amoni Biflorua"
  },
  {
    "id": "2397",
    "formula": "NH4HSO3",
    "formatted_formula": "NH<sub>4</sub>HSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni bisunfit"
  },
  {
    "id": "2398",
    "formula": "SOCl2",
    "formatted_formula": "SOCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thionyl clorua"
  },
  {
    "id": "2399",
    "formula": "SBr2O",
    "formatted_formula": "SBr<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thionyl bromua"
  },
  {
    "id": "2400",
    "formula": "PCl3O",
    "formatted_formula": "PCl<sub>3</sub>O<sup></sup>",
    "vietnamese_name": "Phosphoryl clorua"
  },
  {
    "id": "2401",
    "formula": "Ag3N",
    "formatted_formula": "Ag<sub>3</sub>N<sup></sup>",
    "vietnamese_name": "Bạc nitrua"
  },
  {
    "id": "2402",
    "formula": "NaAsO2",
    "formatted_formula": "NaAsO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri asenit"
  },
  {
    "id": "2403",
    "formula": "Na3AsO4",
    "formatted_formula": "Na<sub>3</sub>AsO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri Asenat"
  },
  {
    "id": "2404",
    "formula": "SnCl2.2H2O",
    "formatted_formula": "SnCl<sub>2</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thiếc(II) clorua dihidrat"
  },
  {
    "id": "2405",
    "formula": "H2Sn",
    "formatted_formula": "H<sub>2</sub>Sn<sup></sup>",
    "vietnamese_name": "Thiếc dihidrua"
  },
  {
    "id": "2406",
    "formula": "KHSO5",
    "formatted_formula": "KHSO<sub>5</sub><sup></sup>",
    "vietnamese_name": "Kali monopersunfat"
  },
  {
    "id": "2407",
    "formula": "PbCrO4",
    "formatted_formula": "PbCrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Chì(II) cromat"
  },
  {
    "id": "2408",
    "formula": "KOCN",
    "formatted_formula": "KOCN<sup></sup>",
    "vietnamese_name": "Kali cyanat"
  },
  {
    "id": "2409",
    "formula": "SnCl4.5H2O",
    "formatted_formula": "SnCl<sub>4</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thiếc(IV) Clorua Pentahidrat"
  },
  {
    "id": "2410",
    "formula": "SnF4",
    "formatted_formula": "SnF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thiếc(IV) florua"
  },
  {
    "id": "2411",
    "formula": "Sn(SO4)2",
    "formatted_formula": "Sn(SO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thiếc(IV) Sunfat"
  },
  {
    "id": "2412",
    "formula": "[Li(H2O)4)]OH",
    "formatted_formula": "[Li(H<sub>2</sub>O)<sub>4</sub>)]OH<sup></sup>",
    "vietnamese_name": "Tetraaqualithium(I) hydroxide"
  },
  {
    "id": "2413",
    "formula": "LiOH.H2O",
    "formatted_formula": "LiOH.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Liti hidroxit monohidrat"
  },
  {
    "id": "2414",
    "formula": "NiCl2.6H2O",
    "formatted_formula": "NiCl<sub>2</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Niken(II) Clorua Hexahidrat"
  },
  {
    "id": "2415",
    "formula": "H2S2O8",
    "formatted_formula": "H<sub>2</sub>S<sub>2</sub>O<sub>8</sub><sup></sup>",
    "vietnamese_name": "Axit peroxydisunfuric"
  },
  {
    "id": "2416",
    "formula": "NaNCS",
    "formatted_formula": "NaNCS<sup></sup>",
    "vietnamese_name": "Natri thiocyanat"
  },
  {
    "id": "2417",
    "formula": "NaBF4",
    "formatted_formula": "NaBF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri boroflorua"
  },
  {
    "id": "2418",
    "formula": "C3H5(COOH)3",
    "formatted_formula": "C<sub>3</sub>H<sub>5</sub>(COOH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit tricarballylic"
  },
  {
    "id": "2419",
    "formula": "C4H5Ag",
    "formatted_formula": "C<sub>4</sub>H<sub>5</sub>Ag<sup></sup>",
    "vietnamese_name": "Bạc(I) butynua"
  },
  {
    "id": "2420",
    "formula": "Na2BeF4",
    "formatted_formula": "Na<sub>2</sub>BeF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri beri tetraflorua"
  },
  {
    "id": "2421",
    "formula": "NaF.nHF",
    "formatted_formula": "NaF.nHF<sup></sup>",
    "vietnamese_name": "Natri hidro florua"
  },
  {
    "id": "2422",
    "formula": "S4N4",
    "formatted_formula": "S<sub>4</sub>N<sub>4</sub><sup></sup>",
    "vietnamese_name": "Tetralưu huỳnh tetranitrua"
  },
  {
    "id": "2423",
    "formula": "KC8",
    "formatted_formula": "KC<sub>8</sub><sup></sup>",
    "vietnamese_name": "Kali grafit"
  },
  {
    "id": "2424",
    "formula": "Ni(CN)2",
    "formatted_formula": "Ni(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Niken(II) cyanua"
  },
  {
    "id": "2425",
    "formula": "K3[Ni(CN)5]",
    "formatted_formula": "K<sub>3</sub>[Ni(CN)<sub>5</sub>]<sup></sup>",
    "vietnamese_name": "Potassium pentacyanidonickelate(II)"
  },
  {
    "id": "2426",
    "formula": "BiF5",
    "formatted_formula": "BiF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Bitmut(V) florua"
  },
  {
    "id": "2427",
    "formula": "S8",
    "formatted_formula": "S<sub>8</sub><sup></sup>",
    "vietnamese_name": "Anpha-lưu huỳnh"
  },
  {
    "id": "2428",
    "formula": "H4V2O7",
    "formatted_formula": "H<sub>4</sub>V<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Axit pyrovanadic"
  },
  {
    "id": "2429",
    "formula": "VCl3O",
    "formatted_formula": "VCl<sub>3</sub>O<sup></sup>",
    "vietnamese_name": "Vanadi triclorua oxit"
  },
  {
    "id": "2430",
    "formula": "VO2Cl",
    "formatted_formula": "VO<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Vanadi(V) clorua dioxit"
  },
  {
    "id": "2431",
    "formula": "VO2",
    "formatted_formula": "VO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Vanadi(IV) oxit"
  },
  {
    "id": "2432",
    "formula": "V2O3",
    "formatted_formula": "V<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Vanadi(III) oxit"
  },
  {
    "id": "2433",
    "formula": "SnS",
    "formatted_formula": "SnS<sup></sup>",
    "vietnamese_name": "Thiếc(II) sunfua"
  },
  {
    "id": "2434",
    "formula": "V",
    "formatted_formula": "V<sup></sup>",
    "vietnamese_name": "Vanadi"
  },
  {
    "id": "2435",
    "formula": "NH4VO3",
    "formatted_formula": "NH<sub>4</sub>VO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni metavanadat"
  },
  {
    "id": "2436",
    "formula": "NaVO3",
    "formatted_formula": "NaVO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri metavanadat"
  },
  {
    "id": "2437",
    "formula": "VO2NO3",
    "formatted_formula": "VO<sub>2</sub>NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Vanadyl nitrat"
  },
  {
    "id": "2438",
    "formula": "Al(BH4)3",
    "formatted_formula": "Al(BH<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm borohydrua"
  },
  {
    "id": "2439",
    "formula": "[BH4]-",
    "formatted_formula": "[BH<sub>4</sub>]<sup>-</sup>",
    "vietnamese_name": "Ion tetrahydroborat"
  },
  {
    "id": "2440",
    "formula": "Na2Hg",
    "formatted_formula": "Na<sub>2</sub>Hg<sup></sup>",
    "vietnamese_name": "Hỗn hống natri"
  },
  {
    "id": "2441",
    "formula": "NaB3H8",
    "formatted_formula": "NaB<sub>3</sub>H<sub>8</sub><sup></sup>",
    "vietnamese_name": "Natri octahidrotriborat"
  },
  {
    "id": "2442",
    "formula": "SrO",
    "formatted_formula": "SrO<sup></sup>",
    "vietnamese_name": "Stronti oxit"
  },
  {
    "id": "2443",
    "formula": "Sr(HCO3)2",
    "formatted_formula": "Sr(HCO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Stronti bicacbonat"
  },
  {
    "id": "2444",
    "formula": "SrSO4",
    "formatted_formula": "SrSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Stronti sunfat"
  },
  {
    "id": "2445",
    "formula": "SrS",
    "formatted_formula": "SrS<sup></sup>",
    "vietnamese_name": "Stronti sunfua"
  },
  {
    "id": "2446",
    "formula": "Sr(OH)2",
    "formatted_formula": "Sr(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Stronti hidroxit"
  },
  {
    "id": "2447",
    "formula": "SrCl2",
    "formatted_formula": "SrCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Stronti clorua"
  },
  {
    "id": "2448",
    "formula": "Sr(NO3)2",
    "formatted_formula": "Sr(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Stronti nitrat"
  },
  {
    "id": "2449",
    "formula": "(NH4)2SiF6",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>SiF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Amoni hexaflorosilicat"
  },
  {
    "id": "2452",
    "formula": "Sb2O4",
    "formatted_formula": "Sb<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Antimon tetroxit"
  },
  {
    "id": "2454",
    "formula": "SbH3",
    "formatted_formula": "SbH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Antimon trihidrua"
  },
  {
    "id": "2455",
    "formula": "Na[Sb(OH)4]",
    "formatted_formula": "Na[Sb(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium tetrahydroxoantimonate(III)"
  },
  {
    "id": "2456",
    "formula": "Sb2O5.nH2O",
    "formatted_formula": "Sb<sub>2</sub>O<sub>5</sub>.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Antimon pentoxit hidrat"
  },
  {
    "id": "2457",
    "formula": "Sb2O5.5H2O",
    "formatted_formula": "Sb<sub>2</sub>O<sub>5</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Antimon pentoxit pentahidrat"
  },
  {
    "id": "2458",
    "formula": "NaSbO3",
    "formatted_formula": "NaSbO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri Antimonat"
  },
  {
    "id": "2459",
    "formula": "Na[Sb(OH)6]",
    "formatted_formula": "Na[Sb(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Sodium hexahydroxoantimonate(V)"
  },
  {
    "id": "2460",
    "formula": "SbOF3",
    "formatted_formula": "SbOF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Antimon(V) triflorua oxit"
  },
  {
    "id": "2461",
    "formula": "SbOF",
    "formatted_formula": "SbOF<sup></sup>",
    "vietnamese_name": "Antimon(III) florua oxit"
  },
  {
    "id": "2462",
    "formula": "HSbF6",
    "formatted_formula": "HSbF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit floroantimonic"
  },
  {
    "id": "2463",
    "formula": "AsCl3",
    "formatted_formula": "AsCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Asen triclorua"
  },
  {
    "id": "2465",
    "formula": "As(OH)3",
    "formatted_formula": "As(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Arsenous acid"
  },
  {
    "id": "2467",
    "formula": "K3[Fe(CN)6]",
    "formatted_formula": "K<sub>3</sub>[Fe(CN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Kali ferricyanua"
  },
  {
    "id": "2468",
    "formula": "Fe3O4",
    "formatted_formula": "Fe<sub>3</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sắt(II,III) oxit"
  },
  {
    "id": "2469",
    "formula": "HBF4",
    "formatted_formula": "HBF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit floroboric"
  },
  {
    "id": "2470",
    "formula": "B4H10",
    "formatted_formula": "B<sub>4</sub>H<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Borobutan"
  },
  {
    "id": "2471",
    "formula": "SbOCl",
    "formatted_formula": "SbOCl<sup></sup>",
    "vietnamese_name": "Antimon clorua oxit"
  },
  {
    "id": "2472",
    "formula": "LiBH4",
    "formatted_formula": "LiBH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti borohidrua"
  },
  {
    "id": "2473",
    "formula": "Na2S2O4.2H2O",
    "formatted_formula": "Na<sub>2</sub>S<sub>2</sub>O<sub>4</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri Dithionit Dihidrat"
  },
  {
    "id": "2474",
    "formula": "AuCl",
    "formatted_formula": "AuCl<sup></sup>",
    "vietnamese_name": "Vàng(I) clorua"
  },
  {
    "id": "2475",
    "formula": "AuCl3.2H2O",
    "formatted_formula": "AuCl<sub>3</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Vàng(III) clorua dihidrat"
  },
  {
    "id": "2476",
    "formula": "HAuCl4.4H2O",
    "formatted_formula": "HAuCl<sub>4</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit tetracloroauric(III) tetrahidrate"
  },
  {
    "id": "2477",
    "formula": "Au2S3",
    "formatted_formula": "Au<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Vàng(III) sunfua"
  },
  {
    "id": "2478",
    "formula": "HBrO4",
    "formatted_formula": "HBrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit perbromic"
  },
  {
    "id": "2479",
    "formula": "BrF5",
    "formatted_formula": "BrF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Brom pentaflorua"
  },
  {
    "id": "2480",
    "formula": "NH4BrO3",
    "formatted_formula": "NH<sub>4</sub>BrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni perbromat"
  },
  {
    "id": "2481",
    "formula": "CaHPO4.2H2O",
    "formatted_formula": "CaHPO<sub>4</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Canxi hidro photphat dihidrat"
  },
  {
    "id": "2482",
    "formula": "Ca2P2O7",
    "formatted_formula": "Ca<sub>2</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Canxi diphotphat"
  },
  {
    "id": "2483",
    "formula": "NbCl5",
    "formatted_formula": "NbCl<sub>5</sub><sup></sup>",
    "vietnamese_name": "Niobi(V) clorua"
  },
  {
    "id": "2484",
    "formula": "[PCl4][NbCl4]",
    "formatted_formula": "[PCl<sub>4</sub>][NbCl<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Tetraclorophotphonium-tetracloroniobat"
  },
  {
    "id": "2485",
    "formula": "[PCl4][NbCl6]",
    "formatted_formula": "[PCl<sub>4</sub>][NbCl<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Tetraclorophotphonium-hexacloroniobat"
  },
  {
    "id": "2486",
    "formula": "Na2[Cr(CO)5]",
    "formatted_formula": "Na<sub>2</sub>[Cr(CO)<sub>5</sub>]<sup></sup>",
    "vietnamese_name": "Natri pentacacbonylcromat"
  },
  {
    "id": "2487",
    "formula": "Cu2[Fe(CN)6]",
    "formatted_formula": "Cu<sub>2</sub>[Fe(CN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Copper ferrocyanide"
  },
  {
    "id": "2488",
    "formula": "H4[Fe(CN)6]",
    "formatted_formula": "H<sub>4</sub>[Fe(CN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Hexacyanoferrous acid"
  },
  {
    "id": "2489",
    "formula": "[Cu(NH3)2]2SO4",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>2</sub>]<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Diamminecopper(II) sulfate"
  },
  {
    "id": "2491",
    "formula": "[Cu(NH3)4]SO4.H2O",
    "formatted_formula": "[Cu(NH<sub>3</sub>)<sub>4</sub>]SO<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Tetraamminecopper(II) sulfate monohydrate"
  },
  {
    "id": "2492",
    "formula": "Ag4[Fe(CN)6]",
    "formatted_formula": "Ag<sub>4</sub>[Fe(CN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Silver Ferrocyanide"
  },
  {
    "id": "2493",
    "formula": "FeCuS2",
    "formatted_formula": "FeCuS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chalcopyrit"
  },
  {
    "id": "2494",
    "formula": "H2SiO3",
    "formatted_formula": "H<sub>2</sub>SiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit metasilicic"
  },
  {
    "id": "2495",
    "formula": "BeSO4.4H2O",
    "formatted_formula": "BeSO<sub>4</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Beri sunfat tetrahidrat"
  },
  {
    "id": "2496",
    "formula": "Li2SO4",
    "formatted_formula": "Li<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti sunfat"
  },
  {
    "id": "2497",
    "formula": "[Li(H2O)4]+",
    "formatted_formula": "[Li(H<sub>2</sub>O)<sub>4</sub>]<sup>+</sup>",
    "vietnamese_name": "Tetraaqualithium(I) ion"
  },
  {
    "id": "2499",
    "formula": "Be2SO4(OH)2",
    "formatted_formula": "Be<sub>2</sub>SO<sub>4</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diberi(II) sunfat dihidroxit"
  },
  {
    "id": "2500",
    "formula": "NaPO3",
    "formatted_formula": "NaPO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri metaphotphat"
  },
  {
    "id": "2501",
    "formula": "NaH2PO4.2H2O\t",
    "formatted_formula": "NaH<sub>2</sub>PO<sub>4</sub>.2H<sub>2</sub>O\t<sup></sup>",
    "vietnamese_name": "Natri dihidrophotphat dihidrat"
  },
  {
    "id": "2502",
    "formula": "Pt2Cl6",
    "formatted_formula": "Pt<sub>2</sub>Cl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Diplatin(II, IV) hexaclorua"
  },
  {
    "id": "2503",
    "formula": "BiI3",
    "formatted_formula": "BiI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut(III) iodua"
  },
  {
    "id": "2505",
    "formula": "BiBr3",
    "formatted_formula": "BiBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bitmut tribromua"
  },
  {
    "id": "2506",
    "formula": "BiOF",
    "formatted_formula": "BiOF<sup></sup>",
    "vietnamese_name": "Florobitmut oxit"
  },
  {
    "id": "2507",
    "formula": "NaBiO3",
    "formatted_formula": "NaBiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri bismutat"
  },
  {
    "id": "2508",
    "formula": "Ba(ClO3)2.H2O",
    "formatted_formula": "Ba(ClO<sub>3</sub>)<sub>2</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Bari clorat monohidrat"
  },
  {
    "id": "2510",
    "formula": "[Ba(H2O)8]2+",
    "formatted_formula": "[Ba(H<sub>2</sub>O)<sub>8</sub>]<sup>2+</sup>",
    "vietnamese_name": "Octaaquabarium ion"
  },
  {
    "id": "2511",
    "formula": "Bi2O4",
    "formatted_formula": "Bi<sub>2</sub>O<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dibitmut(III, V) teroxit"
  },
  {
    "id": "2512",
    "formula": "Ba(ClO4)2",
    "formatted_formula": "Ba(ClO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari Perclorat"
  },
  {
    "id": "2513",
    "formula": "MgBr2",
    "formatted_formula": "MgBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magie dibromua"
  },
  {
    "id": "2514",
    "formula": "RbOH.H2O",
    "formatted_formula": "RbOH.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Rubidi hidroxit monohidrat"
  },
  {
    "id": "2515",
    "formula": "RbOH.2H2O",
    "formatted_formula": "RbOH.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Rubidi hidroxit dihidrat"
  },
  {
    "id": "2516",
    "formula": "RbHO2",
    "formatted_formula": "RbHO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Rubidi hidroxit oxit"
  },
  {
    "id": "2517",
    "formula": "RbNH2",
    "formatted_formula": "RbNH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Rubidi Amit"
  },
  {
    "id": "2518",
    "formula": "RbHS",
    "formatted_formula": "RbHS<sup></sup>",
    "vietnamese_name": "Rubidi hidrosunfua"
  },
  {
    "id": "2519",
    "formula": "Rb2SO4",
    "formatted_formula": "Rb<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Rubidi sunfat"
  },
  {
    "id": "2520",
    "formula": "Rb2S.4H2O",
    "formatted_formula": "Rb<sub>2</sub>S.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Rubidi sunfua tetrahidrat"
  },
  {
    "id": "2521",
    "formula": "P4S10",
    "formatted_formula": "P<sub>4</sub>S<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Tetraphotpho decasunfua"
  },
  {
    "id": "2522",
    "formula": "[Zn(NH3)4]SO4\t",
    "formatted_formula": "[Zn(NH<sub>3</sub>)<sub>4</sub>]SO<sub>4</sub>\t<sup></sup>",
    "vietnamese_name": "Tetraamminezinc sulfate"
  },
  {
    "id": "2523",
    "formula": "RbHSO4",
    "formatted_formula": "RbHSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Rubidi hidrosunfat"
  },
  {
    "id": "2524",
    "formula": "Rb2S2O3",
    "formatted_formula": "Rb<sub>2</sub>S<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rubidi Thiosunfat"
  },
  {
    "id": "2525",
    "formula": "[Rb(H2O)6]+",
    "formatted_formula": "[Rb(H<sub>2</sub>O)<sub>6</sub>]<sup>+</sup>",
    "vietnamese_name": "Hexaaquarubidium(I) ion"
  },
  {
    "id": "2526",
    "formula": "Na3PO2S2",
    "formatted_formula": "Na<sub>3</sub>PO<sub>2</sub>S<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri dithiophotphat"
  },
  {
    "id": "2527",
    "formula": "Na3POS3",
    "formatted_formula": "Na<sub>3</sub>POS<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri trithiophotphat"
  },
  {
    "id": "2529",
    "formula": "Ba3XeO6",
    "formatted_formula": "Ba<sub>3</sub>XeO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Bari xenonat"
  },
  {
    "id": "2530",
    "formula": "S2F2",
    "formatted_formula": "S<sub>2</sub>F<sub>2</sub><sup></sup>",
    "vietnamese_name": "Lưu huỳnh(I) diflorua"
  },
  {
    "id": "2531",
    "formula": "SOF4",
    "formatted_formula": "SOF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thionyl tetraflorua"
  },
  {
    "id": "2532",
    "formula": "Zn3As2",
    "formatted_formula": "Zn<sub>3</sub>As<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kẽm Asenua"
  },
  {
    "id": "2533",
    "formula": "AsI3",
    "formatted_formula": "AsI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Asen triiodua"
  },
  {
    "id": "2534",
    "formula": "Hg3As2",
    "formatted_formula": "Hg<sub>3</sub>As<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(II) Asenua"
  },
  {
    "id": "2535",
    "formula": "Br3N.6NH3",
    "formatted_formula": "Br<sub>3</sub>N.6NH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nitơ tribromua. Hexaamoniac"
  },
  {
    "id": "2536",
    "formula": "NH4+",
    "formatted_formula": "NH<sub>4</sub><sup>+</sup>",
    "vietnamese_name": "Ion amoni"
  },
  {
    "id": "2537",
    "formula": "Pr6O11",
    "formatted_formula": "Pr<sub>6</sub>O<sub>1</sub><sub>1</sub><sup></sup>",
    "vietnamese_name": "Praseodymi(III,IV) Oxit"
  },
  {
    "id": "2538",
    "formula": "PrO2",
    "formatted_formula": "PrO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Praseodymi(IV) Oxit"
  },
  {
    "id": "2539",
    "formula": "NaClO3.3H2O",
    "formatted_formula": "NaClO<sub>3</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri Clorat trihidrat"
  },
  {
    "id": "2540",
    "formula": "Pr",
    "formatted_formula": "Pr<sup></sup>",
    "vietnamese_name": "Praseodymi"
  },
  {
    "id": "2541",
    "formula": "PrF3",
    "formatted_formula": "PrF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Praseodymi florua"
  },
  {
    "id": "2542",
    "formula": "PrI3",
    "formatted_formula": "PrI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Praseodymi iodua"
  },
  {
    "id": "2543",
    "formula": "PrBr3",
    "formatted_formula": "PrBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Praseodymi tribromua"
  },
  {
    "id": "2544",
    "formula": "Si2H6",
    "formatted_formula": "Si<sub>2</sub>H<sub>6</sub><sup></sup>",
    "vietnamese_name": "Disilan"
  },
  {
    "id": "2545",
    "formula": "Ca3SiO5",
    "formatted_formula": "Ca<sub>3</sub>SiO<sub>5</sub><sup></sup>",
    "vietnamese_name": "Tricanxi silicat"
  },
  {
    "id": "2547",
    "formula": "H2Cr3O10",
    "formatted_formula": "H<sub>2</sub>Cr<sub>3</sub>O<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Axit tricromic"
  },
  {
    "id": "2548",
    "formula": "BrO3-",
    "formatted_formula": "BrO<sub>3</sub><sup>-</sup>",
    "vietnamese_name": "Bromat"
  },
  {
    "id": "2549",
    "formula": "Ba(BrO3)2",
    "formatted_formula": "Ba(BrO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari Bromat"
  },
  {
    "id": "2550",
    "formula": "N3-",
    "formatted_formula": "N<sub>3</sub><sup>-</sup>",
    "vietnamese_name": "Ion azua"
  },
  {
    "id": "2551",
    "formula": "LiAlF4",
    "formatted_formula": "LiAlF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti floroaluminat"
  },
  {
    "id": "2553",
    "formula": "LiClO4",
    "formatted_formula": "LiClO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti perclorat"
  },
  {
    "id": "2554",
    "formula": "LiCl.H2O",
    "formatted_formula": "LiCl.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Liti clorua monohidrat"
  },
  {
    "id": "2555",
    "formula": "LiClO3",
    "formatted_formula": "LiClO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Liti clorat"
  },
  {
    "id": "2556",
    "formula": "Na2[Zn(OH)4].2H2O",
    "formatted_formula": "Na<sub>2</sub>[Zn(OH)<sub>4</sub>].2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri zincat dihidrat"
  },
  {
    "id": "2557",
    "formula": "SiS2",
    "formatted_formula": "SiS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Silicon disunfua"
  },
  {
    "id": "2558",
    "formula": "OsS2",
    "formatted_formula": "OsS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Osmi disunfua"
  },
  {
    "id": "2559",
    "formula": "PbCl4",
    "formatted_formula": "PbCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Chì tetraclorua"
  },
  {
    "id": "2560",
    "formula": "PbClOH",
    "formatted_formula": "PbClOH<sup></sup>",
    "vietnamese_name": "Chì(II) clorua hidroxit"
  },
  {
    "id": "2562",
    "formula": "CfO2",
    "formatted_formula": "CfO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Californi(IV) oxit"
  },
  {
    "id": "2563",
    "formula": "Cf2O3",
    "formatted_formula": "Cf<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Californi(III) oxit"
  },
  {
    "id": "2564",
    "formula": "Cf(OH)3",
    "formatted_formula": "Cf(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Californi(III) hidroxit"
  },
  {
    "id": "2565",
    "formula": "Cf(NO3)3",
    "formatted_formula": "Cf(NO<sub>3</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Californi(III) nitrat"
  },
  {
    "id": "2566",
    "formula": "CfBr2",
    "formatted_formula": "CfBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Californi(II) bromua"
  },
  {
    "id": "2567",
    "formula": "RhF6",
    "formatted_formula": "RhF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Rhodi hexaflorua"
  },
  {
    "id": "2568",
    "formula": "RhF5",
    "formatted_formula": "RhF<sub>5</sub><sup></sup>",
    "vietnamese_name": "Rhodi pentaflorua"
  },
  {
    "id": "2569",
    "formula": "Rh2O3",
    "formatted_formula": "Rh<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rhodi(III) oxit"
  },
  {
    "id": "2570",
    "formula": "Cf(NO3)4",
    "formatted_formula": "Cf(NO<sub>3</sub>)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Californi(IV) nitrat"
  },
  {
    "id": "2571",
    "formula": "Na3RhCl6",
    "formatted_formula": "Na<sub>3</sub>RhCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri hexaclororhodat(III)"
  },
  {
    "id": "2572",
    "formula": "TlOH",
    "formatted_formula": "TlOH<sup></sup>",
    "vietnamese_name": "Thali(I) hidroxit"
  },
  {
    "id": "2573",
    "formula": "Zn2P2O7",
    "formatted_formula": "Zn<sub>2</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Kẽm pyrophotphat"
  },
  {
    "id": "2574",
    "formula": "NaAlSiO4",
    "formatted_formula": "NaAlSiO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri nhôm silicat"
  },
  {
    "id": "2575",
    "formula": "AlAlO[SiO4]",
    "formatted_formula": "AlAlO[SiO<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Kyanite"
  },
  {
    "id": "2577",
    "formula": "[AlF6]3-",
    "formatted_formula": "[AlF<sub>6</sub>]<sup>3-</sup>",
    "vietnamese_name": "Hexafluoroaluminate ion"
  },
  {
    "id": "2578",
    "formula": "LiPO3",
    "formatted_formula": "LiPO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Liti metaphotphat"
  },
  {
    "id": "2579",
    "formula": "Cl-",
    "formatted_formula": "Cl<sup>-</sup>",
    "vietnamese_name": "Ion clorua"
  },
  {
    "id": "2580",
    "formula": "Rb2O2",
    "formatted_formula": "Rb<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Rubidi peroxit"
  },
  {
    "id": "2581",
    "formula": "H2SO2",
    "formatted_formula": "H<sub>2</sub>SO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit hyposunfurơ"
  },
  {
    "id": "2582",
    "formula": "K2S5O6",
    "formatted_formula": "K<sub>2</sub>S<sub>5</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali pentathionat"
  },
  {
    "id": "2583",
    "formula": "FeSi2",
    "formatted_formula": "FeSi<sub>2</sub><sup></sup>",
    "vietnamese_name": "Iron disilicon"
  },
  {
    "id": "2584",
    "formula": "P4O8",
    "formatted_formula": "P<sub>4</sub>O<sub>8</sub><sup></sup>",
    "vietnamese_name": "Photpho dioxit"
  },
  {
    "id": "2585",
    "formula": "P4S3",
    "formatted_formula": "P<sub>4</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Tetraphotpho trisunfua"
  },
  {
    "id": "2586",
    "formula": "KO3",
    "formatted_formula": "KO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Postassium ozonide"
  },
  {
    "id": "2588",
    "formula": "NaBrO4",
    "formatted_formula": "NaBrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri Perbromat"
  },
  {
    "id": "2589",
    "formula": "B3H6N3",
    "formatted_formula": "B<sub>3</sub>H<sub>6</sub>N<sub>3</sub><sup></sup>",
    "vietnamese_name": "Borazine"
  },
  {
    "id": "2590",
    "formula": "NH4H2PO4",
    "formatted_formula": "NH<sub>4</sub>H<sub>2</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni dihidrophotphat"
  },
  {
    "id": "2591",
    "formula": "(NH4)3H2P3O10",
    "formatted_formula": "(NH<sub>4</sub>)<sub>3</sub>H<sub>2</sub>P<sub>3</sub>O<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Amoni triphotphat"
  },
  {
    "id": "2592",
    "formula": "NH4PO3",
    "formatted_formula": "NH<sub>4</sub>PO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni metaphotphat"
  },
  {
    "id": "2593",
    "formula": "KPO3",
    "formatted_formula": "KPO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali metaphotphat"
  },
  {
    "id": "2594",
    "formula": "KH2PO4",
    "formatted_formula": "KH<sub>2</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali dihidro photphat"
  },
  {
    "id": "2595",
    "formula": "Hf(NO3)4",
    "formatted_formula": "Hf(NO<sub>3</sub>)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hafni(IV) nitrat"
  },
  {
    "id": "2596",
    "formula": "[Ag(CN)2]-",
    "formatted_formula": "[Ag(CN)<sub>2</sub>]<sup>-</sup>",
    "vietnamese_name": "Dicyanosilver(I) ion"
  },
  {
    "id": "2597",
    "formula": "KAu(CN)2",
    "formatted_formula": "KAu(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Potassium dicyanoaurate(I)"
  },
  {
    "id": "2598",
    "formula": "K2[Zn(CN)4]",
    "formatted_formula": "K<sub>2</sub>[Zn(CN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Potassium hexacyanozincate(II)"
  },
  {
    "id": "2599",
    "formula": "SeCl2O",
    "formatted_formula": "SeCl<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Selenyl diclorua"
  },
  {
    "id": "2600",
    "formula": "SrCrO4",
    "formatted_formula": "SrCrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Stronti cromat"
  },
  {
    "id": "2601",
    "formula": "SeO",
    "formatted_formula": "SeO<sup></sup>",
    "vietnamese_name": "Selen oxit"
  },
  {
    "id": "2602",
    "formula": "BeCO3.4H2O",
    "formatted_formula": "BeCO<sub>3</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Beri cacbonat tetrahidrat"
  },
  {
    "id": "2603",
    "formula": "HBr.H2O",
    "formatted_formula": "HBr.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit hidrobromic hidrat"
  },
  {
    "id": "2604",
    "formula": "HOCN",
    "formatted_formula": "HOCN<sup></sup>",
    "vietnamese_name": "Axit cyanuric"
  },
  {
    "id": "2605",
    "formula": "LiNO3.3H2O",
    "formatted_formula": "LiNO<sub>3</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Liti Nitrat Trihidrat"
  },
  {
    "id": "2606",
    "formula": "NaCN.2H2O",
    "formatted_formula": "NaCN.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri cyanua dihidrat"
  },
  {
    "id": "2607",
    "formula": "NaOCN",
    "formatted_formula": "NaOCN<sup></sup>",
    "vietnamese_name": "Natri cyanat"
  },
  {
    "id": "2608",
    "formula": "NaAg(CN)2",
    "formatted_formula": "NaAg(CN)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sodium argentocyanide"
  },
  {
    "id": "2609",
    "formula": "KAl(SO4)2",
    "formatted_formula": "KAl(SO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali alum"
  },
  {
    "id": "2610",
    "formula": "AlCl3.6H2O",
    "formatted_formula": "AlCl<sub>3</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nhôm clorua Hexahidrat"
  },
  {
    "id": "2611",
    "formula": "BrF3",
    "formatted_formula": "BrF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Brom triflorua"
  },
  {
    "id": "2612",
    "formula": "Ba3N2",
    "formatted_formula": "Ba<sub>3</sub>N<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari nitrua"
  },
  {
    "id": "2613",
    "formula": "Au(OH)3",
    "formatted_formula": "Au(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Vàng(III) hidroxit"
  },
  {
    "id": "2614",
    "formula": "K[Pt(C2H4)Cl3].H2O",
    "formatted_formula": "K[Pt(C<sub>2</sub>H<sub>4</sub>)Cl<sub>3</sub>].H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Zeise's salt monohydrate"
  },
  {
    "id": "2615",
    "formula": "[Pt(C2H4)Cl3]-",
    "formatted_formula": "[Pt(C<sub>2</sub>H<sub>4</sub>)Cl<sub>3</sub>]<sup>-</sup>",
    "vietnamese_name": "Trichloro(ethylene)platinate(II) ion"
  },
  {
    "id": "2616",
    "formula": "PtS",
    "formatted_formula": "PtS<sup></sup>",
    "vietnamese_name": "Platin(II) sunfua"
  },
  {
    "id": "2617",
    "formula": "[Pt(NH3)4][PtCl4]",
    "formatted_formula": "[Pt(NH<sub>3</sub>)<sub>4</sub>][PtCl<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Tetraaminplatin(II) tetracloroplatinat(II)"
  },
  {
    "id": "2618",
    "formula": "Pt(NH3)2Cl2",
    "formatted_formula": "Pt(NH<sub>3</sub>)<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Diamindicloridoplatin(II)"
  },
  {
    "id": "2619",
    "formula": "trans-[Pt(NH3)2Cl2]",
    "formatted_formula": "trans-[Pt(NH<sub>3</sub>)<sub>2</sub>Cl<sub>2</sub>]<sup></sup>",
    "vietnamese_name": "Trans-Diamindicloridoplatin(II)"
  },
  {
    "id": "2620",
    "formula": "K2Pt(NO2)4",
    "formatted_formula": "K<sub>2</sub>Pt(NO<sub>2</sub>)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali tetranitroplatinat(II)"
  },
  {
    "id": "2621",
    "formula": "PtO2",
    "formatted_formula": "PtO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Platin Oxit"
  },
  {
    "id": "2622",
    "formula": "[Pt(NH3)6]Cl4",
    "formatted_formula": "[Pt(NH<sub>3</sub>)<sub>6</sub>]Cl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hexaminplatin(IV) Clorua"
  },
  {
    "id": "2623",
    "formula": "[Pt(NH3)4]Cl2.H2O",
    "formatted_formula": "[Pt(NH<sub>3</sub>)<sub>4</sub>]Cl<sub>2</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Tetraaminplatin(II) clorua hidrat"
  },
  {
    "id": "2624",
    "formula": "BaPtCl4",
    "formatted_formula": "BaPtCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Bari tetracloroplatinat"
  },
  {
    "id": "2625",
    "formula": "Li(C2H5O)",
    "formatted_formula": "Li(C<sub>2</sub>H<sub>5</sub>O)<sup></sup>",
    "vietnamese_name": "Etoxit liti "
  },
  {
    "id": "2626",
    "formula": "Pd(NO3)2",
    "formatted_formula": "Pd(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Paladi(II) nitrat"
  },
  {
    "id": "2627",
    "formula": "[Pd(H2O)4]2+",
    "formatted_formula": "[Pd(H<sub>2</sub>O)<sub>4</sub>]<sup>2+</sup>",
    "vietnamese_name": "Tetraaquapalladium(II) ion"
  },
  {
    "id": "2628",
    "formula": "(NH4)2[BeF4]",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>[BeF<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Amoni tetrafloroberilat(II)"
  },
  {
    "id": "2629",
    "formula": "NH4BeF3",
    "formatted_formula": "NH<sub>4</sub>BeF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Amoni trifloroberilat(II)"
  },
  {
    "id": "2630",
    "formula": "RbPF6",
    "formatted_formula": "RbPF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Rubidi hexaflorophotphat"
  },
  {
    "id": "2631",
    "formula": "KPF6",
    "formatted_formula": "KPF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali hexaflorophotphat"
  },
  {
    "id": "2632",
    "formula": "NH4SO3F",
    "formatted_formula": "NH<sub>4</sub>SO<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Amoni Florosunfonat"
  },
  {
    "id": "2633",
    "formula": "UOF2.H2O",
    "formatted_formula": "UOF<sub>2</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Uran(IV) diflorua oxit monohidrat"
  },
  {
    "id": "2634",
    "formula": "LiHCO3",
    "formatted_formula": "LiHCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Liti hidro cacbonat"
  },
  {
    "id": "2635",
    "formula": "LiAlO2",
    "formatted_formula": "LiAlO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Liti metaaluminat"
  },
  {
    "id": "2636",
    "formula": "Hg2(NO3)2.2H2O",
    "formatted_formula": "Hg<sub>2</sub>(NO<sub>3</sub>)<sub>2</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thủy ngân(I) nitrat dihidrat"
  },
  {
    "id": "2637",
    "formula": "Hg2NO3OH",
    "formatted_formula": "Hg<sub>2</sub>NO<sub>3</sub>OH<sup></sup>",
    "vietnamese_name": "Thủy ngân(I) nitrat hidroxit"
  },
  {
    "id": "2638",
    "formula": "Hg2CrO4",
    "formatted_formula": "Hg<sub>2</sub>CrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thủy ngân(I) Cromat"
  },
  {
    "id": "2639",
    "formula": "Cu2SO4(OH)2",
    "formatted_formula": "Cu<sub>2</sub>SO<sub>4</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) hidroxit sunfat"
  },
  {
    "id": "2640",
    "formula": "Na2Cu(OH)4",
    "formatted_formula": "Na<sub>2</sub>Cu(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Disodium tetrahydroxidecuprate(II)"
  },
  {
    "id": "2641",
    "formula": "Na4FeO3",
    "formatted_formula": "Na<sub>4</sub>FeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Tetrasodium Oxoferrat(II)"
  },
  {
    "id": "2642",
    "formula": "FeHPO4",
    "formatted_formula": "FeHPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) hidro photphat"
  },
  {
    "id": "2643",
    "formula": "(HCOO)2Mg",
    "formatted_formula": "(HCOO)<sub>2</sub>Mg<sup></sup>",
    "vietnamese_name": "Magie format"
  },
  {
    "id": "2644",
    "formula": "(NH4)2PtCl6",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>PtCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Amoni hexacloroplatinat"
  },
  {
    "id": "2645",
    "formula": "(NH4)3VS4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>3</sub>VS<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni Ortothiovanadat"
  },
  {
    "id": "2646",
    "formula": "Na2S2O6",
    "formatted_formula": "Na<sub>2</sub>S<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri dithionat"
  },
  {
    "id": "2647",
    "formula": "U(SO4)2",
    "formatted_formula": "U(SO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Urani sunfat"
  },
  {
    "id": "2648",
    "formula": "UO2(OH)2",
    "formatted_formula": "UO<sub>2</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Uranyl dihidroxit"
  },
  {
    "id": "2649",
    "formula": "VSO4",
    "formatted_formula": "VSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Vanadi(II) Sunfat"
  },
  {
    "id": "2650",
    "formula": "(VO)SO4",
    "formatted_formula": "(VO)SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Vanadyl sunfat"
  },
  {
    "id": "2651",
    "formula": "(NH4)4P2O7",
    "formatted_formula": "(NH<sub>4</sub>)<sub>4</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Amoni pyrophotphat"
  },
  {
    "id": "2652",
    "formula": "Cs[AuCl4]",
    "formatted_formula": "Cs[AuCl<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Xezi tetracloroaurat(III)"
  },
  {
    "id": "2653",
    "formula": "Au2O3",
    "formatted_formula": "Au<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Vàng Oxit"
  },
  {
    "id": "2654",
    "formula": "Au(NH2)2Cl",
    "formatted_formula": "Au(NH<sub>2</sub>)<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Diamminegold(I) chloride"
  },
  {
    "id": "2655",
    "formula": "NH2OH.H2O",
    "formatted_formula": "NH<sub>2</sub>OH.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hydroxylamin monohidrat"
  },
  {
    "id": "2656",
    "formula": "(NH3OH)3PO4",
    "formatted_formula": "(NH<sub>3</sub>OH)<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydroxylamin photphat"
  },
  {
    "id": "2658",
    "formula": "NH4C",
    "formatted_formula": "NH<sub>4</sub>C<sup></sup>",
    "vietnamese_name": "Amoni cacbua"
  },
  {
    "id": "2659",
    "formula": "NaC",
    "formatted_formula": "NaC<sup></sup>",
    "vietnamese_name": "Natri monocacbua"
  },
  {
    "id": "2660",
    "formula": "Na3AsS4",
    "formatted_formula": "Na<sub>3</sub>AsS<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri thioasenat"
  },
  {
    "id": "2661",
    "formula": "Na2TeO4",
    "formatted_formula": "Na<sub>2</sub>TeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri Telurat"
  },
  {
    "id": "2662",
    "formula": "SeCl2",
    "formatted_formula": "SeCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Selen Diclorua"
  },
  {
    "id": "2663",
    "formula": "H2SeCl6",
    "formatted_formula": "H<sub>2</sub>SeCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Hexachloroselenic acid"
  },
  {
    "id": "2664",
    "formula": "TeCl4",
    "formatted_formula": "TeCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Telu tetraclorua"
  },
  {
    "id": "2665",
    "formula": "TlNO3",
    "formatted_formula": "TlNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Thali(I) nitrat"
  },
  {
    "id": "2666",
    "formula": "Rh2S3",
    "formatted_formula": "Rh<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rhodi sunfua"
  },
  {
    "id": "2667",
    "formula": "[Rh(NH3)6]Cl3",
    "formatted_formula": "[Rh(NH<sub>3</sub>)<sub>6</sub>]Cl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hexaamminerhodium(III) chloride"
  },
  {
    "id": "2668",
    "formula": "H3RhCl6",
    "formatted_formula": "H<sub>3</sub>RhCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit clororhodic(III)"
  },
  {
    "id": "2669",
    "formula": "C2H5NH3Cl",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>NH<sub>3</sub>Cl<sup></sup>",
    "vietnamese_name": "Etylamoni clorua"
  },
  {
    "id": "2670",
    "formula": "(NH4)2PtCl4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>PtCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Ammonium tetrachloroplatinate(II)"
  },
  {
    "id": "2671",
    "formula": "AsCl4",
    "formatted_formula": "AsCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Tetracloroasenat(III)"
  },
  {
    "id": "2672",
    "formula": "Ni(NO2)2",
    "formatted_formula": "Ni(NO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Niken(II) Nitrit"
  },
  {
    "id": "2673",
    "formula": "[PCl4][PF6]",
    "formatted_formula": "[PCl<sub>4</sub>][PF<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Tetrachlorphosphonium‐hexafluorophosphat"
  },
  {
    "id": "2674",
    "formula": "[AsCl4][AsF6]",
    "formatted_formula": "[AsCl<sub>4</sub>][AsF<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Tetrachloroarsen hexafluoroarsenate"
  },
  {
    "id": "2675",
    "formula": "[Ni(H2O)2(NH3)4]SO4",
    "formatted_formula": "[Ni(H<sub>2</sub>O)<sub>2</sub>(NH<sub>3</sub>)<sub>4</sub>]SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Diaquatetraamminenickel(II) sulfate"
  },
  {
    "id": "2676",
    "formula": "NO2ClO",
    "formatted_formula": "NO<sub>2</sub>ClO<sup></sup>",
    "vietnamese_name": "Cloronitrat"
  },
  {
    "id": "2677",
    "formula": "ZrCl2O",
    "formatted_formula": "ZrCl<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Zirconi oxyclorua"
  },
  {
    "id": "2678",
    "formula": "SnCl2O",
    "formatted_formula": "SnCl<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thiếc(IV) oxyclorua"
  },
  {
    "id": "2679",
    "formula": "(NO)2S2O7",
    "formatted_formula": "(NO)<sub>2</sub>S<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Nitrosyl pyrosunfat"
  },
  {
    "id": "2680",
    "formula": "HfCl2O",
    "formatted_formula": "HfCl<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Diclorohafni oxit"
  },
  {
    "id": "2681",
    "formula": "RbNO2",
    "formatted_formula": "RbNO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Rubidi Nitrit"
  },
  {
    "id": "2682",
    "formula": "RbNO3.HNO3",
    "formatted_formula": "RbNO<sub>3</sub>.HNO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rubidi nitrat. Axit nitric"
  },
  {
    "id": "2683",
    "formula": "Tl2O",
    "formatted_formula": "Tl<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thali(I) oxit"
  },
  {
    "id": "2684",
    "formula": "TlCl",
    "formatted_formula": "TlCl<sup></sup>",
    "vietnamese_name": "Thali clorua"
  },
  {
    "id": "2685",
    "formula": "[Tl(H2O)]+",
    "formatted_formula": "[Tl(H<sub>2</sub>O)]<sup>+</sup>",
    "vietnamese_name": "Monoaquathallium(I) ion"
  },
  {
    "id": "2686",
    "formula": "Tl2S",
    "formatted_formula": "Tl<sub>2</sub>S<sup></sup>",
    "vietnamese_name": "Thali sunfua"
  },
  {
    "id": "2687",
    "formula": "Tl2CrO4",
    "formatted_formula": "Tl<sub>2</sub>CrO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thali cromat"
  },
  {
    "id": "2688",
    "formula": "Tl2[Zn(OH)4]",
    "formatted_formula": "Tl<sub>2</sub>[Zn(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Thallium tetrahydroxozincat(II)"
  },
  {
    "id": "2689",
    "formula": "Tl3PO4",
    "formatted_formula": "Tl<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thali(I) Photphat"
  },
  {
    "id": "2690",
    "formula": "NaH2PO2",
    "formatted_formula": "NaH<sub>2</sub>PO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri hypophotphit"
  },
  {
    "id": "2691",
    "formula": "H2PO2-",
    "formatted_formula": "H<sub>2</sub>PO<sub>2</sub><sup>-</sup>",
    "vietnamese_name": "Hypophotphit"
  },
  {
    "id": "2692",
    "formula": "S2O62-",
    "formatted_formula": "S<sub>2</sub>O<sub>6</sub><sup>2-</sup>",
    "vietnamese_name": "Ion dithionat"
  },
  {
    "id": "2693",
    "formula": "Ag2SO3",
    "formatted_formula": "Ag<sub>2</sub>SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bạc Sunfit"
  },
  {
    "id": "2696",
    "formula": "LiHSO4",
    "formatted_formula": "LiHSO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti sunfat"
  },
  {
    "id": "2697",
    "formula": "Li2HPO4",
    "formatted_formula": "Li<sub>2</sub>HPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Diliti hidrophotphat"
  },
  {
    "id": "2698",
    "formula": "Li3PO4.12H2O",
    "formatted_formula": "Li<sub>3</sub>PO<sub>4</sub>.12H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Liti photphat dodecahidrat"
  },
  {
    "id": "2699",
    "formula": "K5P3O10",
    "formatted_formula": "K<sub>5</sub>P<sub>3</sub>O<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Kali triphotphat"
  },
  {
    "id": "2700",
    "formula": "K4P2O7",
    "formatted_formula": "K<sub>4</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Kali pyrophotphat"
  },
  {
    "id": "2701",
    "formula": "K2HPO4.3H2O",
    "formatted_formula": "K<sub>2</sub>HPO<sub>4</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Dikali hidrophotphat trihidrat"
  },
  {
    "id": "2702",
    "formula": "LiH2PO4",
    "formatted_formula": "LiH<sub>2</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Liti dihidrophotphat"
  },
  {
    "id": "2703",
    "formula": "NiSO4.7H2O",
    "formatted_formula": "NiSO<sub>4</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nicken(II) sunphat Heptahidrat"
  },
  {
    "id": "2704",
    "formula": "Sc",
    "formatted_formula": "Sc<sup></sup>",
    "vietnamese_name": "Scandi"
  },
  {
    "id": "2706",
    "formula": "ScCl2OH",
    "formatted_formula": "ScCl<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Scandi diclorua hidroxit"
  },
  {
    "id": "2707",
    "formula": "ScF3",
    "formatted_formula": "ScF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Scandi florua"
  },
  {
    "id": "2708",
    "formula": "Sc(OH)3",
    "formatted_formula": "Sc(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Scandi trihidroxit"
  },
  {
    "id": "2709",
    "formula": "Sc2O3",
    "formatted_formula": "Sc<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Scandi Oxit"
  },
  {
    "id": "2710",
    "formula": "ZrCl2",
    "formatted_formula": "ZrCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Zirconi diclorua"
  },
  {
    "id": "2713",
    "formula": "ScCl3.xH2O",
    "formatted_formula": "ScCl<sub>3</sub>.xH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Scandi clorua hidrat"
  },
  {
    "id": "2714",
    "formula": "ZrCl",
    "formatted_formula": "ZrCl<sup></sup>",
    "vietnamese_name": "Zirconi monoclorua"
  },
  {
    "id": "2715",
    "formula": "[Zr3Cl3(OH)6]Cl3",
    "formatted_formula": "[Zr<sub>3</sub>Cl<sub>3</sub>(OH)<sub>6</sub>]Cl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hexahydroxytrichlorozirconium(IV) chloride"
  },
  {
    "id": "2716",
    "formula": "Zr",
    "formatted_formula": "Zr<sup></sup>",
    "vietnamese_name": "Zirconi"
  },
  {
    "id": "2717",
    "formula": "ZrO2",
    "formatted_formula": "ZrO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Zirconi dioxit"
  },
  {
    "id": "2718",
    "formula": "ZrCl3",
    "formatted_formula": "ZrCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Zirconi triclorua"
  },
  {
    "id": "2719",
    "formula": "HfCl3",
    "formatted_formula": "HfCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hafni triclorua"
  },
  {
    "id": "2720",
    "formula": "[Hf3Cl3(OH)6]Cl3",
    "formatted_formula": "[Hf<sub>3</sub>Cl<sub>3</sub>(OH)<sub>6</sub>]Cl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hexahydroxytrichlorohafnium(IV) chloride"
  },
  {
    "id": "2721",
    "formula": "K2Pt(OH)6",
    "formatted_formula": "K<sub>2</sub>Pt(OH)<sub>6</sub><sup></sup>",
    "vietnamese_name": "Dikali hexahydroxyplatinat"
  },
  {
    "id": "2722",
    "formula": "K2Pt(CN)6",
    "formatted_formula": "K<sub>2</sub>Pt(CN)<sub>6</sub><sup></sup>",
    "vietnamese_name": "Potassium hexacyanoplatinate(IV)"
  },
  {
    "id": "2723",
    "formula": "PtS2",
    "formatted_formula": "PtS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Platin disufua"
  },
  {
    "id": "2724",
    "formula": "Pt(NH3)2Cl4",
    "formatted_formula": "Pt(NH<sub>3</sub>)<sub>2</sub>Cl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Diaminplatin(IV) tetraclorua"
  },
  {
    "id": "2725",
    "formula": "K2Pt(SCN)6",
    "formatted_formula": "K<sub>2</sub>Pt(SCN)<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali hexathiocyanatoplatinat(IV) "
  },
  {
    "id": "2726",
    "formula": "ThCl2O",
    "formatted_formula": "ThCl<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thori diclorua oxit"
  },
  {
    "id": "2727",
    "formula": "[Th(H2O)]4+",
    "formatted_formula": "[Th(H<sub>2</sub>O)]<sup>4+</sup>",
    "vietnamese_name": "Monoaquathorium(IV) ion"
  },
  {
    "id": "2728",
    "formula": "H2PtCl6.6H2O",
    "formatted_formula": "H<sub>2</sub>PtCl<sub>6</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit cloroplatinic hexahidrat"
  },
  {
    "id": "2729",
    "formula": "[PtCl4]2-",
    "formatted_formula": "[PtCl<sub>4</sub>]<sup>2-</sup>",
    "vietnamese_name": "Tetrachloroplatinate(II) ion"
  },
  {
    "id": "2730",
    "formula": "Th",
    "formatted_formula": "Th<sup></sup>",
    "vietnamese_name": "Thori"
  },
  {
    "id": "2731",
    "formula": "Th(OH)4",
    "formatted_formula": "Th(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Thori(IV) hydroxit"
  },
  {
    "id": "2732",
    "formula": "ThCl4.8H2O",
    "formatted_formula": "ThCl<sub>4</sub>.8H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Thori clorua octahidrat"
  },
  {
    "id": "2734",
    "formula": "ThO2",
    "formatted_formula": "ThO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thori dioxit"
  },
  {
    "id": "2735",
    "formula": "[SO3]2-",
    "formatted_formula": "[SO<sub>3</sub>]<sup>2-</sup>",
    "vietnamese_name": "Ion sunfit"
  },
  {
    "id": "2736",
    "formula": "BaI2",
    "formatted_formula": "BaI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari iodua"
  },
  {
    "id": "2737",
    "formula": "Na2SeO4.10H2O",
    "formatted_formula": "Na<sub>2</sub>SeO<sub>4</sub>.10H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri selenat decahidrat"
  },
  {
    "id": "2738",
    "formula": "(NH4)2SO3.H2O",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>SO<sub>3</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Amoni sulfit monohidrat"
  },
  {
    "id": "2739",
    "formula": "Na5P3O10",
    "formatted_formula": "Na<sub>5</sub>P<sub>3</sub>O<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Natri tripolyphotphat"
  },
  {
    "id": "2740",
    "formula": "TeO",
    "formatted_formula": "TeO<sup></sup>",
    "vietnamese_name": "Telu(II) oxit"
  },
  {
    "id": "2741",
    "formula": "Na4P2O7.10H2O",
    "formatted_formula": "Na<sub>4</sub>P<sub>2</sub>O<sub>7</sub>.10H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri Pyrophotphat Decahidrat"
  },
  {
    "id": "2742",
    "formula": "Na2Se2O5",
    "formatted_formula": "Na<sub>2</sub>Se<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Natri pyroselenit"
  },
  {
    "id": "2743",
    "formula": "Na2SeO3.5H2O",
    "formatted_formula": "Na<sub>2</sub>SeO<sub>3</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri selenit pentahidrat"
  },
  {
    "id": "2744",
    "formula": "H3[Fe(CN)6]",
    "formatted_formula": "H<sub>3</sub>[Fe(CN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Axit Hydroferricyanic"
  },
  {
    "id": "2745",
    "formula": "Ag3[Fe(CN)6]",
    "formatted_formula": "Ag<sub>3</sub>[Fe(CN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Silver(I) ferricyanide "
  },
  {
    "id": "2746",
    "formula": "NaIO4",
    "formatted_formula": "NaIO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri periodat"
  },
  {
    "id": "2747",
    "formula": "NaIO3.H2O",
    "formatted_formula": "NaIO<sub>3</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri iodat monohidrat"
  },
  {
    "id": "2748",
    "formula": "GeS",
    "formatted_formula": "GeS<sup></sup>",
    "vietnamese_name": "Germani monosunfua"
  },
  {
    "id": "2749",
    "formula": "HS-",
    "formatted_formula": "HS<sup>-</sup>",
    "vietnamese_name": "Ion hidrosunfua "
  },
  {
    "id": "2750",
    "formula": "Ba(OH)2.8H2O",
    "formatted_formula": "Ba(OH)<sub>2</sub>.8H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Bari hidroxit octahidrat"
  },
  {
    "id": "2751",
    "formula": "KFe[Fe(CN)6]",
    "formatted_formula": "KFe[Fe(CN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Iron(III) hexacyanoferrate(II)"
  },
  {
    "id": "2752",
    "formula": "K2[Fe(H2O)(CN)5]",
    "formatted_formula": "K<sub>2</sub>[Fe(H<sub>2</sub>O)(CN)<sub>5</sub>]<sup></sup>",
    "vietnamese_name": "Potassium monoquapentacyanoferrate(III) "
  },
  {
    "id": "2753",
    "formula": "Fe[Fe(CN)6]",
    "formatted_formula": "Fe[Fe(CN)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Iron(III) Ferricyanide"
  },
  {
    "id": "2754",
    "formula": "Cu3[Fe(CN)6]2",
    "formatted_formula": "Cu<sub>3</sub>[Fe(CN)<sub>6</sub>]<sub>2</sub><sup></sup>",
    "vietnamese_name": "Copper hexacyanoferrate(III)"
  },
  {
    "id": "2755",
    "formula": "K[Al(OH)4]",
    "formatted_formula": "K[Al(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Potasium tetrahydroxyaluminate(III)"
  },
  {
    "id": "2757",
    "formula": "Ba(HS)2.4H2O",
    "formatted_formula": "Ba(HS)<sub>2</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Bari Hidrosunfua tetrahidrat"
  },
  {
    "id": "2758",
    "formula": "AgSbS2",
    "formatted_formula": "AgSbS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bạc antimon sunfua"
  },
  {
    "id": "2759",
    "formula": "Sb2S5",
    "formatted_formula": "Sb<sub>2</sub>S<sub>5</sub><sup></sup>",
    "vietnamese_name": "Antimon(V) sunfua"
  },
  {
    "id": "2760",
    "formula": "Na2S2O5.7H2O",
    "formatted_formula": "Na<sub>2</sub>S<sub>2</sub>O<sub>5</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri metabisunfit heptahidrat"
  },
  {
    "id": "2761",
    "formula": "Na3SbS3.9H2O",
    "formatted_formula": "Na<sub>3</sub>SbS<sub>3</sub>.9H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri thioantimonit nonahidrat"
  },
  {
    "id": "2762",
    "formula": "Na3SbS4",
    "formatted_formula": "Na<sub>3</sub>SbS<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri thioantimoniat"
  },
  {
    "id": "2764",
    "formula": "Na3SbS4.9 H2O",
    "formatted_formula": "Na<sub>3</sub>SbS<sub>4</sub>.9 H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri thioantimoniat nonahidrat"
  },
  {
    "id": "2765",
    "formula": "Na2H2P2O7.6H2O",
    "formatted_formula": "Na<sub>2</sub>H<sub>2</sub>P<sub>2</sub>O<sub>7</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri dihidropyrophotphat hexahidrat"
  },
  {
    "id": "2766",
    "formula": "Na3P3O9",
    "formatted_formula": "Na<sub>3</sub>P<sub>3</sub>O<sub>9</sub><sup></sup>",
    "vietnamese_name": "Trinatri trimetaphotphat"
  },
  {
    "id": "2767",
    "formula": "H2P2O72-",
    "formatted_formula": "H<sub>2</sub>P<sub>2</sub>O<sub>7</sub><sup>2-</sup>",
    "vietnamese_name": "Ion dihidropyrophotphat"
  },
  {
    "id": "2768",
    "formula": "Na2H2P2O6.6H2O",
    "formatted_formula": "Na<sub>2</sub>H<sub>2</sub>P<sub>2</sub>O<sub>6</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Dinatri hypophotphat hexahidrat"
  },
  {
    "id": "2769",
    "formula": "Na2H2P2O5",
    "formatted_formula": "Na<sub>2</sub>H<sub>2</sub>P<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Natri dihidropyrophotphorit"
  },
  {
    "id": "2770",
    "formula": "Ag4Ge",
    "formatted_formula": "Ag<sub>4</sub>Ge<sup></sup>",
    "vietnamese_name": "Tetrasilver germanide"
  },
  {
    "id": "2771",
    "formula": "Na2GeO3",
    "formatted_formula": "Na<sub>2</sub>GeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri metagermanat"
  },
  {
    "id": "2772",
    "formula": "H2GeO3",
    "formatted_formula": "H<sub>2</sub>GeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Axit germanic(IV)"
  },
  {
    "id": "2773",
    "formula": "CoNO3OH",
    "formatted_formula": "CoNO<sub>3</sub>OH<sup></sup>",
    "vietnamese_name": "Coban nitrat hidroxit"
  },
  {
    "id": "2774",
    "formula": "Na3[Co(NO2)6].0,5H2O",
    "formatted_formula": "Na<sub>3</sub>[Co(NO<sub>2</sub>)<sub>6</sub>].0,<sub>5</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Sodium hexanitrocobaltate(III) hemihydrate"
  },
  {
    "id": "2775",
    "formula": "Na[B(OH)4].2H2O",
    "formatted_formula": "Na[B(OH)<sub>4</sub>].2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri tetrahydroxyborat dihidrat"
  },
  {
    "id": "2776",
    "formula": "[B(H2O)(OH)3]",
    "formatted_formula": "[B(H<sub>2</sub>O)(OH)<sub>3</sub>]<sup></sup>",
    "vietnamese_name": "Boron aqua trihidroxide"
  },
  {
    "id": "2777",
    "formula": "BI3",
    "formatted_formula": "BI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bo triiodua"
  },
  {
    "id": "2778",
    "formula": "PN(NH)",
    "formatted_formula": "PN(NH)<sup></sup>",
    "vietnamese_name": "Phospham"
  },
  {
    "id": "2779",
    "formula": "TcO2",
    "formatted_formula": "TcO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Techneti(IV) oxit"
  },
  {
    "id": "2780",
    "formula": "Tc2O7",
    "formatted_formula": "Tc<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Techneti(VII) oxit"
  },
  {
    "id": "2781",
    "formula": "H2TcCl6",
    "formatted_formula": "H<sub>2</sub>TcCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Axit pertechnetic(IV)"
  },
  {
    "id": "2782",
    "formula": "NaTcO4",
    "formatted_formula": "NaTcO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri pertechnetat"
  },
  {
    "id": "2783",
    "formula": "Tc",
    "formatted_formula": "Tc<sup></sup>",
    "vietnamese_name": "Techneti"
  },
  {
    "id": "2784",
    "formula": "HTcO4",
    "formatted_formula": "HTcO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit pertechnetic"
  },
  {
    "id": "2786",
    "formula": "Tc2S7",
    "formatted_formula": "Tc<sub>2</sub>S<sub>7</sub><sup></sup>",
    "vietnamese_name": "Techneti(VII) sunfua"
  },
  {
    "id": "2787",
    "formula": "TcS2",
    "formatted_formula": "TcS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Techneti(IV) sunfua"
  },
  {
    "id": "2788",
    "formula": "Tc(OH)4",
    "formatted_formula": "Tc(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Techneti(IV) hidroxit"
  },
  {
    "id": "2789",
    "formula": "Pb(HCO3)2",
    "formatted_formula": "Pb(HCO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì(II) hidro cacbonat"
  },
  {
    "id": "2790",
    "formula": "Pb2CO3(OH)2",
    "formatted_formula": "Pb<sub>2</sub>CO<sub>3</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì(IV) cacbonat hidroxit"
  },
  {
    "id": "2791",
    "formula": "PbF2",
    "formatted_formula": "PbF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì(II) florua"
  },
  {
    "id": "2792",
    "formula": "I-",
    "formatted_formula": "I<sup>-</sup>",
    "vietnamese_name": "Ion idua"
  },
  {
    "id": "2793",
    "formula": "SnF2",
    "formatted_formula": "SnF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thiếc(II) florua"
  },
  {
    "id": "2794",
    "formula": "Si2O3",
    "formatted_formula": "Si<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Disilic Trioxit"
  },
  {
    "id": "2795",
    "formula": "Na[Sn(OH)3]",
    "formatted_formula": "Na[Sn(OH)<sub>3</sub>]<sup></sup>",
    "vietnamese_name": "Sodium trihydroxystannate(II)"
  },
  {
    "id": "2796",
    "formula": "Na2SnO2",
    "formatted_formula": "Na<sub>2</sub>SnO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Disodium tin(II) dioxide"
  },
  {
    "id": "2797",
    "formula": "Ca[Sn(OH)6]",
    "formatted_formula": "Ca[Sn(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Calcium hexahydroxystannate(IV)"
  },
  {
    "id": "2798",
    "formula": "S[Sn(OH)6]",
    "formatted_formula": "S[Sn(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Sulfur hexahydroxystannate(IV)"
  },
  {
    "id": "2799",
    "formula": "Na2SnO3",
    "formatted_formula": "Na<sub>2</sub>SnO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri stannat"
  },
  {
    "id": "2800",
    "formula": "Sr[Sn(OH)6]",
    "formatted_formula": "Sr[Sn(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Strontium hexahydroxystannate(IV)"
  },
  {
    "id": "2801",
    "formula": "Na2SnCl6",
    "formatted_formula": "Na<sub>2</sub>SnCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "sodium hexachlorostannate(IV)"
  },
  {
    "id": "2802",
    "formula": "Ba[Sn(OH)6]",
    "formatted_formula": "Ba[Sn(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Barium hexahydroxystannate(IV)"
  },
  {
    "id": "2803",
    "formula": "K[Sn(OH)3]",
    "formatted_formula": "K[Sn(OH)<sub>3</sub>]<sup></sup>",
    "vietnamese_name": "Potassium trihydroxystannate(II)"
  },
  {
    "id": "2804",
    "formula": "KCr(SO4)2",
    "formatted_formula": "KCr(SO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Potassium chromium(III) sulfate"
  },
  {
    "id": "2805",
    "formula": "NaClO.5H2O",
    "formatted_formula": "NaClO.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri hypoclorit pentahidrat"
  },
  {
    "id": "2806",
    "formula": "NaOH.H2O",
    "formatted_formula": "NaOH.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri hidroxit monohidrat"
  },
  {
    "id": "2807",
    "formula": "SO3F-",
    "formatted_formula": "SO<sub>3</sub>F<sup>-</sup>",
    "vietnamese_name": "Ion florosunphat"
  },
  {
    "id": "2808",
    "formula": "NaSO3F",
    "formatted_formula": "NaSO<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Natri florosunfonat"
  },
  {
    "id": "2810",
    "formula": "SO2.nH2O",
    "formatted_formula": "SO<sub>2</sub>.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Lưu huỳnh dioxit hidrat"
  },
  {
    "id": "2811",
    "formula": "SO3NH2-",
    "formatted_formula": "SO<sub>3</sub>NH<sub>2</sub><sup>-</sup>",
    "vietnamese_name": "Ion sunphamat "
  },
  {
    "id": "2812",
    "formula": "BiNO3(OH)2",
    "formatted_formula": "BiNO<sub>3</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bitmut nitrat dihidroxit"
  },
  {
    "id": "2813",
    "formula": "Bi(NO3)O",
    "formatted_formula": "Bi(NO<sub>3</sub>)O<sup></sup>",
    "vietnamese_name": "Bitmut oxynitrat"
  },
  {
    "id": "2814",
    "formula": "Bi(NO3)3.5H2O",
    "formatted_formula": "Bi(NO<sub>3</sub>)<sub>3</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Bitmut(III) Nitrat Pentahidrat"
  },
  {
    "id": "2815",
    "formula": "Bi(NO3)2OH",
    "formatted_formula": "Bi(NO<sub>3</sub>)<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Bitmut dinitrat hidroxit"
  },
  {
    "id": "2816",
    "formula": "BiO(OH)",
    "formatted_formula": "BiO(OH)<sup></sup>",
    "vietnamese_name": "Bitmut hidroxit oxit"
  },
  {
    "id": "2817",
    "formula": "BiClO",
    "formatted_formula": "BiClO<sup></sup>",
    "vietnamese_name": "Clorooxobitmut"
  },
  {
    "id": "2818",
    "formula": "Bi2(SO4)O2",
    "formatted_formula": "Bi<sub>2</sub>(SO<sub>4</sub>)O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bitmut sunfat oxit"
  },
  {
    "id": "2819",
    "formula": "BiCl(OH)2",
    "formatted_formula": "BiCl(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bitmut clorua hidroxit"
  },
  {
    "id": "2820",
    "formula": "BiSO4(OH)",
    "formatted_formula": "BiSO<sub>4</sub>(OH)<sup></sup>",
    "vietnamese_name": "Bitmut sunfat hidroxit"
  },
  {
    "id": "2821",
    "formula": "Bi(HSO4)SO4",
    "formatted_formula": "Bi(HSO<sub>4</sub>)SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Bitmut(III) bisunfat sunfat"
  },
  {
    "id": "2822",
    "formula": "Bi2CO3(OH)4",
    "formatted_formula": "Bi<sub>2</sub>CO<sub>3</sub>(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dibitmut(III) cacbonat tetrahidroxit"
  },
  {
    "id": "2823",
    "formula": "At2S3",
    "formatted_formula": "At<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Astatin(III) sunfua"
  },
  {
    "id": "2824",
    "formula": "AtCl3",
    "formatted_formula": "AtCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Astatin(III) clorua"
  },
  {
    "id": "2825",
    "formula": "[N2O2]2-",
    "formatted_formula": "[N<sub>2</sub>O<sub>2</sub>]<sup>2-</sup>",
    "vietnamese_name": "Ion hyponitrit"
  },
  {
    "id": "2826",
    "formula": "Ag2N2O2",
    "formatted_formula": "Ag<sub>2</sub>N<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bạc hyponitrit"
  },
  {
    "id": "2827",
    "formula": "Na2[Ni(OH)4]",
    "formatted_formula": "Na<sub>2</sub>[Ni(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium tetrahydroxynickelate(II)"
  },
  {
    "id": "2828",
    "formula": "NiF3",
    "formatted_formula": "NiF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nicken triflorua"
  },
  {
    "id": "2829",
    "formula": "KHF2",
    "formatted_formula": "KHF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali biflorua"
  },
  {
    "id": "2830",
    "formula": "K2NiF4",
    "formatted_formula": "K<sub>2</sub>NiF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Potassium tetrafluoronickelate(II)"
  },
  {
    "id": "2831",
    "formula": "Ni2SO4(OH)2",
    "formatted_formula": "Ni<sub>2</sub>SO<sub>4</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Nicken hidroxit sunfat"
  },
  {
    "id": "2832",
    "formula": "[Ni(NH3)6]SO4",
    "formatted_formula": "[Ni(NH<sub>3</sub>)<sub>6</sub>]SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hexaaminenickel(II) sulfate"
  },
  {
    "id": "2833",
    "formula": "Ni(NO3)OH",
    "formatted_formula": "Ni(NO<sub>3</sub>)OH<sup></sup>",
    "vietnamese_name": "Nicken hidroxit nitrat"
  },
  {
    "id": "2834",
    "formula": "[Ni(NH3)6](NO3)2",
    "formatted_formula": "[Ni(NH<sub>3</sub>)<sub>6</sub>](NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexaaminenickel(II) nitrate"
  },
  {
    "id": "2835",
    "formula": "NiF2.4H2O",
    "formatted_formula": "NiF<sub>2</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nicken diflorua tetrahidrat"
  },
  {
    "id": "2836",
    "formula": "Ni(NO3)2.6H2O",
    "formatted_formula": "Ni(NO<sub>3</sub>)<sub>2</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nicken(II) Nitrat Hexahidrat"
  },
  {
    "id": "2837",
    "formula": "[Ni(NH3)6]F2",
    "formatted_formula": "[Ni(NH<sub>3</sub>)<sub>6</sub>]F<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hexaaminenickel(II) fluoride"
  },
  {
    "id": "2838",
    "formula": "Ni2O(OH)4",
    "formatted_formula": "Ni<sub>2</sub>O(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dinicken tetrahidroxit oxit"
  },
  {
    "id": "2839",
    "formula": "Li2O2.H2O",
    "formatted_formula": "Li<sub>2</sub>O<sub>2</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Liti peroxit monohidrat"
  },
  {
    "id": "2840",
    "formula": "LiOOH·H2O",
    "formatted_formula": "LiOOH·H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Liti hidroperoxit monohidrat"
  },
  {
    "id": "2841",
    "formula": "Li2O2.H2O2.3H2O",
    "formatted_formula": "Li<sub>2</sub>O<sub>2</sub>.H<sub>2</sub>O<sub>2</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Liti peroxit. Hidro peroxit. nước"
  },
  {
    "id": "2842",
    "formula": "HSeO3F",
    "formatted_formula": "HSeO<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Axit floroselenic"
  },
  {
    "id": "2843",
    "formula": "[SeO3]2-",
    "formatted_formula": "[SeO<sub>3</sub>]<sup>2-</sup>",
    "vietnamese_name": "Ion selenit"
  },
  {
    "id": "2844",
    "formula": "BeF2.H2O",
    "formatted_formula": "BeF<sub>2</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Beri diflorua monohidrat"
  },
  {
    "id": "2845",
    "formula": "Fe(NH4)2(SO4)2",
    "formatted_formula": "Fe(NH<sub>4</sub>)<sub>2</sub>(SO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Amoni sắtn(II) sunfat"
  },
  {
    "id": "2846",
    "formula": "K[AsF4]",
    "formatted_formula": "K[AsF<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Potassium tetrafluoroarsennate(III)"
  },
  {
    "id": "2847",
    "formula": "CaHClO",
    "formatted_formula": "CaHClO<sup></sup>",
    "vietnamese_name": "Canxi hypoclorit"
  },
  {
    "id": "2848",
    "formula": "Na2[Pb(OH)6]",
    "formatted_formula": "Na<sub>2</sub>[Pb(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Sodium Hexahydroxyplumbate(iV) "
  },
  {
    "id": "2849",
    "formula": "Ca(HCN2)2",
    "formatted_formula": "Ca(HCN<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi hidrocyanamua"
  },
  {
    "id": "2850",
    "formula": "BeCl2.4H2O",
    "formatted_formula": "BeCl<sub>2</sub>.4H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Beri clorua tetrahidrat"
  },
  {
    "id": "2851",
    "formula": "Na2[Pd(OH)4]",
    "formatted_formula": "Na<sub>2</sub>[Pd(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium tetrahydroxypalladate(II)"
  },
  {
    "id": "2852",
    "formula": "PdO",
    "formatted_formula": "PdO<sup></sup>",
    "vietnamese_name": "Paladi oxit"
  },
  {
    "id": "2854",
    "formula": "[Pd(NH3)4](OH)2",
    "formatted_formula": "[Pd(NH<sub>3</sub>)<sub>4</sub>](OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetraaminepalladium(II) hydroxide"
  },
  {
    "id": "2855",
    "formula": "[Pd(NH3)4]Cl2",
    "formatted_formula": "[Pd(NH<sub>3</sub>)<sub>4</sub>]Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Tetraaminepalladium(II) chloride"
  },
  {
    "id": "2856",
    "formula": "(NH4)4SnS4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>4</sub>SnS<sub>4</sub><sup></sup>",
    "vietnamese_name": "Sodium Tetrathiostannate (IV)"
  },
  {
    "id": "2857",
    "formula": "(NH4)2PdCl4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>PdCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Ammonium tetrachloropalladate(II)"
  },
  {
    "id": "2858",
    "formula": "K2PdCl4",
    "formatted_formula": "K<sub>2</sub>PdCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Potassium Tetrachloropallidate"
  },
  {
    "id": "2859",
    "formula": "(NH4)2PdCl6",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>PdCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Ammonium hexachloropalladate(IV)"
  },
  {
    "id": "2860",
    "formula": "Na2SnS3",
    "formatted_formula": "Na<sub>2</sub>SnS<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri thiostannat"
  },
  {
    "id": "2861",
    "formula": "K2RuO4.H2O",
    "formatted_formula": "K<sub>2</sub>RuO<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kali ruthenat monohidrat"
  },
  {
    "id": "2862",
    "formula": "Ru",
    "formatted_formula": "Ru<sup></sup>",
    "vietnamese_name": "Rutheni"
  },
  {
    "id": "2863",
    "formula": "K2[RuCl6]",
    "formatted_formula": "K<sub>2</sub>[RuCl<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Kali hexaclororuthenat(IV)"
  },
  {
    "id": "2864",
    "formula": "RuO2",
    "formatted_formula": "RuO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Rutheni dioxit"
  },
  {
    "id": "2865",
    "formula": "RuCl3.RuCl4",
    "formatted_formula": "RuCl<sub>3</sub>.RuCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Rutheni(III, IV) heptaclorua"
  },
  {
    "id": "2866",
    "formula": "OsO2",
    "formatted_formula": "OsO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Osmi dioxit"
  },
  {
    "id": "2867",
    "formula": "OsO4",
    "formatted_formula": "OsO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Osmi tetroxit"
  },
  {
    "id": "2868",
    "formula": "Os3(CO)12",
    "formatted_formula": "Os<sub>3</sub>(CO)<sub>1</sub><sub>2</sub><sup></sup>",
    "vietnamese_name": "Triosmi dodecacacbonyl"
  },
  {
    "id": "2869",
    "formula": "Os(OH)4",
    "formatted_formula": "Os(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Osmi tetrahidroxit"
  },
  {
    "id": "2870",
    "formula": "[OsO2(OH)4]2-",
    "formatted_formula": "[OsO<sub>2</sub>(OH)<sub>4</sub>]<sup>2-</sup>",
    "vietnamese_name": "Osmate(VI) ion"
  },
  {
    "id": "2871",
    "formula": "(CH3)3CNH2",
    "formatted_formula": "(CH<sub>3</sub>)<sub>3</sub>CNH<sub>2</sub><sup></sup>",
    "vietnamese_name": "tert-Butylamin"
  },
  {
    "id": "2872",
    "formula": "(CH3)2C=CH2",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>C=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Isobutylen"
  },
  {
    "id": "2873",
    "formula": "(CH3)3CNHCHO",
    "formatted_formula": "(CH<sub>3</sub>)<sub>3</sub>CNHCHO<sup></sup>",
    "vietnamese_name": "N-tert-Butylformamide"
  },
  {
    "id": "2874",
    "formula": "KOH.H2O",
    "formatted_formula": "KOH.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kali hidroxit monohidrat"
  },
  {
    "id": "2875",
    "formula": "K2[OsO4(OH)2]",
    "formatted_formula": "K<sub>2</sub>[OsO<sub>4</sub>(OH)<sub>2</sub>]<sup></sup>",
    "vietnamese_name": "Kali perosmat"
  },
  {
    "id": "2876",
    "formula": "K3FeO4",
    "formatted_formula": "K<sub>3</sub>FeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Kali ferrat(V)"
  },
  {
    "id": "2877",
    "formula": "KFeO2",
    "formatted_formula": "KFeO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Kali Ferrat(III)"
  },
  {
    "id": "2878",
    "formula": "BaFeO4.H2O",
    "formatted_formula": "BaFeO<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Bari ferrat monohidrat"
  },
  {
    "id": "2879",
    "formula": "[Sr(H2O)n]2+",
    "formatted_formula": "[Sr(H<sub>2</sub>O)n]<sup>2+</sup>",
    "vietnamese_name": "Aquastrontium(II)"
  },
  {
    "id": "2882",
    "formula": "AgAtO3",
    "formatted_formula": "AgAtO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bạc astatat(V)"
  },
  {
    "id": "2883",
    "formula": "Na2Te.9H2O",
    "formatted_formula": "Na<sub>2</sub>Te.9H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri telurua nonahidrat"
  },
  {
    "id": "2884",
    "formula": "H2Te",
    "formatted_formula": "H<sub>2</sub>Te<sup></sup>",
    "vietnamese_name": "Dihidro telurua"
  },
  {
    "id": "2885",
    "formula": "[Co(NH3)6]Cl2OH",
    "formatted_formula": "[Co(NH<sub>3</sub>)<sub>6</sub>]Cl<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Hexaamincoban(III) diclorua hidroxit"
  },
  {
    "id": "2886",
    "formula": "K2Ni(CN)4.H2O",
    "formatted_formula": "K<sub>2</sub>Ni(CN)<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kali tetracyanonickelate(II) monohidrat"
  },
  {
    "id": "2887",
    "formula": "K3[Ni(CN)4]",
    "formatted_formula": "K<sub>3</sub>[Ni(CN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Potassium tetracyanidonickelate(I)"
  },
  {
    "id": "2888",
    "formula": "K2[Pt(CN)4].3H2O",
    "formatted_formula": "K<sub>2</sub>[Pt(CN)<sub>4</sub>].3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Potassium tetracyanoplatinate(II) trihydrate"
  },
  {
    "id": "2889",
    "formula": "KAsF6",
    "formatted_formula": "KAsF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Potassium Hexafluoroarsenate(V)"
  },
  {
    "id": "2890",
    "formula": "[AsF6]-",
    "formatted_formula": "[AsF<sub>6</sub>]<sup>-</sup>",
    "vietnamese_name": "Hexafluoroarsenate(V) ion"
  },
  {
    "id": "2891",
    "formula": "H2F+",
    "formatted_formula": "H<sub>2</sub>F<sup>+</sup>",
    "vietnamese_name": "Fluoronium ion"
  },
  {
    "id": "2892",
    "formula": "AsOF3",
    "formatted_formula": "AsOF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Trifloroasin oxit"
  },
  {
    "id": "2893",
    "formula": "HAsF6.H2O",
    "formatted_formula": "HAsF<sub>6</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit hexafloroasenic monohidrat"
  },
  {
    "id": "2894",
    "formula": "[Fe(C5H5)2]NO3",
    "formatted_formula": "[Fe(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub>]NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ferricenium nitrate"
  },
  {
    "id": "2895",
    "formula": "Na2HAsO3",
    "formatted_formula": "Na<sub>2</sub>HAsO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dinatri hidroarsenit"
  },
  {
    "id": "2896",
    "formula": "Sr(ClO4)2",
    "formatted_formula": "Sr(ClO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Stronti Perclorat"
  },
  {
    "id": "2897",
    "formula": "Na2ZrO3",
    "formatted_formula": "Na<sub>2</sub>ZrO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri Metazirconat"
  },
  {
    "id": "2898",
    "formula": "H2ZrOF4",
    "formatted_formula": "H<sub>2</sub>ZrOF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit tetraflorozirconic"
  },
  {
    "id": "2899",
    "formula": "Na[Zr(H2O)3(OH)5]",
    "formatted_formula": "Na[Zr(H<sub>2</sub>O)<sub>3</sub>(OH)<sub>5</sub>]<sup></sup>",
    "vietnamese_name": "Triaquapentahydroxyzirconate(IV)"
  },
  {
    "id": "2900",
    "formula": "CeOOH",
    "formatted_formula": "CeOOH<sup></sup>",
    "vietnamese_name": "Cerium hydroxide oxide"
  },
  {
    "id": "2901",
    "formula": "CeCO3(OH)",
    "formatted_formula": "CeCO<sub>3</sub>(OH)<sup></sup>",
    "vietnamese_name": "Xeri(III) hidroxit cacbonat"
  },
  {
    "id": "2902",
    "formula": "HCl.H2O",
    "formatted_formula": "HCl.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hidro clorua monohidrat"
  },
  {
    "id": "2903",
    "formula": "Ce(NO3)3.6H2O",
    "formatted_formula": "Ce(NO<sub>3</sub>)<sub>3</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Ceri(III) nitrat hexahidrat"
  },
  {
    "id": "2904",
    "formula": "Ce2(SO4)3",
    "formatted_formula": "Ce<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Xeri(III) sunphat"
  },
  {
    "id": "2905",
    "formula": "Ce(NO3)3OH",
    "formatted_formula": "Ce(NO<sub>3</sub>)<sub>3</sub>OH<sup></sup>",
    "vietnamese_name": "Xeri(IV) hidroxit trinitrat"
  },
  {
    "id": "2906",
    "formula": "Ce(NO3)O",
    "formatted_formula": "Ce(NO<sub>3</sub>)O<sup></sup>",
    "vietnamese_name": "Xeri(III) oxynitrat"
  },
  {
    "id": "2907",
    "formula": "[KrF][AuF6]",
    "formatted_formula": "[KrF][AuF<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Fluorokrypton hexafluoroaurate"
  },
  {
    "id": "2908",
    "formula": "[ClF6][AsF6]",
    "formatted_formula": "[ClF<sub>6</sub>][AsF<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Hexafluorochlorine hexafluoroarsenate"
  },
  {
    "id": "2909",
    "formula": "IO2F",
    "formatted_formula": "IO<sub>2</sub>F<sup></sup>",
    "vietnamese_name": "Dioxodifluoroiodate"
  },
  {
    "id": "2911",
    "formula": "NH4(Hg)",
    "formatted_formula": "NH<sub>4</sub>(Hg)<sup></sup>",
    "vietnamese_name": "Hỗn hống amoni"
  },
  {
    "id": "2912",
    "formula": "[Co(NH3)6](OH)3",
    "formatted_formula": "[Co(NH<sub>3</sub>)<sub>6</sub>](OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Hexamminecobalt(III) hydroxide"
  },
  {
    "id": "2914",
    "formula": "S2F10",
    "formatted_formula": "S<sub>2</sub>F<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Đi lưu huỳnh decaflorua"
  },
  {
    "id": "2915",
    "formula": "SClF5.17H2O",
    "formatted_formula": "SClF<sub>5</sub>.17H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Lưu huỳnh clorua pentaflorua heptadecahidrat"
  },
  {
    "id": "2916",
    "formula": "HSbCl4",
    "formatted_formula": "HSbCl<sub>4</sub><sup></sup>",
    "vietnamese_name": "Tetrachloroantimonic(III) acid"
  },
  {
    "id": "2917",
    "formula": "RbO3",
    "formatted_formula": "RbO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rubidium ozonide"
  },
  {
    "id": "2918",
    "formula": "Cs2S2O7",
    "formatted_formula": "Cs<sub>2</sub>S<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Xezi Pyrosunphat"
  },
  {
    "id": "2919",
    "formula": "CrSi2",
    "formatted_formula": "CrSi<sub>2</sub><sup></sup>",
    "vietnamese_name": "Crom silicua"
  },
  {
    "id": "2920",
    "formula": "Rb2S2O7",
    "formatted_formula": "Rb<sub>2</sub>S<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Dirubidi Disunphat"
  },
  {
    "id": "2921",
    "formula": "RbHCO3",
    "formatted_formula": "RbHCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rubidi hidro cacbonat"
  },
  {
    "id": "2922",
    "formula": "Al2(SO4)3.18H2O",
    "formatted_formula": "Al<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub>.18H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nhôm Sunphat Octadecahidrat"
  },
  {
    "id": "2923",
    "formula": "Cr(SO4)OH",
    "formatted_formula": "Cr(SO<sub>4</sub>)OH<sup></sup>",
    "vietnamese_name": "Crom hidroxit sunphat"
  },
  {
    "id": "2924",
    "formula": "Pr(OH)3",
    "formatted_formula": "Pr(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Praseodymi trihiydroxt"
  },
  {
    "id": "2925",
    "formula": "PrCl3.7H2O",
    "formatted_formula": "PrCl<sub>3</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Praseodymi(III) clorua heptahidrat"
  },
  {
    "id": "2926",
    "formula": "PrClO",
    "formatted_formula": "PrClO<sup></sup>",
    "vietnamese_name": "Praseodymi clorua oxit"
  },
  {
    "id": "2927",
    "formula": "LaCl(OH)2",
    "formatted_formula": "LaCl(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Lantan clorua dihidroxt"
  },
  {
    "id": "2928",
    "formula": "La",
    "formatted_formula": "La<sup></sup>",
    "vietnamese_name": "Lantan"
  },
  {
    "id": "2929",
    "formula": "Pr2O3",
    "formatted_formula": "Pr<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Praseodymi(III) oxit"
  },
  {
    "id": "2930",
    "formula": "La(OH)3",
    "formatted_formula": "La(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Lantan(III) hidroxit"
  },
  {
    "id": "2931",
    "formula": "LaBr3",
    "formatted_formula": "LaBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Lantan(III) bromua"
  },
  {
    "id": "2932",
    "formula": "LaI3",
    "formatted_formula": "LaI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Lantan iodua"
  },
  {
    "id": "2933",
    "formula": "PrPO4",
    "formatted_formula": "PrPO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Praseodymi(III) photphat"
  },
  {
    "id": "2934",
    "formula": "LaCl3.7H2O",
    "formatted_formula": "LaCl<sub>3</sub>.7H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Lantan(III) clorua heptahidrat"
  },
  {
    "id": "2935",
    "formula": "LaCO3(OH)",
    "formatted_formula": "LaCO<sub>3</sub>(OH)<sup></sup>",
    "vietnamese_name": "Lantan hidroxit cacbonat"
  },
  {
    "id": "2936",
    "formula": "LaClO",
    "formatted_formula": "LaClO<sup></sup>",
    "vietnamese_name": "Lantan clorua oxit"
  },
  {
    "id": "2937",
    "formula": "Yb2O3",
    "formatted_formula": "Yb<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ytterbi oxit"
  },
  {
    "id": "2938",
    "formula": "Yb",
    "formatted_formula": "Yb<sup></sup>",
    "vietnamese_name": "Ytterbi"
  },
  {
    "id": "2939",
    "formula": "La2S3",
    "formatted_formula": "La<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dilantan trisunphua"
  },
  {
    "id": "2940",
    "formula": "La2(SO4)3",
    "formatted_formula": "La<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Lantan sunphat"
  },
  {
    "id": "2941",
    "formula": "Sm2O3",
    "formatted_formula": "Sm<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Samari(III) oxit"
  },
  {
    "id": "2942",
    "formula": "Sm",
    "formatted_formula": "Sm<sup></sup>",
    "vietnamese_name": "Samari"
  },
  {
    "id": "2943",
    "formula": "YbF3",
    "formatted_formula": "YbF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ytterbi florua"
  },
  {
    "id": "2944",
    "formula": "YbCl3",
    "formatted_formula": "YbCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ytterbi clorua"
  },
  {
    "id": "2945",
    "formula": "YbBr3",
    "formatted_formula": "YbBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ytterbi bromua"
  },
  {
    "id": "2946",
    "formula": "YbI3",
    "formatted_formula": "YbI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ytterbi iodua"
  },
  {
    "id": "2947",
    "formula": "Yb2(SO4)3",
    "formatted_formula": "Yb<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ytterbi(III) sunphat"
  },
  {
    "id": "2948",
    "formula": "Yb(OH)3",
    "formatted_formula": "Yb(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ytterbi(III) hidroxit"
  },
  {
    "id": "2949",
    "formula": "NaPF6.H2O",
    "formatted_formula": "NaPF<sub>6</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri hexaflorophotphat monohidrat"
  },
  {
    "id": "2950",
    "formula": "HPF6.6H2O",
    "formatted_formula": "HPF<sub>6</sub>.6H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Axit hexaflorophotphoric hexahidrat"
  },
  {
    "id": "2951",
    "formula": "NaPO2F2",
    "formatted_formula": "NaPO<sub>2</sub>F<sub>2</sub><sup></sup>",
    "vietnamese_name": "Natri diflorophotphat"
  },
  {
    "id": "2952",
    "formula": "GeCl2",
    "formatted_formula": "GeCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Germani clorua"
  },
  {
    "id": "2953",
    "formula": "H2GeCl6",
    "formatted_formula": "H<sub>2</sub>GeCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Hexachlorogermanic acid"
  },
  {
    "id": "2954",
    "formula": "Na2[Ge(OH)6]",
    "formatted_formula": "Na<sub>2</sub>[Ge(OH)<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Sodium hexahydroxygermanate(IV)"
  },
  {
    "id": "2955",
    "formula": "Na2[GeS3]",
    "formatted_formula": "Na<sub>2</sub>[GeS<sub>3</sub>]<sup></sup>",
    "vietnamese_name": "Sodium trithiogermanate(IV)"
  },
  {
    "id": "2956",
    "formula": "H2[HfOF4]",
    "formatted_formula": "H<sub>2</sub>[HfOF<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Tetrafluorooxyhafnic(IV) acid"
  },
  {
    "id": "2957",
    "formula": "HfO(OH)2",
    "formatted_formula": "HfO(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Hafni dihidroxit oxit"
  },
  {
    "id": "2958",
    "formula": "HfO2.nH2O",
    "formatted_formula": "HfO<sub>2</sub>.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hafni dioxit hidrat"
  },
  {
    "id": "2959",
    "formula": "Rb2CO3.1,5H2O",
    "formatted_formula": "Rb<sub>2</sub>CO<sub>3</sub>.1,<sub>5</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Rubidi cacbonat sesquihidrat"
  },
  {
    "id": "2960",
    "formula": "RbIF4",
    "formatted_formula": "RbIF<sub>4</sub><sup></sup>",
    "vietnamese_name": "Rubidi tetraflorua iodua"
  },
  {
    "id": "2961",
    "formula": "RbSO2F",
    "formatted_formula": "RbSO<sub>2</sub>F<sup></sup>",
    "vietnamese_name": "Rubidi florosunfit"
  },
  {
    "id": "2962",
    "formula": "[IF6][AuF6]",
    "formatted_formula": "[IF<sub>6</sub>][AuF<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Hexafluoroiodine hexafluoroaurate"
  },
  {
    "id": "2963",
    "formula": "UF4.2,5H2O",
    "formatted_formula": "UF<sub>4</sub>.2,<sub>5</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Urani(IV) florua 2,5 hidrat"
  },
  {
    "id": "2964",
    "formula": "UF4.H2O",
    "formatted_formula": "UF<sub>4</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Urani(IV) floua monohidrat"
  },
  {
    "id": "2965",
    "formula": "K[PtF6]",
    "formatted_formula": "K[PtF<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Kali hexafloroplatinat(V)"
  },
  {
    "id": "2966",
    "formula": "UO2Cl2",
    "formatted_formula": "UO<sub>2</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Uranyl Clorua"
  },
  {
    "id": "2967",
    "formula": "O2PtF6",
    "formatted_formula": "O<sub>2</sub>PtF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Dioxygenyl hexafluoroplatinate"
  },
  {
    "id": "2968",
    "formula": "PtF6",
    "formatted_formula": "PtF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Platin(VI) florua"
  },
  {
    "id": "2969",
    "formula": "KPtF6",
    "formatted_formula": "KPtF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Kali hexafloroplatinat(V)"
  },
  {
    "id": "2970",
    "formula": "UO2(NO3)2",
    "formatted_formula": "UO<sub>2</sub>(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Uranyl nitrat"
  },
  {
    "id": "2971",
    "formula": "Na2UO4",
    "formatted_formula": "Na<sub>2</sub>UO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Dinatri uranat"
  },
  {
    "id": "2972",
    "formula": "UO2SO4",
    "formatted_formula": "UO<sub>2</sub>SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Uranyl sunfat"
  },
  {
    "id": "2973",
    "formula": "(NH4)2U2O7",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>U<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Ammoni Diuranat"
  },
  {
    "id": "2974",
    "formula": "Na2U2O7",
    "formatted_formula": "Na<sub>2</sub>U<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Natri diuranat"
  },
  {
    "id": "2975",
    "formula": "NaWO3",
    "formatted_formula": "NaWO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri tungsten oxit"
  },
  {
    "id": "2976",
    "formula": "WO3.H2O",
    "formatted_formula": "WO<sub>3</sub>.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Tungsten(VI) oxit monohidrat"
  },
  {
    "id": "2977",
    "formula": "WO3.2H2O",
    "formatted_formula": "WO<sub>3</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Tungsten(VI) oxit dihidrat"
  },
  {
    "id": "2978",
    "formula": "H3[PW12O40]",
    "formatted_formula": "H<sub>3</sub>[PW<sub>1</sub><sub>2</sub>O<sub>4</sub><sub>0</sub>]<sup></sup>",
    "vietnamese_name": "Dodecatungstophosphoric acid"
  },
  {
    "id": "2979",
    "formula": "WC",
    "formatted_formula": "WC<sup></sup>",
    "vietnamese_name": "Tungsten cacbua"
  },
  {
    "id": "2980",
    "formula": "Na4XeO6.nH2O",
    "formatted_formula": "Na<sub>4</sub>XeO<sub>6</sub>.nH<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri Perxenat hidrat"
  },
  {
    "id": "2981",
    "formula": "HIO4",
    "formatted_formula": "HIO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Axit periodic"
  },
  {
    "id": "2982",
    "formula": "WCl6",
    "formatted_formula": "WCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Wolfram(VI) clorua"
  },
  {
    "id": "2983",
    "formula": "WF6",
    "formatted_formula": "WF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Tungsten hexaflorua"
  },
  {
    "id": "2984",
    "formula": "H4I2O9",
    "formatted_formula": "H<sub>4</sub>I<sub>2</sub>O<sub>9</sub><sup></sup>",
    "vietnamese_name": "Dimesoiodic(VII) acid"
  },
  {
    "id": "2985",
    "formula": "NaH4IO6",
    "formatted_formula": "NaH<sub>4</sub>IO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Natri tetrahidro orthoperiodat"
  },
  {
    "id": "2986",
    "formula": "Ba3(H2IO6)2",
    "formatted_formula": "Ba<sub>3</sub>(H<sub>2</sub>IO<sub>6</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari hidro orthoperiodat"
  },
  {
    "id": "2987",
    "formula": "Na5IO6",
    "formatted_formula": "Na<sub>5</sub>IO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Pentanatri periodat"
  },
  {
    "id": "2988",
    "formula": "ReO2",
    "formatted_formula": "ReO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Rheni(IV) oxit"
  },
  {
    "id": "2989",
    "formula": "NH4ReO4",
    "formatted_formula": "NH<sub>4</sub>ReO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Ammoni perrhenat"
  },
  {
    "id": "2990",
    "formula": "H4Re2O9",
    "formatted_formula": "H<sub>4</sub>Re<sub>2</sub>O<sub>9</sub><sup></sup>",
    "vietnamese_name": "Axit Perrhenic"
  },
  {
    "id": "2991",
    "formula": "Re2O7",
    "formatted_formula": "Re<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Rheni(VII) oxit"
  },
  {
    "id": "2992",
    "formula": "ReO3",
    "formatted_formula": "ReO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rheni trioxit"
  },
  {
    "id": "2993",
    "formula": "Re2S7",
    "formatted_formula": "Re<sub>2</sub>S<sub>7</sub><sup></sup>",
    "vietnamese_name": "Dirheni heptasunfua"
  },
  {
    "id": "2994",
    "formula": "Re2(CO)10",
    "formatted_formula": "Re<sub>2</sub>(CO)<sub>1</sub><sub>0</sub><sup></sup>",
    "vietnamese_name": "Dirheni decacarbonyl"
  },
  {
    "id": "2996",
    "formula": "Na2ReO3",
    "formatted_formula": "Na<sub>2</sub>ReO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri Rhenit(IV)"
  },
  {
    "id": "2997",
    "formula": "Na2ReH9",
    "formatted_formula": "Na<sub>2</sub>ReH<sub>9</sub><sup></sup>",
    "vietnamese_name": "Natri nonahydridorhenat"
  },
  {
    "id": "2998",
    "formula": "ReF6",
    "formatted_formula": "ReF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Rheni florua"
  },
  {
    "id": "2999",
    "formula": "Re(CO)5Br",
    "formatted_formula": "Re(CO)<sub>5</sub>Br<sup></sup>",
    "vietnamese_name": "Bromopentacarbonylrhenium(I)"
  },
  {
    "id": "3000",
    "formula": "ReBr3",
    "formatted_formula": "ReBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "Rheni(III) bromua"
  },
  {
    "id": "3001",
    "formula": "ReCl5",
    "formatted_formula": "ReCl<sub>5</sub><sup></sup>",
    "vietnamese_name": "Rheni(V) clorua"
  },
  {
    "id": "3002",
    "formula": "Co(C5H5)2",
    "formatted_formula": "Co(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Cobaltocene"
  },
  {
    "id": "3003",
    "formula": "Ni(C5H5)2",
    "formatted_formula": "Ni(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Nickelocene"
  },
  {
    "id": "3004",
    "formula": "Tl(C5H5)2",
    "formatted_formula": "Tl(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bis(eta-cyclopentadienyl)thallium"
  },
  {
    "id": "3005",
    "formula": "TlCl2",
    "formatted_formula": "TlCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thalli(II) clorua"
  },
  {
    "id": "3006",
    "formula": "V(C5H5)2",
    "formatted_formula": "V(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bis(eta-cyclopentadienyl)vanadium"
  },
  {
    "id": "3007",
    "formula": "VCl3",
    "formatted_formula": "VCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Vanadi(III) clorua"
  },
  {
    "id": "3008",
    "formula": "Cr(C5H5)2",
    "formatted_formula": "Cr(C<sub>5</sub>H<sub>5</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bis(eta-cyclopentadienyl)chromium"
  },
  {
    "id": "3009",
    "formula": "FeS2O3",
    "formatted_formula": "FeS<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt(II) Thiosunfat"
  },
  {
    "id": "3010",
    "formula": "ReO3Cl",
    "formatted_formula": "ReO<sub>3</sub>Cl<sup></sup>",
    "vietnamese_name": "Clorotrioxorheni(VII)"
  },
  {
    "id": "3011",
    "formula": "VCl2",
    "formatted_formula": "VCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Vanadi diclorua"
  },
  {
    "id": "3012",
    "formula": "C5H5",
    "formatted_formula": "C<sub>5</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "2,4-Cyclopentadienide"
  },
  {
    "id": "3013",
    "formula": "FeSO3.2,75H2O",
    "formatted_formula": "FeSO<sub>3</sub>.2,<sub>7</sub><sub>5</sub>H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Sắt(II) sunfit 2,75 hidrat"
  },
  {
    "id": "3014",
    "formula": "FeS2O6",
    "formatted_formula": "FeS<sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Sắt dithionat"
  },
  {
    "id": "3015",
    "formula": "[Bi6(OH)12](ClO4)6",
    "formatted_formula": "[Bi<sub>6</sub>(OH)<sub>1</sub><sub>2</sub>](ClO<sub>4</sub>)<sub>6</sub><sup></sup>",
    "vietnamese_name": "Dodecahydroxobitmut(III) hexaperclorat"
  },
  {
    "id": "3016",
    "formula": "KBiO3",
    "formatted_formula": "KBiO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali bitmutat"
  },
  {
    "id": "3017",
    "formula": "Ga(NO3)3.9H2O",
    "formatted_formula": "Ga(NO<sub>3</sub>)<sub>3</sub>.9H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Gali nitrat nonahidrat"
  },
  {
    "id": "3018",
    "formula": "GaF3",
    "formatted_formula": "GaF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Gali triflorua"
  },
  {
    "id": "3019",
    "formula": "Na[Ga(OH)4]",
    "formatted_formula": "Na[Ga(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium tetrahydroxogallate(III)"
  },
  {
    "id": "3020",
    "formula": "NH4[Ga(OH)4]",
    "formatted_formula": "NH<sub>4</sub>[Ga(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Ammonium tetrahydroxogallate(III)"
  },
  {
    "id": "3021",
    "formula": "Na2[Pt(CN)4]",
    "formatted_formula": "Na<sub>2</sub>[Pt(CN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Sodium tetracyanoplatinate(II)"
  },
  {
    "id": "3022",
    "formula": "H2[Pt(CN)4].5H2O",
    "formatted_formula": "H<sub>2</sub>[Pt(CN)<sub>4</sub>].5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hydrogen tetracyanoplatinate(II) pentahydrate"
  },
  {
    "id": "3024",
    "formula": "(NH3OH)ClO4",
    "formatted_formula": "(NH<sub>3</sub>OH)ClO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Hydroxylamoni perclorat"
  },
  {
    "id": "3025",
    "formula": "CNF",
    "formatted_formula": "CNF<sup></sup>",
    "vietnamese_name": "Flo cyanua"
  },
  {
    "id": "3026",
    "formula": "NH4CN",
    "formatted_formula": "NH<sub>4</sub>CN<sup></sup>",
    "vietnamese_name": "Amoni cyanua"
  },
  {
    "id": "3028",
    "formula": "GaCl",
    "formatted_formula": "GaCl<sup></sup>",
    "vietnamese_name": "Gali monoclorua"
  },
  {
    "id": "3029",
    "formula": "GaH3",
    "formatted_formula": "GaH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Gallane"
  },
  {
    "id": "3030",
    "formula": "Na3HXeO6",
    "formatted_formula": "Na<sub>3</sub>HXeO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Trinatri hidro Perxenat"
  },
  {
    "id": "3031",
    "formula": "Na2H2XeO6",
    "formatted_formula": "Na<sub>2</sub>H<sub>2</sub>XeO<sub>6</sub><sup></sup>",
    "vietnamese_name": "Dinatri dihidro perxenat"
  },
  {
    "id": "3032",
    "formula": "NaHXeO4",
    "formatted_formula": "NaHXeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Natri hidro xenat"
  },
  {
    "id": "3033",
    "formula": "[PO2F2]-",
    "formatted_formula": "[PO<sub>2</sub>F<sub>2</sub>]<sup>-</sup>",
    "vietnamese_name": "Ion diflorophotphat"
  },
  {
    "id": "3034",
    "formula": "H2PO3F",
    "formatted_formula": "H<sub>2</sub>PO<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Axit florophotphoric"
  },
  {
    "id": "3035",
    "formula": "HPO2F2",
    "formatted_formula": "HPO<sub>2</sub>F<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit diflorophotphinic"
  },
  {
    "id": "3036",
    "formula": "NH4PF6",
    "formatted_formula": "NH<sub>4</sub>PF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Amoni hexaflorophotphat"
  },
  {
    "id": "3037",
    "formula": "K2TeO4",
    "formatted_formula": "K<sub>2</sub>TeO<sub>4</sub><sup></sup>",
    "vietnamese_name": "kali telurat"
  },
  {
    "id": "3038",
    "formula": "K2H4TeO6.3H2O",
    "formatted_formula": "K<sub>2</sub>H<sub>4</sub>TeO<sub>6</sub>.3H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kali tetrahidro orthotelurat trihidrat"
  },
  {
    "id": "3039",
    "formula": "K2TeO3",
    "formatted_formula": "K<sub>2</sub>TeO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Kali telurit"
  },
  {
    "id": "3040",
    "formula": "Na6TeO6.2H2O",
    "formatted_formula": "Na<sub>6</sub>TeO<sub>6</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Natri orthotelurat dihidrat"
  },
  {
    "id": "3041",
    "formula": "HfI2O",
    "formatted_formula": "HfI<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hafni(IV) iodua oxit"
  },
  {
    "id": "3042",
    "formula": "HfN",
    "formatted_formula": "HfN<sup></sup>",
    "vietnamese_name": "Hafni nitrua"
  },
  {
    "id": "3043",
    "formula": "K2HgI4.2H2O",
    "formatted_formula": "K<sub>2</sub>HgI<sub>4</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Kali iodomercurat(II) dihdrat"
  },
  {
    "id": "3044",
    "formula": "(Hg2N)I.H2O",
    "formatted_formula": "(Hg<sub>2</sub>N)I.H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Nitridodimercury iodide hydrate"
  },
  {
    "id": "3045",
    "formula": "(NH4)2S4O6",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>S<sub>4</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Amoni dithionat"
  },
  {
    "id": "3046",
    "formula": "I3N",
    "formatted_formula": "I<sub>3</sub>N<sup></sup>",
    "vietnamese_name": "Nitơ triiodua"
  },
  {
    "id": "3047",
    "formula": "Rb2SnCl6",
    "formatted_formula": "Rb<sub>2</sub>SnCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Rubidium hexachlorostannate"
  },
  {
    "id": "3048",
    "formula": "(NH4)2SnCl6",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>SnCl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Ammonium hexachlorostannate"
  },
  {
    "id": "3049",
    "formula": "Cs2[SnCl6]",
    "formatted_formula": "Cs<sub>2</sub>[SnCl<sub>6</sub>]<sup></sup>",
    "vietnamese_name": "Caesium hexachlorostannate"
  },
  {
    "id": "3050",
    "formula": "OCN-",
    "formatted_formula": "OCN<sup>-</sup>",
    "vietnamese_name": "Ion cyanate"
  },
  {
    "id": "3051",
    "formula": "BO3-",
    "formatted_formula": "BO<sub>3</sub><sup>-</sup>",
    "vietnamese_name": "Ion borat"
  },
  {
    "id": "3052",
    "formula": "SCN-",
    "formatted_formula": "SCN<sup>-</sup>",
    "vietnamese_name": "Ion thiocyanat"
  },
  {
    "id": "3053",
    "formula": "[S2O3]2-",
    "formatted_formula": "[S<sub>2</sub>O<sub>3</sub>]<sup>2-</sup>",
    "vietnamese_name": "Ion thiosunfat"
  },
  {
    "id": "3054",
    "formula": "In(NO3)3.5H2O",
    "formatted_formula": "In(NO<sub>3</sub>)<sub>3</sub>.5H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Indi Nitrat heptahidrat"
  },
  {
    "id": "3055",
    "formula": "In(NO3)O",
    "formatted_formula": "In(NO<sub>3</sub>)O<sup></sup>",
    "vietnamese_name": "Indi(III) nitrat oxit"
  },
  {
    "id": "3056",
    "formula": "In2(SO4)3.9H2O",
    "formatted_formula": "In<sub>2</sub>(SO<sub>4</sub>)<sub>3</sub>.9H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Indi sunfat nonahidrat"
  },
  {
    "id": "3057",
    "formula": "CH3CHClCOOH",
    "formatted_formula": "CH<sub>3</sub>CHClCOOH<sup></sup>",
    "vietnamese_name": "Axit 2-cloropropanoic"
  },
  {
    "id": "3059",
    "formula": "NH2CH2CH2CH2CN",
    "formatted_formula": "NH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>CN<sup></sup>",
    "vietnamese_name": "4-Aminobutyronitrile"
  },
  {
    "id": "3060",
    "formula": "HNCO",
    "formatted_formula": "HNCO<sup></sup>",
    "vietnamese_name": "Isocyanic acid"
  },
  {
    "id": "3061",
    "formula": "CN-",
    "formatted_formula": "CN<sup>-</sup>",
    "vietnamese_name": "Ion xyanua"
  },
  {
    "id": "3062",
    "formula": "Na[Au(CN)2]",
    "formatted_formula": "Na[Au(CN)<sub>2</sub>]<sup></sup>",
    "vietnamese_name": "Natri aurocyanua"
  },
  {
    "id": "3063",
    "formula": "Na[Ag(CN)2]",
    "formatted_formula": "Na[Ag(CN)<sub>2</sub>]<sup></sup>",
    "vietnamese_name": "Natri argentocyanua"
  },
  {
    "id": "3064",
    "formula": "CH2=C(CH3)COOH",
    "formatted_formula": "CH<sub>2</sub>=C(CH<sub>3</sub>)COOH<sup></sup>",
    "vietnamese_name": "Axit methacrylic"
  },
  {
    "id": "3065",
    "formula": "CH2=C(CH3)COOCH3",
    "formatted_formula": "CH<sub>2</sub>=C(CH<sub>3</sub>)COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Methyl methacrylate"
  },
  {
    "id": "3066",
    "formula": "C2H5COOCH3",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Methyl propionate"
  },
  {
    "id": "3067",
    "formula": "(CH3)3CCOOH",
    "formatted_formula": "(CH<sub>3</sub>)<sub>3</sub>CCOOH<sup></sup>",
    "vietnamese_name": "Axit pivalic"
  },
  {
    "id": "3068",
    "formula": "C3H7COOH",
    "formatted_formula": "C<sub>3</sub>H<sub>7</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit butanic"
  },
  {
    "id": "3069",
    "formula": "C3H7CHO",
    "formatted_formula": "C<sub>3</sub>H<sub>7</sub>CHO<sup></sup>",
    "vietnamese_name": "Butanal"
  },
  {
    "id": "3070",
    "formula": "CaZnO2",
    "formatted_formula": "CaZnO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi zincat"
  },
  {
    "id": "3071",
    "formula": "AlO2-",
    "formatted_formula": "AlO<sub>2</sub><sup>-</sup>",
    "vietnamese_name": "Aluminat"
  },
  {
    "id": "3072",
    "formula": "Mg2C3",
    "formatted_formula": "Mg<sub>2</sub>C<sub>3</sub><sup></sup>",
    "vietnamese_name": "Magie cacbua"
  },
  {
    "id": "3073",
    "formula": "C3H4",
    "formatted_formula": "C<sub>3</sub>H<sub>4</sub><sup></sup>",
    "vietnamese_name": "Propadien"
  },
  {
    "id": "3074",
    "formula": "NaKCO3",
    "formatted_formula": "NaKCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri kali cacbonat"
  },
  {
    "id": "3075",
    "formula": "CH3CH(OH)CH2CH3",
    "formatted_formula": "CH<sub>3</sub>CH(OH)CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-butanol"
  },
  {
    "id": "3076",
    "formula": "CH3C(O)CH2CH3",
    "formatted_formula": "CH<sub>3</sub>C(O)CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-Butanone"
  },
  {
    "id": "3077",
    "formula": "C5H11Cl",
    "formatted_formula": "C<sub>5</sub>H<sub>1</sub><sub>1</sub>Cl<sup></sup>",
    "vietnamese_name": "1-Cloropentan"
  },
  {
    "id": "3078",
    "formula": "C5H11Br",
    "formatted_formula": "C<sub>5</sub>H<sub>1</sub><sub>1</sub>Br<sup></sup>",
    "vietnamese_name": "1-bromopentan"
  },
  {
    "id": "3080",
    "formula": "FexOy",
    "formatted_formula": "FexOy<sup></sup>",
    "vietnamese_name": "Oxit sắt"
  },
  {
    "id": "3081",
    "formula": "CHI3",
    "formatted_formula": "CHI<sub>3</sub><sup></sup>",
    "vietnamese_name": "Iodoform"
  },
  {
    "id": "3083",
    "formula": "C7H15Br",
    "formatted_formula": "C<sub>7</sub>H<sub>1</sub><sub>5</sub>Br<sup></sup>",
    "vietnamese_name": "1-Bromoheptan"
  },
  {
    "id": "3084",
    "formula": "C2H2Br2",
    "formatted_formula": "C<sub>2</sub>H<sub>2</sub>Br<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,2-Dibromoethen"
  },
  {
    "id": "3085",
    "formula": "C2H2Br4",
    "formatted_formula": "C<sub>2</sub>H<sub>2</sub>Br<sub>4</sub><sup></sup>",
    "vietnamese_name": "1,1,2,2-Tetrabromoethan"
  },
  {
    "id": "3087",
    "formula": "(CH3)2-N-N=O",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>-N-N=O<sup></sup>",
    "vietnamese_name": "Dimethylnitrosamine"
  },
  {
    "id": "3088",
    "formula": "(CH3)2NH",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>NH<sup></sup>",
    "vietnamese_name": "Dimethylamine"
  },
  {
    "id": "3089",
    "formula": "C6H14O6",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>4</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "sobitol"
  },
  {
    "id": "3090",
    "formula": "C3H5(ONa)3",
    "formatted_formula": "C<sub>3</sub>H<sub>5</sub>(ONa)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Natri glixerat"
  },
  {
    "id": "3091",
    "formula": "C3H7Cl",
    "formatted_formula": "C<sub>3</sub>H<sub>7</sub>Cl<sup></sup>",
    "vietnamese_name": "2-Cloropropan"
  },
  {
    "id": "3092",
    "formula": "PbI2",
    "formatted_formula": "PbI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì iodua"
  },
  {
    "id": "3093",
    "formula": "[C3H5(OH)2O]2Cu",
    "formatted_formula": "[C<sub>3</sub>H<sub>5</sub>(OH)<sub>2</sub>O]<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": "đồng (II) glixerat"
  },
  {
    "id": "3094",
    "formula": "C6H5SO3Na",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>SO<sub>3</sub>Na<sup></sup>",
    "vietnamese_name": "Natri benzenesulfonat"
  },
  {
    "id": "3095",
    "formula": "C4H4",
    "formatted_formula": "C<sub>4</sub>H<sub>4</sub><sup></sup>",
    "vietnamese_name": "Vinylacetylene"
  },
  {
    "id": "3097",
    "formula": "CH2=CH-COONa",
    "formatted_formula": "CH<sub>2</sub>=CH-COONa<sup></sup>",
    "vietnamese_name": "Natri acrylat"
  },
  {
    "id": "3098",
    "formula": "CH2=CH-COOH",
    "formatted_formula": "CH<sub>2</sub>=CH-COOH<sup></sup>",
    "vietnamese_name": "Axit acrylic"
  },
  {
    "id": "3099",
    "formula": "HCOO-CH=CH2",
    "formatted_formula": "HCOO-CH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Vinyl Fomat"
  },
  {
    "id": "3100",
    "formula": "C6H5N2Cl",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>N<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Benzenediazonium chloride"
  },
  {
    "id": "3101",
    "formula": "(C2H4)n",
    "formatted_formula": "(C<sub>2</sub>H<sub>4</sub>)n<sup></sup>",
    "vietnamese_name": "Poly Ethylen"
  },
  {
    "id": "3103",
    "formula": "C4H6Br2",
    "formatted_formula": "C<sub>4</sub>H<sub>6</sub>Br<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,2-Dibromo-1-butene"
  },
  {
    "id": "3104",
    "formula": "C3H4Br4",
    "formatted_formula": "C<sub>3</sub>H<sub>4</sub>Br<sub>4</sub><sup></sup>",
    "vietnamese_name": "1,2,2,3-Tetrabromopropane"
  },
  {
    "id": "3105",
    "formula": "Ba(HSO3)2",
    "formatted_formula": "Ba(HSO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Barium Hydrogen Sulfite"
  },
  {
    "id": "3106",
    "formula": "CuCl2.2H2O",
    "formatted_formula": "CuCl<sub>2</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Đồng(II) clorua dihydrat"
  },
  {
    "id": "3108",
    "formula": "C2H4(ONa)2",
    "formatted_formula": "C<sub>2</sub>H<sub>4</sub>(ONa)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sodium ethylene glycolate"
  },
  {
    "id": "3109",
    "formula": "H2SO4.3SO3",
    "formatted_formula": "H<sub>2</sub>SO<sub>4</sub>.3SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "oleum"
  },
  {
    "id": "3110",
    "formula": "C2H4Cl2",
    "formatted_formula": "C<sub>2</sub>H<sub>4</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,1-Dichloroethane"
  },
  {
    "id": "3111",
    "formula": "C6Cl6",
    "formatted_formula": "C<sub>6</sub>Cl<sub>6</sub><sup></sup>",
    "vietnamese_name": "Hexachlorobenzene"
  },
  {
    "id": "3112",
    "formula": "C4H6Br4",
    "formatted_formula": "C<sub>4</sub>H<sub>6</sub>Br<sub>4</sub><sup></sup>",
    "vietnamese_name": "Butadiene tetrabromide"
  },
  {
    "id": "3113",
    "formula": "C4H6(OH)4",
    "formatted_formula": "C<sub>4</sub>H<sub>6</sub>(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": "Threitol"
  },
  {
    "id": "3114",
    "formula": "Fe(SCN)3",
    "formatted_formula": "Fe(SCN)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Sắt (III) Thiocyanate"
  },
  {
    "id": "3115",
    "formula": "CuS2",
    "formatted_formula": "CuS<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng sulfua"
  },
  {
    "id": "3116",
    "formula": "(CH3COO)2Zn",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>2</sub>Zn<sup></sup>",
    "vietnamese_name": "Kẽm Acetate"
  },
  {
    "id": "3117",
    "formula": "C4H9OH",
    "formatted_formula": "C<sub>4</sub>H<sub>9</sub>OH<sup></sup>",
    "vietnamese_name": "2-Butanol"
  },
  {
    "id": "3118",
    "formula": "C6H5OCH2CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>OCH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ethoxybenzene"
  },
  {
    "id": "3119",
    "formula": "C6H4CH3Br",
    "formatted_formula": "C<sub>6</sub>H<sub>4</sub>CH<sub>3</sub>Br<sup></sup>",
    "vietnamese_name": "2-Bromotoluene"
  },
  {
    "id": "3120",
    "formula": "C6H4CH3ONa",
    "formatted_formula": "C<sub>6</sub>H<sub>4</sub>CH<sub>3</sub>ONa<sup></sup>",
    "vietnamese_name": "Natri 2-methylphenolat"
  },
  {
    "id": "3121",
    "formula": "P2H4",
    "formatted_formula": "P<sub>2</sub>H<sub>4</sub><sup></sup>",
    "vietnamese_name": "Diphosphane"
  },
  {
    "id": "3122",
    "formula": "H2SO4.2SO3",
    "formatted_formula": "H<sub>2</sub>SO<sub>4</sub>.2SO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Oleum"
  },
  {
    "id": "3126",
    "formula": "[Ag(NH3)6]3PO4",
    "formatted_formula": "[Ag(NH<sub>3</sub>)<sub>6</sub>]<sub>3</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Silver ammonium phosphate"
  },
  {
    "id": "3127",
    "formula": "(CH3COO)3Fe",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>3</sub>Fe<sup></sup>",
    "vietnamese_name": "Sắt (III) axetat"
  },
  {
    "id": "3128",
    "formula": "HOCH2(CHOH)4COONH4",
    "formatted_formula": "HOCH<sub>2</sub>(CHOH)<sub>4</sub>COONH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni gluconat"
  },
  {
    "id": "3129",
    "formula": "OHCH2(CHOH)4COOH",
    "formatted_formula": "OHCH<sub>2</sub>(CHOH)<sub>4</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit gluconic"
  },
  {
    "id": "3130",
    "formula": "C6H5CH(CH3)2",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH(CH<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "isopropylbenzen, cumen"
  },
  {
    "id": "3133",
    "formula": "Ca5F(PO4)3",
    "formatted_formula": "Ca<sub>5</sub>F(PO<sub>4</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Fluorapatite"
  },
  {
    "id": "3134",
    "formula": "(C2H5)2O",
    "formatted_formula": "(C<sub>2</sub>H<sub>5</sub>)<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Diethyl ether"
  },
  {
    "id": "3136",
    "formula": "Ba(COO)2",
    "formatted_formula": "Ba(COO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari oxalat"
  },
  {
    "id": "3137",
    "formula": "Ca(COO)2",
    "formatted_formula": "Ca(COO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Canxi Oxalat"
  },
  {
    "id": "3138",
    "formula": "Sr(COO)2",
    "formatted_formula": "Sr(COO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Stronti oxalat"
  },
  {
    "id": "3139",
    "formula": "BaBr2",
    "formatted_formula": "BaBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari bromua"
  },
  {
    "id": "3140",
    "formula": "CH2BrCHBrCH2OH",
    "formatted_formula": "CH<sub>2</sub>BrCHBrCH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "2,3-dibromopropanol"
  },
  {
    "id": "3141",
    "formula": "CH2=CHCH2OH",
    "formatted_formula": "CH<sub>2</sub>=CHCH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Allyl alcohol"
  },
  {
    "id": "3142",
    "formula": "CH3CH2CH2NH2",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Propylamin"
  },
  {
    "id": "3143",
    "formula": "CH3CH2CH2NH3+Cl-",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>NH<sub>3</sub>+Cl-<sup></sup>",
    "vietnamese_name": "propylammonium chloride"
  },
  {
    "id": "3144",
    "formula": "H2NCH2COOCH3",
    "formatted_formula": "H<sub>2</sub>NCH<sub>2</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Glycine methyl"
  },
  {
    "id": "3145",
    "formula": "HOOC(CH2)4COOH",
    "formatted_formula": "HOOC(CH<sub>2</sub>)<sub>4</sub>COOH<sup></sup>",
    "vietnamese_name": "Axid Adipic"
  },
  {
    "id": "3146",
    "formula": "NaOOC(CH2)4COONa",
    "formatted_formula": "NaOOC(CH<sub>2</sub>)<sub>4</sub>COONa<sup></sup>",
    "vietnamese_name": "Dinatri adipat"
  },
  {
    "id": "3147",
    "formula": "(HOC6H3CH2)n",
    "formatted_formula": "(HOC<sub>6</sub>H<sub>3</sub>CH<sub>2</sub>)n<sup></sup>",
    "vietnamese_name": "Nhựa Novolac"
  },
  {
    "id": "3148",
    "formula": "(C2H5O)2Mg",
    "formatted_formula": "(C<sub>2</sub>H<sub>5</sub>O)<sub>2</sub>Mg<sup></sup>",
    "vietnamese_name": "Magnesium diethoxide"
  },
  {
    "id": "3149",
    "formula": "CxHy",
    "formatted_formula": "CxHy<sup></sup>",
    "vietnamese_name": "Hidrocacbon"
  },
  {
    "id": "3150",
    "formula": "CCl3CHO",
    "formatted_formula": "CCl<sub>3</sub>CHO<sup></sup>",
    "vietnamese_name": "Chloral"
  },
  {
    "id": "3151",
    "formula": "(NH4)2[Hg(SCN)4]",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>[Hg(SCN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Mercury(II) Ammonium Thiocyanate"
  },
  {
    "id": "3152",
    "formula": "Zn[Hg(SCN)4]",
    "formatted_formula": "Zn[Hg(SCN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Mercury(II) zinc thiocyanate"
  },
  {
    "id": "3154",
    "formula": "fecl2y/x",
    "formatted_formula": "fecl<sub>2</sub>y/x<sup></sup>",
    "vietnamese_name": "Sắt clorua"
  },
  {
    "id": "3155",
    "formula": "C15H31COONa",
    "formatted_formula": "C<sub>1</sub><sub>5</sub>H<sub>3</sub><sub>1</sub>COONa<sup></sup>",
    "vietnamese_name": "Natri palmitat"
  },
  {
    "id": "3156",
    "formula": "(C15H31COO)3C3H5",
    "formatted_formula": "(C<sub>1</sub><sub>5</sub>H<sub>3</sub><sub>1</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Tripalmitin"
  },
  {
    "id": "3157",
    "formula": "Al4C3",
    "formatted_formula": "Al<sub>4</sub>C<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nhôm Cacbua"
  },
  {
    "id": "3158",
    "formula": "OF2",
    "formatted_formula": "OF<sub>2</sub><sup></sup>",
    "vietnamese_name": "Oxygen difluoride"
  },
  {
    "id": "3159",
    "formula": "Sb2O5",
    "formatted_formula": "Sb<sub>2</sub>O<sub>5</sub><sup></sup>",
    "vietnamese_name": "Antimony pentoxide"
  },
  {
    "id": "3160",
    "formula": "BP",
    "formatted_formula": "BP<sup></sup>",
    "vietnamese_name": "Boron phosphide"
  },
  {
    "id": "3161",
    "formula": "NaFeO2",
    "formatted_formula": "NaFeO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sodium ferrite"
  },
  {
    "id": "3162",
    "formula": "H4P2O6.2H2O",
    "formatted_formula": "H<sub>4</sub>P<sub>2</sub>O<sub>6</sub>.2H<sub>2</sub>O<sup></sup>",
    "vietnamese_name": "Hypophosphoric acid dihydrate"
  },
  {
    "id": "3163",
    "formula": "C3H5O9N3",
    "formatted_formula": "C<sub>3</sub>H<sub>5</sub>O<sub>9</sub>N<sub>3</sub><sup></sup>",
    "vietnamese_name": "Nitroglycerine"
  },
  {
    "id": "3164",
    "formula": "(C6H10O5)n",
    "formatted_formula": "(C<sub>6</sub>H<sub>1</sub><sub>0</sub>O<sub>5</sub>)n<sup></sup>",
    "vietnamese_name": "Polysaccharid"
  },
  {
    "id": "3166",
    "formula": "(CH3COO)2C2H4",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>2</sub>C<sub>2</sub>H<sub>4</sub><sup></sup>",
    "vietnamese_name": "etylenglicol diaxetat"
  },
  {
    "id": "3167",
    "formula": "CxHy(COOH)2",
    "formatted_formula": "CxHy(COOH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Axit hữu cơ"
  },
  {
    "id": "3168",
    "formula": "CH2=CH-CH=CH2",
    "formatted_formula": "CH<sub>2</sub>=CH-CH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "buta-1,3-dien"
  },
  {
    "id": "3169",
    "formula": "(C2H3Cl)n",
    "formatted_formula": "(C<sub>2</sub>H<sub>3</sub>Cl)n<sup></sup>",
    "vietnamese_name": "polyvinyl clorua"
  },
  {
    "id": "3170",
    "formula": "CBrCl3",
    "formatted_formula": "CBrCl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bromotrichloromethane"
  },
  {
    "id": "3171",
    "formula": "Ag4P2O7",
    "formatted_formula": "Ag<sub>4</sub>P<sub>2</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Silver diphosphate"
  },
  {
    "id": "3172",
    "formula": "BaS4O6",
    "formatted_formula": "BaS<sub>4</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Barium Tetrathionate"
  },
  {
    "id": "3174",
    "formula": "HgO.Hg(NH2)I",
    "formatted_formula": "HgO.Hg(NH<sub>2</sub>)I<sup></sup>",
    "vietnamese_name": "Basic mercury (II) amido-iodine"
  },
  {
    "id": "3175",
    "formula": "NH2.Hg2I3",
    "formatted_formula": "NH<sub>2</sub>.Hg<sub>2</sub>I<sub>3</sub><sup></sup>",
    "vietnamese_name": "Mercure (II) amido-iodine"
  },
  {
    "id": "3177",
    "formula": "NxOy",
    "formatted_formula": "NxOy<sup></sup>",
    "vietnamese_name": "Oxit Nito"
  },
  {
    "id": "3178",
    "formula": "MgSO3",
    "formatted_formula": "MgSO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Magne sulfit"
  },
  {
    "id": "3179",
    "formula": "Mg3(BO3)2",
    "formatted_formula": "Mg<sub>3</sub>(BO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Magne borat"
  },
  {
    "id": "3180",
    "formula": "H2B4O7",
    "formatted_formula": "H<sub>2</sub>B<sub>4</sub>O<sub>7</sub><sup></sup>",
    "vietnamese_name": "Acid pyroboric"
  },
  {
    "id": "3182",
    "formula": "MgNH4PO4",
    "formatted_formula": "MgNH<sub>4</sub>PO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Ammonium magnesium phosphate"
  },
  {
    "id": "3184",
    "formula": "K2MnF6",
    "formatted_formula": "K<sub>2</sub>MnF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Potassium hexafluoromanganate"
  },
  {
    "id": "3185",
    "formula": "MnF3",
    "formatted_formula": "MnF<sub>3</sub><sup></sup>",
    "vietnamese_name": "Manganese(III) fluoride"
  },
  {
    "id": "3186",
    "formula": "KSbF6",
    "formatted_formula": "KSbF<sub>6</sub><sup></sup>",
    "vietnamese_name": "Potassium hexafluoroantimonate"
  },
  {
    "id": "3187",
    "formula": "NaSCN",
    "formatted_formula": "NaSCN<sup></sup>",
    "vietnamese_name": "Sodium thiocyanate"
  },
  {
    "id": "3188",
    "formula": "Cr(OH)SO4",
    "formatted_formula": "Cr(OH)SO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Chromium hydroxide sulfate"
  },
  {
    "id": "3190",
    "formula": "C6H11O7Na",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>O<sub>7</sub>Na<sup></sup>",
    "vietnamese_name": "Gluconic acid sodium"
  },
  {
    "id": "3191",
    "formula": "FePO4",
    "formatted_formula": "FePO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Iron(III) phosphate"
  },
  {
    "id": "3192",
    "formula": "CH2(Br)-CH(Br)-CH3",
    "formatted_formula": "CH<sub>2</sub>(Br)-CH(Br)-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1,2-Dibrompropan"
  },
  {
    "id": "3193",
    "formula": "CH2OH-CHOH-CH3",
    "formatted_formula": "CH<sub>2</sub>OH-CHOH-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Propylene Glycol"
  },
  {
    "id": "3194",
    "formula": "CH2Br-CH2-CHBr2",
    "formatted_formula": "CH<sub>2</sub>Br-CH<sub>2</sub>-CHBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,1,3-Tribromopropane"
  },
  {
    "id": "3195",
    "formula": "CHBr2-CHBr-CH3",
    "formatted_formula": "CHBr<sub>2</sub>-CHBr-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1,1,2-Tribromopropane"
  },
  {
    "id": "3196",
    "formula": "CH3-CH2-CBr3",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CBr<sub>3</sub><sup></sup>",
    "vietnamese_name": "1,1,1-Tribromopropan"
  },
  {
    "id": "3197",
    "formula": "CH2OH-CH2-CHO",
    "formatted_formula": "CH<sub>2</sub>OH-CH<sub>2</sub>-CHO<sup></sup>",
    "vietnamese_name": "3-Hydroxypropionaldehyde"
  },
  {
    "id": "3198",
    "formula": "CH3-CHOH-CHO",
    "formatted_formula": "CH<sub>3</sub>-CHOH-CHO<sup></sup>",
    "vietnamese_name": "Lactaldehyde"
  },
  {
    "id": "3199",
    "formula": "Ca(OCl)2",
    "formatted_formula": "Ca(OCl)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Calcium hypochlorite"
  },
  {
    "id": "3200",
    "formula": "ZnI2",
    "formatted_formula": "ZnI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Zinc iodide"
  },
  {
    "id": "3201",
    "formula": "HCOONH3CH3",
    "formatted_formula": "HCOONH<sub>3</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metylamoni format"
  },
  {
    "id": "3202",
    "formula": "Ba(MnO4)2",
    "formatted_formula": "Ba(MnO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari Permanganat"
  },
  {
    "id": "3203",
    "formula": "Ag2S2O3",
    "formatted_formula": "Ag<sub>2</sub>S<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "Bạc thiosulphat"
  },
  {
    "id": "3204",
    "formula": "(NH4)2MoO4",
    "formatted_formula": "(NH<sub>4</sub>)<sub>2</sub>MoO<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni Molybdat (VI)"
  },
  {
    "id": "3205",
    "formula": "MoCl2",
    "formatted_formula": "MoCl<sub>2</sub><sup></sup>",
    "vietnamese_name": "Molybdenum dichloride"
  },
  {
    "id": "3206",
    "formula": "PbBr2",
    "formatted_formula": "PbBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Lead dibromide"
  },
  {
    "id": "3207",
    "formula": "CnH2nBr2",
    "formatted_formula": "CnH<sub>2</sub>nBr<sub>2</sub><sup></sup>",
    "vietnamese_name": "Dibromide"
  },
  {
    "id": "3208",
    "formula": "CuI2",
    "formatted_formula": "CuI<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng(II) Iodua"
  },
  {
    "id": "3209",
    "formula": "(NH2CO)2NH",
    "formatted_formula": "(NH<sub>2</sub>CO)<sub>2</sub>NH<sup></sup>",
    "vietnamese_name": "Biuret"
  },
  {
    "id": "3210",
    "formula": "Ca5(PO4)3F",
    "formatted_formula": "Ca<sub>5</sub>(PO<sub>4</sub>)<sub>3</sub>F<sup></sup>",
    "vietnamese_name": "Apatite"
  },
  {
    "id": "3211",
    "formula": "AAC",
    "formatted_formula": "AAC<sup></sup>",
    "vietnamese_name": "AA"
  },
  {
    "id": "3212",
    "formula": "Sn(NO3)2",
    "formatted_formula": "Sn(NO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Thiếc(II) Nitrat"
  },
  {
    "id": "3213",
    "formula": "CH3CH2CHO",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CHO<sup></sup>",
    "vietnamese_name": "Propanal"
  },
  {
    "id": "3214",
    "formula": "C4H5Cl",
    "formatted_formula": "C<sub>4</sub>H<sub>5</sub>Cl<sup></sup>",
    "vietnamese_name": "Clopren"
  },
  {
    "id": "3215",
    "formula": "NH2CH2COOH",
    "formatted_formula": "NH<sub>2</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Glycine "
  },
  {
    "id": "3216",
    "formula": "ClNH3CH2COOH",
    "formatted_formula": "ClNH<sub>3</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Acid Aminoacetic"
  },
  {
    "id": "3217",
    "formula": "NH2CH2COONa",
    "formatted_formula": "NH<sub>2</sub>CH<sub>2</sub>COONa<sup></sup>",
    "vietnamese_name": "Glycine sodium salt"
  },
  {
    "id": "3219",
    "formula": "CH3CH(NH2)COOC2H5",
    "formatted_formula": "CH<sub>3</sub>CH(NH<sub>2</sub>)COOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "2-Aminopropionic acid ethyl ester"
  },
  {
    "id": "3220",
    "formula": "C3H5Cl",
    "formatted_formula": "C<sub>3</sub>H<sub>5</sub>Cl<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3221",
    "formula": "CH3CHCH2Cl",
    "formatted_formula": "CH<sub>3</sub>CHCH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Allyl chloride"
  },
  {
    "id": "3222",
    "formula": "C6H5CH2ONa",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH<sub>2</sub>ONa<sup></sup>",
    "vietnamese_name": "Natri benzyloxid"
  },
  {
    "id": "3223",
    "formula": "C6H5NH3NO3 ",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>NH<sub>3</sub>NO<sub>3</sub> <sup></sup>",
    "vietnamese_name": "Anilinium nitrate"
  },
  {
    "id": "3224",
    "formula": "(NH4)3PO4.12MoO3",
    "formatted_formula": "(NH<sub>4</sub>)<sub>3</sub>PO<sub>4</sub>.12MoO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ammonium molybdophosphate"
  },
  {
    "id": "3225",
    "formula": "Na2CrO2",
    "formatted_formula": "Na<sub>2</sub>CrO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Sodium Hypochromite"
  },
  {
    "id": "3226",
    "formula": "CH3OCS2K",
    "formatted_formula": "CH<sub>3</sub>OCS<sub>2</sub>K<sup></sup>",
    "vietnamese_name": "Kaliummethylxanthogenat"
  },
  {
    "id": "3227",
    "formula": "CH3COONH3C6H5",
    "formatted_formula": "CH<sub>3</sub>COONH<sub>3</sub>C<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Acetic acid aniline salt"
  },
  {
    "id": "3228",
    "formula": "2PbCO3.Pb(OH)2",
    "formatted_formula": "<sub>2</sub>PbCO<sub>3</sub>.Pb(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Basic Lead Carbonate"
  },
  {
    "id": "3229",
    "formula": "Pb(BF4)2",
    "formatted_formula": "Pb(BF<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Chì(II) tetrafluoroborat"
  },
  {
    "id": "3230",
    "formula": "CH2BrCHBrCHCH2",
    "formatted_formula": "CH<sub>2</sub>BrCHBrCHCH<sub>2</sub><sup></sup>",
    "vietnamese_name": "3,4-Dibromo-1-butene"
  },
  {
    "id": "3231",
    "formula": "CH3CHClCH3",
    "formatted_formula": "CH<sub>3</sub>CHClCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-Chloropropane"
  },
  {
    "id": "3232",
    "formula": "OHCH2-CH(CH3)O-Cu-OH(CH3)C-CH2OH",
    "formatted_formula": "OHCH<sub>2</sub>-CH(CH<sub>3</sub>)O-Cu-OH(CH<sub>3</sub>)C-CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Đồng (II) propyleneglycolat"
  },
  {
    "id": "3235",
    "formula": "CH3COO-",
    "formatted_formula": "CH<sub>3</sub>COO<sup>-</sup>",
    "vietnamese_name": "Ion acetat"
  },
  {
    "id": "3236",
    "formula": "H2PO4-",
    "formatted_formula": "H<sub>2</sub>PO<sub>4</sub><sup>-</sup>",
    "vietnamese_name": "Ion dihidro phosphat"
  },
  {
    "id": "3237",
    "formula": "HPO42−",
    "formatted_formula": "HPO<sub>4</sub><sup>2−</sup>",
    "vietnamese_name": "Ion hidro phosphat"
  },
  {
    "id": "3238",
    "formula": "PO43−",
    "formatted_formula": "PO<sub>4</sub><sup>3−</sup>",
    "vietnamese_name": "Ion phosphat"
  },
  {
    "id": "3240",
    "formula": "ZnO22-",
    "formatted_formula": "ZnO<sub>2</sub><sup>2-</sup>",
    "vietnamese_name": "Ion kẽm peroxid"
  },
  {
    "id": "3242",
    "formula": "P2S3",
    "formatted_formula": "P<sub>2</sub>S<sub>3</sub><sup></sup>",
    "vietnamese_name": "diphotpho trisunfua"
  },
  {
    "id": "3243",
    "formula": "C6H14",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>4</sub><sup></sup>",
    "vietnamese_name": "Hexan"
  },
  {
    "id": "3244",
    "formula": "C4H10O",
    "formatted_formula": "C<sub>4</sub>H<sub>1</sub><sub>0</sub>O<sup></sup>",
    "vietnamese_name": "N-Butanol"
  },
  {
    "id": "3245",
    "formula": "C7H14",
    "formatted_formula": "C<sub>7</sub>H<sub>1</sub><sub>4</sub><sup></sup>",
    "vietnamese_name": "hept-1-en"
  },
  {
    "id": "3246",
    "formula": "C8H16",
    "formatted_formula": "C<sub>8</sub>H<sub>1</sub><sub>6</sub><sup></sup>",
    "vietnamese_name": "oct-1-en"
  },
  {
    "id": "3247",
    "formula": "N",
    "formatted_formula": "N<sup></sup>",
    "vietnamese_name": "nitơ"
  },
  {
    "id": "3248",
    "formula": "C2H3Cl3",
    "formatted_formula": "C<sub>2</sub>H<sub>3</sub>Cl<sub>3</sub><sup></sup>",
    "vietnamese_name": "Vinyl trichloride"
  },
  {
    "id": "3249",
    "formula": "SCl2O",
    "formatted_formula": "SCl<sub>2</sub>O<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3250",
    "formula": "C6H6O",
    "formatted_formula": "C<sub>6</sub>H<sub>6</sub>O<sup></sup>",
    "vietnamese_name": "Phenol"
  },
  {
    "id": "3251",
    "formula": "Cu3P2",
    "formatted_formula": "Cu<sub>3</sub>P<sub>2</sub><sup></sup>",
    "vietnamese_name": "Đồng II photphua"
  },
  {
    "id": "3252",
    "formula": "MnO4",
    "formatted_formula": "MnO<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3253",
    "formula": "KCrO4",
    "formatted_formula": "KCrO<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3254",
    "formula": "CrO5",
    "formatted_formula": "CrO<sub>5</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3255",
    "formula": "H[CuCl2]",
    "formatted_formula": "H[CuCl<sub>2</sub>]<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3256",
    "formula": "AlCO3",
    "formatted_formula": "AlCO<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3258",
    "formula": "C6H5CHNC6H5",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CHNC<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "benzanalin"
  },
  {
    "id": "3259",
    "formula": "CH3COOC6H5COOH",
    "formatted_formula": "CH<sub>3</sub>COOC<sub>6</sub>H<sub>5</sub>COOH<sup></sup>",
    "vietnamese_name": "Aspirin"
  },
  {
    "id": "3260",
    "formula": "OHC6H5COOH",
    "formatted_formula": "OHC<sub>6</sub>H<sub>5</sub>COOH<sup></sup>",
    "vietnamese_name": "axit salicylic"
  },
  {
    "id": "3265",
    "formula": "HONO",
    "formatted_formula": "HONO<sup></sup>",
    "vietnamese_name": "axit nitro"
  },
  {
    "id": "3266",
    "formula": "CH3[CH2]7CH=CH[CH2]7COOCH3",
    "formatted_formula": "CH<sub>3</sub>[CH<sub>2</sub>]<sub>7</sub>CH=CH[CH<sub>2</sub>]<sub>7</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "metyl oleat"
  },
  {
    "id": "3267",
    "formula": "CH3[CH2]16COOCH3",
    "formatted_formula": "CH<sub>3</sub>[CH<sub>2</sub>]<sub>1</sub><sub>6</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "metyl stearat"
  },
  {
    "id": "3269",
    "formula": "(CH3)2CHCH2CH2OH",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>CHCH<sub>2</sub>CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "ancol isoamylic"
  },
  {
    "id": "3270",
    "formula": "CH3COOCH2CH2CH(CH3)2",
    "formatted_formula": "CH<sub>3</sub>COOCH<sub>2</sub>CH<sub>2</sub>CH(CH<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "isoamyl axetat"
  },
  {
    "id": "3274",
    "formula": "R - COO - R'",
    "formatted_formula": "R - COO - R'<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3275",
    "formula": "[C6H7O2(ONO2)3]n",
    "formatted_formula": "[C<sub>6</sub>H<sub>7</sub>O<sub>2</sub>(ONO<sub>2</sub>)<sub>3</sub>]n<sup></sup>",
    "vietnamese_name": "xenlulozo trinitrat"
  },
  {
    "id": "3284",
    "formula": "Ba(H2PO4)2",
    "formatted_formula": "Ba(H<sub>2</sub>PO<sub>4</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Bari dihydrogen phosphate"
  },
  {
    "id": "3285",
    "formula": "K[Ag(CN)2]",
    "formatted_formula": "K[Ag(CN)<sub>2</sub>]<sup></sup>",
    "vietnamese_name": "Kali Dixiano Acgentat (I)"
  },
  {
    "id": "3286",
    "formula": "K[Au(CN)2]",
    "formatted_formula": "K[Au(CN)<sub>2</sub>]<sup></sup>",
    "vietnamese_name": "Kali Vàng Xyanua,  Muối Vàng"
  },
  {
    "id": "3287",
    "formula": "(CH3COO)2Pb",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>2</sub>Pb<sup></sup>",
    "vietnamese_name": "chì diacetate"
  },
  {
    "id": "3288",
    "formula": "NH4OCOOCH3",
    "formatted_formula": "NH<sub>4</sub>OCOOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3289",
    "formula": "Mn(OH)4",
    "formatted_formula": "Mn(OH)<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3291",
    "formula": "Cu2O3",
    "formatted_formula": "Cu<sub>2</sub>O<sub>3</sub><sup></sup>",
    "vietnamese_name": "đồng oxit"
  },
  {
    "id": "3298",
    "formula": "CH3MgI",
    "formatted_formula": "CH<sub>3</sub>MgI<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3299",
    "formula": "CH3CH2CH2CH2CN",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>CN<sup></sup>",
    "vietnamese_name": "1-bromopropan"
  },
  {
    "id": "3301",
    "formula": "CH3CH2OCH3",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>OCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "methoxy etan"
  },
  {
    "id": "3302",
    "formula": "CH3CH2I",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>I<sup></sup>",
    "vietnamese_name": "iodoetan"
  },
  {
    "id": "3307",
    "formula": "CH3CH2CH2Cl",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "1-clopropan"
  },
  {
    "id": "3309",
    "formula": "1,2-C6H4(OH)2",
    "formatted_formula": "<sub>1</sub>,<sub>2</sub>-C<sub>6</sub>H<sub>4</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Catechol"
  },
  {
    "id": "3310",
    "formula": "o-CH3C6H4OH",
    "formatted_formula": "o-CH<sub>3</sub>C<sub>6</sub>H<sub>4</sub>OH<sup></sup>",
    "vietnamese_name": "o-crezol"
  },
  {
    "id": "3312",
    "formula": "(CH3)3COH",
    "formatted_formula": "(CH<sub>3</sub>)<sub>3</sub>COH<sup></sup>",
    "vietnamese_name": "ancol tert-butylic"
  },
  {
    "id": "3313",
    "formula": "HCOOCH = CH2",
    "formatted_formula": "HCOOCH = CH<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3314",
    "formula": "(C6H11O6)2Cu",
    "formatted_formula": "(C<sub>6</sub>H<sub>1</sub><sub>1</sub>O<sub>6</sub>)<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": "phức đồng - glucozo"
  },
  {
    "id": "3315",
    "formula": "KI",
    "formatted_formula": "KI<sup></sup>",
    "vietnamese_name": "kali iodua"
  },
  {
    "id": "3316",
    "formula": "protein",
    "formatted_formula": "protein<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3317",
    "formula": "amino axit",
    "formatted_formula": "amino axit<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3318",
    "formula": "(C6H11O6)2Cu",
    "formatted_formula": "(C<sub>6</sub>H<sub>1</sub><sub>1</sub>O<sub>6</sub>)<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": "phức đồng-glucozo"
  },
  {
    "id": "3319",
    "formula": "(C12H22O11)2Cu",
    "formatted_formula": "(C<sub>1</sub><sub>2</sub>H<sub>2</sub><sub>2</sub>O<sub>1</sub><sub>1</sub>)<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": "phức đồng saccarozo"
  },
  {
    "id": "3320",
    "formula": "C12H22O11",
    "formatted_formula": "C<sub>1</sub><sub>2</sub>H<sub>2</sub><sub>2</sub>O<sub>1</sub><sub>1</sub><sup></sup>",
    "vietnamese_name": "saccarozo"
  },
  {
    "id": "3322",
    "formula": "C15H35COOH",
    "formatted_formula": "C<sub>1</sub><sub>5</sub>H<sub>3</sub><sub>5</sub>COOH<sup></sup>",
    "vietnamese_name": "axit stearic"
  },
  {
    "id": "3323",
    "formula": "C3H5(OH)3",
    "formatted_formula": "C<sub>3</sub>H<sub>5</sub>(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": "glixerol"
  },
  {
    "id": "3324",
    "formula": " (C17H31COO)3C3H5",
    "formatted_formula": " (C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>1</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "trilinolein"
  },
  {
    "id": "3325",
    "formula": "C17H31COOH",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>1</sub>COOH<sup></sup>",
    "vietnamese_name": "axit linoleic"
  },
  {
    "id": "3326",
    "formula": "(C17H31COO)3C3H5",
    "formatted_formula": "(C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>1</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3327",
    "formula": "C2H4O2",
    "formatted_formula": "C<sub>2</sub>H<sub>4</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3328",
    "formula": "CH2OH(CHOH)4COONH4",
    "formatted_formula": "CH<sub>2</sub>OH(CHOH)<sub>4</sub>COONH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni gluconat"
  },
  {
    "id": "3329",
    "formula": "CH3COO-C6H4 -COOH",
    "formatted_formula": "CH<sub>3</sub>COO-C<sub>6</sub>H<sub>4</sub> -COOH<sup></sup>",
    "vietnamese_name": "axit axetylsalixylic"
  },
  {
    "id": "3330",
    "formula": "CH3COOK",
    "formatted_formula": "CH<sub>3</sub>COOK<sup></sup>",
    "vietnamese_name": "kali axetat"
  },
  {
    "id": "3331",
    "formula": "KOC6H4 -COOH",
    "formatted_formula": "KOC<sub>6</sub>H<sub>4</sub> -COOH<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3332",
    "formula": " CH3CH2CH2CH2COOH",
    "formatted_formula": " CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit pentanoic"
  },
  {
    "id": "3333",
    "formula": "CH3CH2CH2CH2COONa",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>COONa<sup></sup>",
    "vietnamese_name": "natri pentanat"
  },
  {
    "id": "3334",
    "formula": "C6H5-CH=CH2",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Stiren"
  },
  {
    "id": "3335",
    "formula": "C6H5-CHBr-CH2Br",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CHBr-CH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "(1,2-dibromoethyl)benzen (1,2-Dibromophenylethane)"
  },
  {
    "id": "3336",
    "formula": "CnH2n-2",
    "formatted_formula": "CnH<sub>2</sub>n-<sub>2</sub><sup></sup>",
    "vietnamese_name": "ankadien"
  },
  {
    "id": "3337",
    "formula": "CnH2n +3N",
    "formatted_formula": "CnH<sub>2</sub>n +<sub>3</sub>N<sup></sup>",
    "vietnamese_name": "Amin đơn chức no"
  },
  {
    "id": "3338",
    "formula": "CH3CH2COOH=CH2",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>COOH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3339",
    "formula": "CH3CH2COONa",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>COONa<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3340",
    "formula": "Na[Al(OH)4]",
    "formatted_formula": "Na[Al(OH)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Natri aluminat"
  },
  {
    "id": "3341",
    "formula": "C4H9F",
    "formatted_formula": "C<sub>4</sub>H<sub>9</sub>F<sup></sup>",
    "vietnamese_name": "1-florobutan"
  },
  {
    "id": "3342",
    "formula": "HCOO - C6H4 – CH2 – OOCH ",
    "formatted_formula": "HCOO - C<sub>6</sub>H<sub>4</sub> – CH<sub>2</sub> – OOCH <sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3343",
    "formula": "NaO – C6H4 – CH2OH ",
    "formatted_formula": "NaO – C<sub>6</sub>H<sub>4</sub> – CH<sub>2</sub>OH <sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3344",
    "formula": "HO – C6H4 – CH2OH",
    "formatted_formula": "HO – C<sub>6</sub>H<sub>4</sub> – CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3345",
    "formula": "HCOO - C6H4 – CH2 – OOCH ",
    "formatted_formula": "HCOO - C<sub>6</sub>H<sub>4</sub> – CH<sub>2</sub> – OOCH <sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3346",
    "formula": "Na4C",
    "formatted_formula": "Na<sub>4</sub>C<sup></sup>",
    "vietnamese_name": "Natri cacbua"
  },
  {
    "id": "3347",
    "formula": "(C17H35COO)2Ca",
    "formatted_formula": "(C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>5</sub>COO)<sub>2</sub>Ca<sup></sup>",
    "vietnamese_name": "canxi stearat"
  },
  {
    "id": "3348",
    "formula": "C2H5OH",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OH<sup></sup>",
    "vietnamese_name": "rượu etylic"
  },
  {
    "id": "3350",
    "formula": "CH2OH[CHOH]4COONH4",
    "formatted_formula": "CH<sub>2</sub>OH[CHOH]<sub>4</sub>COONH<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3351",
    "formula": "CH3COOCH3",
    "formatted_formula": "CH<sub>3</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "metyl axetat"
  },
  {
    "id": "3352",
    "formula": "CH3COONa",
    "formatted_formula": "CH<sub>3</sub>COONa<sup></sup>",
    "vietnamese_name": "natri axetat"
  },
  {
    "id": "3353",
    "formula": "CH3COONa ",
    "formatted_formula": "CH<sub>3</sub>COONa <sup></sup>",
    "vietnamese_name": "Natri axetat"
  },
  {
    "id": "3354",
    "formula": "C6H5ONa ",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>ONa <sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3355",
    "formula": "C6H5COOCH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "metyl benzoat"
  },
  {
    "id": "3356",
    "formula": "C6H5COONa",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COONa<sup></sup>",
    "vietnamese_name": "Natri benzoat"
  },
  {
    "id": "3357",
    "formula": "(C17H35COO)3C3H5",
    "formatted_formula": "(C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>5</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Tristearin"
  },
  {
    "id": "3358",
    "formula": "C17H35COONa ",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>5</sub>COONa <sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3359",
    "formula": "C3H5(OH)3",
    "formatted_formula": "C<sub>3</sub>H<sub>5</sub>(OH)<sub>3</sub><sup></sup>",
    "vietnamese_name": " glyxerol"
  },
  {
    "id": "3360",
    "formula": "HCOONH3CH2CH3",
    "formatted_formula": "HCOONH<sub>3</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3362",
    "formula": "CH3CH2NH2",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "etyl amin"
  },
  {
    "id": "3364",
    "formula": "Al",
    "formatted_formula": "Al<sup></sup>",
    "vietnamese_name": "nhôm"
  },
  {
    "id": "3365",
    "formula": "O2",
    "formatted_formula": "O<sub>2</sub><sup></sup>",
    "vietnamese_name": "oxi"
  },
  {
    "id": "3366",
    "formula": " (C12H21O11)2Cu",
    "formatted_formula": " (C<sub>1</sub><sub>2</sub>H<sub>2</sub><sub>1</sub>O<sub>1</sub><sub>1</sub>)<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": "phức hợp đồng saccarozo"
  },
  {
    "id": "3367",
    "formula": "(CH3NH3)2CO3",
    "formatted_formula": "(CH<sub>3</sub>NH<sub>3</sub>)<sub>2</sub>CO<sub>3</sub><sup></sup>",
    "vietnamese_name": "metylamoni cacbonat"
  },
  {
    "id": "3368",
    "formula": "Cu(HCO3)2",
    "formatted_formula": "Cu(HCO<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "đồng hidrocacbonat"
  },
  {
    "id": "3369",
    "formula": "C2H5COOCH=CH2",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COOCH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "vinyl propionat"
  },
  {
    "id": "3370",
    "formula": "C3H6O2",
    "formatted_formula": "C<sub>3</sub>H<sub>6</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3371",
    "formula": "C2H5COOC6H5",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COOC<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "benzyl propionat"
  },
  {
    "id": "3372",
    "formula": "C2H5COONa",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COONa<sup></sup>",
    "vietnamese_name": "natri propionat"
  },
  {
    "id": "3373",
    "formula": "C6H5ONa",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>ONa<sup></sup>",
    "vietnamese_name": "natri phenolat"
  },
  {
    "id": "3374",
    "formula": "CH3COOCH2CH2OOCH",
    "formatted_formula": "CH<sub>3</sub>COOCH<sub>2</sub>CH<sub>2</sub>OOCH<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3375",
    "formula": "HCOOCH = CH2",
    "formatted_formula": "HCOOCH = CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "vinyl fomat"
  },
  {
    "id": "3376",
    "formula": "C3H6Br2",
    "formatted_formula": "C<sub>3</sub>H<sub>6</sub>Br<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,2-Dibromopropan"
  },
  {
    "id": "3377",
    "formula": "CH2(CHO)2",
    "formatted_formula": "CH<sub>2</sub>(CHO)<sub>2</sub><sup></sup>",
    "vietnamese_name": "andehit malonic"
  },
  {
    "id": "3378",
    "formula": "CH2(COOH)2",
    "formatted_formula": "CH<sub>2</sub>(COOH)<sub>2</sub><sup></sup>",
    "vietnamese_name": " axit malonic"
  },
  {
    "id": "3379",
    "formula": "CH2(COOCH3)2",
    "formatted_formula": "CH<sub>2</sub>(COOCH<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3380",
    "formula": "OHCOOCH3",
    "formatted_formula": "OHCOOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3382",
    "formula": "(C17H33COO)3C3H5Br",
    "formatted_formula": "(C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>3</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub>Br<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3383",
    "formula": "H2NCH2CONHCH(CH3)COOH",
    "formatted_formula": "H<sub>2</sub>NCH<sub>2</sub>CONHCH(CH<sub>3</sub>)COOH<sup></sup>",
    "vietnamese_name": "Glyxylalanin"
  },
  {
    "id": "3385",
    "formula": "CH3CH(NH2)COONa",
    "formatted_formula": "CH<sub>3</sub>CH(NH<sub>2</sub>)COONa<sup></sup>",
    "vietnamese_name": "Natri 2 aminopropanat"
  },
  {
    "id": "3386",
    "formula": "(CH3[CH2]16COO)3C3H5",
    "formatted_formula": "(CH<sub>3</sub>[CH<sub>2</sub>]<sub>1</sub><sub>6</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "tristearin"
  },
  {
    "id": "3387",
    "formula": "CH3[CH2]16COONa",
    "formatted_formula": "CH<sub>3</sub>[CH<sub>2</sub>]<sub>1</sub><sub>6</sub>COONa<sup></sup>",
    "vietnamese_name": "natri sterat"
  },
  {
    "id": "3388",
    "formula": "NaZnO2",
    "formatted_formula": "NaZnO<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3390",
    "formula": "CH3CH2COOH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "axit propionic"
  },
  {
    "id": "3391",
    "formula": "CH3COOCH2CH3",
    "formatted_formula": "CH<sub>3</sub>COOCH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "etyl axetat"
  },
  {
    "id": "3392",
    "formula": "CH3COOCH=CH2",
    "formatted_formula": "CH<sub>3</sub>COOCH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "vinyl axetat"
  },
  {
    "id": "3393",
    "formula": " CH3-CO-CH2OH",
    "formatted_formula": " CH<sub>3</sub>-CO-CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3394",
    "formula": "CH3-CO-CH2ONa",
    "formatted_formula": "CH<sub>3</sub>-CO-CH<sub>2</sub>ONa<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3395",
    "formula": "C2H5NH3-OCO2-NH4",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>NH<sub>3</sub>-OCO<sub>2</sub>-NH<sub>4</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3396",
    "formula": "C2H5NH3NO3",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>NH<sub>3</sub>NO<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3397",
    "formula": "C2H5COOCH3",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "metyl propionat"
  },
  {
    "id": "3398",
    "formula": "HCO3H3N(CH2)2NH3NO3",
    "formatted_formula": "HCO<sub>3</sub>H<sub>3</sub>N(CH<sub>2</sub>)<sub>2</sub>NH<sub>3</sub>NO<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3399",
    "formula": "H2N(CH2)2NH2",
    "formatted_formula": "H<sub>2</sub>N(CH<sub>2</sub>)<sub>2</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3400",
    "formula": "C2H4(OH)2",
    "formatted_formula": "C<sub>2</sub>H<sub>4</sub>(OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "etlilen glicol"
  },
  {
    "id": "3401",
    "formula": " [C2H4(OH)O]2Cu",
    "formatted_formula": " [C<sub>2</sub>H<sub>4</sub>(OH)O]<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3402",
    "formula": "(CH3COO)2Cu",
    "formatted_formula": "(CH<sub>3</sub>COO)<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": "Copper acetate"
  },
  {
    "id": "3403",
    "formula": "HCOOCH=CH-CH3",
    "formatted_formula": "HCOOCH=CH-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3404",
    "formula": "HCOOC(CH3)=CH2",
    "formatted_formula": "HCOOC(CH<sub>3</sub>)=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3405",
    "formula": "CH2=C(CH3)COOH",
    "formatted_formula": "CH<sub>2</sub>=C(CH<sub>3</sub>)COOH<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3406",
    "formula": "CH2=C(CH3)COONa",
    "formatted_formula": "CH<sub>2</sub>=C(CH<sub>3</sub>)COONa<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3407",
    "formula": "HCOOCH2CH=CH2",
    "formatted_formula": "HCOOCH<sub>2</sub>CH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3408",
    "formula": "CH2=CH-CH2-OH",
    "formatted_formula": "CH<sub>2</sub>=CH-CH<sub>2</sub>-OH<sup></sup>",
    "vietnamese_name": "ancol anlylic"
  },
  {
    "id": "3409",
    "formula": "C6H12O6",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>2</sub>O<sub>6</sub><sup></sup>",
    "vietnamese_name": "Fructozơ"
  },
  {
    "id": "3410",
    "formula": "[C6H7O2(OH)3]n",
    "formatted_formula": "[C<sub>6</sub>H<sub>7</sub>O<sub>2</sub>(OH)<sub>3</sub>]n<sup></sup>",
    "vietnamese_name": "xenlulozo"
  },
  {
    "id": "3411",
    "formula": "HCOOCH=CH2",
    "formatted_formula": "HCOOCH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Vivyl format"
  },
  {
    "id": "3412",
    "formula": "(C17H31COO)3C3H5",
    "formatted_formula": "(C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>1</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Triolein"
  },
  {
    "id": "3413",
    "formula": "(C17H31COO)3C3H5",
    "formatted_formula": "(C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>1</sub>COO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "tripanmitin"
  },
  {
    "id": "3414",
    "formula": "C17H31COONa",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>1</sub>COONa<sup></sup>",
    "vietnamese_name": "Natri linoleat"
  },
  {
    "id": "3415",
    "formula": " [C6H7O2(ONO2)3]n",
    "formatted_formula": " [C<sub>6</sub>H<sub>7</sub>O<sub>2</sub>(ONO<sub>2</sub>)<sub>3</sub>]n<sup></sup>",
    "vietnamese_name": "xenlulozo nitrat"
  },
  {
    "id": "3416",
    "formula": "H2N-[CH2]6-NH2",
    "formatted_formula": "H<sub>2</sub>N-[CH<sub>2</sub>]<sub>6</sub>-NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "hexametylenđiamin"
  },
  {
    "id": "3417",
    "formula": "HOOC-[CH2]4-COOH ",
    "formatted_formula": "HOOC-[CH<sub>2</sub>]<sub>4</sub>-COOH <sup></sup>",
    "vietnamese_name": "axit ađipic"
  },
  {
    "id": "3418",
    "formula": " [C6H7O2(OH)2OCS–SNa]n ",
    "formatted_formula": " [C<sub>6</sub>H<sub>7</sub>O<sub>2</sub>(OH)<sub>2</sub>OCS–SNa]n <sup></sup>",
    "vietnamese_name": "Xenlulozơ xantogenat"
  },
  {
    "id": "3419",
    "formula": "[C6H7O2(OH)2ONa]n",
    "formatted_formula": "[C<sub>6</sub>H<sub>7</sub>O<sub>2</sub>(OH)<sub>2</sub>ONa]n<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3420",
    "formula": "[C6H7O2(OCOCH3)3]n ",
    "formatted_formula": "[C<sub>6</sub>H<sub>7</sub>O<sub>2</sub>(OCOCH<sub>3</sub>)<sub>3</sub>]n <sup></sup>",
    "vietnamese_name": "xenlulose triacetat"
  },
  {
    "id": "3421",
    "formula": "(CH3)3N",
    "formatted_formula": "(CH<sub>3</sub>)<sub>3</sub>N<sup></sup>",
    "vietnamese_name": "trimetyl amin"
  },
  {
    "id": "3422",
    "formula": "CH2=CH-COOCH3",
    "formatted_formula": "CH<sub>2</sub>=CH-COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "metyl acrylat"
  },
  {
    "id": "3423",
    "formula": " HCOOCH2CH2CH3",
    "formatted_formula": " HCOOCH<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "propyl fomat"
  },
  {
    "id": "3424",
    "formula": "CH3CH(NH2)COOCH3",
    "formatted_formula": "CH<sub>3</sub>CH(NH<sub>2</sub>)COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-aminopropionic acid metyl ester"
  },
  {
    "id": "3425",
    "formula": "C2H5OCOONH4 ",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OCOONH<sub>4</sub> <sup></sup>",
    "vietnamese_name": "amoni latat"
  },
  {
    "id": "3426",
    "formula": "H2NC3H5(COOH)2 ",
    "formatted_formula": "H<sub>2</sub>NC<sub>3</sub>H<sub>5</sub>(COOH)<sub>2</sub> <sup></sup>",
    "vietnamese_name": "axit glutamic"
  },
  {
    "id": "3427",
    "formula": "C6H4Cl2",
    "formatted_formula": "C<sub>6</sub>H<sub>4</sub>Cl<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,4-điclobenzen"
  },
  {
    "id": "3429",
    "formula": " CH2=CH-COONa",
    "formatted_formula": " CH<sub>2</sub>=CH-COONa<sup></sup>",
    "vietnamese_name": "Natri acrylat"
  },
  {
    "id": "3430",
    "formula": "C6H5OOCCH=CH2",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>OOCCH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Vivyl benzoat"
  },
  {
    "id": "3431",
    "formula": "C6H5COOCH=CH2",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COOCH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Vivyl benzoat"
  },
  {
    "id": "3432",
    "formula": "C2H5OOC-COOCH3",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OOC-COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "etyl metyl oxalat"
  },
  {
    "id": "3434",
    "formula": "(RCOO)3C3H5",
    "formatted_formula": "(RCOO)<sub>3</sub>C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "triglixerit"
  },
  {
    "id": "3435",
    "formula": "RCOONa",
    "formatted_formula": "RCOONa<sup></sup>",
    "vietnamese_name": "xà phòng"
  },
  {
    "id": "3436",
    "formula": "HCOOC6H5",
    "formatted_formula": "HCOOC<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "phenyl format"
  },
  {
    "id": "3437",
    "formula": "CH3NH2",
    "formatted_formula": "CH<sub>3</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Metyl amin"
  },
  {
    "id": "3438",
    "formula": "CH3CH2COOH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit propionic"
  },
  {
    "id": "3439",
    "formula": "CH3CH2CH2COOH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit butiric"
  },
  {
    "id": "3440",
    "formula": "C15H31COOH",
    "formatted_formula": "C<sub>1</sub><sub>5</sub>H<sub>3</sub><sub>1</sub>COOH<sup></sup>",
    "vietnamese_name": " Axit panmitic "
  },
  {
    "id": "3441",
    "formula": "C17H33COOH",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>3</sub>COOH<sup></sup>",
    "vietnamese_name": "Axit oleic"
  },
  {
    "id": "3442",
    "formula": "C17H35COOH ",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>5</sub>COOH <sup></sup>",
    "vietnamese_name": "Axit stearic "
  },
  {
    "id": "3443",
    "formula": "HOOC-COOH",
    "formatted_formula": "HOOC-COOH<sup></sup>",
    "vietnamese_name": "Axit oxalic"
  },
  {
    "id": "3444",
    "formula": " HOOC-(CH2)4-COOH ",
    "formatted_formula": " HOOC-(CH<sub>2</sub>)<sub>4</sub>-COOH <sup></sup>",
    "vietnamese_name": "Axit ađipic "
  },
  {
    "id": "3445",
    "formula": " HOOC-CH(OH)-CH2-COOH",
    "formatted_formula": " HOOC-CH(OH)-CH<sub>2</sub>-COOH<sup></sup>",
    "vietnamese_name": "Axit malic (có trong quả táo)"
  },
  {
    "id": "3446",
    "formula": "C6H5-COOH ",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-COOH <sup></sup>",
    "vietnamese_name": "Axit benzoic "
  },
  {
    "id": "3447",
    "formula": " C6H5-CH=CH-COOH",
    "formatted_formula": " C<sub>6</sub>H<sub>5</sub>-CH=CH-COOH<sup></sup>",
    "vietnamese_name": " Axit xiamic "
  },
  {
    "id": "3448",
    "formula": " C6H5-CH2-COOH",
    "formatted_formula": " C<sub>6</sub>H<sub>5</sub>-CH<sub>2</sub>-COOH<sup></sup>",
    "vietnamese_name": "Axit phenylaxetic "
  },
  {
    "id": "3449",
    "formula": " CH3(CH2)3-COOH",
    "formatted_formula": " CH<sub>3</sub>(CH<sub>2</sub>)<sub>3</sub>-COOH<sup></sup>",
    "vietnamese_name": "Axit valeric "
  },
  {
    "id": "3450",
    "formula": " (CH3)2CH-COOH ",
    "formatted_formula": " (CH<sub>3</sub>)<sub>2</sub>CH-COOH <sup></sup>",
    "vietnamese_name": "Axit isobutiric (axit 2-methylpropanoic)"
  },
  {
    "id": "3451",
    "formula": "CH3-(CH2)5-COOH",
    "formatted_formula": "CH<sub>3</sub>-(CH<sub>2</sub>)<sub>5</sub>-COOH<sup></sup>",
    "vietnamese_name": "Axit enantoic "
  },
  {
    "id": "3452",
    "formula": " CH3-(CH2)4-COOH",
    "formatted_formula": " CH<sub>3</sub>-(CH<sub>2</sub>)<sub>4</sub>-COOH<sup></sup>",
    "vietnamese_name": "Axit caproic"
  },
  {
    "id": "3453",
    "formula": "CH2=CH-COOH",
    "formatted_formula": "CH<sub>2</sub>=CH-COOH<sup></sup>",
    "vietnamese_name": "Axit acrylic "
  },
  {
    "id": "3454",
    "formula": "CH2=C(CH3)-COOH",
    "formatted_formula": "CH<sub>2</sub>=C(CH<sub>3</sub>)-COOH<sup></sup>",
    "vietnamese_name": "Axit metacrylic "
  },
  {
    "id": "3455",
    "formula": " CH3-CH=CH-COOH ",
    "formatted_formula": " CH<sub>3</sub>-CH=CH-COOH <sup></sup>",
    "vietnamese_name": "Axit crotonic "
  },
  {
    "id": "3456",
    "formula": "CH2=CH-CH2-COOH",
    "formatted_formula": "CH<sub>2</sub>=CH-CH<sub>2</sub>-COOH<sup></sup>",
    "vietnamese_name": " Axit vynilaxetic "
  },
  {
    "id": "3457",
    "formula": "CH3-CH(OH)-COOH ",
    "formatted_formula": "CH<sub>3</sub>-CH(OH)-COOH <sup></sup>",
    "vietnamese_name": "Axit lactic"
  },
  {
    "id": "3458",
    "formula": "CH2(COOH)2 ",
    "formatted_formula": "CH<sub>2</sub>(COOH)<sub>2</sub> <sup></sup>",
    "vietnamese_name": "Acid malonic"
  },
  {
    "id": "3459",
    "formula": " CH≡C-COOH ",
    "formatted_formula": " CH≡C-COOH <sup></sup>",
    "vietnamese_name": "Axit propiolic "
  },
  {
    "id": "3460",
    "formula": "HO–CH2 –COOH",
    "formatted_formula": "HO–CH<sub>2</sub> –COOH<sup></sup>",
    "vietnamese_name": " axit hiđroxiaxetic"
  },
  {
    "id": "3461",
    "formula": "(NH-[CH2]6-NH-CO-[CH2]4-CO)n",
    "formatted_formula": "(NH-[CH<sub>2</sub>]<sub>6</sub>-NH-CO-[CH<sub>2</sub>]<sub>4</sub>-CO)n<sup></sup>",
    "vietnamese_name": "tơ nilon 6,6"
  },
  {
    "id": "3462",
    "formula": "NH2CH2COOC2H5",
    "formatted_formula": "NH<sub>2</sub>CH<sub>2</sub>COOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "etyl aminoaxetat"
  },
  {
    "id": "3463",
    "formula": "H2N-CH2-COONa",
    "formatted_formula": "H<sub>2</sub>N-CH<sub>2</sub>-COONa<sup></sup>",
    "vietnamese_name": "natri aminoacetat"
  },
  {
    "id": "3464",
    "formula": "CH3 – OOC – (CH2)2 – COO – C2H5 ",
    "formatted_formula": "CH<sub>3</sub> – OOC – (CH<sub>2</sub>)<sub>2</sub> – COO – C<sub>2</sub>H<sub>5</sub> <sup></sup>",
    "vietnamese_name": "etyl metyl ađipat"
  },
  {
    "id": "3465",
    "formula": "CH2 = C (CH3) - CH = CH2",
    "formatted_formula": "CH<sub>2</sub> = C (CH<sub>3</sub>) - CH = CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "isopren"
  },
  {
    "id": "3466",
    "formula": "CH3COOCH2-C6H5",
    "formatted_formula": "CH<sub>3</sub>COOCH<sub>2</sub>-C<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "benyl acetat"
  },
  {
    "id": "3467",
    "formula": "CH3COOCH2-CH = CH2 ",
    "formatted_formula": "CH<sub>3</sub>COOCH<sub>2</sub>-CH = CH<sub>2</sub> <sup></sup>",
    "vietnamese_name": "Anlyl acetat"
  },
  {
    "id": "3468",
    "formula": "CH2 = CH–CH2OH",
    "formatted_formula": "CH<sub>2</sub> = CH–CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "alcol anlylic"
  },
  {
    "id": "3469",
    "formula": "CH3[CH2]3OH",
    "formatted_formula": "CH<sub>3</sub>[CH<sub>2</sub>]<sub>3</sub>OH<sup></sup>",
    "vietnamese_name": "but-1-ol"
  },
  {
    "id": "3470",
    "formula": "CH3CH2CH2COOC2H5",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>COOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Etylbutirat"
  },
  {
    "id": "3471",
    "formula": "C2H5OCO-CH2-COOCH3",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>OCO-CH<sub>2</sub>-COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "etylmetylmalonat"
  },
  {
    "id": "3472",
    "formula": "CH3OCO-COOCH3",
    "formatted_formula": "CH<sub>3</sub>OCO-COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đimetyl oxalat"
  },
  {
    "id": "3473",
    "formula": "RCHO",
    "formatted_formula": "RCHO<sup></sup>",
    "vietnamese_name": "Anđehit"
  },
  {
    "id": "3474",
    "formula": "RCOOH",
    "formatted_formula": "RCOOH<sup></sup>",
    "vietnamese_name": "Acid carboxylic"
  },
  {
    "id": "3475",
    "formula": "C6H5COOC6H5",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COOC<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Phenyl benzoat"
  },
  {
    "id": "3476",
    "formula": "H2NCH(CH3)COOH",
    "formatted_formula": "H<sub>2</sub>NCH(CH<sub>3</sub>)COOH<sup></sup>",
    "vietnamese_name": "alanin"
  },
  {
    "id": "3477",
    "formula": "ClH3N-C3H5(COOH)2",
    "formatted_formula": "ClH<sub>3</sub>N-C<sub>3</sub>H<sub>5</sub>(COOH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "2-amonicloruapentanđioic"
  },
  {
    "id": "3478",
    "formula": "H2N-C3H5-(COONa)2",
    "formatted_formula": "H<sub>2</sub>N-C<sub>3</sub>H<sub>5</sub>-(COONa)<sub>2</sub><sup></sup>",
    "vietnamese_name": "natri α-aminoglutarat"
  },
  {
    "id": "3479",
    "formula": "Ba(CrO2)2",
    "formatted_formula": "Ba(CrO<sub>2</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Baricromit"
  },
  {
    "id": "3480",
    "formula": "C6H5COOC2H5",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Etyl benzoat"
  },
  {
    "id": "3481",
    "formula": "(C2H4(OHO))2",
    "formatted_formula": "(C<sub>2</sub>H<sub>4</sub>(OHO))<sub>2</sub><sup></sup>",
    "vietnamese_name": "Etan-1,2-đioic"
  },
  {
    "id": "3482",
    "formula": " CnH(2n+3)N",
    "formatted_formula": " CnH(<sub>2</sub>n+<sub>3</sub>)N<sup></sup>",
    "vietnamese_name": "công thức chung của amin"
  },
  {
    "id": "3483",
    "formula": "CH3CH(NH2)COOCH3",
    "formatted_formula": "CH<sub>3</sub>CH(NH<sub>2</sub>)COOCH<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3484",
    "formula": "CH3COO-C3H7 Propyl axetat",
    "formatted_formula": "CH<sub>3</sub>COO-C<sub>3</sub>H<sub>7</sub> Propyl axetat<sup></sup>",
    "vietnamese_name": "Propyl axetat"
  },
  {
    "id": "3485",
    "formula": "(HCOO)3-C3H5",
    "formatted_formula": "(HCOO)<sub>3</sub>-C<sub>3</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": " glixerol trifomat"
  },
  {
    "id": "3486",
    "formula": "((CH3)2NH2)NO3",
    "formatted_formula": "((CH<sub>3</sub>)<sub>2</sub>NH<sub>2</sub>)NO<sub>3</sub><sup></sup>",
    "vietnamese_name": "Đimetylamin nitrat"
  },
  {
    "id": "3487",
    "formula": "Cn(H2O)m",
    "formatted_formula": "Cn(H<sub>2</sub>O)m<sup></sup>",
    "vietnamese_name": "carbohidrat"
  },
  {
    "id": "3488",
    "formula": "C2H5COOC2H5",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "etyl propionat"
  },
  {
    "id": "3489",
    "formula": "CH3NH3HCO3",
    "formatted_formula": "CH<sub>3</sub>NH<sub>3</sub>HCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "metylamoni hidrocacbonat"
  },
  {
    "id": "3490",
    "formula": "C2H4(OOCCH3)2",
    "formatted_formula": "C<sub>2</sub>H<sub>4</sub>(OOCCH<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "adipic acid"
  },
  {
    "id": "3491",
    "formula": "C2H4(OOCH)2",
    "formatted_formula": "C<sub>2</sub>H<sub>4</sub>(OOCH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Acetyl peroxide"
  },
  {
    "id": "3492",
    "formula": "CnH2n+2-2kO2 ",
    "formatted_formula": "CnH<sub>2</sub>n+<sub>2</sub>-<sub>2</sub>kO<sub>2</sub> <sup></sup>",
    "vietnamese_name": "este đơn chức,mạch hở"
  },
  {
    "id": "3493",
    "formula": "CH2(COONa)2",
    "formatted_formula": "CH<sub>2</sub>(COONa)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Disodium malonate"
  },
  {
    "id": "3494",
    "formula": "C17H35COONa",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>5</sub>COONa<sup></sup>",
    "vietnamese_name": "natri stearat"
  },
  {
    "id": "3495",
    "formula": "C15H31COONa",
    "formatted_formula": "C<sub>1</sub><sub>5</sub>H<sub>3</sub><sub>1</sub>COONa<sup></sup>",
    "vietnamese_name": "natri panmitat"
  },
  {
    "id": "3496",
    "formula": "C17H33COONa",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>3</sub>COONa<sup></sup>",
    "vietnamese_name": "natri oleat"
  },
  {
    "id": "3497",
    "formula": "C4H9Cl",
    "formatted_formula": "C<sub>4</sub>H<sub>9</sub>Cl<sup></sup>",
    "vietnamese_name": "sec-butyl clorua"
  },
  {
    "id": "3498",
    "formula": "C4H9OH",
    "formatted_formula": "C<sub>4</sub>H<sub>9</sub>OH<sup></sup>",
    "vietnamese_name": "2-butanol"
  },
  {
    "id": "3499",
    "formula": "C4H9NO2",
    "formatted_formula": "C<sub>4</sub>H<sub>9</sub>NO<sub>2</sub><sup></sup>",
    "vietnamese_name": "Butyl nitrite"
  },
  {
    "id": "3500",
    "formula": "CH3-CH2-COONa",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-COONa<sup></sup>",
    "vietnamese_name": "natri propionate"
  },
  {
    "id": "3502",
    "formula": "CH3CH2COCH3",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>COCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "metyl propionat"
  },
  {
    "id": "3503",
    "formula": "CH3-CH2-CONa",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CONa<sup></sup>",
    "vietnamese_name": "natri propionate"
  },
  {
    "id": "3504",
    "formula": "C4H8O",
    "formatted_formula": "C<sub>4</sub>H<sub>8</sub>O<sup></sup>",
    "vietnamese_name": "metyl propionate"
  },
  {
    "id": "3505",
    "formula": "C2H5CHO",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>CHO<sup></sup>",
    "vietnamese_name": "Propanal"
  },
  {
    "id": "3506",
    "formula": "C3H7CHO",
    "formatted_formula": "C<sub>3</sub>H<sub>7</sub>CHO<sup></sup>",
    "vietnamese_name": "Butanal"
  },
  {
    "id": "3507",
    "formula": "C3H7COONH4",
    "formatted_formula": "C<sub>3</sub>H<sub>7</sub>COONH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni isobutirat"
  },
  {
    "id": "3509",
    "formula": "NH2CH2COOCH3 ",
    "formatted_formula": "NH<sub>2</sub>CH<sub>2</sub>COOCH<sub>3</sub> <sup></sup>",
    "vietnamese_name": "metyl glyxinat"
  },
  {
    "id": "3510",
    "formula": "NH2CH2COONa",
    "formatted_formula": "NH<sub>2</sub>CH<sub>2</sub>COONa<sup></sup>",
    "vietnamese_name": "natri glyxinat"
  },
  {
    "id": "3511",
    "formula": "CH2=CH-COONH4",
    "formatted_formula": "CH<sub>2</sub>=CH-COONH<sub>4</sub><sup></sup>",
    "vietnamese_name": "amoni acrylat"
  },
  {
    "id": "3512",
    "formula": "CH2=CH-COONa",
    "formatted_formula": "CH<sub>2</sub>=CH-COONa<sup></sup>",
    "vietnamese_name": "Natri acrylat"
  },
  {
    "id": "3513",
    "formula": "CH3",
    "formatted_formula": "CH<sub>3</sub><sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3514",
    "formula": "(CH3)2NH",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>NH<sup></sup>",
    "vietnamese_name": "Đimetyl amin"
  },
  {
    "id": "3515",
    "formula": "H2NCH(CH3)COOK",
    "formatted_formula": "H<sub>2</sub>NCH(CH<sub>3</sub>)COOK<sup></sup>",
    "vietnamese_name": "Kali 2-aminopropanat"
  },
  {
    "id": "3516",
    "formula": "H-NH-[CH2]5COOH",
    "formatted_formula": "H-NH-[CH<sub>2</sub>]<sub>5</sub>COOH<sup></sup>",
    "vietnamese_name": " axit ε-aminocaproic"
  },
  {
    "id": "3517",
    "formula": "CH2=CHCH=CH2",
    "formatted_formula": "CH<sub>2</sub>=CHCH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "1,3-Butadien"
  },
  {
    "id": "3518",
    "formula": "(-CH2 - CH = CH - CH2 - CH(C6H5) - CH2 - )n",
    "formatted_formula": "(-CH<sub>2</sub> - CH = CH - CH<sub>2</sub> - CH(C<sub>6</sub>H<sub>5</sub>) - CH<sub>2</sub> - )n<sup></sup>",
    "vietnamese_name": " Poli( Butadien-stiren ) "
  },
  {
    "id": "3519",
    "formula": "(-CH2 - CH = CH - CH2 - CH(C6H5) - CH2 - )n",
    "formatted_formula": "(-CH<sub>2</sub> - CH = CH - CH<sub>2</sub> - CH(C<sub>6</sub>H<sub>5</sub>) - CH<sub>2</sub> - )n<sup></sup>",
    "vietnamese_name": "cao su Buna - S "
  },
  {
    "id": "3520",
    "formula": "NaC6H5CO2",
    "formatted_formula": "NaC<sub>6</sub>H<sub>5</sub>CO<sub>2</sub><sup></sup>",
    "vietnamese_name": "natri benzoat"
  },
  {
    "id": "3521",
    "formula": "(C6H5COO)2Cu",
    "formatted_formula": "(C<sub>6</sub>H<sub>5</sub>COO)<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": "đồng (II) benzoat"
  },
  {
    "id": "3522",
    "formula": "CH3CH(OH)COOH",
    "formatted_formula": "CH<sub>3</sub>CH(OH)COOH<sup></sup>",
    "vietnamese_name": "Acid lactic"
  },
  {
    "id": "3523",
    "formula": "CH3CH2CH2COOH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Acid butiric"
  },
  {
    "id": "3524",
    "formula": "CH2=CHCOOC6H5",
    "formatted_formula": "CH<sub>2</sub>=CHCOOC<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "phenylacrylat"
  },
  {
    "id": "3525",
    "formula": "HOCH2CH2NH2",
    "formatted_formula": "HOCH<sub>2</sub>CH<sub>2</sub>NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Etanolamin"
  },
  {
    "id": "3526",
    "formula": "(C12H22O11)2Cu",
    "formatted_formula": "(C<sub>1</sub><sub>2</sub>H<sub>2</sub><sub>2</sub>O<sub>1</sub><sub>1</sub>)<sub>2</sub>Cu<sup></sup>",
    "vietnamese_name": "phức đồng - mantose"
  },
  {
    "id": "3527",
    "formula": "CH3COOCH2CH2CH(CH3)2",
    "formatted_formula": "CH<sub>3</sub>COOCH<sub>2</sub>CH<sub>2</sub>CH(CH<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Isoamylic acetate"
  },
  {
    "id": "3528",
    "formula": "CnH(2n + 3)N",
    "formatted_formula": "CnH(<sub>2</sub>n + <sub>3</sub>)N<sup></sup>",
    "vietnamese_name": "Amin no đơn chức"
  },
  {
    "id": "3529",
    "formula": "CxHyO",
    "formatted_formula": "CxHyO<sup></sup>",
    "vietnamese_name": "Alcohol đơn chức"
  },
  {
    "id": "3530",
    "formula": "CnH2n+2O ",
    "formatted_formula": "CnH<sub>2</sub>n+<sub>2</sub>O <sup></sup>",
    "vietnamese_name": "Alcohol đơn chức"
  },
  {
    "id": "3531",
    "formula": "C6H12O7NH4",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>2</sub>O<sub>7</sub>NH<sub>4</sub><sup></sup>",
    "vietnamese_name": "Amoni gluconat"
  },
  {
    "id": "3532",
    "formula": "C6H5CH2OH",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Benzyl alcohol"
  },
  {
    "id": "3533",
    "formula": "H2N-CH2-COOH",
    "formatted_formula": "H<sub>2</sub>N-CH<sub>2</sub>-COOH<sup></sup>",
    "vietnamese_name": "Glycin"
  },
  {
    "id": "3534",
    "formula": "HO–CH2 –COOH",
    "formatted_formula": "HO–CH<sub>2</sub> –COOH<sup></sup>",
    "vietnamese_name": "axit hiđroxiaxetic"
  },
  {
    "id": "3535",
    "formula": "HOCH2COOH",
    "formatted_formula": "HOCH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Acid hidroxiacetic"
  },
  {
    "id": "3536",
    "formula": "CH2=CHCOO-CH3",
    "formatted_formula": "CH<sub>2</sub>=CHCOO-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metylacrylat"
  },
  {
    "id": "3537",
    "formula": "C2H5NHCH3",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>NHCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyletanamin"
  },
  {
    "id": "3538",
    "formula": "H2N-CH2-COOK",
    "formatted_formula": "H<sub>2</sub>N-CH<sub>2</sub>-COOK<sup></sup>",
    "vietnamese_name": "kali aminoacetate"
  },
  {
    "id": "3539",
    "formula": "H2NCH2CONHCH(CH3)COOH",
    "formatted_formula": "H<sub>2</sub>NCH<sub>2</sub>CONHCH(CH<sub>3</sub>)COOH<sup></sup>",
    "vietnamese_name": " Glyxylalanin"
  },
  {
    "id": "3540",
    "formula": "H2N-CH2-COONa ",
    "formatted_formula": "H<sub>2</sub>N-CH<sub>2</sub>-COONa <sup></sup>",
    "vietnamese_name": "natri aminoacetat"
  },
  {
    "id": "3541",
    "formula": "H2N-CH2-COOC2H5",
    "formatted_formula": "H<sub>2</sub>N-CH<sub>2</sub>-COOC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "etyl aminoaxetat"
  },
  {
    "id": "3542",
    "formula": "CH3CONHC6H5",
    "formatted_formula": "CH<sub>3</sub>CONHC<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Axetanilit"
  },
  {
    "id": "3543",
    "formula": "CH3COOCH(Br)-CH2Br",
    "formatted_formula": "CH<sub>3</sub>COOCH(Br)-CH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3544",
    "formula": "CH2OH[CHOH]4COOH",
    "formatted_formula": "CH<sub>2</sub>OH[CHOH]<sub>4</sub>COOH<sup></sup>",
    "vietnamese_name": "acid gluconic"
  },
  {
    "id": "3545",
    "formula": "CH2OH[CHOH]4COONa",
    "formatted_formula": "CH<sub>2</sub>OH[CHOH]<sub>4</sub>COONa<sup></sup>",
    "vietnamese_name": "natri gluconat"
  },
  {
    "id": "3546",
    "formula": " [C6H7O2(OCOCH3)3]n",
    "formatted_formula": " [C<sub>6</sub>H<sub>7</sub>O<sub>2</sub>(OCOCH<sub>3</sub>)<sub>3</sub>]n<sup></sup>",
    "vietnamese_name": "xenlulozơ triaxetat"
  },
  {
    "id": "3547",
    "formula": " [C6H7O2(OH)(OCOCH3)2]n",
    "formatted_formula": " [C<sub>6</sub>H<sub>7</sub>O<sub>2</sub>(OH)(OCOCH<sub>3</sub>)<sub>2</sub>]n<sup></sup>",
    "vietnamese_name": "xenlulozơ điaxetat"
  },
  {
    "id": "3548",
    "formula": " [C6H7O2(OH)(OCOCH3)2]n",
    "formatted_formula": " [C<sub>6</sub>H<sub>7</sub>O<sub>2</sub>(OH)(OCOCH<sub>3</sub>)<sub>2</sub>]n<sup></sup>",
    "vietnamese_name": "xenlulose điacetic"
  },
  {
    "id": "3549",
    "formula": "CH2=C(CH3)-COOCH3 ",
    "formatted_formula": "CH<sub>2</sub>=C(CH<sub>3</sub>)-COOCH<sub>3</sub> <sup></sup>",
    "vietnamese_name": "Metyl metacrylat"
  },
  {
    "id": "3551",
    "formula": "ClCH2CH(CH3)CHClCH3",
    "formatted_formula": "ClCH<sub>2</sub>CH(CH<sub>3</sub>)CHClCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1,3-điclo-2-metylbutan"
  },
  {
    "id": "3552",
    "formula": "CH2=CHCOONa",
    "formatted_formula": "CH<sub>2</sub>=CHCOONa<sup></sup>",
    "vietnamese_name": "natri acrylat"
  },
  {
    "id": "3553",
    "formula": "HO-C6H2(NO2)3",
    "formatted_formula": "HO-C<sub>6</sub>H<sub>2</sub>(NO<sub>2</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "Acid picric"
  },
  {
    "id": "3554",
    "formula": "CH2=CHCH3",
    "formatted_formula": "CH<sub>2</sub>=CHCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Propen"
  },
  {
    "id": "3555",
    "formula": "CH2Br-CH(Br)-CH3",
    "formatted_formula": "CH<sub>2</sub>Br-CH(Br)-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1,2-đibrompropan"
  },
  {
    "id": "3556",
    "formula": "CH3-CH2-CH3",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Propan"
  },
  {
    "id": "3557",
    "formula": "CH2(CH3)-CH2-CH3",
    "formatted_formula": "CH<sub>2</sub>(CH<sub>3</sub>)-CH<sub>2</sub>-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Isobutan (metyl propan)"
  },
  {
    "id": "3558",
    "formula": "CH3CH2CH2OH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "1-propanal (propan-1-ol)"
  },
  {
    "id": "3559",
    "formula": "CH3CH2CH=O",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH=O<sup></sup>",
    "vietnamese_name": "Propanal"
  },
  {
    "id": "3560",
    "formula": "CH3CH2COOH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Acid propionic"
  },
  {
    "id": "3561",
    "formula": "CH3CH2CH2OH",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "Propan-1-ol"
  },
  {
    "id": "3562",
    "formula": "CH2(Br)-CH(Br)-COOH",
    "formatted_formula": "CH<sub>2</sub>(Br)-CH(Br)-COOH<sup></sup>",
    "vietnamese_name": "2,3-dibromopropionic"
  },
  {
    "id": "3563",
    "formula": "C3H4Br2O2",
    "formatted_formula": "C<sub>3</sub>H<sub>4</sub>Br<sub>2</sub>O<sub>2</sub><sup></sup>",
    "vietnamese_name": "Propanoic acid, 2,3-dibromo"
  },
  {
    "id": "3564",
    "formula": "C6H5-CH(Br)-CH2Br",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH(Br)-CH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "1,2-dibromo-1-phenyl etan"
  },
  {
    "id": "3565",
    "formula": "HCOONa",
    "formatted_formula": "HCOONa<sup></sup>",
    "vietnamese_name": "Natri format"
  },
  {
    "id": "3566",
    "formula": "NH4NaCO3",
    "formatted_formula": "NH<sub>4</sub>NaCO<sub>3</sub><sup></sup>",
    "vietnamese_name": "amoni natri carbonat"
  },
  {
    "id": "3567",
    "formula": "(Br)3C6H2OH",
    "formatted_formula": "(Br)<sub>3</sub>C<sub>6</sub>H<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "2,4,6-tribromphenol"
  },
  {
    "id": "3568",
    "formula": "CH2=CH-CH=CH2",
    "formatted_formula": "CH<sub>2</sub>=CH-CH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Buta-1,3-dien"
  },
  {
    "id": "3569",
    "formula": "CH(C6H5)=CH2",
    "formatted_formula": "CH(C<sub>6</sub>H<sub>5</sub>)=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Stiren"
  },
  {
    "id": "3570",
    "formula": "(-CH2-CH=CH-CH2-)n",
    "formatted_formula": "(-CH<sub>2</sub>-CH=CH-CH<sub>2</sub>-)n<sup></sup>",
    "vietnamese_name": "cao su buna"
  },
  {
    "id": "3571",
    "formula": "CH3-CH2-CH(OH)-CH2(OH)",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CH(OH)-CH<sub>2</sub>(OH)<sup></sup>",
    "vietnamese_name": "Butan-1,2-diol"
  },
  {
    "id": "3572",
    "formula": "RCH=O",
    "formatted_formula": "RCH=O<sup></sup>",
    "vietnamese_name": "Andehit"
  },
  {
    "id": "3573",
    "formula": "(CH3)2CHCH2CH=O",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>CHCH<sub>2</sub>CH=O<sup></sup>",
    "vietnamese_name": "3-metylbutanal"
  },
  {
    "id": "3574",
    "formula": "(CH3)2CHCH2CH2OH",
    "formatted_formula": "(CH<sub>3</sub>)<sub>2</sub>CHCH<sub>2</sub>CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "3-metylbutan-1-ol"
  },
  {
    "id": "3575",
    "formula": "HCOOCH2CH2CH(CH3)2",
    "formatted_formula": "HCOOCH<sub>2</sub>CH<sub>2</sub>CH(CH<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "Isoamyl fomiat (mùi chuối chín)"
  },
  {
    "id": "3576",
    "formula": "C2H5ONa ",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>ONa <sup></sup>",
    "vietnamese_name": "natri etylat"
  },
  {
    "id": "3577",
    "formula": "(-CH2-CH(OOCH3)-)n",
    "formatted_formula": "(-CH<sub>2</sub>-CH(OOCH<sub>3</sub>)-)n<sup></sup>",
    "vietnamese_name": "poli(vivyl acetate)"
  },
  {
    "id": "3578",
    "formula": "(-CH2-CH2-)n",
    "formatted_formula": "(-CH<sub>2</sub>-CH<sub>2</sub>-)n<sup></sup>",
    "vietnamese_name": "polietilen (P.E)"
  },
  {
    "id": "3579",
    "formula": "(-CH(C6H5)-CH2-)n",
    "formatted_formula": "(-CH(C<sub>6</sub>H<sub>5</sub>)-CH<sub>2</sub>-)n<sup></sup>",
    "vietnamese_name": "polistiren"
  },
  {
    "id": "3582",
    "formula": "(-CH2-CH(OOCH3)-)n",
    "formatted_formula": "(-CH<sub>2</sub>-CH(OOCH<sub>3</sub>)-)n<sup></sup>",
    "vietnamese_name": "poli(metyl acrylat)"
  },
  {
    "id": "3583",
    "formula": "CH2=C(CH3)-CH=CH2",
    "formatted_formula": "CH<sub>2</sub>=C(CH<sub>3</sub>)-CH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "isopren"
  },
  {
    "id": "3584",
    "formula": "(-CH2-C(CH3)=CH-CH2-)n",
    "formatted_formula": "(-CH<sub>2</sub>-C(CH<sub>3</sub>)=CH-CH<sub>2</sub>-)n<sup></sup>",
    "vietnamese_name": "poliisopren"
  },
  {
    "id": "3585",
    "formula": "C2H5COOCH − CH = CH2",
    "formatted_formula": "C<sub>2</sub>H<sub>5</sub>COOCH − CH = CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "alyl propionat"
  },
  {
    "id": "3586",
    "formula": "HCOOCH2CH2CH3",
    "formatted_formula": "HCOOCH<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "propyl fomiat "
  },
  {
    "id": "3587",
    "formula": "HCOOCH(CH3)2",
    "formatted_formula": "HCOOCH(CH<sub>3</sub>)<sub>2</sub><sup></sup>",
    "vietnamese_name": "isopropyl fomiat"
  },
  {
    "id": "3588",
    "formula": "HCOOCH2 − C6H5",
    "formatted_formula": "HCOOCH<sub>2</sub> − C<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Benzyl format"
  },
  {
    "id": "3589",
    "formula": "HOCH2 − C6H5",
    "formatted_formula": "HOCH<sub>2</sub> − C<sub>6</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "ancol benzylic"
  },
  {
    "id": "3590",
    "formula": "[-CH2-CH(OCOCH3)-]n",
    "formatted_formula": "[-CH<sub>2</sub>-CH(OCOCH<sub>3</sub>)-]n<sup></sup>",
    "vietnamese_name": "Poli(vilvyl acetate)"
  },
  {
    "id": "3591",
    "formula": "[- CH2-CH(OH)-]n",
    "formatted_formula": "[- CH<sub>2</sub>-CH(OH)-]n<sup></sup>",
    "vietnamese_name": "Poli(vilvyl alcohol)"
  },
  {
    "id": "3592",
    "formula": "CH2=CH(CH3)",
    "formatted_formula": "CH<sub>2</sub>=CH(CH<sub>3</sub>)<sup></sup>",
    "vietnamese_name": "Propilen"
  },
  {
    "id": "3593",
    "formula": "(-CH2-CH(CH3)-)n",
    "formatted_formula": "(-CH<sub>2</sub>-CH(CH<sub>3</sub>)-)n<sup></sup>",
    "vietnamese_name": "polipropilen"
  },
  {
    "id": "3594",
    "formula": "(- CH2-(COOCH3)C(CH3)-)n",
    "formatted_formula": "(- CH<sub>2</sub>-(COOCH<sub>3</sub>)C(CH<sub>3</sub>)-)n<sup></sup>",
    "vietnamese_name": "Poli(Metyl metacrylat)"
  },
  {
    "id": "3595",
    "formula": "(- CH2-(COOCH3)C(CH3)-)n",
    "formatted_formula": "(- CH<sub>2</sub>-(COOCH<sub>3</sub>)C(CH<sub>3</sub>)-)n<sup></sup>",
    "vietnamese_name": "Poli(Metyl metacrylat)"
  },
  {
    "id": "3596",
    "formula": "CH2=CH-Cl",
    "formatted_formula": "CH<sub>2</sub>=CH-Cl<sup></sup>",
    "vietnamese_name": "vinyl clorua"
  },
  {
    "id": "3597",
    "formula": "(-CH2-CH-Cl-)n",
    "formatted_formula": "(-CH<sub>2</sub>-CH-Cl-)n<sup></sup>",
    "vietnamese_name": "poli vinyl clorua"
  },
  {
    "id": "3598",
    "formula": "CH2=CHCl",
    "formatted_formula": "CH<sub>2</sub>=CHCl<sup></sup>",
    "vietnamese_name": "vinyl clrua"
  },
  {
    "id": "3599",
    "formula": "CF2=CF2",
    "formatted_formula": "CF<sub>2</sub>=CF<sub>2</sub><sup></sup>",
    "vietnamese_name": "tetrafloetilen"
  },
  {
    "id": "3600",
    "formula": "(-CF2-CF2-)n",
    "formatted_formula": "(-CF<sub>2</sub>-CF<sub>2</sub>-)n<sup></sup>",
    "vietnamese_name": "poli(tetrafloetilen) "
  },
  {
    "id": "3601",
    "formula": "CH2=C-Cl-CH=CH2",
    "formatted_formula": "CH<sub>2</sub>=C-Cl-CH=CH<sub>2</sub><sup></sup>",
    "vietnamese_name": "cloropren"
  },
  {
    "id": "3602",
    "formula": "(-CH2-C-Cl-CH-CH2-)n",
    "formatted_formula": "(-CH<sub>2</sub>-C-Cl-CH-CH<sub>2</sub>-)n<sup></sup>",
    "vietnamese_name": "poli (cloropren) "
  },
  {
    "id": "3603",
    "formula": " CH2 = CH(CN)  ",
    "formatted_formula": " CH<sub>2</sub> = CH(CN)  <sup></sup>",
    "vietnamese_name": "acrilonitrin"
  },
  {
    "id": "3604",
    "formula": "(-CH2-CH(CN)-)n",
    "formatted_formula": "(-CH<sub>2</sub>-CH(CN)-)n<sup></sup>",
    "vietnamese_name": " poli acrilonitrin "
  },
  {
    "id": "3605",
    "formula": "CH2=CH(CN)",
    "formatted_formula": "CH<sub>2</sub>=CH(CN)<sup></sup>",
    "vietnamese_name": "acrilonitrin "
  },
  {
    "id": "3606",
    "formula": "(CH2CH2)O",
    "formatted_formula": "(CH<sub>2</sub>CH<sub>2</sub>)O<sup></sup>",
    "vietnamese_name": "Ethylene oxide"
  },
  {
    "id": "3607",
    "formula": "OH-CH2-CHO",
    "formatted_formula": "OH-CH<sub>2</sub>-CHO<sup></sup>",
    "vietnamese_name": "Hydroxy ethanal"
  },
  {
    "id": "3608",
    "formula": "(HOCH2CH2)2NH",
    "formatted_formula": "(HOCH<sub>2</sub>CH<sub>2</sub>)<sub>2</sub>NH<sup></sup>",
    "vietnamese_name": "Điethanolamine"
  },
  {
    "id": "3609",
    "formula": "(HOCH2CH2)3N",
    "formatted_formula": "(HOCH<sub>2</sub>CH<sub>2</sub>)<sub>3</sub>N<sup></sup>",
    "vietnamese_name": "Triethanolamine"
  },
  {
    "id": "3610",
    "formula": "HO–CH2CH2 –O–CH2CH2–OH",
    "formatted_formula": "HO–CH<sub>2</sub>CH<sub>2</sub> –O–CH<sub>2</sub>CH<sub>2</sub>–OH<sup></sup>",
    "vietnamese_name": "Điethylene glycol"
  },
  {
    "id": "3611",
    "formula": "HO–CH2CH2–O–CH2CH2 – O–CH2CH2–OH",
    "formatted_formula": "HO–CH<sub>2</sub>CH<sub>2</sub>–O–CH<sub>2</sub>CH<sub>2</sub> – O–CH<sub>2</sub>CH<sub>2</sub>–OH<sup></sup>",
    "vietnamese_name": "Trimetyl glycol"
  },
  {
    "id": "3612",
    "formula": "HO–(CH2CH2 –O–)nH",
    "formatted_formula": "HO–(CH<sub>2</sub>CH<sub>2</sub> –O–)nH<sup></sup>",
    "vietnamese_name": "Polietylen glycol"
  },
  {
    "id": "3614",
    "formula": "CH2OH-CH2Cl",
    "formatted_formula": "CH<sub>2</sub>OH-CH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "Etylen Clohydrin"
  },
  {
    "id": "3615",
    "formula": "ClOH",
    "formatted_formula": "ClOH<sup></sup>",
    "vietnamese_name": "Hypochlorous acid"
  },
  {
    "id": "3616",
    "formula": "CH3-CCNa",
    "formatted_formula": "CH<sub>3</sub>-CCNa<sup></sup>",
    "vietnamese_name": "sodium propynide"
  },
  {
    "id": "3617",
    "formula": "CH3CH2CN",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CN<sup></sup>",
    "vietnamese_name": "propionitrile, Ethyl cyanide, Propiononitrile, Cyanoethane"
  },
  {
    "id": "3618",
    "formula": "CH3CH2CH(Br)CH2CH2CH3",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH(Br)CH<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1-etylbutylbromua"
  },
  {
    "id": "3619",
    "formula": "CH3CH2CH2CH2CH2F",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>F<sup></sup>",
    "vietnamese_name": "1-flopentan"
  },
  {
    "id": "3620",
    "formula": "CH3CH(Br)CH2CH2CH3",
    "formatted_formula": "CH<sub>3</sub>CH(Br)CH<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-brompentan"
  },
  {
    "id": "3621",
    "formula": "CH3CH2CH(I)CH2CH3",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH(I)CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "3-Iotpentan"
  },
  {
    "id": "3622",
    "formula": "CH3CH(CH3)CH2CH2CH(Cl)CH2CH3",
    "formatted_formula": "CH<sub>3</sub>CH(CH<sub>3</sub>)CH<sub>2</sub>CH<sub>2</sub>CH(Cl)CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "5-clo-2-metylheptan"
  },
  {
    "id": "3623",
    "formula": "CH3CH(Cl)CH2CH2CH(CH3)CH2CH3",
    "formatted_formula": "CH<sub>3</sub>CH(Cl)CH<sub>2</sub>CH<sub>2</sub>CH(CH<sub>3</sub>)CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-Clo-5-metylheptan"
  },
  {
    "id": "3624",
    "formula": "R-COO-CH3",
    "formatted_formula": "R-COO-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl este"
  },
  {
    "id": "3625",
    "formula": "R-CH2-OH",
    "formatted_formula": "R-CH<sub>2</sub>-OH<sup></sup>",
    "vietnamese_name": "Alcohol"
  },
  {
    "id": "3626",
    "formula": "C6H5-CH2COOH",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": "Phenylacetic axit"
  },
  {
    "id": "3627",
    "formula": "C6H5-CH2-CH2OH",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH<sub>2</sub>-CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "2-Phenyl etanol"
  },
  {
    "id": "3628",
    "formula": "C6H5-CO-CH2CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CO-CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl phenyl xeton (axetophenon)"
  },
  {
    "id": "3629",
    "formula": "CH3-CH(CH2Br)-CH3",
    "formatted_formula": "CH<sub>3</sub>-CH(CH<sub>2</sub>Br)-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Isobutyl bromua"
  },
  {
    "id": "3630",
    "formula": "CH3-CH(CH2MgBr)-CH3",
    "formatted_formula": "CH<sub>3</sub>-CH(CH<sub>2</sub>MgBr)-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Isobutyl magiebromua"
  },
  {
    "id": "3631",
    "formula": "C6H5-CH2Br",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "benzyl bromua"
  },
  {
    "id": "3632",
    "formula": "C6H5CH2COOH",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": " axit phenyl axetic"
  },
  {
    "id": "3633",
    "formula": "C6H5-COCl",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-COCl<sup></sup>",
    "vietnamese_name": "benzoyl choloride"
  },
  {
    "id": "3634",
    "formula": "Ph-COOH",
    "formatted_formula": "Ph-COOH<sup></sup>",
    "vietnamese_name": "Acid benzoic"
  },
  {
    "id": "3635",
    "formula": "C6H5-CH2-CN",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH<sub>2</sub>-CN<sup></sup>",
    "vietnamese_name": "Benzyl cyanide"
  },
  {
    "id": "3636",
    "formula": "Ph-CH2-CN",
    "formatted_formula": "Ph-CH<sub>2</sub>-CN<sup></sup>",
    "vietnamese_name": "Phenylacetonitril"
  },
  {
    "id": "3637",
    "formula": "C6H5CONHC2H5",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CONHC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "Etyl amine phenyl xeton"
  },
  {
    "id": "3638",
    "formula": "C6H5COCH2CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COCH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ethyl phenyl keton"
  },
  {
    "id": "3639",
    "formula": "C6H5-CH(OH)-CH2-CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH(OH)-CH<sub>2</sub>-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1-phenylpropan-1-ol"
  },
  {
    "id": "3640",
    "formula": "R-CN",
    "formatted_formula": "R-CN<sup></sup>",
    "vietnamese_name": "Nitrile"
  },
  {
    "id": "3641",
    "formula": "R-CO-R",
    "formatted_formula": "R-CO-R<sup></sup>",
    "vietnamese_name": "Xeton"
  },
  {
    "id": "3642",
    "formula": "R-CH2-NH2",
    "formatted_formula": "R-CH<sub>2</sub>-NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Amin"
  },
  {
    "id": "3643",
    "formula": "CH3-CH2-CH2-NH-CH3",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CH<sub>2</sub>-NH-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "metyl propyl amin"
  },
  {
    "id": "3644",
    "formula": "CH3-CH2-N(CH2-CH3)-CH2-CH3",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-N(CH<sub>2</sub>-CH<sub>3</sub>)-CH<sub>2</sub>-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Trietyl amin"
  },
  {
    "id": "3645",
    "formula": "CH3-CH2-CH2-NH2",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CH<sub>2</sub>-NH<sub>2</sub><sup></sup>",
    "vietnamese_name": "1-propanamin"
  },
  {
    "id": "3646",
    "formula": "CH3-CH2-CH(NH2)-CH3",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CH(NH<sub>2</sub>)-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-butanamin"
  },
  {
    "id": "3647",
    "formula": "CH3-CH2-CH2-NH-CH3",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CH<sub>2</sub>-NH-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1-N-methylpropanamine"
  },
  {
    "id": "3648",
    "formula": "H2N-CH2-CH2-CH2-CH2OH",
    "formatted_formula": "H<sub>2</sub>N-CH<sub>2</sub>-CH<sub>2</sub>-CH<sub>2</sub>-CH<sub>2</sub>OH<sup></sup>",
    "vietnamese_name": "4-amino-1-butanol"
  },
  {
    "id": "3649",
    "formula": "CH3CH2CH2NHC2H5",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>NHC<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "1-N etyl propanamin"
  },
  {
    "id": "3650",
    "formula": "C6H5N≡NCl ",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>N≡NCl <sup></sup>",
    "vietnamese_name": "Benzen diazosium clorua"
  },
  {
    "id": "3651",
    "formula": "ArNH2",
    "formatted_formula": "ArNH<sub>2</sub><sup></sup>",
    "vietnamese_name": "Arylamine"
  },
  {
    "id": "3652",
    "formula": "CH3-CH3-N(CH3)-CH2-CH2-CH3",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>3</sub>-N(CH<sub>3</sub>)-CH<sub>2</sub>-CH<sub>2</sub>-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Ethylmethylpropylamine"
  },
  {
    "id": "3653",
    "formula": "CH3-CH2-NH-CH2-CH3",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-NH-CH<sub>2</sub>-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Dimethylamine"
  },
  {
    "id": "3654",
    "formula": "CH3CH2CH2NHCH3",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>NHCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Methylpropylamin"
  },
  {
    "id": "3655",
    "formula": "C6H5CHO",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>CHO<sup></sup>",
    "vietnamese_name": "Benzalhehyde benzencarbaldehyde"
  },
  {
    "id": "3656",
    "formula": "C6H11-CHO",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>-CHO<sup></sup>",
    "vietnamese_name": "cyclohexancarbaldehyde"
  },
  {
    "id": "3657",
    "formula": "C6H5-CH2-CHO",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH<sub>2</sub>-CHO<sup></sup>",
    "vietnamese_name": "Phenylacetaldehyde"
  },
  {
    "id": "3658",
    "formula": "CH3CH2CH2CHO",
    "formatted_formula": "CH<sub>3</sub>CH<sub>2</sub>CH<sub>2</sub>CHO<sup></sup>",
    "vietnamese_name": "Butanal (Butyraldehyde)"
  },
  {
    "id": "3659",
    "formula": "CH3-CH(CH3)-CHO",
    "formatted_formula": "CH<sub>3</sub>-CH(CH<sub>3</sub>)-CHO<sup></sup>",
    "vietnamese_name": "2-metylpropanal"
  },
  {
    "id": "3660",
    "formula": "CH3-CH2-CH2-CH2-CHO",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CH<sub>2</sub>-CH<sub>2</sub>-CHO<sup></sup>",
    "vietnamese_name": "Pentanal"
  },
  {
    "id": "3661",
    "formula": "CH3(CH2)5CHO",
    "formatted_formula": "CH<sub>3</sub>(CH<sub>2</sub>)<sub>5</sub>CHO<sup></sup>",
    "vietnamese_name": "Heptanal"
  },
  {
    "id": "3662",
    "formula": "CH3(CH2)5-C(NOH)-H",
    "formatted_formula": "CH<sub>3</sub>(CH<sub>2</sub>)<sub>5</sub>-C(NOH)-H<sup></sup>",
    "vietnamese_name": "Heptanal oxime"
  },
  {
    "id": "3663",
    "formula": "C6H5-C(NNHC6H5)-CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-C(NNHC<sub>6</sub>H<sub>5</sub>)-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Acetone phenone phenylhydrazone"
  },
  {
    "id": "3664",
    "formula": "CH3-CH2-CH(OH)-CH2CH2CH2CH3",
    "formatted_formula": "CH<sub>3</sub>-CH<sub>2</sub>-CH(OH)-CH<sub>2</sub>CH<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "3-heptanol"
  },
  {
    "id": "3665",
    "formula": "C6H5-CH(OH)-Ph",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH(OH)-Ph<sup></sup>",
    "vietnamese_name": "diphenylmetanol"
  },
  {
    "id": "3666",
    "formula": "C6H11COOH",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>COOH<sup></sup>",
    "vietnamese_name": "cyclohexyl carboxylic acid"
  },
  {
    "id": "3667",
    "formula": "C6H11-CO-CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>-CO-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Metyl cyclohexyl ketone"
  },
  {
    "id": "3668",
    "formula": "C6H5COCH2CH2CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>COCH<sub>2</sub>CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "Butyrophenone"
  },
  {
    "id": "3669",
    "formula": "C6H5-C≡N",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-C≡N<sup></sup>",
    "vietnamese_name": "benzonitrile"
  },
  {
    "id": "3670",
    "formula": "C6H5-CH(OH)-CH2-CH2-CH2-CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CH(OH)-CH<sub>2</sub>-CH<sub>2</sub>-CH<sub>2</sub>-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1-phenyl-1-pentanol"
  },
  {
    "id": "3671",
    "formula": "C6H5-CO-CH2-CH2-CH2-CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>5</sub>-CO-CH<sub>2</sub>-CH<sub>2</sub>-CH<sub>2</sub>-CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "1-phenyl-1-pentanone"
  },
  {
    "id": "3672",
    "formula": "C6H11CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "metylcyclohexane"
  },
  {
    "id": "3673",
    "formula": "C6H11CH2Br",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>CH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "cyclohexyl metylbromide"
  },
  {
    "id": "3674",
    "formula": "C6H11CH2MgBr",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>CH<sub>2</sub>MgBr<sup></sup>",
    "vietnamese_name": "cyclohexyl etylmagiebromide"
  },
  {
    "id": "3675",
    "formula": "C6H11CH2CH(OH)CH3",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>CH<sub>2</sub>CH(OH)CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "3-cyclohexyl propan-2-ol"
  },
  {
    "id": "3676",
    "formula": "CH3C(CH3)=CHCH3",
    "formatted_formula": "CH<sub>3</sub>C(CH<sub>3</sub>)=CHCH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-metylbut-2-en"
  },
  {
    "id": "3677",
    "formula": "CH3CH(CH3)CH2CH3",
    "formatted_formula": "CH<sub>3</sub>CH(CH<sub>3</sub>)CH<sub>2</sub>CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-metylbutan"
  },
  {
    "id": "3678",
    "formula": "CH3CH(CH3)CH3",
    "formatted_formula": "CH<sub>3</sub>CH(CH<sub>3</sub>)CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-metylpropane"
  },
  {
    "id": "3679",
    "formula": "CH3CH(CH3)CH2Cl",
    "formatted_formula": "CH<sub>3</sub>CH(CH<sub>3</sub>)CH<sub>2</sub>Cl<sup></sup>",
    "vietnamese_name": "1-chloro-2-metylpropan"
  },
  {
    "id": "3680",
    "formula": "CH3C(Cl)(CH3)CH3",
    "formatted_formula": "CH<sub>3</sub>C(Cl)(CH<sub>3</sub>)CH<sub>3</sub><sup></sup>",
    "vietnamese_name": "2-chloro-2-metylpropan"
  },
  {
    "id": "3681",
    "formula": "C6H11Br",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>Br<sup></sup>",
    "vietnamese_name": "bromocyclohexane"
  },
  {
    "id": "3682",
    "formula": "C6H11MgBr",
    "formatted_formula": "C<sub>6</sub>H<sub>1</sub><sub>1</sub>MgBr<sup></sup>",
    "vietnamese_name": "cyclohexylmagiesiumbromide "
  },
  {
    "id": "3683",
    "formula": "CH2Br",
    "formatted_formula": "CH<sub>2</sub>Br<sup></sup>",
    "vietnamese_name": "metylbromide"
  },
  {
    "id": "3684",
    "formula": "CH2MgBr",
    "formatted_formula": "CH<sub>2</sub>MgBr<sup></sup>",
    "vietnamese_name": "methylmagiesiumbromide"
  },
  {
    "id": "3685",
    "formula": "CH3CH(Br)CH2(Br)",
    "formatted_formula": "CH<sub>3</sub>CH(Br)CH<sub>2</sub>(Br)<sup></sup>",
    "vietnamese_name": "1,2-dibromopropane"
  },
  {
    "id": "3686",
    "formula": "CH2Br – CHBr – COOH ",
    "formatted_formula": "CH<sub>2</sub>Br – CHBr – COOH <sup></sup>",
    "vietnamese_name": "Axit 2, 3 - dibrompropionic"
  },
  {
    "id": "3687",
    "formula": "C5H10Br2",
    "formatted_formula": "C<sub>5</sub>H<sub>1</sub><sub>0</sub>Br<sub>2</sub><sup></sup>",
    "vietnamese_name": "3,3-dibromopentane"
  },
  {
    "id": "3688",
    "formula": "H-COONa",
    "formatted_formula": "H-COONa<sup></sup>",
    "vietnamese_name": "Natri format"
  },
  {
    "id": "3689",
    "formula": "CH2NH2CH2COOH",
    "formatted_formula": "CH<sub>2</sub>NH<sub>2</sub>CH<sub>2</sub>COOH<sup></sup>",
    "vietnamese_name": " 6-alanine"
  },
  {
    "id": "3690",
    "formula": "CH2NH2CH2COONa",
    "formatted_formula": "CH<sub>2</sub>NH<sub>2</sub>CH<sub>2</sub>COONa<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3691",
    "formula": "CH3-O-C2H5",
    "formatted_formula": "CH<sub>3</sub>-O-C<sub>2</sub>H<sub>5</sub><sup></sup>",
    "vietnamese_name": "etyl metyl ete "
  },
  {
    "id": "3692",
    "formula": "C6H4 (OH)2",
    "formatted_formula": "C<sub>6</sub>H<sub>4</sub> (OH)<sub>2</sub><sup></sup>",
    "vietnamese_name": "benzene-1,4-diol"
  },
  {
    "id": "3693",
    "formula": "C17H33COOK ",
    "formatted_formula": "C<sub>1</sub><sub>7</sub>H<sub>3</sub><sub>3</sub>COOK <sup></sup>",
    "vietnamese_name": "kali oleat "
  },
  {
    "id": "3694",
    "formula": "CH3COOCl",
    "formatted_formula": "CH<sub>3</sub>COOCl<sup></sup>",
    "vietnamese_name": "axit clo axetic"
  },
  {
    "id": "3695",
    "formula": "C3H5(ONO2)3",
    "formatted_formula": "C<sub>3</sub>H<sub>5</sub>(ONO<sub>2</sub>)<sub>3</sub><sup></sup>",
    "vietnamese_name": "nitro glyxerin"
  },
  {
    "id": "3696",
    "formula": "CH3CH(ONa)COONa",
    "formatted_formula": "CH<sub>3</sub>CH(ONa)COONa<sup></sup>",
    "vietnamese_name": ""
  },
  {
    "id": "3697",
    "formula": "Na3P",
    "formatted_formula": "Na<sub>3</sub>P<sup></sup>",
    "vietnamese_name": "natri photphua"
  },
  {
    "id": "3698",
    "formula": "Na2[Zn(CN)4]",
    "formatted_formula": "Na<sub>2</sub>[Zn(CN)<sub>4</sub>]<sup></sup>",
    "vietnamese_name": "Natri tetracacbonyl ferrat "
  }
];