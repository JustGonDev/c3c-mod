var mathsolvefunc = function (type, datas) {
	var args = JSON.parse(JSON.stringify(datas.args));
	args.splice(0, 1);
	var msg = args.join(" ");
	if (msg == "") {
		return {
			handler: "internal",
			data: "Lỗi: Phương trình không được để trống!"
		}
	} else {
		var data = JSON.parse(global.nodemodule['sync-request']("GET", "https://coccoc.com/composer/math?q=" + encodeURIComponent(msg)).body.toString());
		if (!data.math.hasOwnProperty("variants")) {
			return {
				handler: "internal",
				data: "Lỗi: Không phải phương trình!"
			}
		} else if (!data.math.variants.length) {
			return {
				handler: "internal",
				data: "Lỗi: Phương trình không có lời giải!"
			}
		} else {
			var response = "";
			response += "Phương trình: " + data.math.variants[0].texImage.replaced_formula;
			response += "\r\nĐáp án: " + (data.math.variants[0].answers[0].replaced_formula != "" ? data.math.variants[0].answers[0].replaced_formula : data.math.variants[0].answers[0].description);
			if (data.math.variants[0].answers[0].replaced_formula != "") {
				return {
					handler: "internal",
					data: response
				}
			} else {
				if (type != "Facebook") {
					return {
						handler: "internal",
						data: "Xin lỗi, phương trình này có in ra kết quả mà chỉ phiên bản trên Facebook có thể hiện thị được!"
					}
				}
				var img = global.nodemodule['sync-request']("GET", data.math.variants[0].answers[0].answer_url).body;
				var imagesx = new global.nodemodule["stream-buffers"].ReadableStreamBuffer({
				  frequency: 10,
				  chunkSize: 2048
				});
				imagesx.path = "img.jpg";
				imagesx.put(img);
				imagesx.stop();
				return {
					handler: "internal-raw",
					data: {
						body: response,
						attachment: ([imagesx])
					}
				}
			}
		}
	}
}

module.exports = {
	mathsolvefunc: mathsolvefunc
}