//Library
var random = function(min, max) { 
	// if (min > max) {
		// var temp = min;
		// min = max;
		// max = temp;
	// }
	// var bnum = (max - min).toString(16).length / 2;
	// if (bnum < 1) bnum = 1;
	// return Math.round(parseInt(global.nodemodule.crypto.randomBytes(bnum).toString('hex'), 16) / Math.pow(16, bnum * 2) * (max - min)) + min; 
	return global.plugins.librandom.getRandomNumber(min, max, 0);
};

var defaultData = {
	config: {
		payout: {
			work: {
				min: 15000000,
				max: 20000000
			},
			slut: {
				min: 30000000,
				max: 45000000
			},
			crime: {
				min: 60000000,
				max: 85000000
			},
			lottery: {
				min: 850000000,
				max: 1000000000
			}
		},
		fineamount: {
			slut: {
				min: 25000000,
				max: 40000000
			},
			crime: {
				min: 55000000,
				max: 80000000
			},
			lottery: {
				min: 85000000,
				max: 100000000
			}
		},
		failrate: {
			slut: 10,
			crime: 20,
			lottery: 90,
		},
		cooldown: {
			work: 5,
			slut: 5,
			crime: 5,
			lottery: 3,
			rob: 3600
		}
	},
	data: {
		work: {},
		slut: {},
		crime: {},
		lottery: {},
		rob: {},
		minting: {
			amountPerMinute: 10,
			userData: {}
		}
	}
};
!global.data.economyIncome ? global.data.economyIncome = defaultData : "";

var workfunc = function(type, data) {
	switch (type) {
		case "Facebook":
			global.data.economy["FB-" + data.msgdata.senderID] == undefined ? global.data.economy["FB-" + data.msgdata.senderID] = global.data.economyStart : ""; 
			break;
		case "Discord": 
			global.data.economy["DC-" + data.msgdata.author.id] == undefined ? global.data.economy["DC-" + data.msgdata.author.id] = global.data.economyStart : ""; 
			break;
	}
	!global.data.economyIncome.data.work[global.plugins.economy.getID(data.msgdata, type)] ? global.data.economyIncome.data.work[global.plugins.economy.getID(data.msgdata, type)] = 0 : "";
	var time = new Date();
	if (time.getTime() < global.data.economyIncome.data.work[global.plugins.economy.getID(data.msgdata, type)] + (global.data.economyIncome.config.cooldown.work * 1000)) {
		var cooldown = (global.data.economyIncome.data.work[global.plugins.economy.getID(data.msgdata, type)] + global.data.economyIncome.config.cooldown.work * 1000) - time.getTime();
		return {
			handler: "internal",
			data: "Please wait " + (cooldown / 1000).ceil() + "s before use this command again!"
		}
	} else {
		global.data.economyIncome.data.work[global.plugins.economy.getID(data.msgdata, type)] = time.getTime();
		var payout = random(global.data.economyIncome.config.payout.work.min, global.data.economyIncome.config.payout.work.max);
		global.plugins.economy.operator.add(global.plugins.economy.getID(data.msgdata, type), payout, "/work command");
		return {
			handler: "internal",
			data: "+" + payout.floor(2) + global.plugins.economy.getSymbol() + " | Balance: " + global.plugins.economy.operator.get(global.plugins.economy.getID(data.msgdata, type)).floor(2) + global.plugins.economy.getSymbol()
		}
	}
}

var slutfunc = function(type, data) {
	switch (type) {
		case "Facebook":
			global.data.economy["FB-" + data.msgdata.senderID] == undefined ? global.data.economy["FB-" + data.msgdata.senderID] = global.data.economyStart : ""; 
			break;
		case "Discord": 
			global.data.economy["DC-" + data.msgdata.author.id] == undefined ? global.data.economy["DC-" + data.msgdata.author.id] = global.data.economyStart : ""; 
			break;
	}
	!global.data.economyIncome.data.slut[global.plugins.economy.getID(data.msgdata, type)] ? global.data.economyIncome.data.slut[global.plugins.economy.getID(data.msgdata, type)] = 0 : "";
	var time = new Date();
	if (time.getTime() < global.data.economyIncome.data.slut[global.plugins.economy.getID(data.msgdata, type)] + (global.data.economyIncome.config.cooldown.slut * 1000)) {
		var cooldown = (global.data.economyIncome.data.slut[global.plugins.economy.getID(data.msgdata, type)] + global.data.economyIncome.config.cooldown.slut * 1000) - time.getTime();
		return {
			handler: "internal",
			data: "Please wait " + (cooldown / 1000).ceil() + "s before use this command again!"
		}
	} else {
		global.data.economyIncome.data.slut[global.plugins.economy.getID(data.msgdata, type)] = time.getTime();
		var rnd = random(0, 9999) / 100;
		if (global.data.economyIncome.config.failrate.slut <= 0 || global.data.economyIncome.config.failrate.slut > 100 || rnd > global.data.economyIncome.config.failrate.slut) {
			var payout = random(global.data.economyIncome.config.payout.slut.min, global.data.economyIncome.config.payout.slut.max);
			global.plugins.economy.operator.add(global.plugins.economy.getID(data.msgdata, type), payout, "/slut command");
			return {
				handler: "internal",
				data: "+" + payout.floor(2) + global.plugins.economy.getSymbol() + " | Balance: " + global.plugins.economy.operator.get(global.plugins.economy.getID(data.msgdata, type)).floor(2) + global.plugins.economy.getSymbol()
			}
		} else {
			var payout = random(global.data.economyIncome.config.fineamount.slut.min, global.data.economyIncome.config.fineamount.slut.max);
			global.plugins.economy.operator.subtract(global.plugins.economy.getID(data.msgdata, type), payout, "/slut command");
			return {
				handler: "internal",
				data: "-" + payout.floor(2) + global.plugins.economy.getSymbol() + " | Balance: " + global.plugins.economy.operator.get(global.plugins.economy.getID(data.msgdata, type)).floor(2) + global.plugins.economy.getSymbol()
			}
		}
	}
}

var crimefunc = function(type, data) {
	switch (type) {
		case "Facebook":
			global.data.economy["FB-" + data.msgdata.senderID] == undefined ? global.data.economy["FB-" + data.msgdata.senderID] = global.data.economyStart : ""; 
			break;
		case "Discord": 
			global.data.economy["DC-" + data.msgdata.author.id] == undefined ? global.data.economy["DC-" + data.msgdata.author.id] = global.data.economyStart : ""; 
			break;
	}
	!global.data.economyIncome.data.crime[global.plugins.economy.getID(data.msgdata, type)] ? global.data.economyIncome.data.crime[global.plugins.economy.getID(data.msgdata, type)] = 0 : "";
	var time = new Date();
	if (time.getTime() < global.data.economyIncome.data.crime[global.plugins.economy.getID(data.msgdata, type)] + (global.data.economyIncome.config.cooldown.crime * 1000)) {
		var cooldown = (global.data.economyIncome.data.crime[global.plugins.economy.getID(data.msgdata, type)] + global.data.economyIncome.config.cooldown.crime * 1000) - time.getTime();
		return {
			handler: "internal",
			data: "Please wait " + (cooldown / 1000).ceil() + "s before use this command again!"
		}
	} else {
		global.data.economyIncome.data.crime[global.plugins.economy.getID(data.msgdata, type)] = time.getTime();
		var rnd = random(0, 9999) / 100;
		if (global.data.economyIncome.config.failrate.crime <= 0 || global.data.economyIncome.config.failrate.crime > 100 || rnd > global.data.economyIncome.config.failrate.crime) {
			var payout = random(global.data.economyIncome.config.payout.crime.min, global.data.economyIncome.config.payout.crime.max);
			global.plugins.economy.operator.add(global.plugins.economy.getID(data.msgdata, type), payout, "/crime command");
			return {
				handler: "internal",
				data: "+" + payout.floor(2) + global.plugins.economy.getSymbol() + " | Balance: " + global.plugins.economy.operator.get(global.plugins.economy.getID(data.msgdata, type)).floor(2) + global.plugins.economy.getSymbol()
			}
		} else {
			var payout = random(global.data.economyIncome.config.fineamount.crime.min, global.data.economyIncome.config.fineamount.crime.max);
			global.plugins.economy.operator.subtract(global.plugins.economy.getID(data.msgdata, type), payout, "/crime command");
			return {
				handler: "internal",
				data: "-" + payout.floor(2) + global.plugins.economy.getSymbol() + " | Balance: " + global.plugins.economy.operator.get(global.plugins.economy.getID(data.msgdata, type)).floor(2) + global.plugins.economy.getSymbol()
			}
		}
	}
}

var lotteryfunc = function(type, data) {
	switch (type) {
		case "Facebook":
			global.data.economy["FB-" + data.msgdata.senderID] == undefined ? global.data.economy["FB-" + data.msgdata.senderID] = global.data.economyStart : ""; 
			break;
		case "Discord": 
			global.data.economy["DC-" + data.msgdata.author.id] == undefined ? global.data.economy["DC-" + data.msgdata.author.id] = global.data.economyStart : ""; 
			break;
	}
	!global.data.economyIncome.data.lottery[global.plugins.economy.getID(data.msgdata, type)] ? global.data.economyIncome.data.lottery[global.plugins.economy.getID(data.msgdata, type)] = 0 : "";
	var time = new Date();
	if (time.getTime() < global.data.economyIncome.data.lottery[global.plugins.economy.getID(data.msgdata, type)] + (global.data.economyIncome.config.cooldown.lottery * 1000)) {
		var cooldown = (global.data.economyIncome.data.lottery[global.plugins.economy.getID(data.msgdata, type)] + global.data.economyIncome.config.cooldown.lottery * 1000) - time.getTime();
		return {
			handler: "internal",
			data: "Please wait " + (cooldown / 1000).ceil() + "s before use this command again!"
		}
	} else {
		global.data.economyIncome.data.lottery[global.plugins.economy.getID(data.msgdata, type)] = time.getTime();
		var rnd = random(0, 9999) / 100;
		if (global.data.economyIncome.config.failrate.lottery <= 0 || global.data.economyIncome.config.failrate.lottery > 100 || rnd > global.data.economyIncome.config.failrate.lottery) {
			var payout = random(global.data.economyIncome.config.payout.lottery.min, global.data.economyIncome.config.payout.lottery.max);
			global.plugins.economy.operator.add(global.plugins.economy.getID(data.msgdata, type), payout, "/lottery command");
			return {
				handler: "internal",
				data: "+" + payout.floor(2) + global.plugins.economy.getSymbol() + " | Balance: " + global.plugins.economy.operator.get(global.plugins.economy.getID(data.msgdata, type)).floor(2) + global.plugins.economy.getSymbol()
			}
		} else {
			var payout = random(global.data.economyIncome.config.fineamount.lottery.min, global.data.economyIncome.config.fineamount.lottery.max);
			global.plugins.economy.operator.subtract(global.plugins.economy.getID(data.msgdata, type), payout, "/lottery command");
			return {
				handler: "internal",
				data: "-" + payout.floor(2) + global.plugins.economy.getSymbol() + " | Balance: " + global.plugins.economy.operator.get(global.plugins.economy.getID(data.msgdata, type)).floor(2) + global.plugins.economy.getSymbol()
			}
		}
	}
}

var setpayoutfunc = function(type, data) {
	if (data.admin) {
		if (data.args.length > 3) {
			var cmd = "";
			switch (data.args[1]) {
				case "work":
				case "slut":
				case "crime":
					cmd = data.args[1];
					break;
				default:
					return {
						handler: "internal",
						data: "WTF are you typing in argument 1?"
					}
			}
			switch (data.args[2]) {
				case "min":
				case "max":
					if (isNaN(parseFloat(data.args[3]))) {
						return {
							handler: "internal",
							data: "WTF are you typing in argument 3?"
						}
					} else {
						global.data.economyIncome.config.payout[cmd][data.args[2]] = parseFloat(data.args[3]).round(2);
						return {
							handler: "internal",
							data: "OK (" + parseFloat(data.args[3]).round(2) + ")" 
						}
					}
					break;
				default: 
					return {
						handler: "internal",
						data: "WTF are you typing in argument 2?"
					}
			}
		} else {
			return {
				handler: "internal",
				data: "Not enough arguments"
			}
		}
	} else {
		return {
			handler: "internal",
			data: "Insufficient permission"
		}
	}
}

var setfineamountfunc = function(type, data) {
	if (data.admin) {
		if (data.args.length > 3) {
			var cmd = "";
			switch (data.args[1]) {
				case "slut":
				case "crime":
					cmd = data.args[1];
					break;
				default:
					return {
						handler: "internal",
						data: "WTF are you typing in argument 1?"
					}
			}
			switch (data.args[2]) {
				case "min":
				case "max":
					if (isNaN(parseFloat(data.args[3]))) {
						return {
							handler: "internal",
							data: "WTF are you typing in argument 3?"
						}
					} else {
						global.data.economyIncome.config.fineamount[cmd][data.args[2]] = parseFloat(data.args[3]).round(2);
						return {
							handler: "internal",
							data: "OK (" + parseFloat(data.args[3]).round(2) + ")" 
						}
					}
					break;
				default: 
					return {
						handler: "internal",
						data: "WTF are you typing in argument 2?"
					}
			}
		} else {
			return {
				handler: "internal",
				data: "Not enough arguments"
			}
		}
	} else {
		return {
			handler: "internal",
			data: "Insufficient permission"
		}
	}
}

var setfailratefunc = function(type, data) {
	if (data.admin) {
		if (data.args.length > 2) {
			var cmd = "";
			switch (data.args[1]) {
				case "slut":
				case "crime":
					cmd = data.args[1];
					break;
				default:
					return {
						handler: "internal",
						data: "WTF are you typing in argument 1?"
					}
			}
			if (isNaN(parseFloat(data.args[2]))) {
				return {
					handler: "internal",
					data: "WTF are you typing in argument 2?"
				}
			} else {
				global.data.economyIncome.config.failrate[cmd] = parseFloat(data.args[2]).round(2);
				return {
					handler: "internal",
					data: "OK (" + parseFloat(data.args[2]).round(2) + ")" 
				}
			}
		} else {
			return {
				handler: "internal",
				data: "Not enough arguments"
			}
		}
	} else {
		return {
			handler: "internal",
			data: "Insufficient permission"
		}
	}
}

var setcooldownfunc = function(type, data) {
	if (data.admin) {
		if (data.args.length > 2) {
			var cmd = "";
			switch (data.args[1]) {
				case "work":
				case "slut":
				case "crime":
				case "rob":
					cmd = data.args[1];
					break;
				default:
					return {
						handler: "internal",
						data: "WTF are you typing in argument 1?"
					}
			}
			if (isNaN(parseFloat(data.args[2]))) {
				return {
					handler: "internal",
					data: "WTF are you typing in argument 2?"
				}
			} else {
				global.data.economyIncome.config.cooldown[cmd] = parseFloat(data.args[2]).round();
				return {
					handler: "internal",
					data: "OK (" + parseFloat(data.args[2]).round() + ")" 
				}
			}
		} else {
			return {
				handler: "internal",
				data: "Not enough arguments"
			}
		}
	} else {
		return {
			handler: "internal",
			data: "Insufficient permission"
		}
	}
}

var stakefunc = function (type, data) {
	var rt = function(data) {
		return {
			handler: "internal",
			data: data
		}
	}
	//Properly init wallet to avoid NaN error caused by += and -= with undefined object.
	global.data.economy[global.plugins.economy.getID(data.msgdata, type)] == undefined ? global.data.economy[global.plugins.economy.getID(data.msgdata, type)] = global.data.economyStart : ""; 
	!global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)] ? global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)] = {
		locked: false,
		balance: 0,
		lastLocked: 1
	} : "";
	if (data.args.length > 1) {
		switch (data.args[1]) {
			case "lock":
				if (global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].locked) {
					return rt("Already locked!");
				} else {
					if (global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].lastLocked + 3600000 < Date.now()) {
						global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].locked = true;
						return rt("Successfully locked your balance for minting!");
					} else {
						return rt("Please wait " + ((global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].lastLocked + 3600000 - Date.now()) / 1000 / 60).toFixed(2) + " minute(s) before locking again!");
					}
				}
				break;
			case "unlock":
				if (!global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].locked) {
					return rt("Already unlocked!");
				} else {
					global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].locked = false;
					global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].lastLocked = Date.now();
					return rt("Successfully unlocked your balance!");
				}
				break;
			case "deposit":
				if (!global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].locked) {
					if (data.args.length > 2) {
						var depa = (data.args[2] == "all" ? global.data.economy[global.plugins.economy.getID(data.msgdata, type)] : (data.args[2] == "half" ? (global.data.economy[global.plugins.economy.getID(data.msgdata, type)] / 2) : (isNaN(parseFloat(data.args[2])) ? 0 : parseFloat(data.args[2]))));
						if (isNaN(depa)) {
							return rt("Error: NaN!");
						} else if (global.plugins.economy.validBalance(Math.abs(depa)) < 0) {
							return rt(("Not enough money!\r\nHave: {0}\r\nWant: {1}").replace("{0}", global.data.economy[global.plugins.economy.getID(data.msgdata, type)].floor(2) + global.plugins.economy.getSymbol()).replace("{1}", Math.abs(depa).ceil(2) + global.plugins.economy.getSymbol()));
						} else if (Math.abs(depa) == 0) {
							return rt("Cannot deposit 0 value!");
						} else {
							global.plugins.economy.operator.subtract(global.plugins.economy.getID(data.msgdata, type), Math.abs(depa), data.args.join(" "));
							global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].balance += Math.abs(depa);
							return rt("Deposited {0}!".replace("{0}", Math.abs(depa).floor(2) + global.plugins.economy.getSymbol()));
						}
					} else {
						return rt("Please write your deposit amount!");
					}
				} else {
					return rt("You balance is locked! Please unlock your balance first!");
				}
				break;
			case "withdraw":
				if (!global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].locked) {
					if (data.args.length > 2) {
						var witha = (data.args[2] == "all" ? global.data.economy[global.plugins.economy.getID(data.msgdata, type)] : (data.args[2] == "half" ? (global.data.economy[global.plugins.economy.getID(data.msgdata, type)] / 2) : (isNaN(parseFloat(data.args[2])) ? 0 : parseFloat(data.args[2]))));
						if (isNaN(witha)) {
							return rt("Error: NaN!");
						} else if (global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].balance - Math.abs(witha) < 0) {
							return rt(("Not enough money!\r\nHave: {0}\r\nWant: {1}").replace("{0}", global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].balance.floor(2) + global.plugins.economy.getSymbol()).replace("{1}", Math.abs(witha).ceil(2) + global.plugins.economy.getSymbol()));
						} else if (Math.abs(witha) == 0) {
							return rt("Cannot deposit 0 value!");
						} else {
							global.plugins.economy.operator.add(global.plugins.economy.getID(data.msgdata, type), Math.abs(witha), data.args.join(" "));
							global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].balance -= Math.abs(witha);
							return rt("Withdrawn {0}!".replace("{0}", Math.abs(witha).floor(2) + global.plugins.economy.getSymbol()));
						}
					} else {
						return rt("Please write your withdraw amount!");
					}
				} else {
					return rt("You balance is locked! Please unlock your balance first!");
				}
				break;
			case "balance":
				return rt("Your balance for minting: " + global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].balance.floor(2) + global.plugins.economy.getSymbol());
				break;
			case "status":
				var totalminting = 0;
				var usersminting = 0;
				for (var id in global.data.economyIncome.data.minting.userData) {
					if (global.data.economyIncome.data.minting.userData[id].locked) {
						totalminting += global.data.economyIncome.data.minting.userData[id].balance;
						if (global.data.economyIncome.data.minting.userData[id].balance != 0) {
							usersminting++;
						}
					}
				}
				var sentmsg = "\r\n";
				sentmsg += "Number of user currently minting: " + usersminting;
				sentmsg += "\r\n";
				sentmsg += "Total locked amount for minting: " + totalminting.floor(2) + global.plugins.economy.getSymbol();
				sentmsg += "\r\n";
				sentmsg += "Minting rate: " + global.data.economyIncome.data.minting.amountPerMinute.floor(2) + global.plugins.economy.getSymbol() + "/min";
				if (global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].locked) {
					var percentMintReward = global.data.economyIncome.data.minting.userData[global.plugins.economy.getID(data.msgdata, type)].balance / totalminting * 100;
					sentmsg += "\r\n";
					sentmsg += "Your % in minting reward: " + percentMintReward.floor(2) + "% (" + (global.data.economyIncome.data.minting.amountPerMinute * percentMintReward / 100).floor(2) + global.plugins.economy.getSymbol() + "/min)";
				}
				return rt(sentmsg);
			case "help":
				var sentmsg = "Minting help:";
				sentmsg += "\r\n/mint help: Show this help.";
				sentmsg += "\r\n/mint status: Show current status.";
				sentmsg += "\r\n/mint balance: View your current balance.";
				sentmsg += "\r\n/mint lock: Lock your balance to mint.";
				sentmsg += "\r\n/mint unlock: Unlock your balance.";
				sentmsg += "\r\n/mint deposit <amount>: Deposit into your balance.";
				sentmsg += "\r\n/mint withdraw <amount>: Withdraw from your balance.";
				sentmsg += "\r\n/mint changerate <value>: Change minting rate per minute (ADMIN ONLY)";
				return rt(sentmsg);
				break;
			case "changerate":
				if (!data.admin) {
					return rt("No permission!");
				}
				if (data.args.length > 1) {
					var oldrate = global.data.economyIncome.data.minting.amountPerMinute;
					var newrate = parseInt(data.args[2]);
					if (isNaN(newrate)) {
						return rt("Error: NaN!");
					} else {
						global.data.economyIncome.data.minting.amountPerMinute = Math.abs(newrate);
						return rt("OK ({0} => {1})".replace("{0}", oldrate.floor(2)).replace("{1}", Math.abs(newrate).floor(2)));
					}
				}
				break;
			default:
				return rt("Unknown arguments. Please type `/mint help` for help.");
		}
	} else {
		return rt("Unknown arguments. Please type `/mint help` for help.");
	}
}

if (!!global.ecoIncomeMintClock) {
	clearInterval(global.ecoIncomeMintClock);
	delete global.ecoIncomeMintClock;
}
global.ecoIncomeMintClock = setInterval(function() {
	var mintrate = global.data.economyIncome.data.minting.amountPerMinute * 30;
	var totalminting = 0;
	for (var id in global.data.economyIncome.data.minting.userData) {
		if (global.data.economyIncome.data.minting.userData[id].locked) {
			totalminting += global.data.economyIncome.data.minting.userData[id].balance;
		}
	}
	for (var id in global.data.economyIncome.data.minting.userData) {
		if (global.data.economyIncome.data.minting.userData[id].locked) {
			var reward = (global.data.economyIncome.data.minting.userData[id].balance / totalminting) * mintrate;
			global.plugins.economy.operator.add(id, reward, "Minting (30m) (" + reward.floor(2) + " | " + (global.data.economyIncome.data.minting.userData[id].balance / totalminting * 100) + "%)");
		}
	}
}, 1800000);

module.exports = {
	workfunc: workfunc,
	slutfunc: slutfunc,
	crimefunc: crimefunc,
	lotteryfunc: lotteryfunc,
	setpayoutfunc: setpayoutfunc,
	setfineamountfunc: setfineamountfunc,
	setfailratefunc: setfailratefunc,
	setcooldownfunc: setcooldownfunc,
	mintfunc: stakefunc
}