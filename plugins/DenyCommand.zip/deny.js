!global.data.denyCommand ? global.data.denyCommand = [] : "";

var core = function (type, data) {
	if (data.admin) {
		if (global.data.denyCommand.indexOf(data.args[1]) == -1) {
			if (data.args[0] == global.config.commandPrefix + "denycommand") {
				global.data.denyCommand.push(data.args[1]);
				return {
					handler: "internal",
					data: "Successfully mark as denied to execute for command " + global.config.commandPrefix + data.args[1] + "."
				}
			} else if (data.args[0] == global.config.commandPrefix + "allowcommand") {
				return {
					handler: "internal",
					data: "That command is already enabled."
				}
			}
		} else {
			if (data.args[0] == global.config.commandPrefix + "denycommand") {
				return {
					handler: "internal",
					data: "That command is already disabled."
				}
			} else if (data.args[0] == global.config.commandPrefix + "allowcommand") {
				global.data.denyCommand.splice(global.data.denyCommand.indexOf(data.args[1]), 1);
				return {
					handler: "internal",
					data: "Successfully mark as allowed to execute for command " + global.config.commandPrefix + data.args[1] + "."
				}
			}
		}
	} else {
		return {
			handler: "internal",
			data: "No permission!"
		}
	}
}
var allow, deny;
allow = deny = core;

var chathook = function (type, data) {
	var message = data.msgdata;
	if (message.type == "message") {
		var args = message.body
			.replace((/”/g), "\"").replace((/“/g), "\"").split(/((?:"[^"\\]*(?:\\[\S\s][^"\\]*)*"|'[^'\\]*(?:\\[\S\s][^'\\]*)*'|\/[^/\\]*(?:\\[\S\s][^/\\]*)*\/[gimy]*(?=\s|$)|(?:\\\s|\S))+)(?=\s|$)/).filter(function (el) {
				return !(el == null || el == "" || el == " ");
			});
		args = args.map(xy => xy.replace(/["]/g, ""));
		if (message.body.startsWith(global.config.commandPrefix) && global.data.denyCommand.indexOf(args[0].substr(1)) != -1) {
			data.return({
				handler: "internal",
				data: "This command is disabled by admins."
			});
			return true;
		} else {
			return false;
		}
	}
}

module.exports = {
	deny,
	allow,
	chathook
}