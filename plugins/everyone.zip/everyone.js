!global.data.countchat.realtimedata ? global.data.countchat.realtimedata = {} : "";

var everyone = function (type, data) {
	var list = global.data.countchat.realtimedata[data.msgdata.threadID];
	var character = "@";
    var sendString = "";
    var mentionObj = [];
    var i = 0;

    for (var n in list) {
    	sendString += character;
    	mentionObj.push({
    		tag: character,
    		id: list[n],
    		fromIndex: i
    		});
    	i++
    }
    data.facebookapi.sendMessage("Tagged",data.msgdata.threadID);
     data.facebookapi.sendMessage({
     	body: sendString,
     	mentions: mentionObj
     }, data.msgdata.threadID)
 }

 module.exports = {
 	everyone: everyone
 }