var fs = global.nodemodule["fs"];
var path = global.nodemodule["path"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var fetch = global.nodemodule["node-fetch"];
function onLoad(data) {

var onLoadText = "Loaded \"Shibe\" by Trung";

data.log(onLoadText);

}

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}
var rootpath = path.resolve(__dirname, "..", "Shibe-data");
ensureExists(rootpath);
ensureExists(path.join(rootpath, "temp"));

var shibe = async function shibe(type, data) {
	try {
		var fetchdata = await fetch('https://shibe.online/api/shibes');
		var json = await fetchdata.text();
		var str = `${json}`
		str = str.replace('["', '');
		str = str.replace('"]', '');
		data.log("Got 1 shibe xd: "+ str)
		var fetchimage = await fetch(str);
		var buffer = await fetchimage.buffer();
			var imagesx = new streamBuffers.ReadableStreamBuffer({
				frequency: 10,
				chunkSize: 1024
			});
			imagesx.path = "image.png";
			imagesx.put(buffer);
			imagesx.stop();

			return {
				handler: "internal",
				data: {
					body: ``,
					attachment: ([imagesx])
				},
				noDelay: true
			}
	} catch (ex) {data.log(ex)}
}
var bird = async function bird(type, data) {
	try {
		var fetchdata = await fetch('https://shibe.online/api/birds');
		var json = await fetchdata.text();
		var str = `${json}`
		str = str.replace('["', '');
		str = str.replace('"]', '');
		data.log("Got 1 birds xd: "+ str)
		var fetchimage = await fetch(str);
		var buffer = await fetchimage.buffer();
			var imagesx = new streamBuffers.ReadableStreamBuffer({
				frequency: 10,
				chunkSize: 1024
			});
			imagesx.path = "image.png";
			imagesx.put(buffer);
			imagesx.stop();

			return {
				handler: "internal",
				data: {
					body: ``,
					attachment: ([imagesx])
				},
				noDelay: true
			}
	} catch (ex) {data.log(ex)}
}
var meow = async function meow(type, data) {
	try {
		var fetchdata = await fetch('https://shibe.online/api/cats');
		var json = await fetchdata.text();
		var str = `${json}`
		str = str.replace('["', '');
		str = str.replace('"]', '');
		data.log("Got 1 cat xd: "+ str)
		var fetchimage = await fetch(str);
		var buffer = await fetchimage.buffer();
			var imagesx = new streamBuffers.ReadableStreamBuffer({
				frequency: 10,
				chunkSize: 1024
			});
			imagesx.path = "image.png";
			imagesx.put(buffer);
			imagesx.stop();

			return {
				handler: "internal",
				data: {
					body: ``,
					attachment: ([imagesx])
				},
				noDelay: true
			}
	} catch (ex) {data.log(ex)}
}
var pussy = async function pussy(type, data) {
	try {
		var fetchdata = await fetch('https://shibe.online/api/cats');
		var json = await fetchdata.text();
		var str = `${json}`
		str = str.replace('["', '');
		str = str.replace('"]', '');
		data.log("Got 1 pussy xd: "+ str)
		var fetchimage = await fetch(str);
		var buffer = await fetchimage.buffer();
			var imagesx = new streamBuffers.ReadableStreamBuffer({
				frequency: 10,
				chunkSize: 1024
			});
			imagesx.path = "image.png";
			imagesx.put(buffer);
			imagesx.stop();

			return {
				handler: "internal",
				data: {
					body: `Got 1 pussy 😹`,
					attachment: ([imagesx])
				},
				noDelay: true
			}
	} catch (ex) {data.log(ex)}
}
module.exports = {
	shibe: shibe,
	bird: bird,
	meow: meow,
	pussy: pussy,
	onLoad
}
