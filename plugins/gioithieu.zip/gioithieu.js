var fetch = global.nodemodule["node-fetch"];

var gioithieu = function gioithieu(type, data) {
	(async function () {
		var returntext = `C3CBOT là một chatbot được lập trình sẵn, dùng cho cá nhân, cho các boxchat khác, với rất nhiều tiện ích.
Là chương trình mã nguồn mở, vì thế sẽ có nhiều tính năng (plugins).
Được phát triển bởi chủ bot, có thể tự viết plugins hoặc ngửa tay đi xin plugins của người khác.
Nếu muốn biết thêm chi tiết/cách cài bot, vui lòng truy cập vào link nhóm C3CBOT: https://www.facebook.com/groups/c3cbot/
Các Admin nhóm: Trương Gia Hy, Lê Quang Lâm, Trí Trần, Nguyễn Hải Anh, Nguyễn Minh Hiếu
Support: Hà, Thắng và các admin, các member....
Mong bạn có trải nghiệm tốt về C3CBOT.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"GIOI THIEU\" by Wua'n";

data.log(onLoadText);

}
module.exports = {
	gioithieu: gioithieu
}