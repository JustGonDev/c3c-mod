var fs = global.nodemodule["fs"];
var path = global.nodemodule["path"];
var wait = global.nodemodule["wait-for-stuff"];
var streamBuffers = global.nodemodule["stream-buffers"];
var fetch = global.nodemodule["node-fetch"];

var rootpath = path.resolve(__dirname, "..", "dog-data");

function ensureExists(path, mask) {
  if (typeof mask != 'number') {
    mask = 0o777;
  }
  try {
    fs.mkdirSync(path, {
      mode: mask,
      recursive: true
    });
    return undefined;
  } catch (ex) {
    return { err: ex };
  }
}

ensureExists(rootpath);
ensureExists(path.join(rootpath, "temp"));

var dog = async function dog_image(type, data) {
	var fetchdata = await fetch('https://dog.ceo/api/breeds/image/random');
	var json = await fetchdata.json();
	var geturl = json.message;
	var imgurl = geturl.replace("\/", "/");
    var img = global.nodemodule['sync-request']("GET", imgurl).body;
    fs.writeFileSync(path.join(rootpath, data.msgdata.messageID + ".jpg"), img);
    var imagesx = fs.createReadStream(path.join(rootpath, data.msgdata.messageID + ".jpg"));
	return {
		handler: "internal",
		data: {
			body: "1 Chú cún đáng yêu",
			attachment: ([imagesx])
		}
	}
}
module.exports = {
	dog: dog
}