var request = global.nodemodule["request"];
var fetch = global.nodemodule["node-fetch"];
var fs = global.nodemodule["fs"];
var path = global.nodemodule["path"];
var streamBuffers = global.nodemodule["stream-buffers"];

var waiting = {};

var chathook = function(type, datas) {
	if (datas.msgdata.type == "message" || datas.msgdata.type == "message_reply") {
		if (typeof waiting[datas.msgdata.senderID] != "undefined") {
			var atts = datas.msgdata.attachments;
			if (atts.length > 0) {
				var att = null;
				for (var n in atts) {
					att = atts[n];
					if (att.type === "photo") {
						global.plugins.shortener.shortURL(att.url, "").then(function (a) {
						if (a.error) {
							datas.log(`Find error while ShortURL for FB-${datas.msgdata.senderID}`);
						} else {
							datas.log("https://api.qrserver.com/v1/read-qr-code/?fileurl="+encodeURIComponent(a.url))
				fetch("https://api.qrserver.com/v1/read-qr-code/?fileurl="+encodeURIComponent(a.url))
				.then(res => {
					if (res.ok) {
						res.json().then(json => {
							datas.return({
								handler: "internal",
								data: json[0].symbol[0].data
							})
							try {
					clearTimeout(waiting[datas.msgdata.senderID]);
				} catch (ex) {};
				delete waiting[datas.msgdata.senderID];
						}).catch(ex => {
							datas.log(ex)
							try {
					clearTimeout(waiting[datas.msgdata.senderID]);
				} catch (ex) {};
				delete waiting[datas.msgdata.senderID];
						})
					}
				}).catch(ex => {
					datas.log(ex)
					try {
					clearTimeout(waiting[datas.msgdata.senderID]);
				} catch (ex) {};
				delete waiting[datas.msgdata.senderID];
				})
						}
					})
				}
			}
		}
	}
  }
}

var qrFunc = function (type, data) {
    var args = data.args;
        args.shift();
    if (!args[0]) {
        return {
            handler: "internal",
            data: "Vui lòng nhập tham số"
        }
    } else {
        switch (args[0].toLowerCase()) {
            case "gen":
                args.shift();
                var dtxt = args.join(" ");
                request({
                    url: "https://api.qrserver.com/v1/create-qr-code/?size=1000x1000&data="+encodeURIComponent(dtxt),
                    encoding: null
                }, function (err, res, body) {
                    if (err) {
                        data.log(`Error while generator QR-Code for ${data.msgdata.senderID}\n\n${err}`);
                    } else {
                        var imagesx = new streamBuffers.ReadableStreamBuffer({
							frequency: 10,
							chunkSize: 2048
						});
						imagesx.path = "img.png";
						imagesx.put(body);
                        imagesx.stop();
                        data.return({
                            handler: "internal-raw",
                            data: {
								body: `Đây nà anh iu <3`,
                                attachment: ([imagesx])
                            }
                        })
					}
                })
                break;
				case 'scan':
				args.shift();
			if (type === "Facebook") {
				if (typeof waiting[data.msgdata.senderID] != "undefined") {
					try {
						clearTimeout(waiting[data.msgdata.senderID]);
					} catch (ex) {}
				}
			waiting[data.msgdata.senderID] = setTimeout(function (datas) {
				datas.return({
					handler: "internal",
					data: ``
				});
				try {
					clearTimeout(waiting[datas.msgdata.senderID]);
				} catch (ex) {};
				delete waiting[datas.msgdata.senderID];
			}, 120000, data);
			return {
				handler: "internal",
				data: ``
			}
		} else {
			return {
				handler: "internal",
				data: ``
			}
		}
				break;
        }
    }
}

module.exports = {
    qrFunc,
	chathook
}