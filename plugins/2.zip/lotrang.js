var fetch = global.nodemodule["node-fetch"];

var lotrang_get = function lotrang_get(type, data) {
	(async function () {
		var returntext = `Lỗ Trắng\nAstronomical Object Type\nTrong vật lý thiên văn, một lỗ trắng là một thiên thể giả định phóng ra vật chất, ngược với lỗ đen vốn hút mọi vật chất. Nó có thể được coi là nghịch đảo thời gian của lỗ đen, tức là giống một lỗ đen quan sát với thời gian đi ngược lại quá khứ. Thuyết tương đối rộng là đối xứng theo thời gian. Các phương trình về trạng thái cân bằng trong lý thuyết này đều có hai nghiệm tương ứng với hai chiều thời gian. Nếu áp dụng quy luật này cho phương trình cho ra nghiệm miêu tả lỗ đen với chiều thời gian dương, kết quả thu được khi nghịch đảo thời gian là lỗ trắng.\nMôn học:
thiên văn học, Thuyết tương đối\nTrái nghĩa với:
Lỗ đen`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	lotrang_get: lotrang_get
}