var fetch = global.nodemodule["node-fetch"];

var chomsao_get = function chomsao_get(type, data) {
	(async function () {
		var returntext = `Chòm Sao\nChòm sao là một nhóm các ngôi sao được người ta nhìn thấy trên bầu trời về ban đêm là gần nhau theo một hình dạng nhất định nào đó. Trong không gian ba chiều thì phần lớn các ngôi sao mà con người nhìn thấy là gần nhau thì lại không phải như vậy, chúng có rất ít quan hệ với nhau và có thể cách nhau rất xa. Loài người trong lịch sử phát triển của mình đã nghĩ ra các hình mẫu theo trí tưởng tượng để nhóm chúng lại thành các chòm sao.\nSố lần:
88\nLà một phần của:
Thiên cầu\nĐược phê chuẩn bởi:
Hiệp hội Thiên văn Quốc tế\nLớp tương đương:
http://dbpedia.org/ontology/Constellation`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	chomsao_get: chomsao_get
}